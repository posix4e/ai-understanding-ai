"""Exact mathematical counterexample only; no model, prompts, fit or dataset.

N: organ-supplied number. H: other noun number. C: carrier's original number.
R: carrier role. Desired agreement Y=N for head, H for attractor.
"""
from fractions import Fraction as F
from itertools import product
from collections import defaultdict
import json


def choice(margin):
    return 1 if margin>0 else 0 if margin<0 else None


def panel():
    return [dict(N=n,H=h,C=c,R=r,Y=n if r=='head' else h)
            for n,h,c,r in product((0,1),(0,1),(0,1),('head','attractor'))]


def bayes_ceiling(rows,available):
    groups=defaultdict(lambda:[0,0])
    for row in rows:groups[tuple(row[k] for k in available)][row['Y']]+=1
    return F(sum(max(counts) for counts in groups.values()),len(rows))


def native_margin(row):
    baseline=row['C'] if row['R']=='head' else row['H']
    strength=F(1,2) if row['R']=='head' else F(2)
    return strength*(2*baseline-1)


def vote_margin(row,beta=F(1)):
    # The supplied vote depends on N only, not R/H/C.
    return native_margin(row)+beta*(2*row['N']-1)


def beta_interval(rows):
    """Exact open bounds satisfying every strict requested decision for beta>=0.

    This is a mathematical model-class compatibility calculation, not fitting
    an empirical writer or choosing a successful dose.
    """
    lower=F(0);upper=None
    for row in rows:
        t=2*row['Y']-1;d=2*row['N']-1;l=native_margin(row)
        boundary=-F(t*l,t*d)
        if t*d>0:lower=max(lower,boundary)
        else:upper=boundary if upper is None else min(upper,boundary)
    return lower,upper


def checks():
    rows=panel();assert len(rows)==16
    ceilings={'external_N_only':bayes_ceiling(rows,('N',)),
        'host_without_N':bayes_ceiling(rows,('R','H','C')),
        'role_or_patch_address_only':bayes_ceiling(rows,('R',)),
        'original_carrier_number_only':bayes_ceiling(rows,('C',))}
    assert ceilings=={'external_N_only':F(3,4),'host_without_N':F(3,4),
        'role_or_patch_address_only':F(1,2),'original_carrier_number_only':F(1,2)}
    assert sum(row['N']==row['Y'] for row in rows)==12
    assert sum(choice(native_margin(row))==row['Y'] for row in rows)==12
    assert all(choice(vote_margin(row))==row['Y'] for row in rows)
    lower,upper=beta_interval(rows);assert (lower,upper)==(F(1,2),F(2))
    assert any(choice(vote_margin(row,lower)) is None for row in rows)
    assert any(choice(vote_margin(row,upper)) is None for row in rows)
    swaps={r:dict(changed=0,unchanged=0) for r in ('head','attractor')}
    for row in rows:
        other=dict(row,N=1-row['N']);other['Y']=other['N'] if other['R']=='head' else other['H']
        changed=choice(vote_margin(row))!=choice(vote_margin(other))
        swaps[row['R']]['changed' if changed else 'unchanged']+=1
        assert changed==(row['R']=='head')
    donor=[dict(N=n,H=0,C=0,R='attractor',Y=0) for n in (0,1)]
    receiver=[dict(N=n,H=0,C=0,R='head',Y=n) for n in (0,1)]
    assert [choice(vote_margin(x)) for x in donor]==[0,0]
    assert [choice(vote_margin(x)) for x in receiver]==[0,1]
    return {'cell_count':16,'ceilings':{k:str(v) for k,v in ceilings.items()},
        'external_decision_correct':12,'native_only_correct':12,'unconditional_vote_plus_host_correct':16,
        'strict_vote_scale_open_interval':{'lower':str(lower),'upper':str(upper),'endpoints_have_ties':True},
        'directed_N_swap_counts':swaps,
        'answer_matched_donor_control':{'donor_Y':[0,0],'receiver_Y':[0,1],'global_vote_also_passes':True},
        'cells':[{**r,'native_margin':str(native_margin(r)),'N_only_vote':str(2*r['N']-1),
                  'combined_margin':str(vote_margin(r)),'combined_choice':choice(vote_margin(r))} for r in rows]}

if __name__=='__main__':print(json.dumps(checks(),indent=2))
