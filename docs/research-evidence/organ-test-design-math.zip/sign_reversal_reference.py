"""Exact Fraction checks of two-choice identification limits. No empirical data."""
from fractions import Fraction as F
from itertools import product
import json


def sign(x):return 1 if x>0 else -1 if x<0 else 0

def rms_margin_sign(numerator,mean_square,bias=F(0)):
    """Sign of numerator/sqrt(mean_square)+bias using rational comparisons."""
    assert mean_square>0
    if numerator==0:return sign(bias)
    if bias==0 or sign(bias)==sign(numerator):return sign(numerator)
    order=sign(numerator*numerator-bias*bias*mean_square)
    return sign(numerator)*order

def paired_change_sign(a1,r1,a0,r0):
    """Sign of a1/sqrt(r1)-a0/sqrt(r0), without floating point."""
    assert r0>0 and r1>0
    if a1==0:return -sign(a0)
    if a0==0:return sign(a1)
    if sign(a1)!=sign(a0):return sign(a1)
    return sign(a1)*sign(a1*a1*r0-a0*a0*r1)

def checks():
    cells=[dict(N=n,Q=q,Y=int(n==q)) for n,q in product((0,1),repeat=2)]
    assert all(sum(row['Y']==y for row in cells if row['N']==n)==1 for n,y in product((0,1),repeat=2))
    assert all(sum(row['Y']==y for row in cells if row['Q']==q)==1 for q,y in product((0,1),repeat=2))
    # A witness attaining the proved additive maximum3/4; no parameter search.
    additive=[F(row['N']+row['Q'])-F(3,2) for row in cells]
    assert sum(sign(v)==2*r['Y']-1 for v,r in zip(additive,cells))==3
    assert additive[0]+additive[3]==additive[1]+additive[2]
    # Fixed residual delta(0,1), fixed zero-bias readout(1,0), h_Q=(+/-1,0).
    # RMS mean-square changes1/2->1, solely changing a positive denominator.
    changes={str(q):paired_change_sign(F(1-2*q),F(1),F(1-2*q),F(1,2)) for q in (0,1)}
    assert changes=={'0':-1,'1':1}
    for q,n in product((0,1),repeat=2):
        assert rms_margin_sign(F(1-2*q),F(1+n,2))==1-2*q
    zero_bias_correct=sum(rms_margin_sign(F(1-2*r['Q']),F(1+r['N'],2))
        ==2*r['Y']-1 for r in cells)
    assert zero_bias_correct==2
    # Fixed head bias defeats the zero-bias XOR bound. h_Q=(1,Q),d_N=(0,N-1),
    # fixed readout(-1,0),bias5/4. Diagonal y=+/-1; off-diagonal y=0.
    biased=[]
    for row in cells:
        y=F(row['N']+row['Q']-1);r=(1+y*y)/2
        s=rms_margin_sign(F(-1),r,F(5,4))
        assert s==2*row['Y']-1
        biased.append(dict(**row,hidden=['1',str(y)],mean_square=str(r),
            margin='1/4' if r==1 else '5/4-sqrt(2)',strict_sign=s))
    assert F(25,16)<2
    for epsilon in (F(0),F(1,1000000),F(139,1000)):
        assert epsilon<F(7,50)
        assert rms_margin_sign(F(-1),F(1)+epsilon,F(5,4))==1
        assert rms_margin_sign(F(-1),F(1,2)+epsilon,F(5,4))==-1
    assert rms_margin_sign(F(-1),F(1,2)+F(7,50),F(5,4))==0
    return dict(cells=cells,single_party_accuracy_ceiling='1/2',
        arbitrary_additive_output_accuracy_ceiling='3/4',
        ceiling_attained_by_margins=[str(x) for x in additive],
        zero_bias_rms_paired_change_sign=changes,
        zero_bias_rms_expression={'Q0':'1-sqrt(2)','Q1':'sqrt(2)-1'},
        zero_bias_rms_decisions_change=False,
        zero_bias_rms_equality_correct=zero_bias_correct,
        fixed_bias_rms_xnor=biased,
        fixed_bias_example_epsilon_range='0 <= epsilon < 7/50',
        fixed_bias_example_at_epsilon_upper_boundary='off-diagonal ties; not4/4')

if __name__=='__main__':print(json.dumps(checks(),indent=2))
