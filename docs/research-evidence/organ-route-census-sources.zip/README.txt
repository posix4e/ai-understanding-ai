Source and record reading bundle for ORGAN_ROUTE_CENSUS_V1.
35 frozen Python files plus the full report, locally fixed plan, registration, completion and independent audit.
Raw current/historical tensors, preceding study records, model weights and the pinned runtime are not bundled. This archive is not a self-contained reproduction and should not be executed as a fresh run.
The current result is descriptive and reuses exposed toy cases. No novelty, usefulness or necessity of routing changes is established.
