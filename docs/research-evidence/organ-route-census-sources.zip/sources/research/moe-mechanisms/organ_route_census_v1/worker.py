"""Collect192 exact native suffix replays; never summarize routing or answers."""
import argparse
from datetime import datetime, timezone
import hashlib
import inspect
import os
from pathlib import Path
import platform
import resource
import signal
import time

import numpy as np
import torch

from suffix import COMPONENTS, LAYERS, collect_suffix, component_counts


def initial_counts():
    return dict(suffix_attempts=0, suffix_finished=0, **component_counts(),
        full_host_forwards=0, prefix_forwards=0, reader_calls=0, organ_calls=0,
        writer_calls=0, analytical_fits=0, backwards=0, optimizer_steps=0,
        provider_calls=0, generated_tokens=0)


def expected_counts(n=192):
    result = initial_counts()
    result.update(suffix_attempts=n, suffix_finished=n)
    for name in COMPONENTS:
        for phase in ('attempts', 'finished'):
            result[name + '_' + phase] = n * (4 if name in ('decoder', 'attention', 'moe', 'router') else 1)
    return result


def raw(value):
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def source_names(tail_module):
    return {'input_ids', 'returned', 'full_logits', 'final_residual'} | {
        f'b{i}_{name}' for i in LAYERS for name in ('residual_input', 'after_attention', 'after_moe')
    } | {site + '_' + kind for site in tail_module.SITES for kind in ('actual_final', 'returned_final')}


def load_source(p, entry, tail_module):
    """Read only explicitly named tensors from the immutable bound B/W bundle."""
    paths = {}
    for kind in ('call', 'metadata'):
        relative = Path(entry['source_' + kind + '_path'])
        path = p.ROOT / relative
        if relative.is_absolute() or '..' in relative.parts or not path.resolve().is_relative_to(p.ORIGINAL.resolve()):
            raise ValueError('Source path escapes original archive')
        if p.digest(path) != entry['source_' + kind + '_sha256']:
            raise ValueError('Source archive hash differs')
        paths[kind] = path
    meta = p.read(paths['metadata'])
    if (meta['id'] != entry['source_id'] or meta['index'] != int(entry['source_id'])
            or any(meta[k] != entry[k] for k in ('cell_id', 'context_id', 'world_id', 'arm'))
            or meta['arm'] not in ('B', 'W') or meta['forward_completed'] is not True):
        raise ValueError('Source schedule binding differs')
    values = {}
    with np.load(paths['call'], allow_pickle=False) as archive:
        for name in source_names(tail_module):
            info = meta['tensors'][name]
            expected = 'torch.int64' if name == 'input_ids' else 'torch.bfloat16'
            if (info['dtype'] != expected or info['raw_key'] != name + '__raw_uint8'
                    or info['value_key'] != name + '__value'):
                raise ValueError('Unexpected source tensor encoding')
            a = archive[info['raw_key']]
            if a.dtype != np.uint8 or hashlib.sha256(a.tobytes()).hexdigest() != info['raw_sha256']:
                raise ValueError('Source raw bytes differ')
            dtype = torch.int64 if name == 'input_ids' else torch.bfloat16
            value = torch.from_numpy(a.copy()).view(dtype).reshape(info['shape'])
            readable = value.numpy() if name == 'input_ids' else value.float().numpy()
            saved = archive[info['value_key']]
            if (saved.dtype != readable.dtype or saved.shape != readable.shape
                    or saved.tobytes() != readable.tobytes() or not bool(torch.isfinite(value).all())):
                raise ValueError('Source raw/readable disagreement')
            values[name] = value
    return values, meta


def validate(values, info, tail, source, metadata):
    tail.validate()
    n = source['returned'].shape[1]
    if tuple(source['returned'].shape) != (1, n, 1024) or tuple(source['input_ids'].shape) != (1, n):
        raise ValueError('Malformed source entry')
    shapes = {'input_ids': (torch.int64, (1, n)), 'returned': (torch.bfloat16, (1, n, 1024)),
        'full_logits': (torch.bfloat16, (49155,)), 'cache_position': (torch.int64, (n,)),
        'position_ids': (torch.int64, (1, n)), 'mask': (torch.bfloat16, (1, 1, n, n + 1)),
        'rope_cos': (torch.bfloat16, (1, n, 64)), 'rope_sin': (torch.bfloat16, (1, n, 64))}
    for layer in LAYERS:
        shapes[f'b{layer}_moe_input'] = (torch.bfloat16, (1, n, 1024))
        for name, dtype, shape in (('order', torch.int64, (n * 8,)), ('tokens', torch.int64, (n * 8,)),
                                  ('gates', torch.bfloat16, (n * 8,)), ('sizes', torch.int64, (32,)),
                                  ('logits', torch.float32, (n, 32))):
            shapes[f'b{layer}_route_{name}'] = (dtype, shape)
    if set(values) != set(shapes) | set(tail.capture):
        raise ValueError('Suffix tensor inventory differs')
    for name, (dtype, shape) in shapes.items():
        if values[name].dtype != dtype or tuple(values[name].shape) != shape:
            raise ValueError('Suffix tensor shape/dtype differs: ' + name)
    if any(not bool(torch.isfinite(v).all()) for v in values.values()):
        raise ValueError('Nonfinite replay tensor')
    if info['suffix_completed'] is not True or info['component_counts'] != {
            k: v for k, v in expected_counts(1).items() if k in component_counts()}:
        raise ValueError('Suffix component counts differ')
    if values['cache_position'].tolist() != list(range(n)) or values['position_ids'].tolist() != [list(range(n))]:
        raise ValueError('Position schedule differs')
    comparisons = {name: raw(values[name]) == raw(value) for name, value in source.items()}
    comparisons.update({name: info[name] == metadata[name] for name in (
        'tail_entries', 'tail_sites', 'tail_observations', 'residual_multipliers')})
    for layer in LAYERS:
        auxiliary = metadata['tail_sites'][f'b{layer}_moe']['auxiliary_before']
        route = values[f'b{layer}_route_logits']
        comparisons[f'b{layer}_full_router_sha256'] = (
            len(auxiliary) == 1 and auxiliary[0]['dtype'] == str(route.dtype)
            and auxiliary[0]['shape'] == list(route.shape)
            and auxiliary[0]['raw_sha256'] == hashlib.sha256(raw(route)).hexdigest())
    if not all(comparisons.values()):
        raise ValueError('Historical exact replay differs: ' + ','.join(k for k, ok in comparisons.items() if not ok))
    return comparisons


def run_calls(modules, plan, p, tail_module, legacy, identity, event, sample, guard, counts):
    (p.OUT / 'calls').mkdir()
    contexts = {c['id']: c for c in plan['contexts']}
    plan_sha = p.digest(p.OUT / 'plan.json')
    for entry in plan['schedule']:
        if legacy.identity(modules) != identity:
            raise ValueError('Precall frozen ownership differs')
        before = sample('before:' + entry['id']); guard(before)
        source, meta = load_source(p, entry, tail_module)
        if source['input_ids'].tolist() != [contexts[entry['context_id']]['input_ids']]:
            raise ValueError('Source input IDs differ from fixed context')
        device = next(modules['host'].parameters()).device
        hidden = source['returned'].to(device=device)
        ids = source['input_ids'].to(device=device)
        if raw(hidden) != raw(source['returned']) or raw(ids) != raw(source['input_ids']):
            raise ValueError('Suffix entry transfer changed bytes')

        def start():
            counts['suffix_attempts'] += 1
            if counts['suffix_attempts'] > 192:
                raise ValueError('Suffix attempt ceiling')
            event('suffix_started', **entry)

        def component(name, phase, layer):
            event('component_' + phase, component=name, layer=layer, **entry)

        values, info, failure, tail = collect_suffix(modules['host'], hidden, ids, tail_module, start, component)
        for key, value in info['component_counts'].items():
            counts[key] += value
        counts['suffix_finished'] += int(info['suffix_completed'])
        if info['suffix_completed']:
            try:
                event('suffix_finished', **entry)
            except BaseException as exc:
                if failure is None:
                    failure = exc
        # Raw return is durable before exact historical comparisons or resource guards.
        pointers = legacy.retain(p.OUT, 'calls/' + entry['id'], values,
            dict(**entry, plan_sha256=plan_sha, **info))
        comparisons = {}
        after = None
        try:
            if failure is not None:
                raise failure
            comparisons = validate(values, info, tail, source, meta)
            if legacy.identity(modules) != identity:
                raise ValueError('Postcall hooks/ownership differ')
            after = sample('after:' + entry['id']); guard(after)
        except BaseException as exc:
            failure = exc
        row = dict(**entry, **info, **pointers, comparisons=comparisons,
            resources_before=before, resources_after=after, controls_pass=failure is None,
            error=None if failure is None else type(failure).__name__ + ': ' + str(failure))
        legacy.append(p.OUT / 'calls.jsonl', row)
        event('call_saved', **entry, controls_pass=row['controls_pass'])
        if failure is not None:
            raise failure


def main(deadline_utc):
    import protocol as p
    plan = p.verify(); plan_sha = p.digest(p.OUT / 'plan.json')
    started = p.read(p.OUT / 'STARTED.json')
    if (started['owner_pid'] != os.getppid() or started['plan_sha256'] != plan_sha
            or started['deadline_utc'] != deadline_utc):
        raise ValueError('Original owner binding differs')
    os.kill(os.getppid(), 0)
    if any((p.OUT / name).exists() for name in ('WORKER_STARTED.json', 'COLLECTED.json', 'STOPPED.json', 'COMPLETE.json')):
        raise ValueError('Worker already attempted or terminal')
    deadline = datetime.fromisoformat(deadline_utc)
    if deadline.tzinfo is None:
        raise ValueError('Deadline timezone absent')
    p.create(p.OUT / 'WORKER_STARTED.json', dict(at_utc=p.now(), worker_pid=os.getpid(),
        owner_pid=os.getppid(), plan_sha256=plan_sha, deadline_utc=deadline_utc))
    legacy = p.load_legacy('worker'); tail_module = p.load_tail('tail')
    modules = {}; before_identity = None; states_before = None; during = None
    counts = initial_counts(); active = None; resources = []; begin = time.monotonic()

    def event(name, **fields):
        nonlocal active
        if name == 'suffix_started':
            active = dict(fields)
        legacy.append(p.OUT / 'worker-events.jsonl', dict(at_utc=p.now(), event=name, **fields))

    def sample(stage):
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if platform.system() != 'Darwin':
            rss *= 1024
        value = dict(stage=stage, elapsed_seconds=time.monotonic() - begin,
            rss_high_water_bytes=int(rss), mps_driver_bytes=int(torch.mps.driver_allocated_memory()),
            archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file()))
        resources.append(value); event('resources', **value)
        return value

    def guard(value):
        if os.getppid() != started['owner_pid']:
            raise RuntimeError('Original owner disappeared')
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError('Fixed owner deadline expired')
        for field, limit in (('rss_high_water_bytes', 'max_rss_bytes'),
                             ('mps_driver_bytes', 'max_mps_driver_bytes'), ('archive_bytes', 'max_archive_bytes')):
            if value[field] > p.SETTINGS[limit]:
                raise RuntimeError('Fixed resource ceiling exceeded: ' + field)

    def terminated(signum, frame):
        raise SystemExit(128 + signum)

    previous_signal = signal.signal(signal.SIGTERM, terminated)
    try:
        event('worker_started', worker_pid=os.getpid(), owner_pid=os.getppid(), deadline_utc=deadline_utc)
        import transformers
        from transformers import AutoModelForCausalLM
        from transformers.models.granitemoe import modeling_granitemoe
        if (platform.python_version(), torch.__version__, transformers.__version__, np.__version__) != ('3.12.14', '2.8.0', '4.56.2', '2.3.3'):
            raise ValueError('Pinned runtime differs')
        if not torch.backends.mps.is_available() or p.digest(inspect.getfile(modeling_granitemoe)) != plan['installed_model_source_sha256']:
            raise ValueError('Pinned native implementation differs')
        torch.set_num_threads(4)
        if torch.get_num_threads() != 4:
            raise ValueError('Thread count differs')
        guard(sample('before_loading'))
        cache_before = p.validate_model_files(plan)
        p.create(p.OUT / 'MODEL_CACHE_BEFORE.json', cache_before)
        torch.manual_seed(42)
        host = AutoModelForCausalLM.from_pretrained(p.ROOT / plan['model_path'], local_files_only=True,
            torch_dtype=torch.bfloat16, attn_implementation='eager').to('mps').eval()
        modules = dict(host=host)
        before_identity = legacy.identity(modules)
        if any(before_identity['hooks'].values()) or not all(all(v.values()) for v in before_identity['grad_none'].values()):
            raise ValueError('Preexisting hooks or gradients')
        if len(before_identity['requires_grad']['host']) != 218 or len(host.model.layers) != 24:
            raise ValueError('Native architecture differs')
        host.config.use_cache = False
        for parameter in host.parameters():
            parameter.requires_grad_(False)
        during = legacy.identity(modules)
        states_before = dict(host=legacy.state_hash(host))
        if len(states_before['host']) != 219 or states_before['host'] != plan['expected_host_state']:
            raise ValueError('Host state differs')
        p.create(p.OUT / 'RUNTIME.json', dict(plan_sha256=plan_sha, python=platform.python_version(),
            torch=torch.__version__, transformers=transformers.__version__, numpy=np.__version__,
            seed=42, threads=torch.get_num_threads(), device='mps', dtype='bfloat16',
            attention=host.config._attn_implementation, cache=host.config.use_cache,
            output_attentions=host.config.output_attentions, output_hidden_states=host.config.output_hidden_states,
            output_router_logits=host.config.output_router_logits, logits_scaling=host.config.logits_scaling,
            installed_model_source_sha256=p.digest(inspect.getfile(modeling_granitemoe))))
        if len(plan['contexts']) != 24 or len(plan['schedule']) != 192:
            raise ValueError('Fixed panel differs')
        guard(sample('loaded'))
        run_calls(modules, plan, p, tail_module, legacy, during, event, sample, guard, counts)
        if counts != expected_counts():
            raise ValueError('Complete operation counts differ')
        states_after = dict(host=legacy.state_hash(host))
        cache_after = p.validate_model_files(plan)
        p.create(p.OUT / 'MODEL_CACHE_AFTER.json', cache_after)
        after = legacy.restore(modules, before_identity)
        checks = dict(ownership_restored=after == before_identity, states_unchanged=states_before == states_after,
            cache_unchanged=cache_before == cache_after, exact_counts=counts == expected_counts())
        if not all(checks.values()):
            raise ValueError('Terminal frozen identity failure')
        guard(sample('complete'))
        p.create(p.OUT / 'WORKER_COMPLETE.json', dict(status='WORKER_COMPLETED', at_utc=p.now(),
            plan_sha256=plan_sha, counts=counts, states_before=states_before, states_after=states_after,
            identities_before=before_identity, identities_during=during, identities_after=after,
            checks=checks, resource_samples=resources, elapsed_seconds=time.monotonic() - begin,
            analytical_fits=0, backwards=0, optimizer_steps=0, provider_calls=0, generated_tokens=0))
        event('worker_completed', counts=counts)
        exclusions = set(plan['collection_exclusions'])
        inventory = {str(f.relative_to(p.OUT)): p.digest(f) for f in sorted(p.OUT.rglob('*'))
                     if f.is_file() and str(f.relative_to(p.OUT)) not in exclusions}
        guard(dict(resources[-1], archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file())))
        p.create(p.OUT / 'COLLECTED.json', dict(at_utc=p.now(), plan_sha256=plan_sha, counts=counts,
            all_controls_pass=True, artifact_sha256=inventory))
    except BaseException as exc:
        cleanup = None; cleanup_error = None; failure_states = None; failure_state_error = None
        if modules:
            try:
                failure_states = {k: legacy.state_hash(m) for k, m in modules.items()}
            except BaseException as err:
                failure_state_error = repr(err)
        if modules and before_identity is not None:
            try:
                cleanup = legacy.restore(modules, before_identity)
            except BaseException as err:
                cleanup_error = repr(err)
        reason = type(exc).__name__ + ': ' + str(exc)
        try:
            event('worker_failed', counts=counts, reason=reason)
        finally:
            p.create(p.OUT / 'WORKER_FAILURE.json', dict(at_utc=p.now(), plan_sha256=plan_sha,
                counts=counts, active_schedule_entry=active, reason=reason, identities_before=before_identity,
                cleanup_identities=cleanup, cleanup_error=cleanup_error, states_before=states_before,
                available_failure_states=failure_states, failure_state_error=failure_state_error, retry_allowed=False))
        raise
    finally:
        signal.signal(signal.SIGTERM, previous_signal)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--deadline-utc', required=True)
    main(parser.parse_args().deadline_utc)
