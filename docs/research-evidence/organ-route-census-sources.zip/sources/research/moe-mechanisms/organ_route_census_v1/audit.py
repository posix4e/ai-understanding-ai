"""Independent raw-first exact-suffix admission and identity-aligned route census.

No primary worker/suffix imports, model construction, Torch import, or inference.
The 2e-7 allowance applies only to an independent FP64 softmax reconstruction
before BF16 casting. Every historical artifact comparison is byte-exact.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import platform
import sys
import time
import numpy as np
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1'
PREP=OUT.with_name(OUT.name+'_PREPARATION')
ORIGINAL=ROOT/'outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1'
LAYERS=(20,21,22,23)
SITES=tuple(f'b{i}_{part}' for i in LAYERS for part in ('attn','moe'))
SOFTMAX_ATOL=2e-7
K=8
EXPERTS=32
VOCAB=49155
TIMEOUT=900
MEMORY_LIMIT=10*1024**3
ARCHIVE_LIMIT=1024**3
EXCLUSIONS={'owner-events.jsonl','resource-monitor.jsonl','worker.log','independent_audit.log','COLLECTED.json'}
ORIGINAL_SHA={'plan.json':'b03e873cf4aadc83198e6d1a88aff6370b0caf970eac0dab852318dcedcbbdfa',
 'COMPLETE.json':'627e8690c16b948f047d0da3e4b8b0b4779609422443615ecd724012d661605e',
 'INDEPENDENT_AUDIT.json':'ac200d16cf5cba2fe0386e49b72fdc1f1e568db6b0b6fc16f6947feac71bee4a',
 'COLLECTED.json':'95c6dfd1f3f175e5d1a1ad43eb4dbb8d8a2718d4ac636d596d3c00a060bc344d',
 'REPORT.json':'305ad8c90732092e7b29f41571d4d0748e562477a214c3474044dcc8b5cbe9d9'}

class AuditError(ValueError):pass
def require(ok,message):
    if not ok:raise AuditError(message)
def read(path):return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def raw_hash(x):return hashlib.sha256(np.asarray(x).tobytes()).hexdigest()
def exact(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()
def same_json(a,b):return json.dumps(a,sort_keys=True,allow_nan=False)==json.dumps(b,sort_keys=True,allow_nan=False)
def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def safe(directory,name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe path')
    p=Path(directory)/name
    require(p.is_file() and p.resolve().is_relative_to(Path(directory).resolve()),'Missing or escaping file')
    return p
def jsonl(path):
    lines=Path(path).read_text().splitlines();require(all(x.strip() for x in lines),'Blank journal row')
    return [json.loads(x) for x in lines]
def is_alive(pid):
    require(type(pid) is int and pid>1,'Invalid actor')
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
def schedule_fields(row,entry):
    require(all(k in row and same_json(row[k],v) for k,v in entry.items()),'Schedule binding differs')
def bf16_bits(x):
    a=np.asarray(x,dtype=np.float32);require(np.isfinite(a).all(),'Nonfinite BF16 operand')
    u=a.view(np.uint32)
    return ((u+np.uint32(0x7fff)+((u>>16)&1))>>16).astype(np.uint16)
def bf16(x):return (bf16_bits(x).astype(np.uint32)<<16).view(np.float32)
def decode(raw,dtype,shape):
    types={'torch.bfloat16':('<u2',2),'torch.float32':('<f4',4),'torch.int64':('<i8',8),'numpy.float64':('<f8',8)}
    require(dtype in types and all(type(n) is int and n>=0 for n in shape),'Invalid recorded dtype/shape')
    storage,width=types[dtype];a=np.asarray(raw)
    require(a.dtype==np.uint8 and a.shape==(math.prod(shape)*width,),'Invalid raw width')
    v=np.frombuffer(a.tobytes(),dtype=storage)
    if dtype=='torch.bfloat16':v=(v.astype(np.uint32)<<16).view(np.float32)
    return v.reshape(shape)
def load_bundle(path,metadata_path,expected,allow_extra=False):
    meta=read(metadata_path);require(isinstance(meta.get('tensors'),dict),'Missing tensor inventory')
    require(set(expected)<=set(meta['tensors']) if allow_extra else set(expected)==set(meta['tensors']),'Tensor inventory differs')
    values,raws={},{}
    with np.load(path,allow_pickle=False) as archive:
        require(len(archive.files)==len(set(archive.files)),'Duplicate archive member')
        all_keys={n+s for n in meta['tensors'] for s in ('__raw_uint8','__value')}
        require(set(archive.files)==all_keys,'Archive member inventory differs')
        for name,(dtype,shape) in expected.items():
            m=meta['tensors'][name];rk,vk=name+'__raw_uint8',name+'__value'
            require(m['dtype']==dtype and same_json(m['shape'],list(shape)) and m['raw_key']==rk and m['value_key']==vk,'Recorded tensor type differs')
            raw=np.asarray(archive[rk]);v=decode(raw,dtype,shape)
            require(raw_hash(raw)==m['raw_sha256'] and exact(v,archive[vk]),'Raw/hash/readable tensor differs')
            require(np.isfinite(v).all(),'Nonfinite tensor')
            values[name]=v.copy();raws[name]=raw.copy()
    return values,raws,meta

def _ceil32(value):
    x=np.float32(value)
    return np.nextafter(x,np.float32(np.inf),dtype=np.float32) if float(x)<value else x
def _floor32(value):
    x=np.float32(value)
    return np.nextafter(x,np.float32(-np.inf),dtype=np.float32) if float(x)>value else x
def gate_rounding_check(value,reference):
    """Exact FP32 existence in a BF16 RNE bin intersecting the fixed interval."""
    v=np.float32(value);u=int(v.view(np.uint32));require(u&65535==0,'Gate not BF16')
    code=u>>16;require(0<=code<=0x3f80 and math.isfinite(reference),'Gate outside [0,1] or invalid reference')
    lo=max(0.,float(reference)-SOFTMAX_ATOL);hi=min(1.,float(reference)+SOFTMAX_ATOL)
    require(lo<=hi,'Invalid softmax reference')
    def at(bits):return float(np.array(bits<<16,dtype=np.uint32).view(np.float32))
    lower=0. if code==0 else (at(code-1)+float(v))/2
    upper=1. if code==0x3f80 else (float(v)+at(code+1))/2
    low=max(lo,lower);high=min(hi,upper);candidate=_ceil32(low)
    if code%2 and float(candidate)==lower:candidate=np.nextafter(candidate,np.float32(np.inf),dtype=np.float32)
    valid=float(candidate)<=high and not(code%2 and float(candidate)==upper)
    require(valid,'Actual gate outside fixed softmax/BF16 rounding interval')
    first,last=_ceil32(lo),_floor32(hi)
    require(first<=last,'Softmax interval has no FP32 representative')
    return dict(ambiguous=bool(bf16_bits(first)!=bf16_bits(last)),reference=float(reference),
        decoded_error=float(v)-float(reference))

def canonical_route(order,tokens,gates,sizes,logits):
    """Invert native grouped tuples; never infer selected support from nonzero gates."""
    order,tokens,sizes,logits,gates=map(np.asarray,(order,tokens,sizes,logits,gates))
    require(logits.dtype==np.float32 and logits.ndim==2 and logits.shape[1]==EXPERTS and np.isfinite(logits).all(),'Router logits malformed')
    length=len(logits);count=length*K
    require(length>0 and order.dtype==tokens.dtype==sizes.dtype==np.int64,'Router index dtype differs')
    require(order.shape==tokens.shape==gates.shape==(count,) and sizes.shape==(EXPERTS,),'Route shape differs')
    require(gates.dtype==np.float32 and np.isfinite(gates).all() and np.all((gates.view(np.uint32)&65535)==0),'Gate storage differs')
    require(np.array_equal(np.sort(order),np.arange(count)) and np.array_equal(tokens,order//K),'Router permutation/token identity differs')
    require(np.all(sizes>=0) and sum(map(int,sizes))==count,'Router expert counts differ')
    grouped_ids=np.repeat(np.arange(EXPERTS),sizes);support=np.empty(count,dtype=np.int64);slot_gates=np.empty(count,dtype=np.float32)
    support[order]=grouped_ids;slot_gates[order]=gates;support=support.reshape(length,K);slot_gates=slot_gates.reshape(length,K)
    dense=np.zeros((length,EXPERTS),dtype=np.float32);details=[]
    for t in range(length):
        ids=support[t];require(len(set(map(int,ids)))==K,'Duplicate selected expert')
        selected=logits[t,ids].astype(np.float64);excluded=np.delete(logits[t],ids)
        require(np.all(selected[:-1]>=selected[1:]) and min(selected)>=max(excluded),'Selected tuple is not native top-k')
        exp=np.exp(selected-max(selected));reference=exp/math.fsum(map(float,exp))
        checks=[gate_rounding_check(g,p) for g,p in zip(slot_gates[t],reference)]
        dense[t,ids]=slot_gates[t]
        ranked=sorted(map(float,logits[t]),reverse=True);cut=ranked[K-1];gap=Fraction(ranked[K-1])-Fraction(ranked[K])
        high=[e for e,z in enumerate(logits[t]) if float(z)>cut];tied=[e for e,z in enumerate(logits[t]) if float(z)==cut]
        details.append(dict(selected_ids=list(map(int,ids)),selected_gates=list(map(float,slot_gates[t])),
            dense_gates=list(map(float,dense[t])),gate_sum=float(math.fsum(map(float,dense[t]))),
            cutoff_logit=cut,boundary_gap=float(gap),boundary_gap_fraction=str(gap),
            historical_support_unique=gap>0,strictly_above_cutoff=high,at_cutoff=tied,
            slots_at_cutoff=K-len(high),within_selected_ties=len(set(selected))<K,
            gate_rounding_ambiguous=sum(c['ambiguous'] for c in checks),
            maximum_softmax_decoded_error=max(abs(c['decoded_error']) for c in checks)))
    return dict(support=support,gates=slot_gates,dense=dense,rows=details)

def overlap_bounds(a,b):
    """Dynamic program over32 expert identities; all admissible tied top-k sets."""
    ah,at=set(a['strictly_above_cutoff']),set(a['at_cutoff']);bh,bt=set(b['strictly_above_cutoff']),set(b['at_cutoff'])
    dp={(0,0):(0,0)}
    for e in range(EXPERTS):
        av=(1,) if e in ah else ((0,1) if e in at else (0,));bv=(1,) if e in bh else ((0,1) if e in bt else (0,))
        new={}
        for (na,nb),(lower,upper) in dp.items():
            for x in av:
                for y in bv:
                    key=(na+x,nb+y)
                    if max(key)>K:continue
                    lo,hi=new.get(key,(K+1,-1));new[key]=(min(lo,lower+x*y),max(hi,upper+x*y))
        dp=new
    require((K,K) in dp,'No admissible tie support');return dp[K,K]
def compare_routes(base,written,entry,layer):
    b,w=base['rows'][-1],written['rows'][-1];sb,sw=set(b['selected_ids']),set(w['selected_ids'])
    gb,gw=base['dense'][-1],written['dense'][-1];delta=[Fraction(float(v))-Fraction(float(u)) for u,v in zip(gb,gw)]
    intersection=sb&sw;overlap=len(intersection);lo,hi=overlap_bounds(b,w)
    l1=sum(map(abs,delta),Fraction());linf=max(map(abs,delta))
    result={k:entry[k] for k in ('cell_id','context_id','world_id')}
    result.update(layer=layer,B=b,W=w,overlap=overlap,replacements=K-overlap,jaccard=str(Fraction(overlap,2*K-overlap)),
        admissible_overlap_min=lo,admissible_overlap_max=hi,unavoidable_historical_replacement=hi<K,
        support_unchanged=sb==sw,gate_bits_unchanged=exact(gb,gw),
        delta=[float(x) for x in delta],L1=float(l1),L1_fraction=str(l1),half_L1_actual_gates=float(l1/2),Linf=float(linf),
        lost_baseline_mass=float(sum((Fraction(float(gb[e])) for e in sb-sw),Fraction())),
        gained_written_mass=float(sum((Fraction(float(gw[e])) for e in sw-sb),Fraction())),
        intersection_L1=float(sum((abs(delta[e]) for e in intersection),Fraction())),
        intersection_signed_change=float(sum((delta[e] for e in intersection),Fraction())),
        nonfinal_support_equal=exact(np.sort(base['support'][:-1],axis=1),np.sort(written['support'][:-1],axis=1)),
        nonfinal_ordered_slots_equal=exact(base['support'][:-1],written['support'][:-1]),
        nonfinal_gate_bits_equal=exact(base['dense'][:-1],written['dense'][:-1]))
    return result
def summarize(rows):
    require(len(rows)==384 and len({(r['cell_id'],r['layer']) for r in rows})==384,'Incomplete paired route census')
    def group(items):
        require(items,'Empty summary')
        return dict(n=len(items),overlap_histogram={str(k):sum(r['overlap']==k for r in items) for k in range(K+1)},
            support_unchanged=sum(r['support_unchanged'] for r in items),gate_bits_unchanged=sum(r['gate_bits_unchanged'] for r in items),
            boundary_tied_B=sum(not r['B']['historical_support_unique'] for r in items),boundary_tied_W=sum(not r['W']['historical_support_unique'] for r in items),
            gate_rounding_ambiguous=sum(r[a]['gate_rounding_ambiguous'] for r in items for a in ('B','W')),
            unavoidable_historical_replacement=sum(r['unavoidable_historical_replacement'] for r in items),
            nonfinal_mismatch=sum(not(r['nonfinal_support_equal'] and r['nonfinal_gate_bits_equal']) for r in items),
            gate_L1=dict(mean=math.fsum(r['L1'] for r in items)/len(items),minimum=min(r['L1'] for r in items),maximum=max(r['L1'] for r in items)))
    cells=[]
    for cell_id in dict.fromkeys(r['cell_id'] for r in rows):
        part=[r for r in rows if r['cell_id']==cell_id];require(len(part)==4 and {r['layer'] for r in part}==set(LAYERS),'Cell layer coverage differs')
        cells.append(dict(cell_id=cell_id,changed_support_layers=sum(not r['support_unchanged'] for r in part),changed_gate_layers=sum(not r['gate_bits_unchanged'] for r in part)))
    require(len(cells)==96,'Cell census differs')
    return dict(implementation_pass=True,baseline_replication_pass=True,exact_replay_calls=192,
        paired_rows=rows,per_layer={str(l):group([r for r in rows if r['layer']==l]) for l in LAYERS},
        per_world={w:{str(l):group([r for r in rows if r['world_id']==w and r['layer']==l]) for l in LAYERS} for w in [f'dev{i:02d}' for i in range(4)]},
        per_cell=cells,all_layer_support_unchanged=sum(c['changed_support_layers']==0 for c in cells),
        all_layer_gates_unchanged=sum(c['changed_gate_layers']==0 for c in cells))


def check_residual_chain(values,multiplier):
    """Eight actual BF16 multiply/add operations, with rounding at both steps.

    This verifies saved actual operands, not a linear effect decomposition and
    not an independent reexecution of attention/MoE/norm/head.
    """
    require(type(multiplier) is dict and set(multiplier)=={str(i) for i in LAYERS} and all(type(x) in (int,float) and math.isfinite(x) for x in multiplier.values()),'Invalid native residual multipliers')
    previous=values['returned'][:,-1:,:]
    for layer in LAYERS:
        before=values[f'b{layer}_residual_input']
        require(exact(before,previous),'Residual input lost displacement or layer linkage')
        for branch,after_name in (('attn','after_attention'),('moe','after_moe')):
            write=values[f'b{layer}_{branch}_returned_final']
            scaled=bf16(np.multiply(write,np.float32(multiplier[str(layer)]),dtype=np.float32))
            expected=bf16(np.add(before,scaled,dtype=np.float32))
            after=values[f'b{layer}_{after_name}']
            require(exact(after,expected),'Native BF16 residual multiplication/addition differs')
            before=after
        previous=before
    require(exact(previous,values['final_residual'][:,-1:,:]),'Final residual linkage differs')
    return dict(additions=8,multiplications=8,exact=True)


def check_inventory(directory,collected,late=()):
    directory=Path(directory)
    actual={str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file() and str(p.relative_to(directory)) not in EXCLUSIONS|set(late)}
    require(actual==set(collected['artifact_sha256']),'Collected inventory differs')
    for name,h in collected['artifact_sha256'].items():require(digest(safe(directory,name))==h,'Collected artifact changed')
    require(sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())<=ARCHIVE_LIMIT,'Archive cap exceeded')



def owner_guard(directory,plan_sha):
    directory=Path(directory);started=read(directory/'STARTED.json');worker=read(directory/'WORKER_STARTED.json')
    require(started['owner_pid']==os.getppid() and is_alive(started['owner_pid']),'Not original live owner')
    require(started['plan_sha256']==worker['plan_sha256']==plan_sha and worker['owner_pid']==started['owner_pid'],'Actor/plan binding differs')
    begin,deadline=[datetime.fromisoformat(started[k]) for k in ('at_utc','deadline_utc')]
    require(begin.tzinfo is not None and deadline.tzinfo is not None and (deadline-begin).total_seconds()==TIMEOUT and datetime.now(timezone.utc)<deadline,'Invalid/expired900-second deadline')
    require(worker['deadline_utc']==started['deadline_utc'],'Worker deadline changed')
    until=time.monotonic()+2
    while True:
        try:events=jsonl(directory/'owner-events.jsonl')
        except (FileNotFoundError,json.JSONDecodeError):events=[]
        if len(events)>=3:break
        require(time.monotonic()<until and datetime.now(timezone.utc)<deadline,'Audit dispatch handshake absent');time.sleep(.02)
    require(len(events)==3 and [(x['event'],x['stage']) for x in events]==[('started','worker'),('exit','worker'),('started','independent_audit')],'Owner lifecycle differs')
    require(events[0]['pid']==events[1]['pid']==worker['worker_pid'] and events[1]['returncode']==0 and events[1]['process_group_absent'] is True and not is_alive(worker['worker_pid']) and events[2]['pid']==os.getpid(),'Worker not inactive/successful')
    try:os.killpg(worker['worker_pid'],0)
    except ProcessLookupError:pass
    else:raise AuditError('Original worker process group survives')
    python=ROOT/'work/acquisition-representation-venv/bin/python'
    require(events[0]['command']==[str(python),str(HERE/'worker.py'),'--deadline-utc',started['deadline_utc']] and events[2]['command']==[str(python),str(HERE/'audit.py'),'--directory',str(directory)],'Dispatch commands differ')
    claim,launch=read(PREP/'LAUNCH_REQUESTED.json'),read(PREP/'LAUNCH_PID.json');command=[str(python),'-u',str(HERE/'owner.py'),'run']
    require(claim['command']==launch['command']==command and claim['plan_sha256']==launch['plan_sha256']==plan_sha and claim['nonce']==launch['nonce']==started['launch_nonce'] and launch['owner_pid']==started['owner_pid'],'Original launch claim differs')
    require(os.getpgid(started['owner_pid'])==os.getsid(started['owner_pid'])==started['owner_pid'],'Detached owner identity differs')
    times=[datetime.fromisoformat(x['at_utc']) for x in events]
    require(begin<=times[0]<=times[1]<=times[2]<deadline,'Owner chronology differs')
    # Owner monitor remains live. Validate a complete-line prefix; never bind its
    # changing file hash as though final. Parent closure binds its final bytes.
    lines=(directory/'resource-monitor.jsonl').read_text().splitlines(keepends=True)
    records=[json.loads(x) for x in lines if x.endswith('\n')]
    require(records and any(r['stage']=='worker' for r in records),'No owner resource samples')
    previous=-math.inf
    for r in records:
        require(r['stage'] in ('worker','independent_audit') and r['pid']==(worker['worker_pid'] if r['stage']=='worker' else os.getpid()),'Monitor actor differs')
        require(type(r['elapsed_seconds']) in (int,float) and math.isfinite(r['elapsed_seconds']) and previous<=r['elapsed_seconds']<TIMEOUT,'Owner sample time invalid');previous=r['elapsed_seconds']
        require(type(r['child_tree_rss_bytes']) is int and 0<=r['child_tree_rss_bytes']<=MEMORY_LIMIT and type(r['archive_bytes']) is int and 0<=r['archive_bytes']<=ARCHIVE_LIMIT,'Owner resource cap exceeded')
    ws=[r for r in records if r['stage']=='worker'];exitrow=events[1]
    require(exitrow['samples']==len(ws) and exitrow['peak_child_tree_rss_bytes']==max(r['child_tree_rss_bytes'] for r in ws) and exitrow['peak_archive_bytes']==max(r['archive_bytes'] for r in ws),'Closed worker resource receipt differs')
    return started,worker,events,records



def preserve_invalid_publications(directory):
    preserved={}
    for name in ('REPORT.json','INDEPENDENT_AUDIT.json'):
        path=Path(directory)/name
        if path.exists():
            invalid=Path(directory)/('INVALID_'+name)
            require(not invalid.exists(),'Invalid publication archive already exists')
            preserved[name]=dict(sha256=digest(path),preserved_as=invalid.name)
            path.rename(invalid)
    return preserved


SETTINGS=dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',
    suffix_executions=192,decoder_block_executions=768,contexts=24,worlds=4,cells=96,
    layers=[20,21,22,23],experts=32,top_k=8,full_host_forwards=0,prefix_forwards=0,
    reader_applications=0,organ_forwards=0,writer_forwards=0,analytical_fits=0,
    backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0,
    dtype='bfloat16',device='mps',threads=4,batch_size=1,attention='eager',cache=False,
    logits_scaling=6,timeout_seconds=900,max_rss_bytes=MEMORY_LIMIT,
    max_mps_driver_bytes=MEMORY_LIMIT,max_archive_bytes=ARCHIVE_LIMIT,historical_hash_tolerance=0.0)
COMPONENTS=('mask','rope','decoder','attention','moe','router','final_norm','head')
def component_counts():
    return {n+'_'+p:(4 if n in ('decoder','attention','moe','router') else 1) for n in COMPONENTS for p in ('attempts','finished')}
def counts():
    return dict(suffix_attempts=192,suffix_finished=192,
        **{k:v*192 for k,v in component_counts().items()},full_host_forwards=0,prefix_forwards=0,
        reader_calls=0,organ_calls=0,writer_calls=0,analytical_fits=0,backwards=0,
        optimizer_steps=0,provider_calls=0,generated_tokens=0)
def expected_state_keys():
    suffixes=('self_attn.q_proj.weight','self_attn.k_proj.weight','self_attn.v_proj.weight',
        'self_attn.o_proj.weight','block_sparse_moe.input_linear.weight','block_sparse_moe.output_linear.weight',
        'block_sparse_moe.router.layer.weight','input_layernorm.weight','post_attention_layernorm.weight')
    return {'model.embed_tokens.weight','model.norm.weight','lm_head.weight'}|{f'model.layers.{i}.{s}' for i in range(24) for s in suffixes}
def expected_schedule(contexts,inventory):
    require(len(contexts)==24,'Context count differs');rows=[]
    for i,c in enumerate(contexts):
        s,a=divmod(i,3)
        require(c['id']==f's{s}-a{a}' and type(c['state']) is type(c['action']) is int and c['state']==s and c['action']==a,'Context identity/order differs')
        require(c['prompt']==f"World state {s}. Actions {'XYZ'[a]}. Next state:",'Original prompt differs')
        ids=c['input_ids'];require(type(ids) is list and 1<len(ids)<=48 and ids[0]==0 and all(type(x) is int and 0<=x<VOCAB for x in ids),'Input IDs malformed')
        for wi in range(4):
            for ai,arm in enumerate(('B','W')):
                index=len(rows);sid=f'{(i*4+wi)*6+ai:04d}';wid=f'dev{wi:02d}'
                row=dict(index=index,id=f'{index:04d}',source_id=sid,arm=arm,cell_id=f'{c["id"]}-{wid}',context_id=c['id'],world_id=wid)
                for kind,extension in (('call','npz'),('metadata','json')):
                    name=f'calls/{sid}.{extension}';require(name in inventory,'Original call absent from collection')
                    row['source_'+kind+'_path']='outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1/'+name
                    row['source_'+kind+'_sha256']=inventory[name]
                rows.append(row)
    return rows
def verify_plan(directory,root=ROOT):
    directory,root=Path(directory),Path(root);plan=read(directory/'plan.json');plan_sha=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==plan_sha,'Registration changed')
    require(same_json(plan['settings'],SETTINGS) and set(plan['collection_exclusions'])==EXCLUSIONS,'Settings/exclusions differ')
    old=root/'outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1'
    for n,h in ORIGINAL_SHA.items():require(digest(old/n)==h,'Original completion binding changed')
    require(not (old/'STOPPED.json').exists(),'Original study stopped')
    op,done,oa,collection=[read(old/n) for n in ('plan.json','COMPLETE.json','INDEPENDENT_AUDIT.json','COLLECTED.json')]
    require(done['status']=='TAIL_ATTRIBUTION_COMPLETE' and done['implementation_pass'] is True and done['baseline_replication_pass'] is True and oa['status']=='PASS' and oa['implementation_pass'] is True and oa['baseline_replication_pass'] is True,'Original admission absent')
    require(done['plan_sha256']==oa['plan_sha256']==collection['plan_sha256']==ORIGINAL_SHA['plan.json'] and done['report_sha256']==oa['report_sha256']==ORIGINAL_SHA['REPORT.json'] and done['independent_audit_sha256']==ORIGINAL_SHA['INDEPENDENT_AUDIT.json'] and oa['collected_sha256']==ORIGINAL_SHA['COLLECTED.json'],'Original hash chain differs')
    require(same_json(plan['schedule'],expected_schedule(plan['contexts'],collection['artifact_sha256'])),'Fixed192 schedule differs')
    for k in ('expected_host_state','model_path','model_cache_repository','model_files','installed_model_source_sha256','contexts'):
        require(same_json(plan[k],op[k]),'Original model/input context changed')
    require(set(plan['expected_host_state'])==expected_state_keys(),'Host state inventory incomplete')
    names=('protocol.py','suffix.py','worker.py','audit.py','owner.py','launch.py','test_suffix.py','test_audit.py')
    require(set(plan['source_sha256'])==set(op['source_sha256'])|{'research/moe-mechanisms/organ_route_census_v1/'+n for n in names},'Source inventory differs')
    require(all(plan['source_sha256'][n]==h for n,h in op['source_sha256'].items()),'Frozen source hash changed')
    for field in ('source_sha256','lineage_sha256'):
        require(type(plan[field]) is dict and plan[field],'Missing source/lineage')
        for n,h in plan[field].items():
            require(digest(safe(root,n))==h,'Live source/lineage changed')
            if field=='source_sha256':require(digest(safe(directory/'sources',n))==h,'Source archive changed')
    for e in plan['schedule']:
        for kind in ('call','metadata'):require(digest(safe(root,e['source_'+kind+'_path']))==e['source_'+kind+'_sha256'],'Original input changed')
    return plan,plan_sha
def runtime_guard():
    require(platform.python_version()==SETTINGS['python'] and np.__version__==SETTINGS['numpy'],'Python/NumPy runtime differs')
    require(Path(sys.executable).resolve()==(ROOT/'work/acquisition-representation-venv/bin/python').resolve(),'Auditor executable differs')
    for package in ('torch','transformers'):require(importlib.metadata.version(package)==SETTINGS[package],'Installed package version differs')
def validate_cache(plan,root=ROOT):
    """Only the previously reviewed cache path/hash helper is imported."""
    relative='research/moe-mechanisms/model_cache_validation/cache_files.py';path=safe(root,relative)
    require(digest(path)==plan['source_sha256'][relative],'Cache helper source differs')
    spec=importlib.util.spec_from_file_location('census_bound_cache_validator',path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    require(len(plan['model_files'])==9,'Expected nine model payloads')
    receipt=[helper.validate_model_cache_file(Path(root)/plan['model_path'],n,h,cache_repository=Path(root)/plan['model_cache_repository']) for n,h in plan['model_files'].items()]
    installed=Path(root)/'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
    require(digest(installed)==plan['installed_model_source_sha256'],'Installed native source differs')
    return receipt
def historical_shapes(length):
    out={'input_ids':('torch.int64',(1,length)),'returned':('torch.bfloat16',(1,length,1024)),
        'final_residual':('torch.bfloat16',(1,length,1024)),'full_logits':('torch.bfloat16',(VOCAB,))}
    for l in LAYERS:
        for n in ('residual_input','after_attention','after_moe'):out[f'b{l}_{n}']=('torch.bfloat16',(1,1,1024))
    for s in SITES:
        for n in ('actual_final','returned_final'):out[f'{s}_{n}']=('torch.bfloat16',(1,1,1024))
    return out
def call_shapes(length,head_dim):
    out=historical_shapes(length)
    out.update(cache_position=('torch.int64',(length,)),position_ids=('torch.int64',(1,length)),
        mask=('torch.bfloat16',(1,1,length,length+1)),rope_cos=('torch.bfloat16',(1,length,head_dim)),rope_sin=('torch.bfloat16',(1,length,head_dim)))
    for l in LAYERS:
        prefix=f'b{l}_';out[prefix+'moe_input']=('torch.bfloat16',(1,length,1024))
        for name in ('order','tokens'):out[prefix+'route_'+name]=('torch.int64',(length*K,))
        out[prefix+'route_sizes']=('torch.int64',(EXPERTS,));out[prefix+'route_gates']=('torch.bfloat16',(length*K,));out[prefix+'route_logits']=('torch.float32',(length,EXPERTS))
    return out
def compare_historical(new_values,new_raw,new_meta,old_values,old_raw,old_meta,entry):
    for name in old_values:require(exact(new_raw[name],old_raw[name]),'Historical raw tensor mismatch: '+name)
    for key in ('tail_entries','tail_sites','tail_observations','residual_multipliers'):
        require(same_json(new_meta[key],old_meta[key]),'Historical observation metadata mismatch: '+key)
    require(new_meta['suffix_completed'] is True and same_json(new_meta['component_counts'],component_counts()),'Incomplete suffix components')
    require(old_meta['arm']==entry['arm'] and old_meta['id']==entry['source_id'] and old_meta['plan_sha256']==ORIGINAL_SHA['plan.json'],'Historical call identity differs')
    length=new_values['returned'].shape[1]
    require(exact(new_values['cache_position'],np.arange(length,dtype=np.int64)) and exact(new_values['position_ids'],np.arange(length,dtype=np.int64)[None]),'Native positions differ')
    minbf=np.array(0xff7f0000,dtype=np.uint32).view(np.float32)
    expected=np.triu(np.full((length,length+1),minbf,dtype=np.float32),k=1)
    require(exact(new_values['mask'],expected[None,None]),'Native eager causal mask differs')
    for l in LAYERS:
        aux=new_meta['tail_sites'][f'b{l}_moe']['auxiliary_before']
        require(type(aux) is list and len(aux)==1,'MoE auxiliary shape differs')
        expected=dict(dtype='torch.float32',shape=[length,EXPERTS],raw_sha256=raw_hash(new_raw[f'b{l}_route_logits']))
        require(same_json(aux[0],expected),'Full router-logit historical SHA differs')
    check_residual_chain(new_values,new_meta['residual_multipliers'])
    return True

def validate_ownership(complete,plan):
    require(complete['status']=='WORKER_COMPLETED' and same_json(complete['counts'],counts()),'Worker status/counts differ')
    require(complete['states_before']==complete['states_after']=={'host':plan['expected_host_state']} and set(plan['expected_host_state'])==expected_state_keys(),'Frozen host states differ')
    require(complete['checks']==dict(ownership_restored=True,states_unchanged=True,cache_unchanged=True,exact_counts=True),'Worker ownership checks differ')
    before,during,after=[complete['identities_'+x] for x in ('before','during','after')]
    require(same_json(before,after),'Ownership was not restored')
    params=expected_state_keys()-{'lm_head.weight'}
    for identity in (before,during,after):
        require(set(identity)=={'requires_grad','training','hooks','forward_methods','grad_none','host_config'},'Identity fields differ')
        for k in set(identity)-{'host_config'}:require(set(identity[k])=={'host'},'Unexpected component owner')
        require(set(identity['requires_grad']['host'])==set(identity['grad_none']['host'])==params,'Parameter flags incomplete')
        require(all(type(v) is bool for v in identity['requires_grad']['host'].values()) and all(v is True for v in identity['grad_none']['host'].values()),'Gradient ownership differs')
        require(identity['hooks']=={'host':{}},'Foreign/leaked hooks')
        require(identity['training']['host'] and all(v is False for v in identity['training']['host'].values()) and identity['training']==before['training'],'Eval inventory differs')
        require(set(identity['forward_methods']['host'])==set(identity['training']['host']) and identity['forward_methods']==before['forward_methods'],'Forward ownership differs')
    require(all(v is False for v in during['requires_grad']['host'].values()),'Trainable state during suffix replay')
    cfg=dict(before['host_config']);cfg['use_cache']=False
    require(same_json(during['host_config'],cfg),'Configured host changed')
    require(type(cfg.get('logits_scaling')) in (int,float) and cfg['logits_scaling']==6,'Native logit scale differs')
    for k,v in dict(hidden_size=1024,num_attention_heads=16,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,use_cache=False,output_attentions=False,output_hidden_states=False,output_router_logits=False).items():
        require(k in cfg and same_json(cfg[k],v),'Host configuration differs: '+k)
    for k in ('analytical_fits','backwards','optimizer_steps','provider_calls','generated_tokens'):require(type(complete[k]) is int and complete[k]==0,'Forbidden work')
    require(type(complete['elapsed_seconds']) in (int,float) and math.isfinite(complete['elapsed_seconds']) and 0<=complete['elapsed_seconds']<=TIMEOUT,'Worker time invalid')
    return {str(l):cfg['residual_multiplier'] for l in LAYERS}
def expected_events(schedule):
    result=[('worker_started',None),('resources','before_loading'),('resources','loaded')]
    for entry in schedule:
        result.extend([('resources','before:'+entry['id']),('suffix_started',entry)])
        components=[(n,p,None) for n in ('mask','rope') for p in ('started','finished')]
        for l in LAYERS:
            components.extend((n,p,l) for n,p in [('decoder','started'),('attention','started'),('attention','finished'),('moe','started'),('router','started'),('router','finished'),('moe','finished'),('decoder','finished')])
        components.extend((n,p,None) for n in ('final_norm','head') for p in ('started','finished'))
        result.extend(('component_'+p,dict(**entry,component=n,layer=l)) for n,p,l in components)
        result.extend([('suffix_finished',entry),('resources','after:'+entry['id']),('call_saved',entry)])
    return result+[('resources','complete'),('worker_completed',None)]
def validate_events(events,schedule,complete,started=None,worker=None):
    expected=expected_events(schedule);require(len(events)==len(expected)==8645,'Event count differs')
    samples=[];last=None;elapsed=-math.inf
    for row,(event,payload) in zip(events,expected):
        require(row['event']==event,'Event sequence differs');at=datetime.fromisoformat(row['at_utc'])
        require(at.tzinfo is not None and (last is None or at>=last),'Event chronology differs');last=at
        if started:require(datetime.fromisoformat(started['at_utc'])<=at<datetime.fromisoformat(started['deadline_utc']),'Event outside deadline')
        if isinstance(payload,dict):
            schedule_fields(row,payload)
            if event=='call_saved':require(row['controls_pass'] is True,'Failed retained call')
        elif event=='resources':
            sample={k:v for k,v in row.items() if k not in ('event','at_utc')}
            require(set(sample)=={'stage','elapsed_seconds','rss_high_water_bytes','mps_driver_bytes','archive_bytes'} and sample['stage']==payload,'Resource schema/stage differs')
            t=sample['elapsed_seconds'];require(type(t) in (float,int) and math.isfinite(t) and elapsed<=t<=TIMEOUT,'Resource time invalid');elapsed=t
            for key,cap in [('rss_high_water_bytes',MEMORY_LIMIT),('mps_driver_bytes',MEMORY_LIMIT),('archive_bytes',ARCHIVE_LIMIT)]:
                require(type(sample[key]) is int and 0<=sample[key]<=cap,'Resource ceiling exceeded')
            samples.append(sample)
        elif event=='worker_started' and worker:require(all(row[k]==worker[k] for k in ('worker_pid','owner_pid','deadline_utc')),'Worker actor differs')
        elif event=='worker_completed':require(same_json(row['counts'],counts()),'Journal final counts differ')
    require(len(samples)==387 and same_json(samples,complete['resource_samples']),'Resource receipt differs')
    return samples
def validate_runtime(directory,plan,plan_sha):
    actual=read(Path(directory)/'RUNTIME.json')
    require(type(actual.get('logits_scaling')) in (int,float) and actual['logits_scaling']==6,'Runtime logit scale differs')
    expected=dict(plan_sha256=plan_sha,**{k:SETTINGS[k] for k in ('python','torch','transformers','numpy')},
        seed=42,threads=4,device='mps',dtype='bfloat16',attention='eager',cache=False,
        output_attentions=False,output_hidden_states=False,output_router_logits=False,logits_scaling=actual['logits_scaling'],
        installed_model_source_sha256=plan['installed_model_source_sha256'])
    require(same_json(actual,expected),'Recorded runtime differs')
def load_call(directory,row,entry,context,plan_sha,root=ROOT):
    schedule_fields(row,entry);stem='calls/'+entry['id']
    require(row['forward_path']==stem+'.npz' and row['forward_metadata_path']==stem+'.json','Call paths differ')
    paths=[safe(directory,row[k]) for k in ('forward_path','forward_metadata_path')]
    require([digest(p) for p in paths]==[row['forward_sha256'],row['forward_metadata_sha256']],'New call artifact changed')
    length=len(context['input_ids']);values,raw,meta=load_bundle(*paths,call_shapes(length,64))
    schedule_fields(meta,entry)
    fields=('suffix_completed','component_counts','tail_entries','tail_sites','tail_observations','residual_multipliers')
    require(meta['plan_sha256']==plan_sha and all(same_json(row[k],meta[k]) for k in fields),'Call metadata binding differs')
    require(row['controls_pass'] is True and row['error'] is None,'Call was failed')
    require(exact(values['input_ids'],np.array([context['input_ids']],dtype=np.int64)),'Current token IDs differ')
    source_paths=[safe(root,entry['source_'+k+'_path']) for k in ('call','metadata')]
    require([digest(p) for p in source_paths]==[entry['source_call_sha256'],entry['source_metadata_sha256']],'Historical input changed')
    old,oldraw,oldmeta=load_bundle(*source_paths,historical_shapes(length),allow_extra=True)
    require(type(oldmeta['index']) is int and oldmeta['index']==int(entry['source_id']) and oldmeta['forward_completed'] is True,'Historical index/completion differs')
    require(all(oldmeta[k]==entry[k] for k in ('arm','cell_id','context_id','world_id')),'Historical cell differs')
    compare_historical(values,raw,meta,old,oldraw,oldmeta,entry)
    comparisons=dict.fromkeys([*old,'tail_entries','tail_sites','tail_observations','residual_multipliers',*[f'b{l}_full_router_sha256' for l in LAYERS]],True)
    require(same_json(row['comparisons'],comparisons),'Exact comparison claims differ')
    return values,raw,meta
def audit_records(directory,plan,plan_sha,started=None,worker=None,root=ROOT):
    """All192 historical matches before the first route census or summary."""
    directory=Path(directory);schedule=plan['schedule'];require(len(schedule)==192,'Incomplete scheduled panel')
    calls=jsonl(directory/'calls.jsonl');require(len(calls)==192,'Incomplete actual panel')
    for row,entry in zip(calls,schedule):schedule_fields(row,entry)
    complete=read(directory/'WORKER_COMPLETE.json');require(complete['plan_sha256']==plan_sha,'Worker plan differs')
    multipliers=validate_ownership(complete,plan);validate_runtime(directory,plan,plan_sha)
    samples=validate_events(jsonl(directory/'worker-events.jsonl'),schedule,complete,started,worker)
    lookup={r['stage']:r for r in samples};contexts={c['id']:c for c in plan['contexts']};saved=[]
    for row,entry in zip(calls,schedule):
        require(same_json(row['resources_before'],lookup['before:'+entry['id']]) and same_json(row['resources_after'],lookup['after:'+entry['id']]),'Call resource binding differs')
        values,raw,meta=load_call(directory,row,entry,contexts[entry['context_id']],plan_sha,root)
        require(same_json(meta['residual_multipliers'],multipliers),'Native residual multiplier changed')
        saved.append({f'b{l}_route_{n}':values[f'b{l}_route_{n}'] for l in LAYERS for n in ('order','tokens','gates','sizes','logits')})
    require(len(saved)==192,'Missing exact replay')
    # This point is reached only after all whole-sequence historical comparisons.
    pairs=[];nonfinal=[]
    for i in range(0,192,2):
        b,w=schedule[i:i+2];require(b['arm']=='B' and w['arm']=='W' and b['cell_id']==w['cell_id'],'Incomplete B/W pair')
        for l in LAYERS:
            routes=[canonical_route(*(s[f'b{l}_route_{n}'] for n in ('order','tokens','gates','sizes','logits'))) for s in saved[i:i+2]]
            pair=compare_routes(*routes,b,l);pair.update(B_source_id=b['source_id'],W_source_id=w['source_id'],B_replay_id=b['id'],W_replay_id=w['id'])
            pairs.append(pair)
            for arm,route in zip(('B','W'),routes):
                for token,row in enumerate(route['rows'][:-1]):nonfinal.append(dict(cell_id=b['cell_id'],arm=arm,layer=l,token_index=token,**row))
    report=summarize(pairs);report.update(counts=counts(),historical_full_router_hash_matches=768,
        nonfinal_route_rows=nonfinal,softmax_precast_absolute_allowance=SOFTMAX_ATOL,
        resources=dict(samples=len(samples),maximum_rss_bytes=max(s['rss_high_water_bytes'] for s in samples),
            maximum_mps_driver_bytes=max(s['mps_driver_bytes'] for s in samples),maximum_sampled_archive_bytes=max(s['archive_bytes'] for s in samples),worker_elapsed_seconds=complete['elapsed_seconds']))
    return report
def audit(directory=OUT):
    directory=Path(directory);require(directory.resolve()==OUT.resolve(),'Wrong fixed directory')
    forbidden=('STOPPED.json','WORKER_FAILURE.json','COMPLETE.json','AUDIT_STARTED.json','AUDIT_FAILURE.json','REPORT.json','INDEPENDENT_AUDIT.json')
    require(not any((directory/n).exists() for n in forbidden),'Stopped/terminal/already attempted: no retry or partial grading')
    runtime_guard();plan,plan_sha=verify_plan(directory);started,worker,events,monitor=owner_guard(directory,plan_sha)
    collected=read(directory/'COLLECTED.json')
    require(collected['plan_sha256']==plan_sha and collected['all_controls_pass'] is True and same_json(collected['counts'],counts()),'Incomplete collection')
    check_inventory(directory,collected)
    create(directory/'AUDIT_STARTED.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,pid=os.getpid(),owner_pid=os.getppid(),audit_code_sha256=digest(__file__),rerun_allowed=False))
    try:
        cache=validate_cache(plan)
        require(same_json(read(directory/'MODEL_CACHE_BEFORE.json'),cache) and same_json(read(directory/'MODEL_CACHE_AFTER.json'),cache),'Model cache changed')
        report=audit_records(directory,plan,plan_sha,started,worker)
        check_inventory(directory,collected,late=('AUDIT_STARTED.json',));verify_plan(directory)
        require(datetime.now(timezone.utc)<datetime.fromisoformat(started['deadline_utc']),'Deadline expired before publication')
        report.update(status='EXACT_SUFFIX_ROUTE_CENSUS_REPORTED',plan_sha256=plan_sha,at_utc=datetime.now(timezone.utc).isoformat(),
            model_calls_by_auditor=0,answer_scoring_calls=0,
            limits=['New192 suffix replays exactly match historical full-sequence observations; no original prefix, organ, writer or task scoring was rerun.',
                'Raw original router logits are hash-matched. Historical support is unique only with positive eighth/ninth gap; boundary ties retain newly observed replay support and admissible-overlap bounds.',
                'Actual BF16 gates are authoritative and unrenormalized. A fixed2e-7 precast engineering allowance checks reconstructed softmax consistency, not a theorem of exact kernel replay.',
                'All96 exposed cells over24 repeated contexts and four worlds remain; no population inference, new-world generalization, calibrated probabilities or novelty.',
                'A descriptive route difference is not evidence of its necessity, utility, semantic specialization or causal mediation.',
                'Resource maxima are sampled. This auditor validates a live owner-log prefix; the owner verifies stage exits and process-group cleanup, and a later parent terminal review must bind final log/monitor bytes.'])
        create(directory/'REPORT.json',report)
        receipt=dict(status='PASS',implementation_pass=True,baseline_replication_pass=True,plan_sha256=plan_sha,
            report_sha256=digest(directory/'REPORT.json'),audit_code_sha256=digest(__file__),collected_sha256=digest(directory/'COLLECTED.json'),
            counts=counts(),input_sha256={**collected['artifact_sha256'],'COLLECTED.json':digest(directory/'COLLECTED.json')},
            owner_journal_prefix=events,owner_resource_prefix=monitor,live_owner_logs_final_hash_not_claimed=True,
            model_calls=0,fits=0,provider_calls=0,answer_scoring_calls=0)
        create(directory/'INDEPENDENT_AUDIT.json',receipt);return receipt
    except BaseException as exc:
        invalid=preserve_invalid_publications(directory)
        create(directory/'AUDIT_FAILURE.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,reason=type(exc).__name__+': '+str(exc),preserved_invalid_publications=invalid,rerun_allowed=False,partial_interpretation=False))
        raise

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,default=OUT)
    result=audit(parser.parse_args().directory)
    print(json.dumps({k:v for k,v in result.items() if k not in ('input_sha256','owner_journal_prefix','owner_resource_prefix')}),flush=True)
