"""One prospective route census from exact, whole-sequence suffix replay.

The completed source experiment is immutable. No prefix, reader, organ, writer,
tokenizer or old collector executes. Preparation reads metadata and hashes only.
"""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1'
PREP = OUT.with_name(OUT.name+'_PREPARATION')
PYTHON = ROOT/'work/acquisition-representation-venv/bin/python'
ORIGINAL = ROOT/'outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1'
TAIL_SOURCE = ROOT/'research/moe-mechanisms/organ_tail_attribution_v1'
ORIGINAL_SHA = {
    'plan.json':'b03e873cf4aadc83198e6d1a88aff6370b0caf970eac0dab852318dcedcbbdfa',
    'COMPLETE.json':'627e8690c16b948f047d0da3e4b8b0b4779609422443615ecd724012d661605e',
    'INDEPENDENT_AUDIT.json':'ac200d16cf5cba2fe0386e49b72fdc1f1e568db6b0b6fc16f6947feac71bee4a',
    'COLLECTED.json':'95c6dfd1f3f175e5d1a1ad43eb4dbb8d8a2718d4ac636d596d3c00a060bc344d',
    'REPORT.json':'305ad8c90732092e7b29f41571d4d0748e562477a214c3474044dcc8b5cbe9d9',
}
SETTINGS = dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',
    suffix_executions=192,decoder_block_executions=768,contexts=24,worlds=4,cells=96,
    layers=[20,21,22,23],experts=32,top_k=8,full_host_forwards=0,prefix_forwards=0,
    reader_applications=0,organ_forwards=0,writer_forwards=0,analytical_fits=0,
    backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0,
    dtype='bfloat16',device='mps',threads=4,batch_size=1,attention='eager',cache=False,
    logits_scaling=6,timeout_seconds=900,max_rss_bytes=10*1024**3,
    max_mps_driver_bytes=10*1024**3,max_archive_bytes=1024**3,
    historical_hash_tolerance=0.0)
SOURCES = ('protocol.py','suffix.py','worker.py','audit.py','owner.py','launch.py',
           'test_suffix.py','test_audit.py')
COLLECTION_EXCLUSIONS = ('owner-events.jsonl','resource-monitor.jsonl','worker.log',
                         'independent_audit.log','COLLECTED.json')
REVIEW_PATHS = (
    'work/organ-route-attribution-v1/CENSUS_SOURCE_REVIEW.json',
    'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1_PREPARATION/PREPARATION_TESTS.json',
    'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1_PREPARATION/PARENT_SOURCE_REVIEW.json')

def now():return datetime.now(timezone.utc).isoformat()
def read(path):return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def relative(path):return str(Path(path).relative_to(ROOT))
def require(ok,message):
    if not ok:raise ValueError(message)
def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def safe_path(directory,name):
    p=Path(name)
    require(not p.is_absolute() and '..' not in p.parts,'Unsafe bound path')
    result=Path(directory)/p
    require(result.resolve().is_relative_to(Path(directory).resolve()),'Bound path escapes root')
    return result

def original_plan():
    for name,h in ORIGINAL_SHA.items():require(digest(ORIGINAL/name)==h,'Original changed: '+name)
    require(not (ORIGINAL/'STOPPED.json').exists(),'Source study stopped')
    old=read(ORIGINAL/'plan.json');done=read(ORIGINAL/'COMPLETE.json')
    audit=read(ORIGINAL/'INDEPENDENT_AUDIT.json')
    require(done['status']=='TAIL_ATTRIBUTION_COMPLETE' and done['implementation_pass'] is True
        and done['baseline_replication_pass'] is True and audit['status']=='PASS',
        'Source study is not complete and admitted')
    require(done['plan_sha256']==audit['plan_sha256']==ORIGINAL_SHA['plan.json']
        and done['report_sha256']==audit['report_sha256']==ORIGINAL_SHA['REPORT.json']
        and done['independent_audit_sha256']==ORIGINAL_SHA['INDEPENDENT_AUDIT.json'],
        'Source completion chain differs')
    return old

_MODULES={}
def load_tail(name):
    require(name in ('protocol','tail'),'Unlisted tail helper')
    path=TAIL_SOURCE/(name+'.py');old=original_plan()
    require(digest(path)==old['source_sha256'][relative(path)],'Frozen tail source changed')
    if name not in _MODULES:
        spec=importlib.util.spec_from_file_location('route_census_bound_'+name,path)
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
        spec.loader.exec_module(module);_MODULES[name]=module
    return _MODULES[name]
def load_legacy(name):return load_tail('protocol').load_legacy(name)
def validate_model_files(plan):return load_tail('protocol').validate_model_files(plan)

def schedule(old):
    inventory=read(ORIGINAL/'COLLECTED.json')['artifact_sha256'];rows=[]
    for entry in old['schedule']:
        if entry['arm'] not in ('B','W'):continue
        i=len(rows);sid=entry['id']
        row=dict(entry,index=i,id=f'{i:04d}',source_id=sid)
        for kind,extension in (('call','npz'),('metadata','json')):
            local=f'calls/{sid}.{extension}'
            require(local in inventory,'Missing source capture inventory')
            row['source_'+kind+'_path']=relative(ORIGINAL/local)
            row['source_'+kind+'_sha256']=inventory[local]
            require(digest(safe_path(ORIGINAL,local))==inventory[local],'Source input hash differs')
        rows.append(row)
    require(len(rows)==192 and len({r['cell_id'] for r in rows})==96,'Census schedule differs')
    require(all(r['arm']==('B','W')[i%2] for i,r in enumerate(rows)),'Census arm order differs')
    return rows

def source_hashes():
    sources=dict(original_plan()['source_sha256'])
    for name,h in sources.items():require(digest(ROOT/name)==h,'Frozen source changed: '+name)
    for name in SOURCES:sources[relative(HERE/name)]=digest(HERE/name)
    return sources

def build_plan():
    old=original_plan()
    keys=('expected_host_state','model_path','model_cache_repository','model_files',
          'installed_model_source_sha256','contexts')
    lineage={relative(ORIGINAL/n):h for n,h in ORIGINAL_SHA.items()}
    notes=ROOT/'work/organ-route-attribution-v1'
    for name in ('SOURCE_FEASIBILITY.json','IDENTIFIABILITY_REVIEW.json',
                 'PRIOR_ART_ASSESSMENT.json','CENSUS_AUDIT_SPEC.json'):
        lineage[relative(notes/name)]=digest(notes/name)
    budget=ROOT/'outputs/routing-research/BUDGET_AFTER_JEV_FEEDBACK_AMENDED_NEGATIVE.json'
    require(digest(budget)=='8ebcaabedb7bd09cfdf63b9ccbe6c6b60cf2d31e9d753d09e9b7ec4d6975ff58','Budget basis changed')
    lineage[relative(budget)]=digest(budget)
    return dict(status='PROSPECTIVE_EXACT_SUFFIX_ROUTE_CENSUS',created_at_utc=now(),
        settings=SETTINGS,**{k:old[k] for k in keys},schedule=schedule(old),
        source_sha256=source_hashes(),lineage_sha256=lineage,
        collection_exclusions=list(COLLECTION_EXCLUSIONS),
        question='Under exact replay of the completed B/W tails, how do selected expert identities and mixture weights differ after the external supplied-answer signal?',
        design='All96 exposed context/world cells, B then W once each. Start from their saved full post-writer returned tensor. Recompute only native blocks20..23, final norm and vocabulary head. No hidden-state intervention, original prefix, reader, energy, writer, new fit, tokenizer, generation or provider call.',
        replay='Use exact full sequence dimensions, arange positions, native eager causal mask and RoPE; do not apply embedding_multiplier to the saved state. Preserve original layer indices and flags. Native final norm covers all rows; head covers last row; native logits_scaling=6.',
        admission='Before route interpretation require192/192 exact original full-vocabulary logits, full final residual, saved intermediate final rows, all recorded nonfinal hashes, and all768 full router-logit hashes. Preserve raw current traces and STOP on first mismatch. No favorable subset or tolerance change.',
        counting='192 suffix executions and768 decoder-block executions are new real model computation. There are zero full model-prefix executions and zero reader/organ/writer executions. Report partial attempted and completed counts on failure.',
        metrics='Only after complete collection and independent hash/structure audit: canonical expert-ID-aligned32-way gate vectors; final-row B/W support intersection/replacements, exact stored gate changes and L1 differences, per-layer and whole-trajectory counts over all96cells. Describe nonfinal rows separately. Report kth/next router-logit ties and gap for every row; historical support is uniquely implied only with positive boundary gap. Retain tied rows and label replay-observed supports rather than silently dropping them.',
        numerical_audit='Audit-spec mathematical contract is fixed in CENSUS_AUDIT_SPEC.json before registration. Saved gates are actual replay BF16 operands, not renormalized probabilities. Exact matching of old logits does not by itself certify an unrecorded historical tie choice or exact original gate bits.',
        interpretation='A complete descriptive census of exact-replay routes in an engineered answer channel; route changes are not evidence of their necessity, usefulness, semantic expertise, energy advantage or novelty. Repeated baseline contexts and layer rows are not independent trials. No confirmation, p-values or causal mediation fractions.',
        stop='Source, replay, shape, finiteness, ownership, resource or independent audit failure preserves STOP and raw partial records with no route interpretation; no resumption, rerun, relaxed matching or source mutation.',
        resource='One pinned model load;900seconds including audit; RSS and MPS-driver<=10GiB; archive<=1GiB. Owner cleanup and process census are mandatory.',
        budget_new_usd=0,budget_inclusive_committed_and_reserved_usd='7.6774551949',
        budget_remaining_usd='12.3225448051',novelty_established=False,
        scientific_confirmation=False,automatic_next_study=False)

def prepare():
    require(not OUT.exists(),'Already registered; never recreate')
    hashes=source_hashes()
    for path in REVIEW_PATHS:
        review=read(ROOT/path)
        require(review.get('status','').startswith('PASS'),'Missing passing preparation: '+path)
        require(review.get('source_sha256')==hashes,'Stale preparation: '+path)
    plan=build_plan()
    for path in REVIEW_PATHS:plan['lineage_sha256'][path]=digest(ROOT/path)
    validate_model_files(plan)
    OUT.mkdir()
    for path,h in hashes.items():
        target=OUT/'sources'/path;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/path,target);require(digest(target)==h,'Archived source copy differs')
    create(OUT/'plan.json',plan)
    create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)

def verify():
    plan=read(OUT/'plan.json')
    require(read(OUT/'REGISTRATION.json')['plan_sha256']==digest(OUT/'plan.json'),'Plan changed')
    require(plan['settings']==SETTINGS and plan['schedule']==schedule(original_plan()),'Settings/schedule differ')
    require(plan['source_sha256']==source_hashes(),'Bound source inventory differs')
    for field in ('source_sha256','lineage_sha256'):
        for path,h in plan[field].items():require(digest(safe_path(ROOT,path))==h,'Bound file differs: '+path)
    for path,h in plan['source_sha256'].items():
        require(digest(safe_path(OUT/'sources',path))==h,'Archived source differs')
    return plan

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare'])
    parser.parse_args();prepare()
