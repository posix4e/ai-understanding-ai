"""Invented tensors/archives only. No Torch, pretrained model or study data."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import copy
import hashlib
import json
import unittest
import numpy as np
import audit as a

def route(length=2,written=False,tied=False,unequal=False):
    support=np.tile(np.arange(8),(length,1)).astype(np.int64)
    if written:support[-1]=np.arange(8,16)
    logits=np.zeros((length,32),dtype=np.float32)
    for i,ids in enumerate(support):
        logits[i,ids]=0 if tied else (np.arange(8,0,-1) if unequal else 1)
    values=np.take_along_axis(logits,support,axis=1).astype(np.float64)
    q=np.exp(values-values.max(axis=1,keepdims=True));q/=q.sum(axis=1,keepdims=True)
    gates=a.bf16(q.astype(np.float32));order=np.argsort(support.flatten(),kind='stable').astype(np.int64)
    sizes=np.bincount(support.flatten(),minlength=32).astype(np.int64)
    return order,order//8,gates.flatten()[order],sizes,logits

def write_bundle(path,arrays,metadata,shapes):
    path.parent.mkdir(parents=True,exist_ok=True);members={};meta=copy.deepcopy(metadata);meta['tensors']={}
    for name,(dtype,shape) in shapes.items():
        value=np.asarray(arrays[name])
        if dtype=='torch.bfloat16':raw=(value.view(np.uint32)>>16).astype('<u2').view(np.uint8).reshape(-1)
        else:raw=value.tobytes();raw=np.frombuffer(raw,dtype=np.uint8)
        rk,vk=name+'__raw_uint8',name+'__value';members[rk]=raw;members[vk]=value
        meta['tensors'][name]=dict(dtype=dtype,shape=list(shape),raw_key=rk,value_key=vk,raw_sha256=a.raw_hash(raw))
    np.savez(path,**members);mp=path.with_suffix('.json');mp.write_text(json.dumps(meta))
    return meta

def fabricated_call(entry,length=2):
    shapes=a.call_shapes(length,64)
    arrays={n:np.zeros(s,dtype=np.int64 if dtype=='torch.int64' else np.float32) for n,(dtype,s) in shapes.items()}
    arrays['input_ids']=np.array([[0,1]],dtype=np.int64)
    arrays['cache_position']=np.arange(length,dtype=np.int64);arrays['position_ids']=np.arange(length,dtype=np.int64)[None]
    minimum=np.array(0xff7f0000,dtype=np.uint32).view(np.float32)
    arrays['mask']=np.triu(np.full((length,length+1),minimum,dtype=np.float32),k=1)[None,None]
    if entry['arm']=='W':arrays['returned'][:,-1:]=1
    arrays['final_residual']=arrays['returned'].copy()
    arrays['rope_cos'].fill(1)
    for l in a.LAYERS:
        for n in ('residual_input','after_attention','after_moe'):arrays[f'b{l}_{n}']=arrays['returned'][:,-1:].copy()
        for name,value in zip(('order','tokens','gates','sizes','logits'),route(length,entry['arm']=='W')):arrays[f'b{l}_route_{name}']=value
    sites={};observed={}
    zero_hash=hashlib.sha256(bytes((length-1)*1024*2)).hexdigest()
    for l in a.LAYERS:
        for part in ('attn','moe'):
            aux=[None] if part=='attn' else [dict(dtype='torch.float32',shape=[length,32],raw_sha256=a.raw_hash(arrays[f'b{l}_route_logits']))]
            sites[f'b{l}_{part}']=dict(shape=[1,length,1024],dtype='torch.bfloat16',device='mps',nonfinal_before_sha256=zero_hash,
                nonfinal_after_sha256=zero_hash,auxiliary_before=aux,auxiliary_after=copy.deepcopy(aux),auxiliary_objects_preserved=True,replayed=False)
        for n in ('residual_input','after_attention','after_moe'):observed[f'b{l}_{n}']=dict(shape=[1,length,1024],dtype='torch.bfloat16',device='mps',nonfinal_sha256=zero_hash)
    observed['final_residual']=dict(shape=[1,length,1024],dtype='torch.bfloat16',device='mps',nonfinal_sha256=zero_hash)
    info=dict(suffix_completed=True,component_counts=a.component_counts(),tail_entries=dict.fromkeys([*a.SITES,*observed],1),
        tail_sites=sites,tail_observations=observed,residual_multipliers={str(l):.22 for l in a.LAYERS})
    return arrays,info

def fixture(root):
    out=root/'new';out.mkdir();plan_sha='f'*64
    contexts=[dict(id=f's{s}-a{x}',state=s,action=x,prompt=f"World state {s}. Actions {'XYZ'[x]}. Next state:",input_ids=[0,1]) for s in range(8) for x in range(3)]
    inventory={f'calls/{i*6+j:04d}.{ext}':'0'*64 for i in range(96) for j in (0,1) for ext in ('npz','json')}
    schedule=a.expected_schedule(contexts,inventory)
    plan=dict(contexts=contexts,schedule=schedule,expected_host_state=dict.fromkeys(a.expected_state_keys(),'c'*64),installed_model_source_sha256='d'*64)
    params=a.expected_state_keys()-{'lm_head.weight'}
    cfg=dict(hidden_size=1024,num_attention_heads=16,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,
        logits_scaling=6,use_cache=True,output_attentions=False,output_hidden_states=False,output_router_logits=False,residual_multiplier=.22)
    before=dict(requires_grad={'host':dict.fromkeys(params,True)},grad_none={'host':dict.fromkeys(params,True)},
        hooks={'host':{}},training={'host':{'':False}},forward_methods={'host':{'':[123,False]}},host_config=cfg)
    during=copy.deepcopy(before);during['requires_grad']['host']=dict.fromkeys(params,False);during['host_config']['use_cache']=False
    samples=[];events=[]
    for kind,payload in a.expected_events(schedule):
        row=dict(event=kind,at_utc='2026-10-06T00:00:00+00:00')
        if kind=='resources':
            sample=dict(stage=payload,elapsed_seconds=len(samples)/1000,rss_high_water_bytes=10,mps_driver_bytes=10,archive_bytes=10)
            row.update(sample);samples.append(sample)
        elif isinstance(payload,dict):row.update(payload)
        if kind=='call_saved':row['controls_pass']=True
        if kind=='worker_completed':row['counts']=a.counts()
        events.append(row)
    lookup={r['stage']:r for r in samples};calls=[]
    for entry in schedule:
        arrays,info=fabricated_call(entry);oldentry={k:entry[k] for k in ('cell_id','context_id','world_id','arm')}
        oldmeta=dict(**oldentry,id=entry['source_id'],index=int(entry['source_id']),plan_sha256=a.ORIGINAL_SHA['plan.json'],forward_completed=True,**info)
        oldpath=root/entry['source_call_path'];write_bundle(oldpath,arrays,oldmeta,a.historical_shapes(2))
        for kind,path in [('call',oldpath),('metadata',oldpath.with_suffix('.json'))]:entry['source_'+kind+'_sha256']=a.digest(path)
        path=out/'calls'/f"{entry['id']}.npz";write_bundle(path,arrays,dict(**entry,plan_sha256=plan_sha,**info),a.call_shapes(2,64))
        comparisons=dict.fromkeys([*a.historical_shapes(2),'tail_entries','tail_sites','tail_observations','residual_multipliers',*[f'b{l}_full_router_sha256' for l in a.LAYERS]],True)
        calls.append(dict(**entry,**info,forward_path=str(path.relative_to(out)),forward_metadata_path=str(path.with_suffix('.json').relative_to(out)),
            forward_sha256=a.digest(path),forward_metadata_sha256=a.digest(path.with_suffix('.json')),comparisons=comparisons,
            resources_before=lookup['before:'+entry['id']],resources_after=lookup['after:'+entry['id']],controls_pass=True,error=None))
    # Schedule source hashes were filled after the initial event construction.
    byid={e['id']:e for e in schedule}
    for row in events:
        if 'id' in row:row.update(byid[row['id']])
    complete=dict(status='WORKER_COMPLETED',plan_sha256=plan_sha,counts=a.counts(),states_before={'host':plan['expected_host_state']},states_after={'host':plan['expected_host_state']},
        identities_before=before,identities_during=during,identities_after=copy.deepcopy(before),
        checks=dict(ownership_restored=True,states_unchanged=True,cache_unchanged=True,exact_counts=True),resource_samples=samples,elapsed_seconds=1,
        analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)
    for name,data in [('WORKER_COMPLETE.json',complete),('RUNTIME.json',dict(plan_sha256=plan_sha,**{k:a.SETTINGS[k] for k in ('python','torch','transformers','numpy')},seed=42,threads=4,device='mps',dtype='bfloat16',attention='eager',cache=False,output_attentions=False,output_hidden_states=False,output_router_logits=False,logits_scaling=6,installed_model_source_sha256=plan['installed_model_source_sha256']))]:
        (out/name).write_text(json.dumps(data))
    (out/'calls.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in calls));(out/'worker-events.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in events))
    return out,plan,plan_sha,calls

class NumericalTests(unittest.TestCase):
    def test_identity_not_rank(self):
        b=a.canonical_route(*route(2,False,unequal=True));w=a.canonical_route(*route(2,True,unequal=True))
        self.assertEqual(b['rows'][-1]['selected_ids'],list(range(8)))
        e=dict(cell_id='x',context_id='y',world_id='dev00');r=a.compare_routes(b,w,e,20)
        self.assertEqual(r['overlap'],0);self.assertGreater(r['L1'],1.9);self.assertTrue(r['nonfinal_support_equal'])
    def test_gate_rank_corruption(self):
        parts=list(route(2,False,unequal=True));parts[2]=parts[2][::-1].copy()
        with self.assertRaises(a.AuditError):a.canonical_route(*parts)
    def test_duplicate_permutation(self):
        parts=list(route());parts[0][0]=parts[0][1]
        with self.assertRaises(a.AuditError):a.canonical_route(*parts)
    def test_wrong_expert_count(self):
        parts=list(route());parts[3][0]+=1
        with self.assertRaises(a.AuditError):a.canonical_route(*parts)
    def test_topk_boundary_ties_retained(self):
        b=a.canonical_route(*route(1,False,tied=True));w=a.canonical_route(*route(1,True,tied=True))
        self.assertFalse(b['rows'][0]['historical_support_unique']);self.assertEqual(a.overlap_bounds(b['rows'][0],w['rows'][0]),(0,8))
    def test_strict_cutoff_unique(self):
        b=a.canonical_route(*route());self.assertEqual(b['rows'][-1]['boundary_gap_fraction'],'1');self.assertTrue(b['rows'][-1]['historical_support_unique'])
    def test_rne_midpoint_parity(self):
        midpoint=(.5+float(np.array(0x3f010000,dtype=np.uint32).view(np.float32)))/2
        self.assertTrue(a.gate_rounding_check(np.float32(.5),midpoint)['ambiguous'])
        self.assertTrue(a.gate_rounding_check(np.array(0x3f010000,dtype=np.uint32).view(np.float32),midpoint)['ambiguous'])
        with self.assertRaises(a.AuditError):a.gate_rounding_check(np.float32(.25),midpoint)
    def test_underflow_and_negative_zero(self):
        self.assertIsInstance(a.gate_rounding_check(np.float32(0),0),dict)
        with self.assertRaises(a.AuditError):a.gate_rounding_check(np.float32(-0.),0)
    def test_selected_zero_is_membership(self):
        parts=list(route(1));parts[4][0,:8]=[0,-200,-200,-200,-200,-200,-200,-200];parts[4][0,8:]=-300
        parts[2]=np.array([1,0,0,0,0,0,0,0],dtype=np.float32)
        r=a.canonical_route(*parts);self.assertEqual(len(r['rows'][0]['selected_ids']),8);self.assertEqual(np.count_nonzero(r['dense']),1)
    def test_raw_dtype_and_signedzero(self):
        raw=np.frombuffer(bytes.fromhex('0080'),dtype=np.uint8);v=a.decode(raw,'torch.bfloat16',(1,))
        self.assertTrue(np.signbit(v[0]));self.assertFalse(a.exact(v,np.zeros(1,dtype=np.float32)))
        with self.assertRaises(a.AuditError):a.decode(raw,'torch.float32',(1,))
    def test_nonfinite_logit(self):
        parts=list(route());parts[4][0,0]=np.nan
        with self.assertRaises(a.AuditError):a.canonical_route(*parts)
    def test_summary_missing_pair(self):
        with self.assertRaises(a.AuditError):a.summarize([])
    def test_partial_publication_retained(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'REPORT.json').write_bytes(b'{broken')
            result=a.preserve_invalid_publications(p)
            self.assertEqual((p/'INVALID_REPORT.json').read_bytes(),b'{broken');self.assertEqual(result['REPORT.json']['sha256'],a.digest(p/'INVALID_REPORT.json'))

class FullArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=TemporaryDirectory();cls.root=Path(cls.temp.name);cls.out,cls.plan,cls.sha,cls.calls=fixture(cls.root)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_complete192_loader_before_summary(self):
        r=a.audit_records(self.out,self.plan,self.sha,root=self.root)
        self.assertTrue(r['implementation_pass']);self.assertEqual(len(r['paired_rows']),384)
        self.assertEqual(r['historical_full_router_hash_matches'],768)
        self.assertEqual(r['per_layer']['20']['overlap_histogram']['0'],96)
        self.assertNotIn('scores',r);self.assertEqual(r['counts']['full_host_forwards'],0)
    def test_missing_call_closes_before_decode_or_census(self):
        with patch.object(a,'jsonl',return_value=self.calls[:-1]),patch.object(a,'load_call') as load,patch.object(a,'canonical_route') as route_check:
            with self.assertRaises(a.AuditError):a.audit_records(self.out,self.plan,self.sha,root=self.root)
            load.assert_not_called();route_check.assert_not_called()
    def test_last_historical_failure_prevents_any_census(self):
        original=a.load_call
        def loader(*args,**kwargs):
            if args[2]['index']==191:raise a.AuditError('invented last replay mismatch')
            return original(*args,**kwargs)
        with patch.object(a,'load_call',side_effect=loader),patch.object(a,'canonical_route') as route_check:
            with self.assertRaises(a.AuditError):a.audit_records(self.out,self.plan,self.sha,root=self.root)
            route_check.assert_not_called()
    def test_source_pointer_hash_corruption(self):
        entry=copy.deepcopy(self.plan['schedule'][0]);row=copy.deepcopy(self.calls[0]);entry['source_call_sha256']='a'*64;row['source_call_sha256']='a'*64
        with self.assertRaises(a.AuditError):a.load_call(self.out,row,entry,self.plan['contexts'][0],self.sha,self.root)
    def test_wrong_recorded_dtype(self):
        row=copy.deepcopy(self.calls[0]);path=self.out/row['forward_metadata_path'];original=path.read_bytes();meta=json.loads(original);meta['tensors']['returned']['dtype']='torch.float32'
        try:
            path.write_text(json.dumps(meta));row['forward_metadata_sha256']=a.digest(path)
            with self.assertRaises(a.AuditError):a.load_call(self.out,row,self.plan['schedule'][0],self.plan['contexts'][0],self.sha,self.root)
        finally:path.write_bytes(original)
    def test_historical_router_sha_mismatch(self):
        entry=self.plan['schedule'][0];values,info=fabricated_call(entry)
        raw={n:np.frombuffer(v.tobytes(),dtype=np.uint8) for n,v in values.items()}
        oldmeta=dict(**info,id=entry['source_id'],arm='B',plan_sha256=a.ORIGINAL_SHA['plan.json'])
        newmeta=copy.deepcopy(oldmeta);newmeta['tail_sites']['b20_moe']['auxiliary_before'][0]['raw_sha256']='0'*64
        with self.assertRaises(a.AuditError):a.compare_historical(values,raw,newmeta,values,raw,oldmeta,entry)
    def test_owner_event_resource_failure(self):
        complete=a.read(self.out/'WORKER_COMPLETE.json');events=a.jsonl(self.out/'worker-events.jsonl');events[1]['rss_high_water_bytes']=a.MEMORY_LIMIT+1
        with self.assertRaises(a.AuditError):a.validate_events(events,self.plan['schedule'],complete)
    def test_parameter_restoration_failure(self):
        complete=a.read(self.out/'WORKER_COMPLETE.json');complete['identities_after']['requires_grad']['host']['model.norm.weight']=False
        with self.assertRaises(a.AuditError):a.validate_ownership(complete,self.plan)
    def test_numeric_native_scale_is_not_an_integer_count(self):
        complete=a.read(self.out/'WORKER_COMPLETE.json')
        for phase in ('before','during','after'):complete['identities_'+phase]['host_config']['logits_scaling']=6.0
        a.validate_ownership(complete,self.plan)
        path=self.out/'RUNTIME.json';old=path.read_bytes();runtime=json.loads(old)
        try:
            runtime['logits_scaling']=6.0;path.write_text(json.dumps(runtime));a.validate_runtime(self.out,self.plan,self.sha)
            runtime['logits_scaling']=True;path.write_text(json.dumps(runtime))
            with self.assertRaises(a.AuditError):a.validate_runtime(self.out,self.plan,self.sha)
        finally:path.write_bytes(old)

if __name__=='__main__':unittest.main()
