"""Invented CPU tensors and fake modules only; no checkpoint or scientific inputs."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import tempfile
import types
import unittest
from unittest import mock

import numpy as np
import torch
import suffix as s
import worker as w

ROOT = Path(__file__).resolve().parents[3]


def module(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


TAIL = module('census_test_old_tail', 'research/moe-mechanisms/organ_tail_attribution_v1/tail.py')
ASSEMBLY = module('assembly', 'research/moe-mechanisms/organ_live_energy_v1/assembly.py')
LEGACY = module('census_test_old_worker', 'research/moe-mechanisms/organ_live_energy_v1/worker.py')
torch.set_num_threads(4)
OPERATIONS = dict(suffixes=0, blocks=0, routers=0, head=0)


class Config:
    use_cache = False
    _attn_implementation = 'eager'
    output_attentions = False
    output_hidden_states = False
    output_router_logits = False
    logits_scaling = 6

    def to_dict(self):
        return {name: getattr(self, name) for name in ('use_cache', '_attn_implementation',
            'output_attentions', 'output_hidden_states', 'output_router_logits', 'logits_scaling')}


class Router(torch.nn.Module):
    def forward(self, hidden):
        OPERATIONS['routers'] += 1
        n = hidden.shape[1]
        logits = torch.arange(32, dtype=torch.float32).repeat(n, 1)
        logits = logits + hidden[0, :, :1].float() / 32
        selected, ids = logits.topk(8, dim=1)
        gates = selected.softmax(-1).to(torch.bfloat16)
        flat = ids.flatten()
        order = flat.argsort()
        result = (order, order // 8, gates.flatten()[order],
                  flat.bincount(minlength=32).tolist(), logits)
        self.last = result
        return result


class Attention(torch.nn.Module):
    def forward(self, hidden):
        return hidden * .125, None


class MoE(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.router = Router()

    def forward(self, hidden):
        route = self.router(hidden)
        return hidden * .25, route[-1]


class Block(torch.nn.Module):
    residual_multiplier = .22

    def __init__(self):
        super().__init__()
        self.self_attn = Attention()
        self.block_sparse_moe = MoE()
        self.post_attention_layernorm = torch.nn.Identity()
        self.fail = False

    def forward(self, hidden, **kwargs):
        OPERATIONS['blocks'] += 1
        self.kwargs = kwargs
        if self.fail:
            raise RuntimeError('invented decoder failure')
        output = hidden + self.self_attn(hidden)[0] * self.residual_multiplier
        return (output + self.block_sparse_moe(self.post_attention_layernorm(output))[0]
                * self.residual_multiplier,)


class Forbidden(torch.nn.Module):
    def forward(self, *args, **kwargs):
        raise AssertionError('prefix/embedding/full-host execution forbidden')


class Backbone(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = torch.nn.ModuleList([Forbidden() for _ in range(20)] + [Block() for _ in range(4)])
        self.norm = torch.nn.Identity()
        self.embed_tokens = Forbidden()

    def _update_causal_mask(self, attention_mask, hidden, cache_position, past, output_attentions):
        OPERATIONS['suffixes'] += 1
        self.mask_args = (attention_mask, past, output_attentions)
        self.cache_position = cache_position.clone()
        n = hidden.shape[1]
        return torch.triu(torch.full((1, 1, n, n+1), torch.finfo(torch.bfloat16).min,
                                    dtype=torch.bfloat16), diagonal=1)

    def rotary_emb(self, hidden, position_ids):
        self.rope_ids = position_ids.clone()
        shape = (1, hidden.shape[1], 64)
        return torch.ones(shape, dtype=torch.bfloat16), torch.zeros(shape, dtype=torch.bfloat16)


class Head(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.nan = False

    def forward(self, hidden):
        OPERATIONS['head'] += 1
        self.shape = tuple(hidden.shape)
        value = torch.zeros((1, 1, 49155), dtype=torch.bfloat16)
        value[..., :1024] = hidden
        if self.nan:
            value[..., 3] = float('nan')
        return value


class Host(Forbidden):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
        self.config = Config()
        self.model = Backbone()
        self.lm_head = Head()
        self.eval()


def invented_input():
    h = (torch.arange(3*1024).reshape(1, 3, 1024) % 19).to(torch.bfloat16) / 8
    h[..., 50] = -0.0
    return h, torch.tensor([[0, 1, 2]], dtype=torch.int64)


def capture(host=None, callback=lambda *args: None):
    return s.collect_suffix(host or Host(), *invented_input(), TAIL, on_component=callback)


def source_fixture(host=None):
    values, info, error, tail = capture(host)
    if error:
        raise error
    source = {name: values[name].clone() for name in w.source_names(TAIL)}
    return source, copy.deepcopy(info), tail


def context(temp, n=1):
    root = Path(temp)
    out = root / 'new'; out.mkdir()
    old = root / 'original'; old.mkdir()
    (out / 'plan.json').write_text('{}')
    p = types.SimpleNamespace(ROOT=root, OUT=out, ORIGINAL=old, digest=LEGACY.digest,
                              read=lambda path: json.loads(Path(path).read_text()))
    schedule = [dict(index=i, id=f'{i:04d}', source_id=f'{i*3:04d}', cell_id=f'cell{i//2}',
        context_id='invented', world_id='invented-world', arm=('B','W')[i % 2]) for i in range(n)]
    plan = dict(contexts=[dict(id='invented', input_ids=[0, 1, 2])], schedule=schedule)
    return p, plan


def execute(p, plan, host, source, meta, event=lambda *a, **kw: None, guard=lambda v: None):
    counts = w.initial_counts()
    modules = dict(host=host)
    with mock.patch.object(w, 'load_source', return_value=(source, meta)):
        w.run_calls(modules, plan, p, TAIL, LEGACY, LEGACY.identity(modules), event,
                    lambda stage: dict(stage=stage), guard, counts)
    return counts


class SuffixTests(unittest.TestCase):
    def test_exact_native_boundaries_counts_and_no_full_host(self):
        host = Host(); before = LEGACY.identity(dict(host=host))
        events = []
        values, info, failure, tail = capture(host, lambda *x: events.append(x))
        self.assertIsNone(failure)
        self.assertEqual(info['component_counts'], {k: v for k, v in w.expected_counts(1).items()
                                                   if k in s.component_counts()})
        self.assertEqual(len(events), 40)
        self.assertEqual(before, LEGACY.identity(dict(host=host)))
        self.assertEqual(host.model.mask_args, (None, None, False))
        self.assertEqual(host.model.rope_ids.tolist(), [[0, 1, 2]])
        self.assertEqual(host.lm_head.shape, (1, 1, 1024))
        self.assertEqual(w.raw(values['returned']), w.raw(invented_input()[0]))
        self.assertEqual(w.raw(values['full_logits'][:1024]), w.raw(values['final_residual'][0, -1] / 6))
        for block in host.model.layers[20:]:
            self.assertEqual(set(block.kwargs), {'attention_mask','position_ids','past_key_values',
                'output_attentions','use_cache','cache_position','output_router_logits','position_embeddings'})
            self.assertEqual(tuple(block.kwargs['attention_mask'].shape), (1, 1, 3, 4))
            self.assertIsNone(block.kwargs['past_key_values'])
            for field in ('output_attentions','use_cache','output_router_logits'):
                self.assertIs(block.kwargs[field], False)
        source = {k: values[k] for k in w.source_names(TAIL)}
        self.assertTrue(all(w.validate(values, info, tail, source, info).values()))

    def test_actual_router_tuple_is_retained_without_topk_relabeling(self):
        host = Host(); values, _, failure, _ = capture(host)
        self.assertIsNone(failure)
        for layer in s.LAYERS:
            route = host.model.layers[layer].block_sparse_moe.router.last
            for name, value in zip(('order','tokens','gates','sizes','logits'), route):
                expected = torch.tensor(value) if name == 'sizes' else value
                self.assertEqual(w.raw(values[f'b{layer}_route_{name}']), w.raw(expected))
            order = values[f'b{layer}_route_order']
            self.assertEqual(sorted(order.tolist()), list(range(24)))
            self.assertEqual(values[f'b{layer}_route_tokens'].tolist(), (order // 8).tolist())

    def test_partial_decoder_failure_counts_and_hook_cleanup(self):
        host = Host(); host.model.layers[22].fail = True
        before = LEGACY.identity(dict(host=host))
        values, info, failure, _ = capture(host)
        self.assertIsInstance(failure, RuntimeError)
        self.assertEqual(info['component_counts']['decoder_attempts'], 3)
        self.assertEqual(info['component_counts']['decoder_finished'], 2)
        self.assertIn('b21_route_logits', values)
        self.assertNotIn('full_logits', values)
        self.assertEqual(before, LEGACY.identity(dict(host=host)))

    def test_finished_journal_failure_preserves_returned_operation(self):
        def fail(name, phase, layer):
            if (name, phase, layer) == ('router','finished',20):
                raise OSError('invented journal failure')
        host = Host(); before = LEGACY.identity(dict(host=host))
        values, info, failure, _ = capture(host, fail)
        self.assertIsInstance(failure, OSError)
        self.assertEqual(info['component_counts']['router_finished'], 1)
        self.assertIn('b20_route_logits', values)
        self.assertEqual(before, LEGACY.identity(dict(host=host)))

    def test_nonfinite_return_retained_then_rejected(self):
        host = Host(); host.lm_head.nan = True
        values, info, failure, tail = capture(host)
        self.assertIsNone(failure)
        self.assertTrue(info['suffix_completed'])
        self.assertTrue(torch.isnan(values['full_logits'][3]))
        with self.assertRaisesRegex(ValueError, 'Nonfinite replay tensor'):
            w.validate(values, info, tail, {k: values[k] for k in w.source_names(TAIL)}, info)

    def test_invalid_entry_or_flags_execute_no_suffix(self):
        host = Host(); host.config.use_cache = True
        _, info, failure, _ = capture(host)
        self.assertIsInstance(failure, ValueError)
        self.assertEqual(info['component_counts'], s.component_counts())
        _, info, failure, _ = s.collect_suffix(Host(), invented_input()[0].float(), invented_input()[1], TAIL)
        self.assertIsInstance(failure, ValueError)
        self.assertEqual(info['component_counts'], s.component_counts())

    def test_exact_historical_router_and_nonfinal_hash_required(self):
        values, info, _, tail = capture()
        src = {k: values[k] for k in w.source_names(TAIL)}
        for field in ('router', 'nonfinal'):
            changed = copy.deepcopy(info)
            if field == 'router':
                changed['tail_sites']['b20_moe']['auxiliary_before'][0]['raw_sha256'] = '0'*64
            else:
                changed['tail_observations']['b20_after_attention']['nonfinal_sha256'] = '0'*64
            with self.assertRaisesRegex(ValueError, 'Historical exact replay differs'):
                w.validate(values, info, tail, src, changed)


class ArchiveTests(unittest.TestCase):
    def make_archive(self, temp):
        p, plan = context(temp); entry = plan['schedule'][0]
        src, info, _ = source_fixture()
        metadata = dict(info, id=entry['source_id'], index=int(entry['source_id']),
            **{k: entry[k] for k in ('cell_id','context_id','world_id','arm')}, forward_completed=True)
        pointers = LEGACY.retain(p.ORIGINAL, 'saved', src, metadata)
        for kind, key in (('call','forward'),('metadata','forward_metadata')):
            entry['source_'+kind+'_path'] = 'original/' + pointers[key+'_path']
            entry['source_'+kind+'_sha256'] = pointers[key+'_sha256']
        return p, entry, src

    def test_exact_source_raw_readable_roundtrip(self):
        with tempfile.TemporaryDirectory() as temp:
            p, entry, src = self.make_archive(temp)
            got, _ = w.load_source(p, entry, TAIL)
            self.assertEqual(set(got), w.source_names(TAIL))
            self.assertTrue(all(w.raw(got[k]) == w.raw(src[k]) for k in got))
            self.assertTrue(torch.signbit(got['returned'][0,0,50]))

    def test_source_paths_hashes_schedule_fail_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            p, entry, _ = self.make_archive(temp)
            for key, val in (('source_call_path','../outside.npz'), ('source_call_sha256','0'*64),
                             ('source_id','9999'), ('arm','D')):
                bad = dict(entry); bad[key] = val
                with self.assertRaises(ValueError):
                    w.load_source(p, bad, TAIL)

    def test_readable_signed_zero_corruption_rejected_even_rebound_file(self):
        with tempfile.TemporaryDirectory() as temp:
            p, entry, _ = self.make_archive(temp)
            path = p.ROOT / entry['source_call_path']
            with np.load(path, allow_pickle=False) as z:
                arrays = {k: z[k] for k in z.files}
            arrays['returned__value'][0,0,50] = 0.0
            with path.open('wb') as f:
                np.savez_compressed(f, **arrays)
            entry['source_call_sha256'] = LEGACY.digest(path)
            with self.assertRaisesRegex(ValueError, 'raw/readable disagreement'):
                w.load_source(p, entry, TAIL)

    def test_full_192_controlflow_archives_and_counts(self):
        source, meta, _ = source_fixture(); events = []
        with tempfile.TemporaryDirectory() as temp:
            p, plan = context(temp, 192)
            host = Host()
            before = LEGACY.identity(dict(host=host))
            counts = execute(p, plan, host, source, meta, lambda name, **kw: events.append((name, kw)))
            self.assertEqual(counts, w.expected_counts())
            rows = [json.loads(x) for x in (p.OUT/'calls.jsonl').read_text().splitlines()]
            self.assertEqual(len(rows), 192)
            self.assertTrue(all(r['controls_pass'] and all(r['comparisons'].values()) for r in rows))
            self.assertEqual(len(list((p.OUT/'calls').glob('*.npz'))), 192)
            self.assertEqual(len(events), 192*43)
            self.assertEqual(before, LEGACY.identity(dict(host=host)))
            last = rows[-1]
            self.assertEqual(LEGACY.digest(p.OUT/last['forward_path']), last['forward_sha256'])
            self.assertEqual(LEGACY.digest(p.OUT/last['forward_metadata_path']), last['forward_metadata_sha256'])

    def test_guard_failure_keeps_return_before_control_row(self):
        source, meta, _ = source_fixture()
        with tempfile.TemporaryDirectory() as temp:
            p, plan = context(temp, 2)
            def guard(sample):
                if sample['stage'].startswith('after:'):
                    raise RuntimeError('invented resource ceiling')
            with self.assertRaisesRegex(RuntimeError, 'resource ceiling'):
                execute(p, plan, Host(), source, meta, guard=guard)
            rows = [json.loads(x) for x in (p.OUT/'calls.jsonl').read_text().splitlines()]
            self.assertEqual(len(rows), 1)
            self.assertFalse(rows[0]['controls_pass'])
            self.assertTrue(rows[0]['suffix_completed'])
            self.assertTrue((p.OUT/rows[0]['forward_path']).is_file())

    def test_suffix_finish_journal_error_still_durable(self):
        source, meta, _ = source_fixture()
        with tempfile.TemporaryDirectory() as temp:
            p, plan = context(temp, 2)
            def event(name, **kw):
                if name == 'suffix_finished':
                    raise OSError('invented finish journal error')
            with self.assertRaisesRegex(OSError, 'finish journal'):
                execute(p, plan, Host(), source, meta, event)
            row = json.loads((p.OUT/'calls.jsonl').read_text())
            self.assertTrue(row['suffix_completed'])
            self.assertFalse(row['controls_pass'])
            self.assertTrue((p.OUT/row['forward_metadata_path']).exists())

    def test_storage_failure_does_not_erase_finished_counts(self):
        source, meta, _ = source_fixture()
        with tempfile.TemporaryDirectory() as temp:
            p, plan = context(temp); host = Host(); counts = w.initial_counts()
            with mock.patch.object(w,'load_source',return_value=(source,meta)), \
                 mock.patch.object(LEGACY,'retain',side_effect=OSError('invented disk failure')):
                with self.assertRaisesRegex(OSError, 'disk failure'):
                    w.run_calls(dict(host=host), plan, p, TAIL, LEGACY, LEGACY.identity(dict(host=host)),
                        lambda *a, **kw: None, lambda stage: dict(stage=stage), lambda v: None, counts)
            self.assertEqual(counts, w.expected_counts(1))

    def test_historical_failure_stops_before_next_suffix(self):
        source, meta, _ = source_fixture()
        meta['tail_observations']['b20_after_attention']['nonfinal_sha256'] = '0'*64
        with tempfile.TemporaryDirectory() as temp:
            p, plan = context(temp, 2)
            with self.assertRaisesRegex(ValueError, 'Historical exact replay'):
                execute(p, plan, Host(), source, meta)
            rows = (p.OUT/'calls.jsonl').read_text().splitlines()
            self.assertEqual(len(rows), 1)
            self.assertFalse(json.loads(rows[0])['controls_pass'])
            self.assertEqual(len(list((p.OUT/'calls').glob('*.npz'))), 1)


if __name__ == '__main__':
    try:
        unittest.main()
    finally:
        print('INVENTED_OPERATION_COUNTS=' + json.dumps(OPERATIONS, sort_keys=True))
