"""Native full-sequence blocks20..23 only; observation never replaces a value."""
import torch

LAYERS = (20, 21, 22, 23)
COMPONENTS = ('mask', 'rope', 'decoder', 'attention', 'moe', 'router', 'final_norm', 'head')


def component_counts():
    return {name + '_' + phase: 0 for name in COMPONENTS for phase in ('attempts', 'finished')}


def collect_suffix(model, hidden, ids, tail_module, on_start=lambda: None,
                   on_component=lambda name, phase, layer: None):
    """Return available raw evidence on every ordinary exception, then clean hooks.

    The caller retains evidence before validating it. No original full-model,
    embedding, tokenizer, writer, reader or organ forward is invoked here.
    """
    values = {'input_ids': ids.detach().cpu().clone(),
              'returned': hidden.detach().cpu().clone()}
    counts = component_counts()
    handles = []
    tail = tail_module.TailReplay(model)
    finished = False
    failure = None

    def mark(name, phase, layer=None):
        counts[name + '_' + ('attempts' if phase == 'started' else 'finished')] += 1
        on_component(name, phase, layer)

    def pre(name, layer, args):
        mark(name, 'started', layer)
        if name == 'moe':
            values[f'b{layer}_moe_input'] = args[0].detach().cpu().clone()

    def post(name, layer, output):
        # Count a returned operation even if retention or journaling fails.
        counts[name + '_finished'] += 1
        if name == 'router':
            for key, value in zip(('order', 'tokens', 'gates', 'sizes', 'logits'), output):
                if key == 'sizes':
                    value = torch.tensor(value, dtype=torch.int64)
                values[f'b{layer}_route_{key}'] = value.detach().cpu().clone()
        on_component(name, 'finished', layer)

    try:
        if (hidden.dtype != torch.bfloat16 or hidden.ndim != 3 or hidden.shape[0] != 1
                or hidden.shape[2] != 1024 or ids.dtype != torch.int64
                or tuple(ids.shape) != tuple(hidden.shape[:2])):
            raise ValueError('Invalid full-sequence suffix entry')
        cfg = model.config
        if (cfg.use_cache is not False or cfg._attn_implementation != 'eager'
                or cfg.output_attentions is not False or cfg.output_hidden_states is not False
                or cfg.output_router_logits is not False or cfg.logits_scaling != 6
                or len(model.model.layers) != 24 or model.training):
            raise ValueError('Native suffix flags differ')
        if model.model.rotary_emb is None:
            raise ValueError('Missing native RoPE')
        for layer in LAYERS:
            block = model.model.layers[layer]
            for name, module in (('decoder', block), ('attention', block.self_attn),
                                 ('moe', block.block_sparse_moe), ('router', block.block_sparse_moe.router)):
                handles.append(module.register_forward_pre_hook(
                    lambda m, a, n=name, l=layer: pre(n, l, a)))
                handles.append(module.register_forward_hook(
                    lambda m, a, o, n=name, l=layer: post(n, l, o)))
        on_start()
        with torch.no_grad(), tail:
            cache_position = torch.arange(hidden.shape[1], device=hidden.device)
            position_ids = cache_position.unsqueeze(0)
            values['cache_position'] = cache_position.detach().cpu().clone()
            values['position_ids'] = position_ids.detach().cpu().clone()
            mark('mask', 'started')
            mask = model.model._update_causal_mask(None, hidden, cache_position, None, False)
            counts['mask_finished'] += 1
            if isinstance(mask, torch.Tensor):
                values['mask'] = mask.detach().cpu().clone()
            on_component('mask', 'finished', None)
            mark('rope', 'started')
            position_embeddings = model.model.rotary_emb(hidden, position_ids)
            counts['rope_finished'] += 1
            values['rope_cos'] = position_embeddings[0].detach().cpu().clone()
            values['rope_sin'] = position_embeddings[1].detach().cpu().clone()
            on_component('rope', 'finished', None)
            current = hidden
            for layer in LAYERS:
                current = model.model.layers[layer](current, attention_mask=mask,
                    position_ids=position_ids, past_key_values=None, output_attentions=False,
                    use_cache=False, cache_position=cache_position, output_router_logits=False,
                    position_embeddings=position_embeddings)[0]
            mark('final_norm', 'started')
            current = model.model.norm(current)
            mark('final_norm', 'finished')
            mark('head', 'started')
            logits = model.lm_head(current[:, -1:, :])
            counts['head_finished'] += 1
            # Preserve the native shape and division boundary used by logits_to_keep=1.
            logits = logits / cfg.logits_scaling
            values['full_logits'] = logits[0, -1].detach().cpu().clone()
            finished = True
            on_component('head', 'finished', None)
    except BaseException as exc:
        failure = exc
    finally:
        for handle in reversed(handles):
            handle.remove()
        tail.close()
        values.update(tail.capture)
    info = dict(suffix_completed=finished, component_counts=counts,
        tail_entries=tail.entries, tail_sites=tail.sites,
        tail_observations=tail.observations, residual_multipliers=tail.residual_multipliers)
    return values, info, failure, tail
