"""One saved-data review of a separate exploratory oracle-row intervention."""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
PILOT = ROOT / "outputs/world-model-planning/V1"
REPAIR = ROOT / "outputs/world-model-planning/REPAIR_V1"
DESTINATION = Path(__file__).with_name("REPAIR_DIAGNOSTIC_REVIEW.json")
AUDIT_PATH = ROOT / "research/world-model-planning-v1/audit.py"
AUDIT_SHA = "44dbd8a361782ca881f9942f7449b2a93f9afc181d2d2001aed9d44bd0be751b"
PILOT_PASS_SHA = "06659be81a1998143731cad7e52245f07155f95191e03e2cf7cac7513304e281"
VARIANTS = ("key", "door", "both", "all_heldout")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def inventory(directory):
    return {str(p.relative_to(directory)): sha(p) for p in sorted(directory.rglob("*")) if p.is_file()}


def check_mask(base, repaired, flat_rows, transition_table):
    require(base.dtype == repaired.dtype == np.dtype("float64") and base.shape == repaired.shape,
            "Matrix dtype/shape differs")
    require(np.isfinite(base).all() and np.isfinite(repaired).all(), "Nonfinite probabilities")
    require(base.ndim == 3 and base.shape[:2] == transition_table.shape and base.shape[2] == base.shape[0],
            "Matrix state/action support differs")
    require(len(set(flat_rows)) == len(flat_rows) and all(type(i) is int and 0 <= i < transition_table.size for i in flat_rows),
            "Invalid/duplicate repair mask")
    expected = base.copy()
    for index in flat_rows:
        s, action = divmod(index, transition_table.shape[1])
        expected[s, action] = 0.0
        expected[s, action, transition_table[s, action]] = 1.0
    require(repaired.tobytes() == expected.tobytes(), "Repair changes non-mask bytes or fails exact one-hot replacement")
    base_rows, repaired_rows = base.reshape(-1, base.shape[-1]), repaired.reshape(-1, repaired.shape[-1])
    return [i for i, (left, right) in enumerate(zip(base_rows, repaired_rows)) if left.tobytes() != right.tobytes()]


def invented_mask_tests():
    base = np.full((2, 2, 2), 0.5, dtype=np.float64)
    table = np.array([[0, 1], [0, 1]])
    repaired = base.copy()
    repaired[0, 1] = [0, 1]
    require(check_mask(base, repaired, [1], table) == [1], "Invented mask check failed")
    for wrong, mask in ((base, [1]), (repaired, [0]), (repaired, [1, 1])):
        try:
            check_mask(base, wrong, mask, table)
        except ValueError:
            continue
        raise AssertionError("Malformed invented mask admitted")
    outside = repaired.copy()
    outside[1, 1] = [.25, .75]
    try:
        check_mask(base, outside, [1], table)
    except ValueError:
        return 5
    raise AssertionError("Non-mask mutation admitted")


def run():
    require(not DESTINATION.exists(), "Refuse repeated review")
    start = time.monotonic()
    require(sha(AUDIT_PATH) == AUDIT_SHA, "Frozen audit source differs")
    spec = importlib.util.spec_from_file_location("bound_pilot_arithmetic", AUDIT_PATH)
    a = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(a)
    tests = invented_mask_tests()
    require(sha(PILOT / "INDEPENDENT_AUDIT.json") == PILOT_PASS_SHA, "Pilot PASS receipt differs")
    pilot_inventory, repair_inventory = inventory(PILOT), inventory(REPAIR)
    require(set(repair_inventory) == {"plan.json", "base_probabilities.npz", "repaired_probabilities.npz",
                                      "episodes.json", "summary.json", "COLLECTED.json"}, "Repair inventory differs")
    pass_receipt = read(PILOT/"INDEPENDENT_AUDIT.json")
    require(pass_receipt["status"] == "PASS" and pass_receipt["implementation_pass"] is True,
            "Original pilot not admitted")
    require(all(pilot_inventory[name] == digest for name, digest in pass_receipt["artifact_sha256"].items()),
            "Original pilot artifact changed since its audit")
    pilot_plan = read(PILOT/"plan.json")
    require(all(sha(AUDIT_PATH.parent/name) == digest for name, digest in pilot_plan["source_sha256"].items()),
            "Original source changed")
    plan, collected = read(REPAIR/"plan.json"), read(REPAIR/"COLLECTED.json")
    require(collected["status"] == "COLLECTED" and collected["files_sha256"] == {
        name: digest for name, digest in repair_inventory.items() if name != "COLLECTED.json"}, "Repair seals differ")
    require(plan["status"] == "EXPLORATORY_POST_HOC_FIXED_MASK_DIAGNOSTIC"
            and plan["selected_after_pilot_results"] is True and plan["horizon"] == 16, "Repair scope differs")
    require(all(plan[key] == 0 for key in ("model_fits", "neural_forwards", "provider_calls", "new_spending_usd")),
            "Unexpected new model work")
    for field in ("inputs_sha256", "source_sha256"):
        require(all(sha(ROOT/path) == digest for path, digest in plan[field].items()), f"Bindings differ: {field}")
    states, table, cases, _ = a.validate_plan(pilot_plan)
    state_index = {tuple(state): i for i, state in enumerate(states)}
    key, door = 4*state_index[(0, 3, 0)]+2, 4*state_index[(1, 2, 1)]+1
    masks = {"key": [key], "door": [door], "both": sorted([key, door]), "all_heldout": pilot_plan["test"]}
    require(a.same(plan["masks"], masks) and a.same(plan["cases"], cases), "Mask/episode design differs")
    require({key, door} <= set(pilot_plan["test"]), "Selected repair not held out")
    original_report, summary = read(PILOT/"report.json"), read(REPAIR/"summary.json")
    saved_episodes = read(REPAIR/"episodes.json")
    require(summary["status"] == "COLLECTED_PENDING_REPAIR_AUDIT" and summary["episodes"] == 14400
            and len(saved_episodes) == 14400, "Incomplete repair collection")
    require(math.isfinite(summary["seconds"]) and 0 <= summary["seconds"] <= 300, "Diagnostic elapsed bound differs")
    original_episodes = read(PILOT/"episodes.json")
    original_h16 = [row for row in original_episodes if row["model"] != "oracle" and row["horizon"] == 16]
    require(len(original_h16) == 3600, "Original H16 coverage differs")
    goals = sorted({tuple(case["goal"]) for case in cases})
    base_summary, expected_summaries, all_repaired_rows, all_base_rows, mask_checks = {}, {}, [], [], []
    max_softmax_difference = 0.0
    with np.load(PILOT/"predictions.npz", allow_pickle=False) as logits, \
         np.load(REPAIR/"base_probabilities.npz", allow_pickle=False) as base_archive, \
         np.load(REPAIR/"repaired_probabilities.npz", allow_pickle=False) as repaired_archive:
        require(set(logits.files) == set(base_archive.files) == set(a.MODEL_NAMES), "Base model coverage differs")
        require(set(repaired_archive.files) == {f"{name}__{variant}" for name in a.MODEL_NAMES for variant in VARIANTS},
                "Repair model/mask coverage differs")
        for name in a.MODEL_NAMES:
            base = base_archive[name]
            require(base.dtype == np.dtype("float64") and base.shape == (30, 4, 30), "Invalid base matrix")
            independent = a.probability_from_logits(logits[name])
            difference = float(np.max(np.abs(base-independent)))
            max_softmax_difference = max(max_softmax_difference, difference)
            require(np.allclose(base, independent, rtol=1e-12, atol=1e-14), "Base matrix is not original logits softmax")
            expected_summaries[name] = {}
            for variant in ("base", *VARIANTS):
                if variant == "base":
                    matrix = base
                else:
                    matrix = repaired_archive[f"{name}__{variant}"]
                    changed = check_mask(base, matrix, masks[variant], table)
                    mask_checks.append({"model": name, "repair": variant, "declared_rows": masks[variant],
                                        "actually_changed_rows": changed, "exact_other_rows": True,
                                        "exact_oracle_one_hot": True})
                policies = {goal: a.bellman_policy(matrix, states, goal, 16) for goal in goals}
                rows = []
                for case in cases:
                    actions, ties, _ = policies[tuple(case["goal"])]
                    row = {"model": name, "horizon": 16, **case,
                           **a.replay_episode(table, states, case["start"], case["goal"], actions, ties)}
                    if variant != "base":
                        row["repair"] = variant
                    rows.append(row)
                detailed = a.planning_summary(rows)
                if variant == "base":
                    a.compare_numeric(original_report["models"][name]["planning"]["16"], detailed)
                    base_summary[name] = detailed
                    all_base_rows.extend(rows)
                else:
                    expected_summaries[name][variant] = {key: detailed[key] for key in
                                                         ("n", "successes", "cycles", "mean_steps_success")}
                    all_repaired_rows.extend(rows)
            print(json.dumps({"verified": name, "base_successes": base_summary[name]["successes"],
                              "repairs": {variant: expected_summaries[name][variant]["successes"] for variant in VARIANTS}}), flush=True)
    require(a.same(all_base_rows, original_h16), "Original H16 replay differs")
    require(a.same(all_repaired_rows, saved_episodes), "Repair episode state/action/tie/cycle trace differs")
    a.compare_numeric(summary["results"], expected_summaries)
    require(inventory(PILOT) == pilot_inventory and inventory(REPAIR) == repair_inventory,
            "Original or diagnostic artifact changed during review")
    require(sha(AUDIT_PATH) == AUDIT_SHA, "Frozen primitive source changed")
    return {
        "status": "PASS_REPAIR_DIAGNOSTIC_REVIEW", "scope": "Exploratory post-hoc ground-truth row replacement; not learning improvement or independent confirmation.",
        "checker_sha256": sha(__file__), "reused_audit_sha256": AUDIT_SHA,
        "original_audit_sha256": PILOT_PASS_SHA, "pilot_files_sha256": pilot_inventory,
        "repair_files_sha256": repair_inventory, "repair_source_sha256": plan["source_sha256"],
        "invented_mask_checks": tests, "base_episodes_replayed": 3600, "repaired_episodes_replayed": 14400,
        "models": 6, "repairs_per_model": 4, "mask_checks": mask_checks,
        "base_softmax_max_absolute_difference": max_softmax_difference,
        "base_softmax_tolerance": {"absolute": 1e-14, "relative": 1e-12},
        "episode_trace_comparison": "exact", "original_files_unchanged": True,
        "base": base_summary, "repairs": expected_summaries,
        "success_deltas": {name: {variant: expected_summaries[name][variant]["successes"]-base_summary[name]["successes"]
                                  for variant in VARIANTS} for name in a.MODEL_NAMES},
        "limits": [
            "The masks were selected after observing pilot outcomes; this is a sensitivity analysis of those fitted models.",
            "Replacing a whole probability row changes its calibration, support and mode together. An effect is not uniquely attributable to correcting the argmax alone.",
            "Episode counts share one world and fitted matrix; they are not independent worlds or independent training runs.",
            "The repair source writes its fixed plan before repaired computation; saved files do not independently timestamp that ordering beyond the reviewed source path.",
            "The checker reuses its author's frozen independent arithmetic primitives, not the primary planner. It is not a fresh third-author replication.",
        ],
        "model_calls": 0, "fits": 0, "provider_calls": 0, "seconds": time.monotonic()-start,
    }


if __name__ == "__main__":
    try:
        result = run()
        with DESTINATION.open("x") as stream:
            json.dump(result, stream, indent=2, allow_nan=False)
            stream.write("\n")
        print(json.dumps({"status": result["status"], "path": str(DESTINATION), "sha256": sha(DESTINATION)}))
    except BaseException as error:
        path = DESTINATION.with_name("REPAIR_DIAGNOSTIC_REVIEW_FAILURE.json")
        with path.open("x") as stream:
            json.dump({"status": "FAIL", "reason": str(error), "type": type(error).__name__,
                       "checker_sha256": sha(__file__)}, stream, indent=2)
            stream.write("\n")
        raise
