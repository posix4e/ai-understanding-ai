"""Invented NumPy arrays only; no real checkpoint, predecessor arrays or model."""
import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

SPEC=importlib.util.spec_from_file_location('independent_live_energy_audit',Path(__file__).with_name('audit.py'))
audit=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(audit)


def invented_organ(offset=0):
    w1=np.zeros((32,19),dtype=np.float32)
    for c in range(8):w1[c,(c-offset)%8]=1;w1[c,11+c]=1
    w2=np.eye(32,dtype=np.float32)
    w3=np.zeros((1,32),dtype=np.float32);w3[0,:8]=-1
    return {'input_proj.weight':w1,'hidden_proj.weight':w2,'output_proj.weight':w3}


def invented_energy(weights,state=3,action=1):
    q=audit.canonical_queries(state,action)
    def gelu(x):return np.array([.5*float(v)*(1+math.erf(float(v)/math.sqrt(2))) for v in x.ravel()],dtype=np.float32).reshape(x.shape)
    z1=q@weights['input_proj.weight'].T;a1=gelu(z1)
    z2=a1@weights['hidden_proj.weight'].T;a2=gelu(z2)
    z3=a2@weights['output_proj.weight'].T;e=z3.reshape(8)
    exp=np.exp((-e.astype(np.float64))-float((-e).max()));p=(exp/exp.sum()).astype(np.float32)
    return dict(query=q,linear1_input=q.copy(),linear1=z1,gelu1_input=z1.copy(),gelu1=a1,
                linear2_input=a1.copy(),linear2=z2,gelu2_input=z2.copy(),gelu2=a2,
                linear3_input=a2.copy(),linear3=z3,energies=e.copy(),probabilities_cpu=p)


def contexts():
    return [dict(id=f's{s}-a{a}',state=s,action=a,split='held' if a==s%3 else 'train',
                 prompt=f"World state {s}. Actions {'XYZ'[a]}. Next state:",input_ids=[0,10+s,20+a])
            for s in range(8) for a in range(3)]


def decisions(s,a):
    def scores(n,label):
        x=np.zeros(n);x[label]=1;return audit.strict_choice(x)
    return dict(state=scores(8,s),action=scores(3,a),address=scores(24,3*s+a))


class NumericalCoreTests(unittest.TestCase):
    def test_live_energy_arithmetic_and_actual_rule(self):
        for offset in range(4):
            w=invented_organ(offset);v=invented_energy(w)
            result=audit.check_energy(v,w,3,1)
            self.assertTrue(result['unique_and_equal']);self.assertEqual(result['energy_choice']['winner'],(3+offset)%8)

    def test_consumed_operand_chain_cannot_be_substituted(self):
        w=invented_organ();v=invented_energy(w)
        v['linear2_input'][0,0]=np.nextafter(v['linear2_input'][0,0],np.float32(np.inf))
        with self.assertRaisesRegex(audit.AuditError,'interstage'):audit.check_energy(v,w,3,1)

    def test_query_uses_actual_predicted_address(self):
        w=invented_organ();v=invented_energy(w)
        with self.assertRaisesRegex(audit.AuditError,'query differs'):audit.check_energy(v,w,2,1)

    def test_linear_and_gelu_outside_fixed_bounds_rejected(self):
        w=invented_organ();v=invented_energy(w)
        with self.assertRaises(audit.AuditError):audit.check_linear(v['query'],w['input_proj.weight'],v['linear1']+.001)
        with self.assertRaises(audit.AuditError):audit.check_gelu(v['linear1'],v['gelu1']+.001)

    def test_softmax_wrong_temperature_rejected(self):
        w=invented_organ();v=invented_energy(w)
        x=np.exp(-v['energies'].astype(np.float64)/2);v['probabilities_cpu']=(x/x.sum()).astype(np.float32)
        with self.assertRaisesRegex(audit.AuditError,'softmax'):audit.check_energy(v,w,3,1)

    def test_equal_energy_probability_ties_are_finite_negative(self):
        w={k:np.zeros_like(v) for k,v in invented_organ().items()};v=invented_energy(w)
        r=audit.check_energy(v,w,3,1)
        self.assertTrue(r['winning_sets_equal']);self.assertFalse(r['unique_and_equal'])

    def test_probability_winner_mismatch_is_completed_negative(self):
        w={k:np.zeros_like(v) for k,v in invented_organ().items()};v=invented_energy(w)
        v['probabilities_cpu'][0]=np.nextafter(np.float32(.125),np.float32(1))
        checked=audit.check_energy(v,w,3,1)
        self.assertFalse(checked['winning_sets_equal']);self.assertFalse(checked['unique_and_equal'])

    def test_unresolved_reader_has_no_synthetic_route(self):
        d=decisions(1,2);d['state']=audit.strict_choice(np.zeros(8))
        self.assertEqual(audit.route_from_decisions(d,'main'),dict(resolved=False,state=None,action=None,address=None))
        self.assertEqual(audit.derive_counts(0)['writer_applications'],24)
        self.assertEqual(audit.derive_counts(192)['energy_forwards'],192)

    def test_wrong_route_uses_prediction_not_evaluator_address(self):
        self.assertEqual(audit.route_from_decisions(decisions(7,2),'wrong'),dict(resolved=True,state=0,action=2,address=2))

    def test_literal264_schedule_and_no_extra_uniform_per_world(self):
        s=audit.independent_schedule(contexts());self.assertEqual(len(s),264)
        self.assertEqual(sum(x['phase']=='uniform' for x in s),24)
        self.assertEqual([x['world_id'] for x in s[:3]],[None,None,'dev00'])

    def test_nonfinite_energy_or_bound_is_rejected(self):
        w=invented_organ();v=invented_energy(w);v['gelu1'][0,0]=np.inf
        with self.assertRaises(audit.AuditError):audit.check_energy(v,w,3,1)

    def test_bound_numerical_modules_are_independent_and_pinned(self):
        r=audit.bound_core(audit.READER_CORE);w=audit.bound_core(audit.WRITER_CORE)
        self.assertTrue(callable(r.check_application));self.assertTrue(callable(w.audit_writer_math))
        with patch.object(audit,'digest',return_value='0'*64):
            with self.assertRaises(audit.AuditError):audit.bound_core(audit.READER_CORE)





def retain(directory,stem,values,dtypes,meta):
    """Invented archive serialization; independent of primary worker."""
    arrays={};specs={}
    for name,v in values.items():
        v=np.asarray(v);dtype=dtypes[name]
        if dtype=='torch.bfloat16':
            rounded=audit.bound_core(audit.WRITER_CORE).bf16_round(v)
            if not audit.exact(v,rounded):raise ValueError('Invented BF16 fixture not representable')
            raw=(v.view(np.uint32)>>16).astype('<u2').view(np.uint8).reshape(-1).copy()
        else:raw=np.frombuffer(v.tobytes(),dtype=np.uint8).copy()
        rk,vk=name+'__raw_uint8',name+'__value';arrays[rk]=raw;arrays[vk]=v.copy()
        specs[name]=dict(dtype=dtype,shape=list(v.shape),raw_key=rk,value_key=vk,
                         raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest())
    path=directory/(stem+'.npz');path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as f:np.savez_compressed(f,**arrays)
    mp=directory/(stem+'.json');mp.write_text(json.dumps(dict(**meta,tensors=specs)))
    return dict(forward_path=stem+'.npz',forward_sha256=audit.digest(path),
                forward_metadata_path=stem+'.json',forward_metadata_sha256=audit.digest(mp))


def invented_parameters(unresolved=False):
    reader=dict(coefficients=np.zeros((1024,11),np.float64),x_mean=np.zeros(1024,np.float64),y_mean=np.zeros(11,np.float64))
    if not unresolved:reader['coefficients'][:11]=np.eye(11)*math.sqrt(2/1024)
    w=np.zeros((1024,8),np.float32);w[:8]=np.eye(8,dtype=np.float32)
    return {'reader':reader,'writer':{'weight':w},**{wid:invented_organ(i) for i,wid in enumerate(audit.WORLD_IDS)}}


def reader_values(h,params):
    h64=h.astype(np.float64);rms=math.sqrt(math.fsum(float(x)*float(x) for x in h64)/1024)
    normalized=h64/rms;centered=normalized-params['x_mean'];w=params['coefficients']
    comp=np.array([math.fsum(float(centered[i])*float(w[i,j]) for i in range(1024))+float(params['y_mean'][j])
                   for j in range(11)],np.float64)
    addr=np.array([comp[s]+comp[8+a] for s in range(8) for a in range(3)],np.float64)
    return dict(h64=h64,rms=np.array(rms),normalized=normalized,reader_centered=centered,
                component_scores=comp,address_scores=addr)


def make_panel(directory,unresolved=False):
    params=invented_parameters(unresolved)
    hashes={k:{name:hashlib.sha256(v.tobytes()).hexdigest() for name,v in values.items()} for k,values in params.items()}
    worlds=[dict(id=wid,transitions=[[(s+i)%8 for s in range(8)] for _ in range(3)]) for i,wid in enumerate(audit.WORLD_IDS)]
    hostkeys=audit.bound_core(audit.READER_CORE).expected_state_keys()
    plan=dict(contexts=contexts(),worlds=worlds,label_ids=list(range(34,42)),expected_host_state=dict.fromkeys(hostkeys,'1'*64),
              reader_artifact=dict(member_sha256=hashes['reader']))
    plan['schedule']=audit.independent_schedule(plan['contexts'])
    paramnames={'host':hostkeys-{'lm_head.weight'},'writer':{'weight'},**{wid:set(audit.ORGAN_SHAPES) for wid in audit.WORLD_IDS}}
    owners=list(paramnames)
    before=dict(requires_grad={k:dict.fromkeys(v,True) for k,v in paramnames.items()},
        training={k:{'':False} for k in owners},hooks={k:{} for k in owners},
        forward_methods={k:{'':[False,i]} for i,k in enumerate(owners)},
        grad_none={k:dict.fromkeys(v,True) for k,v in paramnames.items()},host_config=dict(use_cache=True,logits_scaling=6))
    during=copy.deepcopy(before);during['host_config']['use_cache']=False
    for v in during['requires_grad'].values():v.update(dict.fromkeys(v,False))
    resolved=0 if unresolved else 192;counts=audit.operation_counts(resolved)
    states={'host':plan['expected_host_state'],**{k:hashes[k] for k in owners if k!='host'}}
    complete=dict(status='WORKER_COMPLETED',plan_sha256='fake-plan',counts=counts,states_before=states,states_after=states,
        reader_state_before=hashes['reader'],reader_state_after=hashes['reader'],
        identities_before=before,identities_during=during,identities_after=copy.deepcopy(before),
        checks=dict(ownership_restored=True,states_unchanged=True,reader_unchanged=True,cache_unchanged=True,exact_counts=True),
        elapsed_seconds=4.,analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)
    calls=[];timestamp='2026-10-05T20:00:00+00:00';resources=[]
    def sample(stage):
        r=dict(stage=stage,elapsed_seconds=len(resources)/200.,rss_high_water_bytes=10000,mps_driver_bytes=20000)
        resources.append(r);return r
    sample('before_loading');core=audit.bound_core(audit.WRITER_CORE)
    for entry in plan['schedule']:
        context=plan['contexts'][entry['index']//11];s,a=context['state'],context['action'];phase=entry['phase']
        h=np.zeros((1,3,1024),np.float32);h[0,-1,s]=1;h[0,-1,8+a]=1
        v=dict(input_ids=np.array([context['input_ids']],np.int64),hidden_before=h.copy(),hidden_after=h.copy(),returned=h.copy(),full_logits=np.zeros(audit.VOCAB,np.float32))
        v['full_logits'][34]=1
        routed=phase in ('main','wrong');resolved_here=routed and not unresolved;writes=phase=='uniform' or resolved_here
        info=dict(forward_completed=True,hook_entries=1,reader_entered=routed,reader_completed=routed,decisions=None,
            resolved=resolved_here if routed else None,predicted_state=None,predicted_action=None,predicted_address=None,
            query_state=None,query_action=None,organ_entered=resolved_here,organ_completed=resolved_here,
            writer_entered=writes,writer_completed=writes,patched=writes,unresolved_reason=None,
            energy_hook_entries=None,energy_hook_finished=None)
        if routed:
            v.update(reader_values(h[0,-1],params['reader']))
            choice={k:audit.strict_choice(x) for k,x in dict(state=v['component_scores'][:8],action=v['component_scores'][8:],address=v['address_scores']).items()}
            info['decisions']=choice
            if resolved_here:
                qs=(s+(phase=='wrong'))%8
                info.update(predicted_state=s,predicted_action=a,predicted_address=3*s+a,query_state=qs,query_action=a,
                    energy_hook_entries=dict.fromkeys(('linear1','linear2','linear3','gelu1','gelu2'),1),
                    energy_hook_finished=dict.fromkeys(('linear1','linear2','linear3','gelu1','gelu2'),1))
                v.update(invented_energy(params[entry['world_id']],qs,a))
                v['full_logits'][:]=0;v['full_logits'][34+(qs+int(entry['world_id'][-2:]))%8]=1
            else:info['unresolved_reason']='tied_choice'
        if writes:
            if phase=='uniform':v['probabilities_cpu']=np.full(8,.125,np.float32)
            p=v['probabilities_cpu'].copy();centered=p-np.float32(.125)
            delta=(params['writer']['weight']@centered).astype(np.float32);dh=core.bf16_round(delta)
            returned=h.copy();returned[0,-1]=core.bf16_round(h[0,-1]+dh)
            v.update(probabilities=p,centered=centered,delta32=delta,delta_host=dh,returned=returned)
        shapes=audit.call_shapes(entry,3,resolved_here);dtypes={k:d for k,(d,shape) in shapes.items()}
        paths=retain(directory,'calls/'+entry['id'],v,dtypes,dict(**entry,**info,plan_sha256='fake-plan'))
        comp={}
        if phase in ('uniform','restored'):
            for old in (['native'] if phase=='uniform' else ['native','uniform']):
                comp[old]=dict(full_vocabulary_max_absolute_error=0.,full_vocabulary_raw_equal=True,
                    hidden_raw_equal=True,hidden_max_absolute_error=0.,**{'pass':True})
        calls.append(dict(**entry,**info,**paths,comparisons=comp,controls_pass=True,error=None,
            resources_before=sample('before:'+entry['id']),resources_after=sample('after:'+entry['id'])))
    sample('complete');complete['resource_samples']=resources
    eventrows=[];rs=iter(resources)
    for kind,payload in audit.expected_events(plan['schedule'],calls):
        e=dict(event=kind,at_utc=timestamp)
        if kind=='resources':e.update(next(rs))
        elif isinstance(payload,dict):e.update(payload)
        elif kind=='worker_started':e.update(worker_pid=12345,owner_pid=1234,deadline_utc='2026-10-05T20:10:00+00:00')
        elif kind=='worker_completed':e['counts']=counts
        eventrows.append(e)
    (directory/'WORKER_COMPLETE.json').write_text(json.dumps(complete))
    (directory/'calls.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in calls))
    (directory/'worker-events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in eventrows))
    return plan,params,hashes


class CompletePanelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.directory=Path(cls.temp.name)
        cls.plan,cls.params,cls.hashes=make_panel(cls.directory)
        cls.report=audit.audit_records(cls.directory,cls.plan,'fake-plan',cls.params,cls.hashes)

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def test_complete264_panel_and_all_derived_counts(self):
        r=self.report
        self.assertTrue(r['gate_pass']);self.assertTrue(r['implementation_pass'])
        self.assertEqual(r['counts'],audit.operation_counts(192));self.assertEqual(len(r['rows']),192)
        self.assertEqual(len(r['controls']),72);self.assertEqual(r['main_wrong_pairs']['both_followed'],96)
        self.assertEqual(r['world_pairs']['both_followed'],144);self.assertEqual(r['world_pairs']['same_outcome'],0)
        self.assertEqual(r['groups']['main']['original_task_correct'],96)
        self.assertEqual(r['groups']['wrong']['selected_query_correct'],96)
        self.assertEqual(r['groups']['wrong']['original_task_correct'],0)
        self.assertEqual(r['baselines']['native'],dict(calls=24,world_context_cells=96,correct=12,ties=0,call_ties=0))
        json.dumps(r,allow_nan=False)

    def test_predicted_and_actual_wrong_routes_distinct(self):
        row=next(x for x in self.report['rows'] if x['phase']=='wrong')
        self.assertEqual(row['predicted_route']['state'],0);self.assertEqual(row['route']['state'],1)
        self.assertEqual(row['selected_query_target'],1)

    def test_duplicate_and_missing_calls_rejected(self):
        calls=audit.jsonl(self.directory/'calls.jsonl');p=self.directory/'calls.jsonl';original=p.read_bytes()
        try:
            p.write_text(''.join(json.dumps(x)+'\n' for x in calls[:-1]))
            with self.assertRaisesRegex(audit.AuditError,'coverage'):audit.audit_records(self.directory,self.plan,'fake-plan',self.params,self.hashes)
            calls[1]=calls[0];p.write_text(''.join(json.dumps(x)+'\n' for x in calls))
            with self.assertRaisesRegex(audit.AuditError,'schedule'):audit.audit_records(self.directory,self.plan,'fake-plan',self.params,self.hashes)
        finally:p.write_bytes(original)

    def test_altered_journal_or_forbidden_training_rejected(self):
        complete=audit.read(self.directory/'WORKER_COMPLETE.json');events=audit.jsonl(self.directory/'worker-events.jsonl')
        calls=audit.jsonl(self.directory/'calls.jsonl')
        events[3]['event']='backward_started'
        with self.assertRaisesRegex(audit.AuditError,'operation order'):audit.validate_events(events,self.plan['schedule'],calls,complete)
        complete['counts']['optimizer_steps']=1
        with self.assertRaisesRegex(audit.AuditError,'counts'):audit.validate_ownership(complete,self.plan,self.hashes,audit.operation_counts(192))

    def test_changed_state_and_missing_parameter_coverage_rejected(self):
        complete=audit.read(self.directory/'WORKER_COMPLETE.json')
        del complete['states_after']['host']['lm_head.weight']
        with self.assertRaisesRegex(audit.AuditError,'states'):audit.validate_ownership(complete,self.plan,self.hashes,audit.operation_counts(192))

    def test_opaque_archive_tamper_rejected_before_decoding(self):
        calls=audit.jsonl(self.directory/'calls.jsonl');r=copy.deepcopy(calls[0]);r['forward_sha256']='0'*64
        with self.assertRaisesRegex(audit.AuditError,'hash'):audit.load_call(self.directory,r,self.plan['schedule'][0],self.plan['contexts'][0],'fake-plan')

    def test_live_array_readable_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);v={'a':np.array([-0.,1.],np.float32)}
            retain(d,'v',v,{'a':'torch.bfloat16'},{})
            with np.load(d/'v.npz',allow_pickle=False) as z:data={k:z[k].copy() for k in z.files}
            data['a__value'][0]=0.
            np.savez(d/'v.npz',**data)
            with self.assertRaisesRegex(audit.AuditError,'Raw/readable'):audit.load_bundle(d/'v.npz',d/'v.json',{'a':('torch.bfloat16',(2,))})

    def test_unresolved_full_panel_valid_negative_without_fake_calls(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);p,v,h=make_panel(d,unresolved=True)
            result=audit.audit_records(d,p,'fake-plan',v,h)
            self.assertTrue(result['implementation_pass']);self.assertFalse(result['gate_pass'])
            self.assertEqual(result['counts'],audit.operation_counts(0));self.assertEqual(result['organ_forwards'],0)
            self.assertEqual(result['writer_forwards'],24);self.assertEqual(result['main_wrong_pairs']['both_followed'],0)
            self.assertTrue(all(x['route']['resolved'] is False and x['selected_query_target'] is None for x in result['rows']))





class ProvenanceAndGateTests(unittest.TestCase):
    def test_fixed_initial_final_snapshots_bound_by_raw_hashes(self):
        params=invented_parameters();hashes={k:{n:hashlib.sha256(v.tobytes()).hexdigest() for n,v in x.items()} for k,x in params.items()}
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);directory=root/'study';directory.mkdir()
            retain(root,'original-writer',params['writer'],{'weight':'torch.float32'},{})
            plan=dict(reader_artifact=dict(member_sha256=hashes['reader']),
                writer_artifact=dict(path='original-writer.npz',metadata_path='original-writer.json',member_sha256=hashes['writer']),
                organ_artifacts={wid:dict(state_sha256=hashes[wid]) for wid in audit.WORLD_IDS})
            for stem,values in params.items():
                dt='numpy.float64' if stem=='reader' else 'torch.float32'
                for phase in ('initial','final'):retain(directory,stem+'-'+phase,values,dict.fromkeys(values,dt),dict(plan_sha256='plan'))
            core=audit.bound_core(audit.READER_CORE)
            with patch.object(core,'load_frozen_reader',return_value=params['reader']):
                loaded,actual=audit.load_fixed_parameters(directory,plan,'plan',root)
                self.assertEqual(actual,hashes)
                self.assertTrue(audit.exact(loaded['dev00']['input_proj.weight'],params['dev00']['input_proj.weight']))
                changed={k:v.copy() for k,v in params['dev00'].items()};changed['input_proj.weight'][0,0]+=1
                retain(directory,'dev00-final',changed,dict.fromkeys(changed,'torch.float32'),dict(plan_sha256='plan'))
                with self.assertRaisesRegex(audit.AuditError,'parameters changed'):audit.load_fixed_parameters(directory,plan,'plan',root)

    def test_arbitrary_artifact_and_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);(d/'one.json').write_text('{}')
            collection=dict(artifact_sha256={'one.json':audit.digest(d/'one.json')})
            audit.check_inventory(d,collection)
            (d/'extra.json').write_text('{}')
            with self.assertRaisesRegex(audit.AuditError,'missing or extra'):audit.check_inventory(d,collection)
            with self.assertRaisesRegex(audit.AuditError,'Unsafe'):audit.safe(d,'../one.json')
            with self.assertRaisesRegex(audit.AuditError,'Unsafe'):audit.safe(d,str(d/'one.json'))

    def test_stop_refuses_any_new_audit_before_array_or_runtime(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);(d/'STOPPED.json').write_text('{}')
            with patch.object(audit,'OUT',d),patch.object(audit,'runtime_guard') as runtime,patch.object(np,'load') as load:
                with self.assertRaisesRegex(audit.AuditError,'Stopped/terminal'):audit.audit(d)
                runtime.assert_not_called();load.assert_not_called()

    def test_owner_pid_or_expired_deadline_rejected(self):
        from datetime import datetime,timedelta,timezone
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);now=datetime.now(timezone.utc)
            started=dict(owner_pid=100,plan_sha256='p',at_utc=(now-timedelta(seconds=601)).isoformat(),
                         deadline_utc=(now-timedelta(seconds=1)).isoformat())
            worker=dict(owner_pid=100,worker_pid=101,plan_sha256='p',deadline_utc=started['deadline_utc'])
            (d/'STARTED.json').write_text(json.dumps(started));(d/'WORKER_STARTED.json').write_text(json.dumps(worker))
            with patch.object(audit.os,'getppid',return_value=999):
                with self.assertRaisesRegex(audit.AuditError,'original owner'):audit.owner_guard(d,'p')
            with patch.object(audit.os,'getppid',return_value=100),patch.object(audit,'is_alive',return_value=True):
                with self.assertRaisesRegex(audit.AuditError,'deadline'):audit.owner_guard(d,'p')

    def test_finite_wrong_organ_cannot_be_rescued_by_correct_host_choices(self):
        rows=copy.deepcopy(CompletePanelTests.report['rows']);rows[0]['organ_correct']=False
        tables={w['id']:w['transitions'] for w in CompletePanelTests.plan['worlds']}
        result=audit.summarize(rows,tables)
        self.assertFalse(result['gate_pass']);self.assertEqual(result['groups']['main']['original_task_correct'],96)
        self.assertEqual(result['main_wrong_pairs']['both_followed'],96)

    def test_resource_bound_not_inferred_from_only_final_sample(self):
        # Only actual invented archive metadata; no model or tensors are needed.
        schedule=audit.independent_schedule(contexts());calls=[dict(resolved=e['phase'] in ('main','wrong')) for e in schedule]
        events=[];resources=[]
        for kind,payload in audit.expected_events(schedule,calls):
            row=dict(event=kind,at_utc='2026-10-05T20:00:00+00:00')
            if kind=='resources':
                sample=dict(stage=payload,elapsed_seconds=0.,rss_high_water_bytes=1,mps_driver_bytes=1)
                if payload=='before:0001':sample['mps_driver_bytes']=audit.MEMORY_LIMIT+1
                row.update(sample);resources.append(sample)
            elif isinstance(payload,dict):row.update(payload)
            elif kind=='worker_completed':row['counts']=audit.operation_counts(192)
            events.append(row)
        self.assertEqual(len(events),2524)
        with self.assertRaisesRegex(audit.AuditError,'memory ceiling'):
            audit.validate_events(events,schedule,calls,dict(counts=audit.operation_counts(192),resource_samples=resources))


if __name__=='__main__':unittest.main()
