"""Fixed live learned-energy connection. No real model execution before main.

Retain actual operands before structural checks; never grade expected answers.
"""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import inspect
import json
import os
from pathlib import Path
import platform
import resource
import signal
import time

import numpy as np
import torch

from assembly import LiveEnergyConnection

HOOKS = ('_forward_pre_hooks', '_forward_hooks', '_backward_pre_hooks', '_backward_hooks')
ROLES = ('native','uniform','main','wrong','restored')
CONTROLS = ('native','uniform','restored')
READER_SHAPES = dict(coefficients=(1024,11), x_mean=(1024,), y_mean=(11,))
INTERMEDIATE_SHAPES = dict(h64=(1024,), rms=(), normalized=(1024,), reader_centered=(1024,),
                           component_scores=(11,), address_scores=(24,))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def create(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())


def append(path, value):
    with Path(path).open('a') as stream:
        stream.write(json.dumps(value, allow_nan=False)+'\n'); stream.flush(); os.fsync(stream.fileno())


def raw_bytes(value):
    if isinstance(value, np.ndarray): return value.tobytes(order='C')
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def state_hash(model):
    return {name:hashlib.sha256(raw_bytes(value)).hexdigest() for name,value in model.state_dict().items()}


def reader_hash(arrays):
    return {name:hashlib.sha256(raw_bytes(value)).hexdigest() for name,value in arrays.items()}


def identity(modules):
    return dict(requires_grad={k:{n:v.requires_grad for n,v in m.named_parameters()} for k,m in modules.items()},
        training={k:{n:v.training for n,v in m.named_modules()} for k,m in modules.items()},
        hooks={k:{n:{a:list(getattr(v,a,{})) for a in HOOKS if getattr(v,a,{})}
                  for n,v in m.named_modules() if any(getattr(v,a,{}) for a in HOOKS)} for k,m in modules.items()},
        forward_methods={k:{n:['forward' in v.__dict__,id(getattr(v.forward,'__func__',v.forward))]
                         for n,v in m.named_modules()} for k,m in modules.items()},
        grad_none={k:{n:v.grad is None for n,v in m.named_parameters()} for k,m in modules.items()},
        host_config=copy.deepcopy(modules['host'].config.to_dict()))


def restore(modules,before):
    for key,module in modules.items():
        for name,p in module.named_parameters():p.requires_grad_(before['requires_grad'][key][name])
        for name,m in module.named_modules():m.training=before['training'][key][name]
    modules['host'].config.use_cache=before['host_config']['use_cache']
    return identity(modules)


def retain(directory, stem, values, metadata):
    arrays, descriptions = {}, {}
    for name,value in values.items():
        if isinstance(value, np.ndarray):
            cpu=np.ascontiguousarray(value) if value.ndim else value.copy()
            raw=np.frombuffer(cpu.tobytes(),dtype=np.uint8).copy(); readable=cpu.copy()
            dtype='numpy.'+str(cpu.dtype)
        elif isinstance(value, torch.Tensor):
            cpu=value.detach().cpu().contiguous()
            raw=cpu.reshape(-1).view(torch.uint8).numpy().copy()
            readable=(cpu.float() if cpu.dtype==torch.bfloat16 else cpu).numpy().copy()
            dtype=str(cpu.dtype)
        else: raise TypeError('Unsupported retained value')
        rk,vk=name+'__raw_uint8',name+'__value'
        arrays[rk],arrays[vk]=raw,readable
        descriptions[name]=dict(dtype=dtype,shape=list(readable.shape),raw_key=rk,value_key=vk,
                                 raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest())
    path,metadata_path=directory/(stem+'.npz'),directory/(stem+'.json')
    with path.open('xb') as stream:
        np.savez_compressed(stream,**arrays);stream.flush();os.fsync(stream.fileno())
    create(metadata_path,dict(**metadata,tensors=descriptions))
    return dict(forward_path=str(path.relative_to(directory)),forward_sha256=digest(path),
        forward_metadata_path=str(metadata_path.relative_to(directory)),forward_metadata_sha256=digest(metadata_path))


def load_reader(path, metadata_path, expected):
    """Load only three frozen members; never load features, targets or fit code."""
    if digest(path)!=expected['sha256'] or digest(metadata_path)!=expected['metadata_sha256']:
        raise ValueError('Frozen reader artifact hash differs')
    metadata=json.loads(Path(metadata_path).read_text())['tensors']
    arrays={}
    with np.load(path,allow_pickle=False) as archive:
        for name,shape in READER_SHAPES.items():
            value=archive[name]
            spec=metadata[name]
            if (value.dtype!=np.float64 or value.shape!=shape or not np.isfinite(value).all()
                    or spec['dtype']!=value.dtype.str or spec['shape']!=list(shape)
                    or spec['raw_sha256']!=hashlib.sha256(value.tobytes()).hexdigest()):
                raise ValueError('Frozen reader member identity differs: '+name)
            if spec['raw_sha256']!=expected['member_sha256'][name]:
                raise ValueError('Registered reader member differs: '+name)
            arrays[name]=value.copy(); arrays[name].flags.writeable=False
    return arrays



def load_writer(path,metadata_path,expected,writer):
    if digest(path)!=expected['sha256'] or digest(metadata_path)!=expected['metadata_sha256']:
        raise ValueError('Frozen writer artifact differs')
    meta=json.loads(Path(metadata_path).read_text())['tensors']['weight']
    with np.load(path,allow_pickle=False) as z:
        raw=z[meta['raw_key']];value=z[meta['value_key']]
        if (meta['dtype']!='torch.float32' or meta['shape']!=[1024,8] or raw.dtype!=np.uint8
            or raw.shape!=(1024*8*4,) or value.dtype!=np.float32 or value.shape!=(1024,8)
            or raw.tobytes()!=value.tobytes() or not np.isfinite(value).all()
            or hashlib.sha256(raw.tobytes()).hexdigest()!=meta['raw_sha256']
            or {'weight':meta['raw_sha256']}!=expected['member_sha256']):
            raise ValueError('Frozen writer raw matrix differs')
        with torch.no_grad():writer.weight.copy_(torch.from_numpy(value.copy()))
    return writer


def load_organ(path,expected,organ):
    if digest(path)!=expected['sha256']:raise ValueError('Frozen organ file differs')
    state=torch.load(path,map_location='cpu',weights_only=True)
    shapes={'input_proj.weight':(32,19),'hidden_proj.weight':(32,32),'output_proj.weight':(1,32)}
    if set(state)!=set(shapes):raise ValueError('Organ state keys differ')
    for name,shape in shapes.items():
        v=state[name]
        if v.dtype!=torch.float32 or tuple(v.shape)!=shape or not bool(torch.isfinite(v).all()):
            raise ValueError('Organ state dtype/shape/finiteness differs')
    organ.load_state_dict(state,strict=True)
    if state_hash(organ)!=expected['state_sha256']:raise ValueError('Organ raw parameters differ')
    return organ


def collect_forward(model,ids,connection,organ,layer,phase,on_start,on_application_event):
    captured={'input_ids':ids.detach().cpu().clone()};entered=0;finished=False;handle=None;failure=None
    connection.last_capture={};connection.last_info={}
    def hook(module,args):
        nonlocal entered
        entered+=1
        if entered!=1:raise ValueError('Repeated insertion hook')
        hidden=args[0];captured['hidden_before']=hidden.detach().cpu().clone()
        try:
            returned=connection.apply(hidden,phase,organ,on_application_event)
            return (returned,*args[1:]) if connection.last_info['patched'] else None
        finally:
            captured['hidden_after']=hidden.detach().cpu().clone()
            captured.update(connection.last_capture)
    try:
        handle=model.model.layers[layer].register_forward_pre_hook(hook)
        on_start()
        with torch.no_grad():
            logits=model(input_ids=ids,use_cache=False,logits_to_keep=1,return_dict=True).logits[0,-1]
        finished=True;captured['full_logits']=logits.detach().cpu().clone()
        if entered!=1:raise ValueError('Insertion hook not entered exactly once')
        if raw_bytes(ids)!=raw_bytes(captured['input_ids']):raise ValueError('Input IDs changed')
    except BaseException as exc:failure=exc
    finally:
        if handle is not None:handle.remove()
    return captured,dict(forward_completed=finished,hook_entries=entered,**connection.last_info),failure


def validate_capture(v,phase,ids,info):
    length=len(ids);shapes={'input_ids':(1,length),'hidden_before':(1,length,1024),
        'hidden_after':(1,length,1024),'returned':(1,length,1024),'full_logits':(49155,)}
    required=set(shapes)
    for name,shape in shapes.items():
        dtype=torch.int64 if name=='input_ids' else torch.bfloat16
        if name not in v or not isinstance(v[name],torch.Tensor) or tuple(v[name].shape)!=shape or v[name].dtype!=dtype:
            raise ValueError('Capture shape/dtype differs: '+name)
    if v['input_ids'].tolist()!=[ids]:raise ValueError('Captured input differs')
    if raw_bytes(v['hidden_before'])!=raw_bytes(v['hidden_after']):raise ValueError('Original hidden input mutated')
    if raw_bytes(v['returned'][:,:-1])!=raw_bytes(v['hidden_before'][:,:-1]):raise ValueError('Nonfinal position changed')
    routed=phase in ('main','wrong')
    if info['reader_entered']!=routed or info['reader_completed']!=routed:raise ValueError('Reader accounting differs')
    if routed:
        required|=set(INTERMEDIATE_SHAPES)
        for name,shape in INTERMEDIATE_SHAPES.items():
            if name not in v or not isinstance(v[name],np.ndarray) or v[name].dtype!=np.float64 or v[name].shape!=shape:
                raise ValueError('Reader shape/dtype differs: '+name)
        if float(v['rms'])<=0:raise ValueError('Reader RMS invalid')
    resolved=routed and info['resolved'] is True
    writes=phase=='uniform' or resolved
    if any(info[k]!=resolved for k in ('organ_entered','organ_completed')):raise ValueError('Organ accounting differs')
    if any(info[k]!=writes for k in ('writer_entered','writer_completed','patched')):raise ValueError('Writer accounting differs')
    if resolved:
        energy_shapes={'query':(8,19),'linear1_input':(8,19),'linear1':(8,32),'gelu1_input':(8,32),
          'gelu1':(8,32),'linear2_input':(8,32),'linear2':(8,32),'gelu2_input':(8,32),
          'gelu2':(8,32),'linear3_input':(8,32),'linear3':(8,1),'energies':(8,)}
        required|=set(energy_shapes)
        for name,shape in energy_shapes.items():
            if name not in v or v[name].dtype!=torch.float32 or tuple(v[name].shape)!=shape or v[name].device.type!='cpu':
                raise ValueError('Energy operand differs: '+name)
        for a,b in [('query','linear1_input'),('linear1','gelu1_input'),('gelu1','linear2_input'),
                    ('linear2','gelu2_input'),('gelu2','linear3_input'),('linear3','energies')]:
            if raw_bytes(v[a])!=raw_bytes(v[b]):raise ValueError('Energy interstage bytes differ')
        from assembly import query_batch
        if raw_bytes(v['query'])!=raw_bytes(query_batch(info['query_state'],info['query_action'])):
            raise ValueError('Actual query encoding differs')
        if info['query_state']!=(info['predicted_state']+(phase=='wrong'))%8 or info['query_action']!=info['predicted_action']:
            raise ValueError('Wrong-condition transformation differs')
        for key in ('energy_hook_entries','energy_hook_finished'):
            if info[key]!={k:1 for k in ('linear1','linear2','linear3','gelu1','gelu2')}:raise ValueError('Energy hook coverage differs')
    if writes:
        writer_shapes={'probabilities_cpu':(8,),'probabilities':(8,),'centered':(8,),
                       'delta32':(1024,),'delta_host':(1024,)}
        required|=set(writer_shapes)
        for name,shape in writer_shapes.items():
            dtype=torch.bfloat16 if name=='delta_host' else torch.float32
            if name not in v or tuple(v[name].shape)!=shape or v[name].dtype!=dtype:raise ValueError('Writer operand differs: '+name)
        if raw_bytes(v['probabilities_cpu'])!=raw_bytes(v['probabilities']):raise ValueError('Probability transfer differs')
        if phase=='uniform' and raw_bytes(v['probabilities_cpu'])!=raw_bytes(torch.full((8,),.125)):
            raise ValueError('Uniform vector differs')
    elif raw_bytes(v['returned'])!=raw_bytes(v['hidden_before']):raise ValueError('No-patch branch changed hidden')
    if set(v)!=required:raise ValueError('Missing or extra captured tensor: '+str(set(v)^required))
    for name,value in v.items():
        finite=np.isfinite(value).all() if isinstance(value,np.ndarray) else bool(torch.isfinite(value).all())
        if not finite:raise ValueError('Nonfinite capture: '+name)
    return True


def compare_calls(previous,current,bound):
    a=previous['full_logits'].float().numpy().astype(np.float64);b=current['full_logits'].float().numpy().astype(np.float64)
    ha=previous['hidden_before'].float().numpy().astype(np.float64);hb=current['hidden_before'].float().numpy().astype(np.float64)
    error=float(np.max(np.abs(a-b)))
    return dict(full_vocabulary_max_absolute_error=error,full_vocabulary_raw_equal=raw_bytes(previous['full_logits'])==raw_bytes(current['full_logits']),
        hidden_raw_equal=raw_bytes(previous['hidden_before'])==raw_bytes(current['hidden_before']),
        hidden_max_absolute_error=float(np.max(np.abs(ha-hb))),**{'pass':error<=bound})


def initial_counts():
    return dict(forward_attempts=0,forward_finished=0,reader_attempts=0,reader_finished=0,
        organ_attempts=0,organ_finished=0,writer_attempts=0,writer_finished=0,
        analytical_fits=0,backward_attempts=0,backward_finished=0,optimizer_attempts=0,optimizer_steps=0)


def run_calls(modules,connection,contexts,schedule,input_tensors,directory,plan_sha,layer,bound,expected_identity,event,sample,guard,counts):
    (directory/'calls').mkdir();baselines={};initial_reader=reader_hash(connection.reader_arrays)
    for active in schedule:
        phase=active['phase'];context=contexts[active['context_id']]
        if identity(modules)!=expected_identity or reader_hash(connection.reader_arrays)!=initial_reader:raise ValueError('Precall ownership changed')
        before=sample('before:'+active['id']);guard(before)
        if counts['forward_attempts']>=264:raise ValueError('Host forward ceiling')
        def forward_start():
            counts['forward_attempts']+=1;event('forward_started',**active)
        def application_event(name):
            prefix,suffix=name.rsplit('_',1);key=prefix+('_attempts' if suffix=='started' else '_finished')
            counts[key]+=1
            if counts[key]>{'reader':192,'organ':192,'writer':216}[prefix]:raise ValueError('Application ceiling')
            event(name,**active)
        organ=modules[active['world_id']] if active['world_id'] is not None else None
        values,info,failure=collect_forward(modules['host'],input_tensors[context['id']],connection,organ,layer,phase,forward_start,application_event)
        if info['forward_completed']:
            counts['forward_finished']+=1
            try:event('forward_finished',**active)
            except BaseException as exc:
                if failure is None:failure=exc
        paths=retain(directory,'calls/'+active['id'],values,dict(**active,plan_sha256=plan_sha,**info))
        after=sample('after:'+active['id'])
        row=dict(**active,**paths,**info,controls_pass=False,comparisons={},error=None,resources_before=before,resources_after=after)
        if failure is None:
            try:
                validate_capture(values,phase,context['input_ids'],info)
                if phase in CONTROLS:
                    for old_phase,old_values in baselines.get(context['id'],{}).items():
                        comp=compare_calls(old_values,values,bound);row['comparisons'][old_phase]=comp
                        if not comp['pass']:raise ValueError('Fixed native-output control bound failed')
                guard(after)
                if identity(modules)!=expected_identity or reader_hash(connection.reader_arrays)!=initial_reader:raise ValueError('Postcall ownership changed')
                row['controls_pass']=True
            except BaseException as exc:failure=exc
        if failure is not None:row['error']=type(failure).__name__+': '+str(failure)
        append(directory/'calls.jsonl',row);event('forward_saved',**active)
        if failure is not None:raise failure
        if phase in CONTROLS:baselines.setdefault(context['id'],{})[phase]=values
        if phase=='restored':del baselines[context['id']]
    if baselines:raise ValueError('Incomplete brackets')


def main(deadline_utc):
    import protocol as p
    plan=p.verify();plan_sha=p.digest(p.OUT/'plan.json');started=p.read(p.OUT/'STARTED.json')
    if started['owner_pid']!=os.getppid() or started['plan_sha256']!=plan_sha or started['deadline_utc']!=deadline_utc:raise ValueError('Owner binding differs')
    if any((p.OUT/n).exists() for n in ('WORKER_STARTED.json','COLLECTED.json','STOPPED.json','COMPLETE.json')):raise ValueError('Worker already attempted')
    deadline=datetime.fromisoformat(deadline_utc)
    if deadline.tzinfo is None:raise ValueError('Timezone absent')
    p.create(p.OUT/'WORKER_STARTED.json',dict(at_utc=p.now(),worker_pid=os.getpid(),owner_pid=os.getppid(),plan_sha256=plan_sha,deadline_utc=deadline_utc))
    start=time.monotonic();modules={};before_identity=None;active=None;resources=[];counts=initial_counts()
    def event(name,**fields):append(p.OUT/'worker-events.jsonl',dict(at_utc=p.now(),event=name,**fields))
    def sample(stage):
        rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if platform.system()!='Darwin':rss*=1024
        r=dict(stage=stage,elapsed_seconds=time.monotonic()-start,rss_high_water_bytes=int(rss),mps_driver_bytes=int(torch.mps.driver_allocated_memory()))
        resources.append(r);event('resources',**r);return r
    def guard(r):
        if datetime.now(timezone.utc)>=deadline:raise TimeoutError('Fixed owner deadline expired')
        if r['rss_high_water_bytes']>p.SETTINGS['max_rss_bytes'] or r['mps_driver_bytes']>p.SETTINGS['max_mps_driver_bytes']:raise RuntimeError('Fixed resource ceiling exceeded')
    def terminated(signum,frame):raise SystemExit(128+signum)
    prior_signal=signal.signal(signal.SIGTERM,terminated)
    try:
        event('worker_started',worker_pid=os.getpid(),owner_pid=os.getppid(),deadline_utc=deadline_utc)
        if datetime.now(timezone.utc)>=deadline:raise TimeoutError('Deadline before loading')
        import transformers
        from transformers import AutoModelForCausalLM
        from transformers.models.granitemoe import modeling_granitemoe
        if (platform.python_version(),torch.__version__,transformers.__version__,np.__version__)!=('3.12.14','2.8.0','4.56.2','2.3.3'):raise ValueError('Pinned runtime differs')
        if not torch.backends.mps.is_available() or digest(inspect.getfile(modeling_granitemoe))!=plan['installed_model_source_sha256']:raise ValueError('Pinned native implementation differs')
        torch.set_num_threads(4)
        if torch.get_num_threads()!=4:raise ValueError('Threads differ')
        guard(sample('before_loading'))
        cache_before=p.validate_model_files(plan);p.create(p.OUT/'MODEL_CACHE_BEFORE.json',cache_before)
        reader_module=p.load_source('bound_live_energy_reader',p.REUSED['reader'])
        writer_module=p.load_source('bound_live_energy_writer',p.REUSED['writer'])
        organ_module=p.load_source('bound_live_energy_organ',p.REUSED['organ'])
        rd=plan['reader_artifact'];arrays=load_reader(p.ROOT/rd['path'],p.ROOT/rd['metadata_path'],rd)
        wd=plan['writer_artifact'];writer=load_writer(p.ROOT/wd['path'],p.ROOT/wd['metadata_path'],wd,writer_module.OutcomeWriter()).to('mps').eval()
        organs={wid:load_organ(p.ROOT/d['path'],d,organ_module.EnergyOrgan()).eval() for wid,d in plan['organ_artifacts'].items()}
        host=AutoModelForCausalLM.from_pretrained(p.ROOT/plan['model_path'],local_files_only=True,torch_dtype=torch.bfloat16,attn_implementation='eager').to('mps').eval()
        modules={'host':host,'writer':writer,**organs};before_identity=identity(modules)
        if any(before_identity['hooks'].values()) or not all(all(v.values()) for v in before_identity['grad_none'].values()):raise ValueError('Preexisting instrumentation/gradients')
        if len(before_identity['requires_grad']['host'])!=218:raise ValueError('Host parameter coverage differs')
        host.config.use_cache=False
        if host.config.logits_scaling!=6:raise ValueError('Logit scaling differs')
        for module in modules.values():
            for parameter in module.parameters():parameter.requires_grad_(False)
        during=identity(modules);states_before={k:state_hash(m) for k,m in modules.items()};reader_before=reader_hash(arrays)
        if len(states_before['host'])!=219 or states_before['host']!=plan['expected_host_state']:raise ValueError('Host state differs')
        if states_before['writer']!=wd['member_sha256'] or any(states_before[k]!=plan['organ_artifacts'][k]['state_sha256'] for k in organs):raise ValueError('Auxiliary state differs after transfer')
        retain(p.OUT,'reader-initial',arrays,dict(plan_sha256=plan_sha))
        for k,m in modules.items():
            if k!='host':retain(p.OUT,k+'-initial',dict(m.state_dict()),dict(plan_sha256=plan_sha))
        connection=LiveEnergyConnection(arrays,reader_module.apply_reader,reader_module.decisions,writer)
        contexts={c['id']:c for c in plan['contexts']}
        if len(contexts)!=24 or len(plan['schedule'])!=264:raise ValueError('Fixed panel differs')
        ids={k:torch.tensor([c['input_ids']],dtype=torch.int64,device='mps') for k,c in contexts.items()}
        def tracked_event(name,**fields):
            nonlocal active
            if name=='forward_started':active={k:fields[k] for k in ('index','id','phase','context_id','world_id')}
            event(name,**fields)
        run_calls(modules,connection,contexts,plan['schedule'],ids,p.OUT,plan_sha,20,p.SETTINGS['max_control_logit_error'],during,tracked_event,sample,guard,counts)
        expected=initial_counts();expected.update(forward_attempts=264,forward_finished=264,reader_attempts=192,reader_finished=192,
            organ_attempts=counts['organ_finished'],organ_finished=counts['organ_finished'],writer_attempts=24+counts['organ_finished'],writer_finished=24+counts['organ_finished'])
        if counts!=expected or counts['organ_finished']>192:raise ValueError('Fixed call accounting differs')
        states_after={k:state_hash(m) for k,m in modules.items()};reader_after=reader_hash(arrays)
        if states_before!=states_after or reader_before!=reader_after:raise ValueError('Frozen parameters changed')
        retain(p.OUT,'reader-final',arrays,dict(plan_sha256=plan_sha))
        for k,m in modules.items():
            if k!='host':retain(p.OUT,k+'-final',dict(m.state_dict()),dict(plan_sha256=plan_sha))
        cache_after=p.validate_model_files(plan);p.create(p.OUT/'MODEL_CACHE_AFTER.json',cache_after)
        after=restore(modules,before_identity)
        checks=dict(ownership_restored=after==before_identity,states_unchanged=states_before==states_after,
            reader_unchanged=reader_before==reader_after,cache_unchanged=cache_before==cache_after,exact_counts=counts==expected)
        if not all(checks.values()):raise ValueError('Terminal identity/control failure')
        guard(sample('complete'))
        p.create(p.OUT/'WORKER_COMPLETE.json',dict(status='WORKER_COMPLETED',at_utc=p.now(),plan_sha256=plan_sha,counts=counts,
            states_before=states_before,states_after=states_after,reader_state_before=reader_before,reader_state_after=reader_after,
            identities_before=before_identity,identities_during=during,identities_after=after,checks=checks,resource_samples=resources,
            elapsed_seconds=time.monotonic()-start,analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0))
        event('worker_completed',counts=counts)
        exclusions=set(plan['collection_exclusions'])
        inventory={str(f.relative_to(p.OUT)):digest(f) for f in sorted(p.OUT.rglob('*')) if f.is_file() and str(f.relative_to(p.OUT)) not in exclusions}
        p.create(p.OUT/'COLLECTED.json',dict(at_utc=p.now(),plan_sha256=plan_sha,counts=counts,all_controls_pass=True,artifact_sha256=inventory))
    except BaseException as exc:
        cleanup=None;cleanup_error=None
        if modules and before_identity is not None:
            try:cleanup=restore(modules,before_identity)
            except BaseException as error:cleanup_error=repr(error)
        reason=type(exc).__name__+': '+str(exc)
        try:event('worker_failed',counts=counts,reason=reason)
        finally:p.create(p.OUT/'WORKER_FAILURE.json',dict(at_utc=p.now(),plan_sha256=plan_sha,counts=counts,active_schedule_entry=active,
            reason=reason,identities_before=before_identity,cleanup_identities=cleanup,cleanup_error=cleanup_error,retry_allowed=False))
        raise
    finally:signal.signal(signal.SIGTERM,prior_signal)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--deadline-utc',required=True)
    main(parser.parse_args().deadline_utc)
