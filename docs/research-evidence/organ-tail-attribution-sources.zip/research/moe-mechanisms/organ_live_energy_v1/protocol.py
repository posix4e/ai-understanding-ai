"""One prospective, fixed-component, live energy-to-language assembly.

Preparation reads metadata and opaque hashes only. Old runs remain immutable.
"""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT/'outputs/moe-mechanisms/ORGAN_LIVE_ENERGY_V1'
PREP = ROOT/'outputs/moe-mechanisms/ORGAN_LIVE_ENERGY_V1_PREPARATION'
PYTHON = ROOT/'work/acquisition-representation-venv/bin/python'
OLD_SOURCE = ROOT/'research/moe-mechanisms/organ_transplant_v2'
LIVE = ROOT/'outputs/moe-mechanisms/ORGAN_LIVE_READER_V1'
OLD = ROOT/'outputs/moe-mechanisms/ORGAN_DEVELOPMENT_V2'
WRITER = ROOT/'outputs/moe-mechanisms/ORGAN_WRITER_V1'
RECOVERY = ROOT/'outputs/moe-mechanisms/ORGAN_WRITER_RECOVERY_V1'
REUSED = {
    'reader': ROOT/'research/moe-mechanisms/organ_live_reader_v1/reader.py',
    'reader_audit': ROOT/'research/moe-mechanisms/organ_live_reader_v1/audit.py',
    'predecessor_protocol': ROOT/'research/moe-mechanisms/organ_live_reader_v1/protocol.py',
    'writer': ROOT/'research/moe-mechanisms/organ_writer_v1/writer.py',
    'writer_audit': ROOT/'research/moe-mechanisms/organ_writer_v1/audit.py',
    'organ': OLD_SOURCE/'organ.py',
    'cache_helper': ROOT/'research/moe-mechanisms/model_cache_validation/cache_files.py',
    'launch_primitive': OLD_SOURCE/'durable_launch.py',
}
REUSED_SHA = {
    'reader':'2bde0ac906d82cfb9d70ec65e920cb16ef6d2abe13d12b09de7bc7da6e6769b7',
    'reader_audit':'d8dbad6ad8585f15746638873c966b8c548da4271adcd61b4c9c4df7865a291f',
    'predecessor_protocol':'2eb888a5f872148b47238eeddb1ca0e271b253d70dc1e12fc3d6192ed1b1759d',
    'writer':'e060d5d3f937e481dd1f75ce3978fd553e0043652cb26d6b47547c5ca6d1a4ea',
    'writer_audit':'b8f52d7b2ea6b03a1b4b31daede2a086b4d6a79393087273ff5d566424cbc1fe',
    'organ':'fda62a514b1b70dc719ddef3eb260002d1413933915622b775e76c88fbff1164',
    'cache_helper':'69b3f31e3a471abd0b488ad432a7e559ea31bec7044b77786409f5e6696d893e',
    'launch_primitive':'8402a52c467d8571f33b4ee203880ad3348665e591048f64adedbcef417e2a13',
}
LIVE_PLAN_SHA = 'c7cc9fde579fc5deccb5d4cdd41c98974919aea733a790c3f6ca998659a27779'
LIVE_COMPLETE_SHA = '39fc10a5d9d9c898ea7f9b23fd94441019505dabbd2cb88f4c56fa3c02246bb7'
WORLD_IDS = ['dev00','dev01','dev02','dev03']
SETTINGS = dict(python='3.12.14', torch='2.8.0', transformers='4.56.2', numpy='2.3.3',
    host_forwards=264, reader_applications=192, organ_forwards_max=192, writer_forwards_max=216,
    contexts=24, worlds=4, analytical_fits=0, backwards=0, optimizer_steps=0, provider_calls=0,
    generated_tokens=0, insertion_layer=20, position='last', dtype='bfloat16', device='mps',
    reader_dtype='float64', reader_device='cpu', organ_dtype='float32', organ_device='cpu',
    organ_query_shape=[8,19], temperature=1.0, writer_dtype='float32', writer_device='mps',
    threads=4, batch_size=1, attention='eager', cache=False, logits_scaling=6,
    timeout_seconds=600, max_rss_bytes=10*1024**3, max_mps_driver_bytes=10*1024**3,
    max_control_logit_error=0.08664339756999316,
    rms_atol=1e-12, rms_rtol=1e-12, feature_atol=1e-12, feature_rtol=1e-12,
    score_atol=1e-9, score_rtol=1e-8, gelu_atol=2e-6, gelu_rtol=2e-6, softmax_atol=2e-7,
    dot_gamma_multiplier=4, dot_reference_u_multiplier=2, dot_tiny_multiplier=8)
SOURCES = ('protocol.py','assembly.py','worker.py','audit.py','owner.py','launch.py',
           'test_assembly.py','test_worker.py','test_audit.py','test_protocol.py')
COLLECTION_EXCLUSIONS = ('owner-events.jsonl','worker.log','independent_audit.log','COLLECTED.json')
REVIEW_FILES = ('WORKER_SCHEMA.json','SOURCE_REVIEW.json','PREPARATION_TESTS.json',
               'SOURCE_IMPLEMENTATION_REVIEW.json','AUDITOR_SOURCE_REVIEW.json')


def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def relative(path): return str(Path(path).relative_to(ROOT))
def require(ok,message):
    if not ok: raise ValueError(message)
def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def safe_path(directory,name):
    p=Path(name);require(not p.is_absolute() and '..' not in p.parts,'Unsafe artifact path')
    target=Path(directory)/p;require(target.resolve().is_relative_to(Path(directory).resolve()),'Artifact escapes directory')
    return target
def load_source(name,path):
    path=Path(path);keys=[k for k,v in REUSED.items() if v==path]
    require(len(keys)==1 and digest(path)==REUSED_SHA[keys[0]],'Unbound reused source')
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module
def predecessor(): return load_source('bound_energy_predecessor_protocol',REUSED['predecessor_protocol'])


def validate_contexts(contexts):
    require(len(contexts)==24,'Expected24 contexts')
    for i,c in enumerate(contexts):
        s,a=divmod(i,3)
        require(c['id']==f's{s}-a{a}' and type(c['state']) is int and type(c['action']) is int
                and c['state']==s and c['action']==a,'Context order/address differs')
        require(c['split']==('held' if a==s%3 else 'train'),'Original fit split differs')
        require(c['prompt']==f"World state {s}. Actions {'XYZ'[a]}. Next state:",'Prompt differs')
        require(isinstance(c['input_ids'],list) and 1<=len(c['input_ids'])<=48 and c['input_ids'][0]==0
                and all(type(x) is int and 0<=x<49155 for x in c['input_ids']),'Input IDs differ')


def schedule(contexts):
    validate_contexts(contexts);rows=[]
    for c in contexts:
        phases=[('native',None),('uniform',None)]
        phases += [(phase,w) for w in WORLD_IDS for phase in ('main','wrong')]
        phases += [('restored',None)]
        for phase,w in phases:
            i=len(rows);rows.append(dict(index=i,id=f'{i:04d}',context_id=c['id'],phase=phase,world_id=w))
    require(len(rows)==264,'Schedule count differs')
    return rows


def build_inputs():
    """Validate predecessor metadata without loading any saved tensor."""
    pp=predecessor();old_live=pp.verify()
    require(digest(LIVE/'plan.json')==LIVE_PLAN_SHA and digest(LIVE/'COMPLETE.json')==LIVE_COMPLETE_SHA,
            'Live reader result changed')
    lc,la=read(LIVE/'COMPLETE.json'),read(LIVE/'INDEPENDENT_AUDIT.json')
    require(not (LIVE/'STOPPED.json').exists() and lc['status']=='LIVE_READER_ADMISSION_PASSED'
            and lc['gate_pass'] is True and la['status']=='PASS' and la['gate_pass'] is True,
            'Live reader was not admitted')
    require(lc['plan_sha256']==la['plan_sha256']==LIVE_PLAN_SHA and
            lc['report_sha256']==la['report_sha256']==digest(LIVE/'REPORT.json') and
            lc['independent_audit_sha256']==digest(LIVE/'INDEPENDENT_AUDIT.json'),'Live reader chain differs')
    bindings=dict(old_live['lineage_sha256'])
    def bind(path,expected=None):
        h=digest(path);require(expected is None or h==expected,'Changed prerequisite: '+str(path))
        bindings[relative(path)]=h
    live_collection=read(LIVE/'COLLECTED.json')
    require(la['collected_sha256']==digest(LIVE/'COLLECTED.json') and
            live_collection['plan_sha256']==LIVE_PLAN_SHA,'Live reader collection link differs')
    for name in ('plan.json','REGISTRATION.json','COMPLETE.json','REPORT.json','INDEPENDENT_AUDIT.json','COLLECTED.json'):
        bind(LIVE/name)
    live_prep=LIVE.with_name(LIVE.name+'_PREPARATION')
    parent=read(live_prep/'PARENT_TERMINAL_RECOUNT.json')
    require(parent['status']=='PASS_PARENT_LIVE_READER_RECOUNT' and parent['gate_pass'] is True and
            parent['complete_sha256']==LIVE_COMPLETE_SHA,'Reader parent recount differs')
    review=read(live_prep/'TERMINAL_REVIEW.json')
    require(review['status']=='PASS_INDEPENDENT_TERMINAL_METADATA_REVIEW' and review['issues']==[],
            'Reader terminal metadata review absent')
    for name in ('PARENT_TERMINAL_RECOUNT.json','TERMINAL_REVIEW.json'):bind(live_prep/name)
    contexts=old_live['contexts'];validate_contexts(contexts)
    op=read(OLD/'plan.json');worlds=op['worlds'];oc=read(OLD/'COLLECTED.json')
    require([w['id'] for w in worlds]==WORLD_IDS and op['settings']['temperature']==1.0,'World identity/temperature differs')
    for world in worlds:
        require(len(world['transitions'])==3 and all(sorted(row)==list(range(8)) for row in world['transitions']),
                'World permutations differ')
    organ_artifacts={}
    for world in worlds:
        wid=world['id'];meta=OLD/f'organ-{wid}.json';weights=OLD/f'organ-{wid}.pt'
        bind(meta,oc['artifact_sha256'][meta.name]);m=read(meta)
        bind(weights,oc['artifact_sha256'][weights.name])
        require(m['world_id']==wid and m['weight_file_sha256']==digest(weights)
                and m['strict_correct']==24 and m['memory_strict_correct']==24,'Original organ admission differs')
        require(set(m['state_sha256'])=={'input_proj.weight','hidden_proj.weight','output_proj.weight'},'Organ parameter inventory differs')
        organ_artifacts[wid]=dict(path=relative(weights),sha256=digest(weights),state_sha256=m['state_sha256'])
    rp=read(RECOVERY/'plan.json');inventory=rp['original_inventory_sha256']
    for name in ('COLLECTED.json','TRAINING_COMPLETE.json','writer-final.pt','writer-final.npz','writer-final.json'):
        bind(WRITER/name,inventory[name])
    wc=read(WRITER/'COLLECTED.json');training=read(WRITER/'TRAINING_COMPLETE.json')
    for name in ('TRAINING_COMPLETE.json','writer-final.pt','writer-final.npz','writer-final.json'):
        require(wc['artifact_sha256'][name]==inventory[name],'Writer collection differs')
    require(training['writer_weights_sha256']==inventory['writer-final.pt'] and
            training['forward_sha256']==inventory['writer-final.npz'] and
            training['forward_metadata_sha256']==inventory['writer-final.json'],'Writer checkpoint boundary differs')
    wm=read(WRITER/'writer-final.json')['tensors']['weight']
    require(wm['dtype']=='torch.float32' and wm['shape']==[1024,8] and
            {'weight':wm['raw_sha256']}==training['writer_state_sha256'],'Writer matrix identity differs')
    writer_artifact=dict(path=relative(WRITER/'writer-final.npz'),sha256=inventory['writer-final.npz'],
        metadata_path=relative(WRITER/'writer-final.json'),metadata_sha256=inventory['writer-final.json'],
        member_sha256=training['writer_state_sha256'])
    for name in ('ORGAN_LIVE_ENERGY_PROPOSAL.json','ORGAN_EXECUTED_ENERGY_ASSEMBLY_DESIGN_REVIEW.json',
                 'ORGAN_ENERGY_NUMERICAL_ALLOWANCE_REVIEW.json'):bind(ROOT/'outputs/moe-mechanisms'/name)
    tokens=read(OLD/'TOKENIZED_QUESTIONS.json');require(tokens['label_ids']==list(range(34,42)),'Label vocabulary changed')
    keep={k:old_live[k] for k in ('reader_artifact','expected_host_state','model_path','model_cache_repository',
                                'model_files','installed_model_source_sha256')}
    return dict(**keep,contexts=contexts,worlds=worlds,label_ids=tokens['label_ids'],schedule=schedule(contexts),
                writer_artifact=writer_artifact,organ_artifacts=organ_artifacts,lineage_sha256=bindings)


def validate_model_files(plan):return predecessor().validate_model_files(plan)
def source_hashes():
    for key,path in REUSED.items():require(digest(path)==REUSED_SHA[key],'Reused source changed: '+key)
    return {relative(path):digest(path) for path in [*[HERE/n for n in SOURCES],*REUSED.values()]}


def prepare():
    require(not OUT.exists(),'Already registered/interrupted; never recreate')
    hashes=source_hashes();review=read(PREP/'SOURCE_REVIEW.json');tests=read(PREP/'PREPARATION_TESTS.json')
    require(review.get('status')=='PASS_SOURCE_REVIEW' and review.get('source_sha256')==hashes
            and review.get('settings')==SETTINGS,'Source review absent/stale')
    require(tests.get('status')=='PASS' and tests.get('source_sha256')==hashes,'Tests absent/stale')
    for name in ('SOURCE_IMPLEMENTATION_REVIEW.json','AUDITOR_SOURCE_REVIEW.json'):
        r=read(PREP/name);require(r.get('status','').startswith('PASS'),'Independent review absent')
        require(all(hashes.get(k)==v for k,v in r['source_sha256'].items()),'Independent review stale')
    inputs=build_inputs()
    for name in REVIEW_FILES:inputs['lineage_sha256'][relative(PREP/name)]=digest(PREP/name)
    plan=dict(status='PROSPECTIVE_LIVE_ENERGY_ASSEMBLY',created_at_utc=now(),settings=SETTINGS,
        source_sha256=hashes,collection_exclusions=list(COLLECTION_EXCLUSIONS),**inputs,
        gates=dict(reader_correct=192,main_correct=96,wrong_query_following=96,organ_query_fidelity=192,
                   paired_following=96,allow_ties=False),
        scope='One-step live execution of four fixed learned energy modules through fixed reader and writer on24 exposed contexts. No fit, new world, external rollout, generated text or provider calls.',
        arithmetic='Per-operation FP32 MLP checks use actual saved consumed inputs; exact intermediate links; linear4gamma_n*sumabs+2u*abs(reference)+8tiny32; GELU2e-6+2e-6abs(reference); stable softmax(-actualFP32energy) absolute2e-7. Frozen independent FP64 reader and FP32writer/BF16cast/add checks reused.',
        unresolved='Any nonunique/inconsistent finite reader address takes an explicitly recorded no-organ/no-patch path. The same host call and entire fixed panel continue. The route is a behavioral failure even if native output happens to match. No oracle/default route.',
        controls='Native/uniform/restored three pairs percontext72 full-vocabulary comparisons withinln2/8. UniformP=.125 is shared acrossworlds. Original hidden input unchanged; writer returned nonfinal rows exact; cross-call hidden differences descriptive.',
        failure='Structural/control/resource failure stops without partial scientific assessment or retry. Complete valid finite wrong/tied panel receives a negative gate. No post-result fitting, altered shape, tolerance rescue or checkpoint selection.',
        automatic_next_study=False)
    validate_model_files(plan);OUT.mkdir()
    for name,h in hashes.items():
        target=OUT/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
        require(digest(target)==h,'Source copy changed')
    create(OUT/'plan.json',plan);create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)


def verify():
    plan=read(OUT/'plan.json')
    require(read(OUT/'REGISTRATION.json')['plan_sha256']==digest(OUT/'plan.json') and plan['settings']==SETTINGS,
            'Plan/settings changed')
    require(plan['schedule']==schedule(plan['contexts']) and plan['source_sha256']==source_hashes(),'Schedule/source set changed')
    for field in ('source_sha256','lineage_sha256'):
        for name,h in plan[field].items():require(digest(safe_path(ROOT,name))==h,'Bound file changed: '+name)
    for name,h in plan['source_sha256'].items():require(digest(safe_path(OUT/'sources',name))==h,'Archived source changed')
    return plan


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare']);parser.parse_args();prepare()
