"""Invented metadata and mocked processes only; no model or saved-study reads."""
from contextlib import ExitStack, contextmanager
from copy import deepcopy
import json
from pathlib import Path
import signal
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import launch
import owner
import protocol


def contexts():
    return [dict(id=f's{s}-a{a}', state=s, action=a,
                 split='held' if a == s % 3 else 'train',
                 prompt=f"World state {s}. Actions {'XYZ'[a]}. Next state:",
                 input_ids=[0, 10+s, 20+a])
            for s in range(8) for a in range(3)]


class ProtocolTests(unittest.TestCase):
    def test_schedule_has_complete_ordered_brackets_without_mutating_inputs(self):
        data = contexts()
        before = deepcopy(data)
        rows = protocol.schedule(data)
        self.assertEqual(data, before)
        self.assertEqual(len(rows), 264)
        for i, c in enumerate(data):
            bracket = rows[11*i:11*i+11]
            self.assertEqual([r['phase'] for r in bracket], ['native', 'uniform']+['main', 'wrong']*4+['restored'])
            self.assertEqual([r['world_id'] for r in bracket], [None, None]+[w for w in ('dev00','dev01','dev02','dev03') for _ in range(2)]+[None])
            self.assertEqual([r['context_id'] for r in bracket], [c['id']]*11)
            self.assertEqual([r['index'] for r in bracket], list(range(11*i, 11*i+11)))
            self.assertEqual([r['id'] for r in bracket], [f'{j:04d}' for j in range(11*i, 11*i+11)])
        self.assertEqual(sum(c['split'] == 'held' for c in data), 8)

    def test_context_inventory_rejects_missing_duplicate_reorder_and_changed_metadata(self):
        bad = [contexts()[:-1]]
        for key, value in [('id', 's0-a1'), ('state', True), ('action', True),
                           ('split', 'train'), ('prompt', 'A changed question')]:
            c = contexts(); c[0][key] = value; bad.append(c)
        c = contexts(); c[0], c[1] = c[1], c[0]; bad.append(c)
        c = contexts(); c[1] = deepcopy(c[0]); bad.append(c)
        for c in bad:
            with self.subTest(first=c[0]), self.assertRaises(ValueError):
                protocol.schedule(c)

    def test_input_ids_are_bounded_integers_with_explicit_bos(self):
        for ids in ([], [1, 20], [0, True], [0, -1], [0, 49155], [0]+[3]*48, (0, 3)):
            c = contexts(); c[0]['input_ids'] = ids
            with self.subTest(ids=ids), self.assertRaises(ValueError):
                protocol.validate_contexts(c)

    def test_artifact_paths_cannot_escape_via_traversal_or_symlink(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); inside = root/'inside'; inside.mkdir()
            outside = root/'outside'; outside.write_text('invented')
            (inside/'link').symlink_to(outside)
            self.assertEqual(protocol.safe_path(inside, 'new.json'), inside/'new.json')
            for name in ('../outside', str(outside), 'link'):
                with self.subTest(name=name), self.assertRaises(ValueError):
                    protocol.safe_path(inside, name)

    def test_json_receipts_are_exclusive(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary)/'receipt.json'
            protocol.create(path, {'original': True})
            with self.assertRaises(FileExistsError):
                protocol.create(path, {'replacement': True})
            self.assertEqual(protocol.read(path), {'original': True})


class RegistrationTests(unittest.TestCase):
    @contextmanager
    def fixture(self):
        """Tiny invented provenance, with real exclusive copies/hashes/JSON only."""
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            root = Path(temporary); here = root/'source'; here.mkdir()
            old = root/'old'; old.mkdir(); prep = root/'prep'; prep.mkdir()
            out = root/'output'
            source = here/'invented.py'; source.write_text('# invented source\n')
            primitive = old/'durable_launch.py'; primitive.write_text('# never imported\n')
            for name, value in dict(ROOT=root, HERE=here, OUT=out, PREP=prep,
                                    OLD_SOURCE=old).items():
                stack.enter_context(patch.object(protocol, name, value))
            def hashes(): return {'source/invented.py': protocol.digest(source)}
            stack.enter_context(patch.object(protocol, 'source_hashes', side_effect=hashes))
            inputs = dict(contexts=contexts(), schedule=protocol.schedule(contexts()), lineage_sha256={})
            build = stack.enter_context(patch.object(protocol, 'build_inputs', side_effect=lambda: deepcopy(inputs)))
            validate = stack.enter_context(patch.object(protocol, 'validate_model_files'))
            stack.enter_context(patch('builtins.print'))
            for name in protocol.REVIEW_FILES:
                value = {'status': 'PASS'}
                if name == 'SOURCE_REVIEW.json':
                    value = dict(status='PASS_SOURCE_REVIEW', source_sha256=hashes(), settings=protocol.SETTINGS)
                elif name in ('PREPARATION_TESTS.json','SOURCE_IMPLEMENTATION_REVIEW.json','AUDITOR_SOURCE_REVIEW.json'):
                    value['source_sha256'] = hashes()
                protocol.create(prep/name, value)
            yield SimpleNamespace(root=root, out=out, prep=prep, source=source,
                                  hashes=hashes, build=build, validate=validate)

    def test_exclusive_prepare_copies_sources_and_verifies_bound_reviews(self):
        with self.fixture() as f:
            protocol.prepare()
            plan = protocol.verify()
            self.assertEqual((f.out/'sources/source/invented.py').read_bytes(), f.source.read_bytes())
            self.assertEqual(plan['source_sha256'], f.hashes())
            self.assertEqual(len(plan['schedule']), 264)
            self.assertEqual(set(plan['lineage_sha256']), {'prep/'+n for n in protocol.REVIEW_FILES})
            f.build.assert_called_once_with(); f.validate.assert_called_once()
            original = (f.out/'REGISTRATION.json').read_bytes()
            with self.assertRaisesRegex(ValueError, 'never recreate'):
                protocol.prepare()
            self.assertEqual((f.out/'REGISTRATION.json').read_bytes(), original)

    def test_stale_review_or_test_binding_refuses_before_inputs_or_registration(self):
        for name in ('SOURCE_REVIEW.json', 'PREPARATION_TESTS.json'):
            with self.subTest(name=name), self.fixture() as f:
                path = f.prep/name; value = protocol.read(path)
                value['source_sha256'] = {'source/invented.py': 'wrong'}
                path.write_text(json.dumps(value))
                with self.assertRaises(ValueError): protocol.prepare()
                self.assertFalse(f.out.exists())
                f.build.assert_not_called(); f.validate.assert_not_called()

    def test_stale_independent_review_refuses_before_registration(self):
        with self.fixture() as f:
            path=f.prep/'AUDITOR_SOURCE_REVIEW.json';value=protocol.read(path)
            value['source_sha256']={'source/invented.py':'wrong'}
            path.write_text(json.dumps(value))
            with self.assertRaisesRegex(ValueError,'Independent review stale'):protocol.prepare()
            self.assertFalse(f.out.exists());f.build.assert_not_called()

    def test_verify_rejects_live_source_archive_registration_and_bound_review_changes(self):
        for changed in ('source', 'archive', 'registration', 'review'):
            with self.subTest(changed=changed), self.fixture() as f:
                protocol.prepare()
                path = {'source': f.source, 'archive': f.out/'sources/source/invented.py',
                        'registration': f.out/'REGISTRATION.json', 'review': f.prep/'WORKER_SCHEMA.json'}[changed]
                path.write_text('{"plan_sha256":"wrong"}' if changed == 'registration' else 'changed')
                with self.assertRaises(ValueError): protocol.verify()


class MetadataBindingTests(unittest.TestCase):
    @contextmanager
    def fixture(self):
        """Only invented JSON and opaque text bytes stand in for old artifacts."""
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            root=Path(temporary);base=root/'outputs/moe-mechanisms';base.mkdir(parents=True)
            live=base/'live';old=base/'old';writer=base/'writer';recovery=base/'recovery'
            live_prep=base/'live_PREPARATION'
            for p in (live,old,writer,recovery,live_prep):p.mkdir()
            for name,value in dict(ROOT=root,LIVE=live,OLD=old,WRITER=writer,RECOVERY=recovery).items():
                stack.enter_context(patch.object(protocol,name,value))
            old_live=dict(contexts=contexts(),lineage_sha256={},reader_artifact={'opaque':'reader'},
                expected_host_state={'opaque':'host'},model_path='mock/model',model_cache_repository='mock/cache',
                model_files={'opaque':'model'},installed_model_source_sha256='native-source')
            stack.enter_context(patch.object(protocol,'predecessor',return_value=SimpleNamespace(verify=lambda:deepcopy(old_live))))
            protocol.create(live/'plan.json',old_live);live_plan_sha=protocol.digest(live/'plan.json')
            protocol.create(live/'REGISTRATION.json',{'plan_sha256':live_plan_sha})
            protocol.create(live/'REPORT.json',{'invented':'summary'})
            protocol.create(live/'COLLECTED.json',dict(plan_sha256=live_plan_sha,artifact_sha256={'invented':'opaque'}))
            protocol.create(live/'INDEPENDENT_AUDIT.json',dict(status='PASS',gate_pass=True,
                plan_sha256=live_plan_sha,report_sha256=protocol.digest(live/'REPORT.json'),
                collected_sha256=protocol.digest(live/'COLLECTED.json')))
            protocol.create(live/'COMPLETE.json',dict(status='LIVE_READER_ADMISSION_PASSED',gate_pass=True,
                plan_sha256=live_plan_sha,report_sha256=protocol.digest(live/'REPORT.json'),
                independent_audit_sha256=protocol.digest(live/'INDEPENDENT_AUDIT.json')))
            complete_sha=protocol.digest(live/'COMPLETE.json')
            stack.enter_context(patch.object(protocol,'LIVE_PLAN_SHA',live_plan_sha))
            stack.enter_context(patch.object(protocol,'LIVE_COMPLETE_SHA',complete_sha))
            protocol.create(live_prep/'PARENT_TERMINAL_RECOUNT.json',dict(status='PASS_PARENT_LIVE_READER_RECOUNT',
                gate_pass=True,complete_sha256=complete_sha))
            protocol.create(live_prep/'TERMINAL_REVIEW.json',dict(status='PASS_INDEPENDENT_TERMINAL_METADATA_REVIEW',issues=[]))
            worlds=[dict(id=f'dev{i:02d}',transitions=[[int((s+a+i)%8)for s in range(8)]for a in range(3)])for i in range(4)]
            protocol.create(old/'plan.json',dict(worlds=worlds,settings={'temperature':1.0}))
            inventory={}
            for world in worlds:
                wid=world['id'];weights=old/f'organ-{wid}.pt';weights.write_bytes(b'not a checkpoint')
                metadata=old/f'organ-{wid}.json'
                protocol.create(metadata,dict(world_id=wid,weight_file_sha256=protocol.digest(weights),
                    strict_correct=24,memory_strict_correct=24,state_sha256={k:'invented'for k in
                        ('input_proj.weight','hidden_proj.weight','output_proj.weight')}))
                inventory.update({p.name:protocol.digest(p)for p in (metadata,weights)})
            protocol.create(old/'COLLECTED.json',{'artifact_sha256':inventory})
            protocol.create(old/'TOKENIZED_QUESTIONS.json',{'label_ids':list(range(34,42))})
            (writer/'writer-final.pt').write_bytes(b'not a checkpoint')
            (writer/'writer-final.npz').write_bytes(b'not an array archive')
            protocol.create(writer/'writer-final.json',{'tensors':{'weight':dict(dtype='torch.float32',shape=[1024,8],raw_sha256='invented-weight')}})
            protocol.create(writer/'TRAINING_COMPLETE.json',dict(writer_weights_sha256=protocol.digest(writer/'writer-final.pt'),
                forward_sha256=protocol.digest(writer/'writer-final.npz'),forward_metadata_sha256=protocol.digest(writer/'writer-final.json'),
                writer_state_sha256={'weight':'invented-weight'}))
            wrinventory={n:protocol.digest(writer/n)for n in ('TRAINING_COMPLETE.json','writer-final.pt','writer-final.npz','writer-final.json')}
            protocol.create(writer/'COLLECTED.json',{'artifact_sha256':wrinventory})
            wrinventory['COLLECTED.json']=protocol.digest(writer/'COLLECTED.json')
            protocol.create(recovery/'plan.json',{'original_inventory_sha256':wrinventory})
            for name in ('ORGAN_LIVE_ENERGY_PROPOSAL.json','ORGAN_EXECUTED_ENERGY_ASSEMBLY_DESIGN_REVIEW.json','ORGAN_ENERGY_NUMERICAL_ALLOWANCE_REVIEW.json'):
                protocol.create(base/name,{'invented':True})
            yield SimpleNamespace(root=root,live=live,old=old,writer=writer,recovery=recovery,old_live=old_live)

    def test_build_inputs_uses_complete_bound_artifacts_without_tensor_decoding(self):
        with self.fixture()as f:
            result=protocol.build_inputs()
            self.assertEqual(len(result['schedule']),264)
            self.assertEqual(result['contexts'],contexts())
            self.assertEqual(set(result['organ_artifacts']),{'dev00','dev01','dev02','dev03'})
            self.assertEqual(result['writer_artifact']['member_sha256'],{'weight':'invented-weight'})
            self.assertEqual(result['reader_artifact'],{'opaque':'reader'})
            for p in [f.writer/'writer-final.npz',f.writer/'TRAINING_COMPLETE.json',f.old/'organ-dev00.pt']:
                self.assertEqual(result['lineage_sha256'][str(p.relative_to(f.root))],protocol.digest(p))

    def test_changed_organ_weight_or_writer_archive_rejected(self):
        for kind in ('organ','writer'):
            with self.subTest(kind=kind),self.fixture()as f:
                p=f.old/'organ-dev00.pt'if kind=='organ'else f.writer/'writer-final.npz'
                p.write_bytes(b'changed')
                with self.assertRaisesRegex(ValueError,'Changed prerequisite'):protocol.build_inputs()

    def test_predecessor_collection_link_is_checked(self):
        with self.fixture()as f:
            path=f.live/'COLLECTED.json';value=protocol.read(path)
            value['artifact_sha256']['invented']='different';path.write_text(json.dumps(value))
            with self.assertRaisesRegex(ValueError,'Live reader collection link differs'):protocol.build_inputs()

    def test_writer_collection_link_and_organ_fidelity_cannot_be_bypassed(self):
        for kind in ('writer_link','organ_fidelity'):
            with self.subTest(kind=kind),self.fixture()as f:
                if kind=='writer_link':
                    p=f.writer/'COLLECTED.json';value=protocol.read(p)
                    value['artifact_sha256']['writer-final.npz']='wrong';p.write_text(json.dumps(value))
                    rp=f.recovery/'plan.json';recovery=protocol.read(rp)
                    recovery['original_inventory_sha256']['COLLECTED.json']=protocol.digest(p);rp.write_text(json.dumps(recovery))
                else:
                    p=f.old/'organ-dev00.json';value=protocol.read(p);value['strict_correct']=23;p.write_text(json.dumps(value))
                    cp=f.old/'COLLECTED.json';collection=protocol.read(cp)
                    collection['artifact_sha256'][p.name]=protocol.digest(p);cp.write_text(json.dumps(collection))
                with self.assertRaisesRegex(ValueError,'collection differs|organ admission differs'):protocol.build_inputs()

    def test_world_permutations_and_negative_live_reader_rejected(self):
        for kind in ('permutation','reader'):
            with self.subTest(kind=kind),self.fixture()as f:
                if kind=='permutation':
                    p=f.old/'plan.json';v=protocol.read(p);v['worlds'][0]['transitions'][0]=[0]*8;p.write_text(json.dumps(v))
                else:
                    p=f.live/'INDEPENDENT_AUDIT.json';v=protocol.read(p);v['gate_pass']=False;p.write_text(json.dumps(v))
                with self.assertRaises(ValueError):protocol.build_inputs()


class OwnerTests(unittest.TestCase):
    def test_owner_receipt_binds_command_plan_nonce_and_actual_pid(self):
        command = ['/invented/python', '-u', '/invented/owner.py', 'run']
        claim = dict(command=command, plan_sha256='plan', nonce='unique')
        receipt = dict(claim, owner_pid=123)
        owner.validate_owner_receipt(claim, receipt, command, 'plan', 123)
        for which, field, value in [('claim', 'nonce', ''), ('claim', 'command', command[:-1]),
                ('claim', 'plan_sha256', 'other'), ('receipt', 'nonce', 'other'),
                ('receipt', 'command', command+['retry']), ('receipt', 'plan_sha256', 'other'),
                ('receipt', 'owner_pid', 124)]:
            left, right = deepcopy(claim), deepcopy(receipt)
            (left if which == 'claim' else right)[field] = value
            with self.subTest(which=which, field=field), self.assertRaises(ValueError):
                owner.validate_owner_receipt(left, right, command, 'plan', 123)

    def test_reap_no_child_or_finished_child_never_signals(self):
        child = Mock(pid=321); child.poll.return_value = 0
        with patch.object(owner.os, 'killpg') as kill:
            owner.terminate_and_reap(None)
            owner.terminate_and_reap(child)
        kill.assert_not_called(); child.wait.assert_not_called()

    def test_term_reaps_child_without_unneeded_kill(self):
        child = Mock(pid=321); child.poll.return_value = None
        with patch.object(owner.os, 'killpg') as kill:
            owner.terminate_and_reap(child)
        kill.assert_called_once_with(321, signal.SIGTERM)
        child.wait.assert_called_once_with(timeout=5)

    def test_stubborn_child_gets_bounded_term_then_kill_and_reap(self):
        child = Mock(pid=321); child.poll.return_value = None
        child.wait.side_effect = [subprocess.TimeoutExpired('invented', 5), -9]
        with patch.object(owner.os, 'killpg') as kill:
            owner.terminate_and_reap(child)
        self.assertEqual([c.args for c in kill.call_args_list],
                         [(321, signal.SIGTERM), (321, signal.SIGKILL)])
        self.assertEqual([c.kwargs for c in child.wait.call_args_list], [{'timeout': 5}]*2)

    def test_exit_race_does_not_skip_reaping(self):
        child = Mock(pid=321); child.poll.return_value = None
        with patch.object(owner.os, 'killpg', side_effect=ProcessLookupError):
            owner.terminate_and_reap(child)
        child.wait.assert_called_once_with(timeout=5)

    def test_existing_start_or_terminal_refuses_before_dispatch(self):
        for name in ('STARTED.json', 'COMPLETE.json', 'STOPPED.json', 'COLLECTED.json'):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temporary:
                out = Path(temporary); (out/name).write_text('{}')
                with patch.object(owner, 'OUT', out), patch.object(owner, 'verify'), \
                     patch.object(owner, 'PathExecutable', return_value=owner.PYTHON.resolve()), \
                     patch.object(owner.subprocess, 'Popen') as popen:
                    with self.assertRaisesRegex(ValueError, 'never run again'):
                        owner.run()
                popen.assert_not_called()

    def test_timeout_preserves_stop_and_does_not_dispatch_audit(self):
        with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
            root = Path(temporary); out = root/'out'; out.mkdir()
            prep = root/'prep'; prep.mkdir(); here = root/'code'; here.mkdir()
            python = root/'python'
            (out/'plan.json').write_text('{"invented":true}')
            command = [str(python), '-u', str(here/'owner.py'), 'run']
            claim = dict(command=command, plan_sha256=protocol.digest(out/'plan.json'), nonce='toy')
            protocol.create(prep/'LAUNCH_REQUESTED.json', claim)
            protocol.create(prep/'LAUNCH_PID.json', dict(claim, owner_pid=123))
            for name, value in dict(ROOT=root, OUT=out, PREP=prep, HERE=here, PYTHON=python).items():
                stack.enter_context(patch.object(owner, name, value))
            stack.enter_context(patch.object(owner, 'verify'))
            stack.enter_context(patch.object(owner, 'PathExecutable', return_value=python.resolve()))
            for name in ('getpid', 'getpgid', 'getsid'):
                stack.enter_context(patch.object(owner.os, name, return_value=123))
            stack.enter_context(patch.object(owner.signal, 'signal'))
            kill = stack.enter_context(patch.object(owner.os, 'killpg'))
            child = Mock(pid=456); child.poll.return_value = None
            child.wait.side_effect = [subprocess.TimeoutExpired('toyworker', 600), -15]
            popen = stack.enter_context(patch.object(owner.subprocess, 'Popen', return_value=child))
            with self.assertRaisesRegex(TimeoutError, 'during worker'):
                owner.run()
            self.assertEqual(popen.call_count, 1)
            self.assertEqual(popen.call_args.args[0][:2], [str(python), str(here/'worker.py')])
            self.assertTrue(popen.call_args.kwargs['start_new_session'])
            stop = protocol.read(out/'STOPPED.json')
            self.assertFalse(stop['rerun_allowed'])
            self.assertFalse(stop['partial_scientific_interpretation_allowed'])
            self.assertIn('during worker', stop['reason'])
            self.assertFalse((out/'COMPLETE.json').exists())
            kill.assert_called_once_with(456, signal.SIGTERM)
            self.assertEqual([x['stage'] for x in map(json.loads, (out/'owner-events.jsonl').read_text().splitlines())], ['worker'])

    def test_valid_negative_audit_reports_actual_conditional_counts(self):
        with tempfile.TemporaryDirectory()as temporary,ExitStack()as stack:
            root=Path(temporary);out=root/'out';out.mkdir();prep=root/'prep';prep.mkdir();here=root/'code';here.mkdir()
            python=root/'python';(out/'plan.json').write_text('{"invented":true}')
            (here/'audit.py').write_text('# invented, never executed\n')
            plan_sha=protocol.digest(out/'plan.json')
            command=[str(python),'-u',str(here/'owner.py'),'run']
            claim=dict(command=command,plan_sha256=plan_sha,nonce='toy-negative')
            protocol.create(prep/'LAUNCH_REQUESTED.json',claim)
            protocol.create(prep/'LAUNCH_PID.json',dict(claim,owner_pid=123))
            # A single unresolved route skips one organ and writer application.
            protocol.create(out/'REPORT.json',dict(implementation_pass=True,gate_pass=False,
                counts=dict(organ_finished=191,writer_finished=215)))
            protocol.create(out/'INDEPENDENT_AUDIT.json',dict(status='PASS',implementation_pass=True,gate_pass=False,
                plan_sha256=plan_sha,report_sha256=protocol.digest(out/'REPORT.json'),audit_code_sha256=protocol.digest(here/'audit.py')))
            for name,value in dict(ROOT=root,OUT=out,PREP=prep,HERE=here,PYTHON=python).items():
                stack.enter_context(patch.object(owner,name,value))
            stack.enter_context(patch.object(owner,'verify'))
            stack.enter_context(patch.object(owner,'PathExecutable',return_value=python.resolve()))
            for name in ('getpid','getpgid','getsid'):stack.enter_context(patch.object(owner.os,name,return_value=123))
            stack.enter_context(patch.object(owner.signal,'signal'))
            stack.enter_context(patch('builtins.print'))
            children=[Mock(pid=456),Mock(pid=457)]
            for child in children:child.wait.return_value=0;child.poll.return_value=0
            popen=stack.enter_context(patch.object(owner.subprocess,'Popen',side_effect=children))
            owner.run()
            complete=protocol.read(out/'COMPLETE.json')
            self.assertEqual(complete['status'],'LIVE_ENERGY_ASSEMBLY_FAILED')
            self.assertFalse(complete['gate_pass']);self.assertEqual(popen.call_count,2)
            self.assertEqual((complete['host_forwards'],complete['reader_applications']),(264,192))
            self.assertEqual((complete['organ_forwards'],complete['writer_forwards']),(191,215))
            self.assertFalse((out/'STOPPED.json').exists())


class LaunchTests(unittest.TestCase):
    def test_dispatch_uses_only_new_fixed_owner_and_bound_primitive(self):
        module = SimpleNamespace(_launch_owner=Mock(return_value={'invented': True}), launch=Mock())
        spec = SimpleNamespace(loader=Mock())
        with patch.object(launch, 'verify') as verify, \
             patch.object(launch, 'digest', side_effect=[launch.PRIMITIVE_SHA, 'plan-sha']), \
             patch.object(launch.importlib.util, 'spec_from_file_location', return_value=spec), \
             patch.object(launch.importlib.util, 'module_from_spec', return_value=module):
            self.assertEqual(launch.launch(), {'invented': True})
        verify.assert_called_once_with(); module.launch.assert_not_called()
        module._launch_owner.assert_called_once_with(
            [str(launch.PYTHON), '-u', str(launch.HERE/'owner.py'), 'run'],
            launch.ROOT, launch.OUT, launch.PREP, 'plan-sha', 600)
        spec.loader.exec_module.assert_called_once_with(module)

    def test_verify_or_primitive_change_prevents_import_and_dispatch(self):
        for verification_error in (False, True):
            with self.subTest(verification_error=verification_error), \
                 patch.object(launch, 'verify', side_effect=ValueError('unbound') if verification_error else None), \
                 patch.object(launch, 'digest', return_value='wrong'), \
                 patch.object(launch.importlib.util, 'spec_from_file_location') as importer:
                with self.assertRaises(ValueError):
                    launch.launch()
                importer.assert_not_called()


if __name__ == '__main__':
    unittest.main()
