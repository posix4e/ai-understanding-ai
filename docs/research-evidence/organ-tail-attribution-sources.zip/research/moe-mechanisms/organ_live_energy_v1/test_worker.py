import json
from pathlib import Path
import tempfile
import types
import unittest
import numpy as np
import torch
import worker as w
from test_assembly import connection,organ,WRITER,ORGAN
class Config:
    use_cache=True;logits_scaling=6
    def to_dict(self):return dict(use_cache=self.use_cache,logits_scaling=self.logits_scaling)
class Block(torch.nn.Module):
    def forward(self,h):return h
class Model(torch.nn.Module):
    def __init__(self):
        super().__init__();self.config=Config();self.weight=torch.nn.Parameter(torch.zeros(1),requires_grad=False)
        self.model=torch.nn.Module();self.model.layers=torch.nn.ModuleList([Block()]);self.calls=0;self.fail=False;self.nonfinite=False;self.drift=False;self.skip=False;self.twice=False
    def forward(self,*,input_ids,use_cache,logits_to_keep,return_dict):
        assert (use_cache,logits_to_keep,return_dict)==(False,1,True)
        self.calls+=1;s,a=divmod(int(input_ids[0,-1])-1,3)
        h=torch.zeros((1,input_ids.shape[1],1024),dtype=torch.bfloat16);h[:,:,s]=1;h[:,:,8+a]=1;h[:,:,30]=-0.0
        if not self.skip:h=self.model.layers[0](h)
        if self.twice:h=self.model.layers[0](h)
        if self.fail:raise RuntimeError('invented suffix')
        v=torch.zeros((1,1,49155),dtype=torch.bfloat16);v[0,0,:11]=h[0,-1,:11]
        if self.nonfinite:v[0,0,20]=float('nan')
        if self.drift:v[0,0,21]=self.calls
        return types.SimpleNamespace(logits=v)
def panel():
    contexts={f's{s}-a{a}':dict(id=f's{s}-a{a}',input_ids=[0,3*s+a+1]) for s in range(8) for a in range(3)};rows=[]
    for key in contexts:
        phases=[('native',None),('uniform',None)]+[(p,f'dev{i:02d}') for i in range(4) for p in ('main','wrong')]+[('restored',None)]
        for phase,wid in phases:
            n=len(rows);rows.append(dict(index=n,id=f'{n:04d}',context_id=key,phase=phase,world_id=wid))
    return contexts,rows,{k:torch.tensor([v['input_ids']],dtype=torch.int64) for k,v in contexts.items()}
class WorkerTests(unittest.TestCase):
    def setup_modules(self,tied=False,model=None):
        c=connection(tied);mods={'host':model or Model(),'writer':c.writer,**{f'dev{i:02d}':organ() for i in range(4)}};return mods,c
    def collect(self,phase='main',model=None,energy=None):
        mods,c=self.setup_modules(model=model);v,i,e=w.collect_forward(mods['host'],torch.tensor([[0,1]]),c,(energy or mods['dev00']) if phase in ('main','wrong') else None,0,phase,lambda:None,lambda n:None);return mods,v,i,e
    def run_panel(self,d,model=None,tied=False,event_override=None):
        mods,c=self.setup_modules(tied,model);contexts,schedule,ids=panel();events=[];counts=w.initial_counts()
        def event(name,**fields):
            events.append(dict(event=name,**fields))
            if event_override:event_override(name)
        def sample(stage):
            r=dict(stage=stage,elapsed_seconds=0.,rss_high_water_bytes=0,mps_driver_bytes=0);event('resources',**r);return r
        w.run_calls(mods,c,contexts,schedule,ids,d,'a'*64,0,.08664339756999316,w.identity(mods),event,sample,lambda r:None,counts)
        return mods,counts,events
    def test_full_264_resolved_panel_and_72_controls(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);mods,counts,events=self.run_panel(d)
            self.assertEqual(counts['forward_finished'],264);self.assertEqual(counts['reader_finished'],192);self.assertEqual(counts['organ_finished'],192);self.assertEqual(counts['writer_finished'],216);self.assertEqual(len(events),2520)
            rows=[json.loads(x) for x in (d/'calls.jsonl').read_text().splitlines()]
            self.assertEqual(sum(len(r['comparisons']) for r in rows),72);self.assertTrue(all(r['controls_pass'] for r in rows))
            self.assertTrue(all(c['full_vocabulary_max_absolute_error']==0 for r in rows for c in r['comparisons'].values()));self.assertEqual(len(list((d/'calls').glob('*.npz'))),264)
    def test_full_tied_panel_no_energy_no_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);mods,counts,events=self.run_panel(d,tied=True)
            self.assertEqual(counts['forward_finished'],264);self.assertEqual(counts['reader_finished'],192);self.assertEqual(counts['organ_finished'],0);self.assertEqual(counts['writer_finished'],24)
            rows=[json.loads(x) for x in (d/'calls.jsonl').read_text().splitlines()];self.assertTrue(all(r['resolved'] is False for r in rows if r['phase'] in ('main','wrong')))
    def test_softmax_rounding_tie_completes_finite_capture(self):
        mods,v,i,e=self.collect(energy=organ(-1e-9));self.assertIsNone(e)
        self.assertEqual(int((v['energies']==v['energies'].min()).sum()),1);self.assertEqual(int((v['probabilities_cpu']==v['probabilities_cpu'].max()).sum()),8)
        self.assertTrue(w.validate_capture(v,'main',[0,1],i));self.assertTrue(i['writer_completed'])
    def test_shapes_interstage_dtype_locality(self):
        mods,v,i,e=self.collect();self.assertIsNone(e);self.assertTrue(w.validate_capture(v,'main',[0,1],i));self.assertEqual(v['hidden_before'][0,0,30].view(torch.int16).item(),-32768)
        v['linear2_input'][0,0]+=1
        with self.assertRaisesRegex(ValueError,'interstage'):w.validate_capture(v,'main',[0,1],i)
    def test_hidden_mutation_rejected(self):
        mods,v,i,e=self.collect();v['hidden_after'][0,0,30]=0
        with self.assertRaisesRegex(ValueError,'mutated'):w.validate_capture(v,'main',[0,1],i)
    def test_suffix_failure_current_raw_and_hook_cleanup(self):
        m=Model();m.fail=True;mods,v,i,e=self.collect(model=m);self.assertIsInstance(e,RuntimeError);self.assertIn('returned',v);self.assertNotIn('full_logits',v);self.assertTrue(i['writer_completed']);self.assertFalse(any(w.identity(mods)['hooks'].values()))
    def test_missing_repeated_hook_rejected(self):
        for flag in ('skip','twice'):
            m=Model();setattr(m,flag,True);mods,v,i,e=self.collect(model=m);self.assertIsNotNone(e);self.assertFalse(any(w.identity(mods)['hooks'].values()))
    def test_nonfinite_saved_before_stop(self):
        m=Model();m.nonfinite=True
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            with self.assertRaisesRegex(ValueError,'Nonfinite'):self.run_panel(d,model=m)
            row=json.loads((d/'calls.jsonl').read_text());self.assertEqual(m.calls,1)
            with np.load(d/row['forward_path'],allow_pickle=False) as z:self.assertTrue(np.isnan(z['full_logits__value']).any())
    def test_control_drift_keeps_failing_second_call(self):
        m=Model();m.drift=True
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            with self.assertRaisesRegex(ValueError,'control bound'):self.run_panel(d,model=m)
            rows=[json.loads(x) for x in (d/'calls.jsonl').read_text().splitlines()];self.assertEqual(len(rows),2);self.assertTrue((d/rows[-1]['forward_path']).exists())
    def test_finish_journal_failure_retains_forward(self):
        def event(n):
            if n=='forward_finished':raise OSError('invented journal')
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            with self.assertRaises(OSError):self.run_panel(d,event_override=event)
            row=json.loads((d/'calls.jsonl').read_text());self.assertTrue(row['forward_completed']);self.assertIn('journal',row['error'])
            with np.load(d/row['forward_path'],allow_pickle=False) as z:self.assertIn('full_logits__value',z.files)
    def test_raw_retention_scalar_and_bfloat16(self):
        mods,v,i,e=self.collect()
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);paths=w.retain(d,'capture',v,i);meta=json.loads((d/paths['forward_metadata_path']).read_text())
            with np.load(d/paths['forward_path'],allow_pickle=False) as z:
                for name,value in v.items():self.assertEqual(z[meta['tensors'][name]['raw_key']].tobytes(),w.raw_bytes(value))
                self.assertEqual(z['rms__value'].shape,());self.assertEqual(meta['tensors']['reader_centered']['dtype'],'numpy.float64')
    def test_restore_flags_exposes_unowned_hook(self):
        mods,c=self.setup_modules();before=w.identity(mods)
        for m in mods.values():
            m.train()
            for p in m.parameters():p.requires_grad_(True)
        mods['host'].config.use_cache=False;self.assertEqual(w.restore(mods,before),before)
        h=mods['dev00'].input_proj.register_forward_hook(lambda m,a,o:None);self.assertNotEqual(w.restore(mods,before),before);h.remove()
    def test_frozen_auxiliary_loaders(self):
        mods,c=self.setup_modules()
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);paths=w.retain(d,'writer',dict(c.writer.state_dict()),{})
            expected=dict(sha256=paths['forward_sha256'],metadata_sha256=paths['forward_metadata_sha256'],member_sha256=w.state_hash(c.writer))
            loaded=w.load_writer(d/'writer.npz',d/'writer.json',expected,WRITER.OutcomeWriter());self.assertEqual(w.state_hash(loaded),w.state_hash(c.writer))
            f=d/'organ.pt';torch.save(mods['dev00'].state_dict(),f);od=dict(sha256=w.digest(f),state_sha256=w.state_hash(mods['dev00']))
            self.assertEqual(w.state_hash(w.load_organ(f,od,ORGAN.EnergyOrgan())),od['state_sha256']);od['sha256']='0'*64
            with self.assertRaises(ValueError):w.load_organ(f,od,ORGAN.EnergyOrgan())
if __name__=='__main__':unittest.main()
