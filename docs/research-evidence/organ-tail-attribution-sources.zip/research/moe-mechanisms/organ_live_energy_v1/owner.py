"""One600-second live energy-assembly owner: worker, independent audit, then close."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timedelta, timezone
import argparse
import json
import os
import signal
import subprocess
import sys
import time
from protocol import ROOT,HERE,OUT,PREP,PYTHON,SETTINGS,verify,create,read,digest,now


def terminate_and_reap(child):
    if child is None or child.poll() is not None:
        return
    try:
        os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(child.pid,signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=5)


def validate_owner_receipt(claim, receipt, command, plan_sha256, pid):
    if (claim.get('command') != command or claim.get('plan_sha256') != plan_sha256
        or receipt.get('command') != command or receipt.get('plan_sha256') != plan_sha256
        or receipt.get('nonce') != claim.get('nonce') or not claim.get('nonce')
        or receipt.get('owner_pid') != pid):
        raise ValueError('This process is not the originally claimed owner')


def run():
    verify()
    if PathExecutable() != PYTHON.resolve():
        raise ValueError('Owner requires pinned Python')
    if any((OUT/n).exists() for n in ('STARTED.json','COMPLETE.json','STOPPED.json','COLLECTED.json')):
        raise ValueError('Already started or terminal; never run again')
    claim = read(PREP/'LAUNCH_REQUESTED.json')
    expected_command = [str(PYTHON),'-u',str(HERE/'owner.py'),'run']
    receipt_deadline = time.monotonic()+2
    while True:
        try:
            receipt = read(PREP/'LAUNCH_PID.json')
            break
        except (FileNotFoundError,json.JSONDecodeError):
            if time.monotonic() >= receipt_deadline:
                raise ValueError('Original launch PID receipt unavailable; no worker dispatch')
            time.sleep(0.02)
    validate_owner_receipt(claim,receipt,expected_command,digest(OUT/'plan.json'),os.getpid())
    if os.getpgid(0) != os.getpid() or os.getsid(0) != os.getpid():
        raise ValueError('Owner was not launched into the registered detached session')
    started = datetime.now(timezone.utc)
    deadline = started + timedelta(seconds=SETTINGS['timeout_seconds'])
    start = time.monotonic()
    create(OUT/'STARTED.json',dict(at_utc=started.isoformat(),deadline_utc=deadline.isoformat(),
           owner_pid=os.getpid(),plan_sha256=digest(OUT/'plan.json'),launch_nonce=claim['nonce']))
    child = None
    def interrupt(signum, frame):
        raise SystemExit(128+signum)
    old_handlers = {s:signal.signal(s,interrupt) for s in (signal.SIGTERM,signal.SIGINT)}
    def event(kind,**fields):
        with (OUT/'owner-events.jsonl').open('a') as stream:
            stream.write(json.dumps(dict(event=kind,at_utc=now(),**fields),allow_nan=False)+'\n')
            stream.flush();os.fsync(stream.fileno())
    try:
        commands = (
            ('worker',[str(PYTHON),str(HERE/'worker.py'),'--deadline-utc',deadline.isoformat()]),
            ('independent_audit',[str(PYTHON),str(HERE/'audit.py'),'--directory',str(OUT)]))
        for stage,command in commands:
            remaining = SETTINGS['timeout_seconds']-(time.monotonic()-start)
            if remaining <= 0:
                raise TimeoutError('Fixed total deadline exceeded before '+stage)
            with (OUT/f'{stage}.log').open('x') as log:
                child = subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                                         stdin=subprocess.DEVNULL,start_new_session=True)
                event('started',stage=stage,pid=child.pid,command=command)
                try:
                    code = child.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    raise TimeoutError('Fixed total deadline exceeded during '+stage)
            event('exit',stage=stage,pid=child.pid,code=code)
            if code != 0:
                raise RuntimeError(stage+' failed; preserve original raw records and logs')
            verify()
        audit = read(OUT/'INDEPENDENT_AUDIT.json')
        if (audit.get('status') != 'PASS' or audit.get('implementation_pass') is not True or type(audit.get('gate_pass')) is not bool
            or audit.get('plan_sha256') != digest(OUT/'plan.json')
            or audit.get('report_sha256') != digest(OUT/'REPORT.json')
            or audit.get('audit_code_sha256') != digest(HERE/'audit.py')):
            raise ValueError('Independent audit failed or binding differs')
        report = read(OUT/'REPORT.json')
        if report.get('implementation_pass') is not True or report.get('gate_pass') is not audit['gate_pass']:
            raise ValueError('Report/audit gate or implementation status differs')
        if time.monotonic()-start > SETTINGS['timeout_seconds']:
            raise TimeoutError('Fixed deadline exceeded during terminal binding checks')
        create(OUT/'COMPLETE.json',dict(at_utc=now(),status=('LIVE_ENERGY_ASSEMBLY_PASSED' if audit['gate_pass'] else 'LIVE_ENERGY_ASSEMBLY_FAILED'),
               plan_sha256=digest(OUT/'plan.json'),report_sha256=digest(OUT/'REPORT.json'),
               independent_audit_sha256=digest(OUT/'INDEPENDENT_AUDIT.json'),
               elapsed_seconds=time.monotonic()-start,host_forwards=264,reader_applications=192,
               backwards=0,optimizer_steps=0,analytical_fits=0,organ_forwards=report["counts"]["organ_finished"],
               writer_forwards=report["counts"]["writer_finished"],provider_calls=0,
               gate_pass=audit['gate_pass'],
               development_readiness_still_failed=True,scientific_confirmation=False,
               novelty_established=False,automatic_next_study=False))
        print(json.dumps(read(OUT/'COMPLETE.json')),flush=True)
    except BaseException as exc:
        cleanup_error = None
        try:
            terminate_and_reap(child)
        except BaseException as cleanup:
            cleanup_error = f'{type(cleanup).__name__}: {cleanup}'
        if not (OUT/'STOPPED.json').exists():
            create(OUT/'STOPPED.json',dict(at_utc=now(),status='LIVE_ENERGY_EXECUTION_STOPPED',
                   reason=f'{type(exc).__name__}: {exc}',plan_sha256=digest(OUT/'plan.json'),
                   elapsed_seconds=time.monotonic()-start,child_pid=child.pid if child else None,
                   child_returncode=child.poll() if child else None,cleanup_error=cleanup_error,
                   rerun_allowed=False,partial_scientific_interpretation_allowed=False))
        raise
    finally:
        for sig,handler in old_handlers.items():
            signal.signal(sig,handler)


def PathExecutable():
    from pathlib import Path
    return Path(sys.executable).resolve()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode',choices=['run'])
    parser.parse_args()
    run()
