"""Only the new fixed sibling owner can be dispatched by this CLI."""
import sys
sys.dont_write_bytecode = True
import importlib.util
import json
from protocol import ROOT,HERE,OUT,PREP,OLD_SOURCE,PYTHON,SETTINGS,verify,digest

PRIMITIVE_SHA = '8402a52c467d8571f33b4ee203880ad3348665e591048f64adedbcef417e2a13'


def command():
    return [str(PYTHON),'-u',str(HERE/'owner.py'),'run']


def launch():
    verify()
    path = OLD_SOURCE/'durable_launch.py'
    if digest(path) != PRIMITIVE_SHA:
        raise ValueError('Detached launch primitive changed')
    spec = importlib.util.spec_from_file_location('bound_detached_owner_primitive',path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Never call that module's original launch(), which targets closed V2.
    return module._launch_owner(command(),ROOT,OUT,PREP,digest(OUT/'plan.json'),
                                SETTINGS['timeout_seconds'])


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.parse_args()
    print(json.dumps(launch(),indent=2),flush=True)
