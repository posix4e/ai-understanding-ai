import importlib.util
from pathlib import Path
import unittest
import numpy as np
import torch
from assembly import LiveEnergyConnection,query_batch,raw
ROOT=Path(__file__).resolve().parents[3]
def source(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
READER=source('invented_reader','research/moe-mechanisms/organ_live_reader_v1/reader.py')
WRITER=source('invented_writer','research/moe-mechanisms/organ_writer_v1/writer.py')
ORGAN=source('invented_organ','research/moe-mechanisms/organ_transplant_v2/organ.py')
def arrays(tied=False):
    w=np.zeros((1024,11),dtype=np.float64)
    if not tied:w[:11,:]=np.eye(11)
    return dict(coefficients=w,x_mean=np.zeros(1024),y_mean=np.zeros(11))
def connection(tied=False):
    writer=WRITER.OutcomeWriter().eval();writer.weight.requires_grad_(False)
    with torch.no_grad():writer.weight[:8,:]=torch.eye(8)
    return LiveEnergyConnection(arrays(tied),READER.apply_reader,READER.decisions,writer)
def organ(scale=-4.):
    obj=ORGAN.EnergyOrgan().eval()
    with torch.no_grad():
        for p in obj.parameters():p.zero_();p.requires_grad_(False)
        obj.input_proj.weight[0,11]=1;obj.hidden_proj.weight[0,0]=1;obj.output_proj.weight[0,0]=scale
    return obj
def hidden(s=0,a=0):
    h=torch.zeros((1,3,1024),dtype=torch.bfloat16);h[:,:,s]=1;h[:,:,8+a]=1;h[:,:,30]=-0.0;return h
class AssemblyTests(unittest.TestCase):
    def test_numeric_query_all_candidates(self):
        q=query_batch(7,2);self.assertEqual(q.shape,(8,19));self.assertTrue(torch.equal(q[:,11:],torch.eye(8)))
        self.assertTrue(bool((q[:,7]==1).all()));self.assertTrue(bool((q[:,10]==1).all()))
        for args in [(8,0),(0,-1),(True,0),(0,1.)]:
            with self.assertRaises(ValueError):query_batch(*args)
    def test_main_wrong_literal_predicted_address(self):
        c=connection();o=organ();h=hidden(7,2)
        with torch.no_grad():c.apply(h,'main',o)
        self.assertEqual((c.last_info['query_state'],c.last_info['query_action']),(7,2))
        with torch.no_grad():out=c.apply(h,'wrong',o)
        self.assertEqual((c.last_info['query_state'],c.last_info['query_action']),(0,2));self.assertEqual(c.last_info['predicted_address'],23)
        self.assertEqual(raw(out[:,:-1]),raw(h[:,:-1]));self.assertEqual(c.last_capture['reader_centered'].dtype,np.float64)
        self.assertEqual(c.last_capture['centered'].dtype,torch.float32)
    def test_actual_energy_chain_and_hook_cleanup(self):
        c=connection();o=organ()
        with torch.no_grad():c.apply(hidden(),'main',o)
        v=c.last_capture
        for a,b in [('query','linear1_input'),('linear1','gelu1_input'),('gelu1','linear2_input'),('linear2','gelu2_input'),('gelu2','linear3_input'),('linear3','energies')]:self.assertEqual(raw(v[a]),raw(v[b]))
        self.assertEqual(raw(v['probabilities_cpu']),raw(v['probabilities']))
        self.assertTrue(all(not m._forward_hooks and not m._forward_pre_hooks for m in o.modules()))
    def test_tie_has_no_organ_writer_or_fallback(self):
        c=connection(True);o=organ();h=hidden();events=[]
        with torch.no_grad():out=c.apply(h,'main',o,events.append)
        self.assertIs(out,h);self.assertFalse(c.last_info['resolved']);self.assertEqual(events,['reader_started','reader_finished'])
        self.assertNotIn('query',c.last_capture);self.assertNotIn('probabilities',c.last_capture)
    def test_inconsistent_choice_is_unresolved(self):
        c=connection();original=c.reader_decisions
        def wrong(*a):
            v=original(*a);v['address']['winner']=23;return v
        c.reader_decisions=wrong
        with torch.no_grad():c.apply(hidden(),'main',organ())
        self.assertFalse(c.last_info['resolved']);self.assertEqual(c.last_info['unresolved_reason'],'inconsistent_choices');self.assertFalse(c.last_info['organ_entered'])
    def test_uniform_never_reads(self):
        c=connection();c.apply_reader=lambda *a:(_ for _ in()).throw(AssertionError('forbidden'));h=hidden()
        with torch.no_grad():out=c.apply(h,'uniform')
        self.assertTrue(torch.equal(out,h));self.assertFalse(c.last_info['reader_entered']);self.assertTrue(c.last_info['writer_completed'])
    def test_native_restored_original_object(self):
        for phase in ('native','restored'):
            c=connection();h=hidden()
            with torch.no_grad():out=c.apply(h,phase)
            self.assertIs(out,h);self.assertEqual(set(c.last_capture),{'returned'});self.assertFalse(c.last_info['patched'])
    def test_energy_failure_partial_capture_cleanup(self):
        c=connection();o=organ();handle=o.hidden_proj.register_forward_hook(lambda m,a,v:(_ for _ in()).throw(RuntimeError('invented failure')))
        with self.assertRaises(RuntimeError),torch.no_grad():c.apply(hidden(),'main',o)
        self.assertIn('linear1',c.last_capture);self.assertIn('linear2_input',c.last_capture);self.assertFalse(c.last_info['organ_completed']);handle.remove()
        self.assertTrue(all(not m._forward_hooks and not m._forward_pre_hooks for m in o.modules()))
    def test_writer_finish_journal_failure_retains_result(self):
        c=connection()
        def event(n):
            if n=='writer_finished':raise OSError('invented journal')
        with self.assertRaises(OSError),torch.no_grad():c.apply(hidden(),'uniform',None,event)
        self.assertIn('returned',c.last_capture);self.assertTrue(c.last_info['writer_completed'])
if __name__=='__main__':unittest.main()
