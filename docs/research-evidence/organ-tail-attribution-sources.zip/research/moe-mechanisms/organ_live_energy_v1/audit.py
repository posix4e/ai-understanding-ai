"""Independent full-panel audit of one-step live reader/energy/writer assembly.

Only immutable independent numerical cores are reused. No primary assembly,
reader, worker, model execution, optimization, or original audit entry is used.
Before registration, these functions may see invented arrays only.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.util
import itertools
import json
import math
import os
import sys
import time

import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'outputs/moe-mechanisms/ORGAN_LIVE_ENERGY_V1'
DEADLINE_SECONDS = 600
MEMORY_LIMIT = 10 * 1024**3
VOCAB = 49155
CONTROL_LIMIT = math.log(2) / 8
U = 2.0**-24
TINY32 = float(np.finfo(np.float32).tiny)
EXCLUSIONS = {'owner-events.jsonl', 'worker.log', 'independent_audit.log', 'COLLECTED.json'}
READER_CORE = ('research/moe-mechanisms/organ_live_reader_v1/audit.py',
               'd8dbad6ad8585f15746638873c966b8c548da4271adcd61b4c9c4df7865a291f')
WRITER_CORE = ('research/moe-mechanisms/organ_writer_v1/audit.py',
               'b8f52d7b2ea6b03a1b4b31daede2a086b4d6a79393087273ff5d566424cbc1fe')
READER_SHAPES = {'coefficients': (1024, 11), 'x_mean': (1024,), 'y_mean': (11,)}
READER_OUTPUT_SHAPES = {'h64': (1024,), 'rms': (), 'normalized': (1024,),
    'centered': (1024,), 'component_scores': (11,), 'address_scores': (24,)}
ORGAN_SHAPES = {'input_proj.weight': (32, 19), 'hidden_proj.weight': (32, 32), 'output_proj.weight': (1, 32)}
ENERGY_SHAPES = {'query': (8, 19), 'linear1_input': (8, 19), 'linear1': (8, 32),
    'gelu1_input': (8, 32), 'gelu1': (8, 32), 'linear2_input': (8, 32), 'linear2': (8, 32),
    'gelu2_input': (8, 32), 'gelu2': (8, 32), 'linear3_input': (8, 32),
    'linear3': (8, 1), 'energies': (8,), 'probabilities_cpu': (8,)}
WORLD_IDS = tuple(f'dev{i:02d}' for i in range(4))
_CORES = {}


class AuditError(ValueError): pass


def require(condition, message):
    if not condition: raise AuditError(message)


def digest(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path): return json.loads(Path(path).read_text())


def create(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')
        stream.flush(); os.fsync(stream.fileno())


def exact(a, b):
    a, b = np.asarray(a), np.asarray(b)
    return a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes()


def bound_core(binding):
    """Hash before every access; import only the independent pure audit module."""
    relative, expected = binding; path = ROOT / relative
    require(digest(path) == expected, 'Immutable independent numerical core changed')
    if relative not in _CORES:
        spec = importlib.util.spec_from_file_location('bound_assembly_' + path.parent.name + '_audit', path)
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        _CORES[relative] = module
    return _CORES[relative]


def safe(directory, name):
    require(type(name) is str and bool(name), 'Missing artifact path')
    relative = Path(name)
    require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe artifact path')
    path = Path(directory) / relative
    require(path.is_file() and path.resolve().is_relative_to(Path(directory).resolve()), 'Artifact missing or escapes directory')
    return path


def jsonl(path):
    rows = Path(path).read_text().splitlines()
    require(all(row.strip() for row in rows), 'Blank journal row')
    return [json.loads(row) for row in rows]


def strict_choice(values, maximum=True):
    a = np.asarray(values)
    require(a.ndim == 1 and len(a) >= 2 and np.isfinite(a).all(), 'Invalid candidate scores')
    best = max(map(float, a)) if maximum else min(map(float, a))
    winners = [i for i, value in enumerate(a) if float(value) == best]
    ordered = sorted(map(float, a), reverse=maximum)
    return dict(winners=winners, unique=len(winners) == 1,
                winner=winners[0] if len(winners) == 1 else None, gap=abs(ordered[0] - ordered[1]))


def canonical_queries(state, action):
    require(type(state) is int and 0 <= state < 8 and type(action) is int and 0 <= action < 3,
            'Invalid predicted rule address')
    result = np.zeros((8, 19), dtype=np.float32)
    result[:, state] = 1; result[:, 8 + action] = 1
    for candidate in range(8): result[candidate, 11 + candidate] = 1
    return result


def check_linear(inputs, weight, output):
    """Check each actual FP32 dot independently; no propagated reference drift."""
    x, w, y = map(np.asarray, (inputs, weight, output))
    require(x.dtype == w.dtype == y.dtype == np.float32 and x.ndim == w.ndim == y.ndim == 2,
            'Linear dtype/rank differs')
    require(x.shape[1] == w.shape[1] and y.shape == (x.shape[0], w.shape[0]) and
            all(np.isfinite(v).all() for v in (x, w, y)), 'Linear shape/nonfinite input')
    n = x.shape[1]; require(n in (19, 32), 'Unregistered linear contraction size')
    gamma = (n * U) / (1 - n * U); largest_error = 0.; largest_bound = 0.
    for row in range(x.shape[0]):
        for column in range(w.shape[0]):
            products = [float(x[row, j]) * float(w[column, j]) for j in range(n)]
            reference = math.fsum(products); absolute = math.fsum(abs(p) for p in products)
            allowance = 4 * gamma * absolute + 2 * U * abs(reference) + 8 * TINY32
            error = abs(float(y[row, column]) - reference)
            require(all(math.isfinite(v) for v in (reference, absolute, allowance, error)), 'Nonfinite linear bound')
            require(error <= allowance, 'FP32 energy linear operation exceeds fixed bound')
            largest_error = max(largest_error, error); largest_bound = max(largest_bound, allowance)
    return dict(contraction=n, maximum_absolute_error=largest_error, maximum_allowance=largest_bound)


def check_gelu(inputs, output):
    x, y = np.asarray(inputs), np.asarray(output)
    require(x.dtype == y.dtype == np.float32 and x.shape == y.shape == (8, 32) and
            np.isfinite(x).all() and np.isfinite(y).all(), 'GELU dtype/shape/nonfinite differs')
    largest_error = 0.; largest_bound = 0.
    for before, after in zip(x.ravel(), y.ravel()):
        value = float(before)
        reference = .5 * value * (1 + math.erf(value / math.sqrt(2)))
        allowance = 2e-6 + 2e-6 * abs(reference); error = abs(float(after) - reference)
        require(all(math.isfinite(v) for v in (reference, allowance, error)), 'Nonfinite GELU bound')
        require(error <= allowance, 'Exact-GELU operation exceeds fixed allowance')
        largest_error = max(largest_error, error); largest_bound = max(largest_bound, allowance)
    return dict(maximum_absolute_error=largest_error, maximum_allowance=largest_bound)


def check_energy(values, weights, state, action):
    for name, shape in ENERGY_SHAPES.items():
        value = np.asarray(values[name])
        require(value.dtype == np.float32 and value.shape == shape and np.isfinite(value).all(),
                'Energy trace dtype/shape/nonfinite differs: ' + name)
    for name, shape in ORGAN_SHAPES.items():
        value = np.asarray(weights[name])
        require(value.dtype == np.float32 and value.shape == shape and np.isfinite(value).all(),
                'Organ parameter dtype/shape/nonfinite differs')
    require(exact(values['query'], canonical_queries(state, action)), 'Actual organ query differs from predicted address')
    for consumed, produced in (('linear1_input','query'), ('gelu1_input','linear1'),
            ('linear2_input','gelu1'), ('gelu2_input','linear2'), ('linear3_input','gelu2')):
        require(exact(values[consumed], values[produced]), 'Actual organ interstage operand link differs')
    linear = [check_linear(values['query'], weights['input_proj.weight'], values['linear1']),
              check_linear(values['gelu1'], weights['hidden_proj.weight'], values['linear2']),
              check_linear(values['gelu2'], weights['output_proj.weight'], values['linear3'])]
    gelu = [check_gelu(values['linear1'], values['gelu1']), check_gelu(values['linear2'], values['gelu2'])]
    require(exact(values['linear3'].reshape(8), values['energies']), 'Energy reshape bytes differ')
    energies, p = values['energies'], values['probabilities_cpu']
    require(np.all(p >= 0) and np.all(p <= 1) and abs(math.fsum(map(float, p)) - 1) <= 2e-6,
            'Invalid actual probability simplex')
    minimum = min(map(float, energies)); exp = [math.exp(minimum - float(e)) for e in energies]
    denominator = math.fsum(exp); reference = [v / denominator for v in exp]
    errors = [abs(float(a) - b) for a, b in zip(p, reference)]
    require(all(math.isfinite(e) and e <= 2e-7 for e in errors), 'FP32 softmax exceeds fixed allowance')
    energy_choice, probability_choice = strict_choice(energies, False), strict_choice(p)
    # Numeric validation precedes strict behavior. FP32 softmax can turn a
    # small energy gap into a tie; retain that as a completed negative.
    categorical_match = energy_choice['winners'] == probability_choice['winners']
    return dict(linear=linear, gelu=gelu, maximum_softmax_error=max(errors),
                energy_choice=energy_choice, probability_choice=probability_choice,
                winning_sets_equal=categorical_match,
                unique_and_equal=energy_choice['unique'] and probability_choice['unique'] and categorical_match)


def independent_schedule(contexts):
    require(len(contexts) == 24, 'Expected exactly24 contexts')
    rows = []
    def put(phase, context, world=None):
        rows.append(dict(index=len(rows), id=f'{len(rows):04d}', phase=phase, context_id=context['id'], world_id=world))
    for index, c in enumerate(contexts):
        s, a = divmod(index, 3)
        require(c['id'] == f's{s}-a{a}' and type(c['state']) is int and c['state'] == s and
                type(c['action']) is int and c['action'] == a and
                c['split'] == ('held' if a == s % 3 else 'train'), 'Context identity/split differs')
        put('native', c); put('uniform', c)
        for world in WORLD_IDS: put('main', c, world); put('wrong', c, world)
        put('restored', c)
    require(len(rows) == 264, 'Internal schedule error')
    return rows


def route_from_decisions(decisions, phase):
    require(phase in ('main', 'wrong'), 'Route outside registered energy phases')
    resolved = all(decisions[k]['unique'] for k in ('state', 'action', 'address'))
    if not resolved: return dict(resolved=False, state=None, action=None, address=None)
    s, a = decisions['state']['winner'], decisions['action']['winner']
    if decisions['address']['winner'] != 3 * s + a:
        return dict(resolved=False, state=None, action=None, address=None)
    if phase == 'wrong': s = (s + 1) % 8
    return dict(resolved=True, state=s, action=a, address=3*s+a)


def derive_counts(resolved):
    require(type(resolved) is int and 0 <= resolved <= 192, 'Invalid resolved-call count')
    return dict(host_forwards=264, reader_applications=192, energy_forwards=resolved,
                writer_applications=24+resolved, unresolved_routes=192-resolved,
                analytical_fits=0, backwards=0, optimizer_steps=0, provider_calls=0, generated_tokens=0)


def summarize(rows, tables):
    require(len(rows) == 192 and len({r['id'] for r in rows}) == 192, 'Missing/duplicate main and wrong rows')
    expected={(f's{s}-a{a}',w,p) for s in range(8) for a in range(3) for w in WORLD_IDS for p in ('main','wrong')}
    require({(r['context_id'],r['world_id'],r['phase']) for r in rows} == expected, 'Scientific cell grid differs')
    by_key={(r['context_id'],r['world_id'],r['phase']):r for r in rows}
    groups={}
    for phase in ('main','wrong'):
        selected=[r for r in rows if r['phase']==phase]
        groups[phase]=dict(n=96,resolved=sum(r['route']['resolved'] for r in selected),
            reader_state_correct=sum(r['reader_state_correct'] for r in selected),
            reader_action_correct=sum(r['reader_action_correct'] for r in selected),
            reader_address_correct=sum(r['reader_address_correct'] for r in selected),
            organ_correct=sum(r['organ_correct'] for r in selected),
            original_task_correct=sum(r['original_task_correct'] for r in selected),
            selected_query_correct=sum(r['selected_query_correct'] for r in selected),
            host_ties=sum(not r['host_choice']['unique'] for r in selected))
    pairs=[];world_pairs=[]
    for s in range(8):
        for a in range(3):
            cid=f's{s}-a{a}'
            for world in WORLD_IDS:
                main,wrong=[by_key[cid,world,p] for p in ('main','wrong')]
                followed=main['original_task_correct'] and wrong['selected_query_correct'] and main['route']['resolved'] and wrong['route']['resolved']
                pairs.append(dict(context_id=cid,world_id=world,both_followed=bool(followed)))
            for first,second in itertools.combinations(WORLD_IDS,2):
                one,two=[by_key[cid,w,'main'] for w in (first,second)]
                t1,t2=tables[first][a][s],tables[second][a][s]
                world_pairs.append(dict(context_id=cid,first_world=first,second_world=second,
                    first_target=t1,second_target=t2,same_outcome=t1==t2,
                    both_followed=bool(one['route']['resolved'] and two['route']['resolved'] and
                                       one['original_task_correct'] and two['original_task_correct'])))
    require(len(pairs)==96 and len(world_pairs)==144,'Derived pair count differs')
    checks=dict(all192_routes_resolved=all(r['route']['resolved'] for r in rows),
        all192_reader_states_correct=all(r['reader_state_correct'] for r in rows),
        all192_reader_actions_correct=all(r['reader_action_correct'] for r in rows),
        all192_reader_addresses_correct=all(r['reader_address_correct'] for r in rows),
        all192_organs_correct_for_actual_query=all(r['organ_correct'] for r in rows),
        all96_main_original_targets_correct=groups['main']['original_task_correct']==96,
        all96_wrong_selected_query_targets_correct=groups['wrong']['selected_query_correct']==96,
        all96_main_wrong_pairs_followed=all(p['both_followed'] for p in pairs))
    return dict(groups=groups,readiness_checks=checks,gate_pass=all(checks.values()),
        main_wrong_pairs=dict(n=96,both_followed=sum(p['both_followed'] for p in pairs),rows=pairs),
        world_pairs=dict(n=144,both_followed=sum(p['both_followed'] for p in world_pairs),
                         same_outcome=sum(p['same_outcome'] for p in world_pairs),rows=world_pairs),
        counts=derive_counts(sum(r['route']['resolved'] for r in rows)))


# Independent structural utilities retained from the reviewed reader audit.
DTYPES = {'torch.bfloat16': ('<u2', 2), 'torch.float32': ('<f4', 4), 'torch.int64': ('<i8', 8), 'numpy.float64': ('<f8', 8)}

def decode(raw, dtype, shape):
    require(dtype in DTYPES, 'Unregistered tensor dtype')
    storage, width = DTYPES[dtype]
    raw = np.asarray(raw)
    require(raw.dtype == np.uint8 and raw.shape == (math.prod(shape) * width,), 'Malformed raw tensor bytes')
    data = np.frombuffer(raw.tobytes(), dtype=storage)
    if dtype == 'torch.bfloat16':
        data = (data.astype(np.uint32) << 16).view(np.float32)
    return data.reshape(shape)

def load_bundle(path, metadata_path, expected):
    metadata = read(metadata_path)
    require(set(metadata['tensors']) == set(expected), 'Unexpected tensor inventory')
    values, raws, keys = {}, {}, set()
    with np.load(path, allow_pickle=False) as archive:
        for name, (dtype, shape) in expected.items():
            meta = metadata['tensors'][name]
            require(meta['dtype'] == dtype and meta['shape'] == list(shape), 'Recorded tensor shape/type differs')
            rk, vk = name + '__raw_uint8', name + '__value'
            require(meta['raw_key'] == rk and meta['value_key'] == vk, 'Tensor key mapping differs')
            raw, readable = np.asarray(archive[rk]), np.asarray(archive[vk])
            value = decode(raw, dtype, shape)
            require(hashlib.sha256(raw.tobytes()).hexdigest() == meta['raw_sha256'], 'Raw tensor hash differs')
            require(exact(value, readable), 'Raw/readable bytes differ')
            require(np.isfinite(value).all(), 'Nonfinite retained tensor')
            values[name], raws[name] = value.copy(), raw.copy()
            keys.update((rk, vk))
        require(set(archive.files) == keys, 'Unexpected archive array member')
    return values, raws, metadata

def check_inventory(directory, collected, late=()):
    directory = Path(directory)
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*')
              if p.is_file() and str(p.relative_to(directory)) not in EXCLUSIONS | set(late)}
    require(set(collected['artifact_sha256']) == actual, 'Collection has missing or extra files')
    for name, sha in collected['artifact_sha256'].items():
        require(digest(safe(directory, name)) == sha, 'Collected artifact changed: ' + name)

def is_alive(pid):
    require(type(pid) is int and pid > 1, 'Invalid process identity')
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False

def owner_guard(directory, plan_sha):
    directory = Path(directory)
    started, worker = read(directory / 'STARTED.json'), read(directory / 'WORKER_STARTED.json')
    require(started['owner_pid'] == os.getppid() and is_alive(started['owner_pid']), 'Audit has no live original owner')
    require(started['plan_sha256'] == worker['plan_sha256'] == plan_sha and worker['owner_pid'] == started['owner_pid'],
            'Worker/owner plan or PID differs')
    begin, deadline = [datetime.fromisoformat(started[k]) for k in ('at_utc', 'deadline_utc')]
    require(begin.tzinfo is not None and deadline.tzinfo is not None and
            (deadline - begin).total_seconds() == DEADLINE_SECONDS and datetime.now(timezone.utc) < deadline,
            'Invalid or expired600-second deadline')
    require(worker['deadline_utc'] == started['deadline_utc'], 'Worker total deadline differs')
    handshake = time.monotonic() + 2
    while True:
        try:
            events = jsonl(directory / 'owner-events.jsonl')
        except (FileNotFoundError, json.JSONDecodeError):
            events = []
        if len(events) >= 3:
            break
        require(time.monotonic() < handshake and datetime.now(timezone.utc) < deadline, 'Audit dispatch journal unavailable')
        time.sleep(.02)
    require(len(events) == 3 and [(x['event'], x['stage']) for x in events] ==
            [('started', 'worker'), ('exit', 'worker'), ('started', 'independent_audit')], 'Owner lifecycle sequence differs')
    require(events[0]['pid'] == events[1]['pid'] == worker['worker_pid'] and events[1]['code'] == 0 and
            events[2]['pid'] == os.getpid() and not is_alive(worker['worker_pid']), 'Original worker did not exit successfully')
    here = Path(__file__).resolve().parent; python = ROOT / 'work/acquisition-representation-venv/bin/python'
    require(events[0]['command'] == [str(python), str(here / 'worker.py'), '--deadline-utc', started['deadline_utc']] and
            events[2]['command'] == [str(python), str(here / 'audit.py'), '--directory', str(directory)], 'Dispatch command differs')
    prep = ROOT / 'outputs/moe-mechanisms/ORGAN_LIVE_ENERGY_V1_PREPARATION'
    claim, launch = read(prep / 'LAUNCH_REQUESTED.json'), read(prep / 'LAUNCH_PID.json')
    expected = [str(python), '-u', str(here / 'owner.py'), 'run']
    require(claim['command'] == launch['command'] == expected and claim['plan_sha256'] == launch['plan_sha256'] == plan_sha and
            claim['nonce'] == launch['nonce'] == started['launch_nonce'] and launch['owner_pid'] == started['owner_pid'],
            'Original owner launch claim differs')
    require(os.getpgid(started['owner_pid']) == os.getsid(started['owner_pid']) == started['owner_pid'],
            'Original owner detached process identity differs')
    times = [datetime.fromisoformat(x['at_utc']) for x in events]
    require(all(t.tzinfo is not None for t in times) and begin <= times[0] <= times[1] <= times[2] < deadline,
            'Owner journal timing differs')
    return started, worker, events

def runtime_guard():
    import importlib.metadata
    import platform
    require(platform.python_version() == SETTINGS['python'] and np.__version__ == SETTINGS['numpy'], 'Auditor Python/NumPy differs')
    require(Path(sys.executable).resolve() == (ROOT / 'work/acquisition-representation-venv/bin/python').resolve(),
            'Auditor executable differs')
    for package in ('torch', 'transformers'):
        require(importlib.metadata.version(package) == SETTINGS[package], 'Installed package version differs')


SETTINGS = dict(python='3.12.14', torch='2.8.0', transformers='4.56.2', numpy='2.3.3',
    host_forwards=264, reader_applications=192, organ_forwards_max=192, writer_forwards_max=216,
    contexts=24, worlds=4, analytical_fits=0, backwards=0, optimizer_steps=0, provider_calls=0,
    generated_tokens=0, insertion_layer=20, position='last', dtype='bfloat16', device='mps',
    reader_dtype='float64', reader_device='cpu', organ_dtype='float32', organ_device='cpu',
    organ_query_shape=[8,19], temperature=1.0, writer_dtype='float32', writer_device='mps',
    threads=4, batch_size=1, attention='eager', cache=False, logits_scaling=6,
    timeout_seconds=600, max_rss_bytes=10*1024**3, max_mps_driver_bytes=10*1024**3,
    max_control_logit_error=CONTROL_LIMIT, rms_atol=1e-12, rms_rtol=1e-12,
    feature_atol=1e-12, feature_rtol=1e-12, score_atol=1e-9, score_rtol=1e-8,
    gelu_atol=2e-6, gelu_rtol=2e-6, softmax_atol=2e-7,
    dot_gamma_multiplier=4, dot_reference_u_multiplier=2, dot_tiny_multiplier=8)
LIVE_PLAN_SHA = 'c7cc9fde579fc5deccb5d4cdd41c98974919aea733a790c3f6ca998659a27779'
LIVE_COMPLETE_SHA = '39fc10a5d9d9c898ea7f9b23fd94441019505dabbd2cb88f4c56fa3c02246bb7'
REUSED_SHA = {
    'research/moe-mechanisms/organ_live_reader_v1/reader.py':'2bde0ac906d82cfb9d70ec65e920cb16ef6d2abe13d12b09de7bc7da6e6769b7',
    READER_CORE[0]:READER_CORE[1],
    'research/moe-mechanisms/organ_live_reader_v1/protocol.py':'2eb888a5f872148b47238eeddb1ca0e271b253d70dc1e12fc3d6192ed1b1759d',
    'research/moe-mechanisms/organ_writer_v1/writer.py':'e060d5d3f937e481dd1f75ce3978fd553e0043652cb26d6b47547c5ca6d1a4ea',
    WRITER_CORE[0]:WRITER_CORE[1],
    'research/moe-mechanisms/organ_transplant_v2/organ.py':'fda62a514b1b70dc719ddef3eb260002d1413933915622b775e76c88fbff1164',
    'research/moe-mechanisms/model_cache_validation/cache_files.py':'69b3f31e3a471abd0b488ad432a7e559ea31bec7044b77786409f5e6696d893e',
    'research/moe-mechanisms/organ_transplant_v2/durable_launch.py':'8402a52c467d8571f33b4ee203880ad3348665e591048f64adedbcef417e2a13'}


def verify_plan(directory, root=ROOT):
    directory, root = Path(directory), Path(root)
    plan = read(directory/'plan.json'); sha = digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256'] == sha, 'Registration differs')
    require(plan['settings'] == SETTINGS and set(plan['collection_exclusions']) == EXCLUSIONS,
            'Fixed settings/exclusions differ')
    require(plan['schedule'] == independent_schedule(plan['contexts']), 'Fixed264 schedule differs')
    require(plan['gates'] == dict(reader_correct=192,main_correct=96,wrong_query_following=96,
            organ_query_fidelity=192,paired_following=96,allow_ties=False), 'Admission gates differ')
    own='research/moe-mechanisms/organ_live_energy_v1/'
    names=('protocol.py','assembly.py','worker.py','audit.py','owner.py','launch.py',
           'test_assembly.py','test_worker.py','test_audit.py','test_protocol.py')
    require(set(plan['source_sha256']) == {own+n for n in names} | set(REUSED_SHA), 'Eighteen-source inventory differs')
    for name, expected in REUSED_SHA.items():
        require(plan['source_sha256'][name] == expected, 'Reused source hash differs')
    for field in ('source_sha256','lineage_sha256'):
        require(type(plan[field]) is dict and plan[field], 'Missing source/lineage inventory')
        for name, expected in plan[field].items():
            require(digest(safe(root,name)) == expected, 'Frozen source/lineage changed: '+name)
            if field == 'source_sha256':
                require(digest(safe(directory/'sources',name)) == expected, 'Archived source changed')
    require(plan['label_ids'] == list(range(34,42)), 'Eight candidate labels differ')
    for c in plan['contexts']:
        ids=c['input_ids']
        require(type(ids) is list and 1 <= len(ids) <= 48 and ids[0] == 0 and
                all(type(x) is int and 0 <= x < VOCAB for x in ids), 'Original input IDs malformed')
        require(c['prompt'] == f"World state {c['state']}. Actions {'XYZ'[c['action']]}. Next state:", 'Prompt changed')
    require([w['id'] for w in plan['worlds']] == list(WORLD_IDS), 'World order differs')
    for w in plan['worlds']:
        table=w['transitions']
        require(len(table)==3 and all(type(r) is list and len(r)==8 and
                all(type(v) is int for v in r) and sorted(r)==list(range(8)) for r in table), 'World table malformed')
    return plan,sha


def validate_lineage(plan, root=ROOT):
    """Reuse metadata-only predecessor checks, never its full audit entry."""
    root=Path(root);core=bound_core(READER_CORE)
    core.validate_lineage(plan,root=root)
    live=root/'outputs/moe-mechanisms/ORGAN_LIVE_READER_V1'
    require(digest(live/'plan.json')==LIVE_PLAN_SHA and digest(live/'COMPLETE.json')==LIVE_COMPLETE_SHA and
            not (live/'STOPPED.json').exists(), 'Live-reader predecessor changed/stopped')
    c,a,col=[read(live/n) for n in ('COMPLETE.json','INDEPENDENT_AUDIT.json','COLLECTED.json')]
    require(c['status']=='LIVE_READER_ADMISSION_PASSED' and c['gate_pass'] is True and
            a['status']=='PASS' and a['implementation_pass'] is True and a['gate_pass'] is True,
            'Live reader not admitted')
    require(c['plan_sha256']==a['plan_sha256']==col['plan_sha256']==LIVE_PLAN_SHA and
            read(live/'REGISTRATION.json')['plan_sha256']==LIVE_PLAN_SHA and
            c['report_sha256']==a['report_sha256']==digest(live/'REPORT.json') and
            c['independent_audit_sha256']==digest(live/'INDEPENDENT_AUDIT.json') and
            a['collected_sha256']==digest(live/'COLLECTED.json'), 'Live-reader artifact chain differs')
    liveplan=read(live/'plan.json')
    require(all(plan[k]==liveplan[k] for k in ('contexts','reader_artifact','expected_host_state','model_path',
                'model_cache_repository','model_files','installed_model_source_sha256')), 'Installed host/reader differs')
    old=root/'outputs/moe-mechanisms/ORGAN_DEVELOPMENT_V2';oldplan=read(old/'plan.json');oldcol=read(old/'COLLECTED.json')
    require(plan['worlds']==oldplan['worlds'] and oldplan['settings']['temperature']==1., 'Original worlds/temperature differ')
    require(set(plan['organ_artifacts'])==set(WORLD_IDS),'Organ artifact inventory differs')
    for wid,artifact in plan['organ_artifacts'].items():
        expected_path=f'outputs/moe-mechanisms/ORGAN_DEVELOPMENT_V2/organ-{wid}.pt'
        require(artifact['path']==expected_path and artifact['sha256']==oldcol['artifact_sha256'][f'organ-{wid}.pt']==
                digest(safe(root,artifact['path'])), 'Organ checkpoint provenance differs')
        meta=read(old/f'organ-{wid}.json')
        require(digest(old/f'organ-{wid}.json')==oldcol['artifact_sha256'][f'organ-{wid}.json'] and
                meta['weight_file_sha256']==artifact['sha256'] and meta['state_sha256']==artifact['state_sha256'] and
                set(artifact['state_sha256'])==set(ORGAN_SHAPES) and meta['world_id']==wid and
                meta['strict_correct']==meta['memory_strict_correct']==24, 'Frozen organ state provenance differs')
    writer=root/'outputs/moe-mechanisms/ORGAN_WRITER_V1'
    recovery=root/'outputs/moe-mechanisms/ORGAN_WRITER_RECOVERY_V1'
    original_inventory=read(recovery/'plan.json')['original_inventory_sha256']
    wc=read(writer/'COLLECTED.json');training=read(writer/'TRAINING_COMPLETE.json');artifact=plan['writer_artifact']
    for name in ('COLLECTED.json','TRAINING_COMPLETE.json','writer-final.pt','writer-final.npz','writer-final.json'):
        require(digest(writer/name)==original_inventory[name], 'Recovered final writer artifact changed')
        if name!='COLLECTED.json':require(wc['artifact_sha256'][name]==original_inventory[name], 'Writer collection link differs')
    require(artifact['path']=='outputs/moe-mechanisms/ORGAN_WRITER_V1/writer-final.npz' and
            artifact['metadata_path']=='outputs/moe-mechanisms/ORGAN_WRITER_V1/writer-final.json' and
            artifact['sha256']==training['forward_sha256']==original_inventory['writer-final.npz'] and
            artifact['metadata_sha256']==training['forward_metadata_sha256']==original_inventory['writer-final.json'] and
            training['writer_weights_sha256']==original_inventory['writer-final.pt'] and
            artifact['member_sha256']==training['writer_state_sha256'], 'Writer training-to-final boundary differs')


def load_fixed_parameters(directory,plan,plan_sha,root=ROOT):
    directory,root=Path(directory),Path(root)
    reader=bound_core(READER_CORE).load_frozen_reader(plan,root=root)
    wa=plan['writer_artifact']
    original,_,_=load_bundle(root/wa['path'],root/wa['metadata_path'],{'weight':('torch.float32',(1024,8))})
    reader_shapes={k:('numpy.float64',v) for k,v in READER_SHAPES.items()}
    loaded={};hashes={}
    specs=[('reader',reader_shapes,reader,plan['reader_artifact']['member_sha256']),
           ('writer',{'weight':('torch.float32',(1024,8))},original,wa['member_sha256'])]
    for wid in WORLD_IDS:
        specs.append((wid,{k:('torch.float32',v) for k,v in ORGAN_SHAPES.items()},None,
                      plan['organ_artifacts'][wid]['state_sha256']))
    for stem,shapes,reference,expected_hashes in specs:
        initial,raw,im=load_bundle(directory/(stem+'-initial.npz'),directory/(stem+'-initial.json'),shapes)
        final,final_raw,fm=load_bundle(directory/(stem+'-final.npz'),directory/(stem+'-final.json'),shapes)
        require(im['plan_sha256']==fm['plan_sha256']==plan_sha,'Parameter plan binding differs')
        h={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in raw.items()}
        require(h==expected_hashes,'Loaded parameter bytes differ from frozen admitted state')
        for name in shapes:
            require(exact(raw[name],final_raw[name]),'Frozen parameters changed during assembly')
            if reference is not None:require(exact(initial[name],reference[name]),'Recorded parameter differs from bound artifact')
        loaded[stem]=initial;hashes[stem]=h
    return loaded,hashes


def operation_counts(resolved):
    require(type(resolved) is int and 0 <= resolved <= 192, 'Invalid resolved count')
    return dict(forward_attempts=264,forward_finished=264,reader_attempts=192,reader_finished=192,
        organ_attempts=resolved,organ_finished=resolved,writer_attempts=24+resolved,writer_finished=24+resolved,
        analytical_fits=0,backward_attempts=0,backward_finished=0,optimizer_attempts=0,optimizer_steps=0)


def schedule_fields(record,entry):
    require(all(type(record.get(k)) is type(v) and record.get(k)==v for k,v in entry.items()),
            'Record schedule differs')


def validate_ownership(complete,plan,hashes,counts):
    require(complete['status']=='WORKER_COMPLETED' and complete['counts']==counts and
            all(type(v) is int for v in complete['counts'].values()),'Worker incomplete/counts differ')
    core=bound_core(READER_CORE);host_names=core.expected_state_keys()
    expected={'host':plan['expected_host_state'],'writer':hashes['writer'],
              **{wid:hashes[wid] for wid in WORLD_IDS}}
    require(set(plan['expected_host_state'])==host_names and
            complete['states_before']==complete['states_after']==expected,'Frozen component states differ')
    require(complete['reader_state_before']==complete['reader_state_after']==hashes['reader']==
            plan['reader_artifact']['member_sha256'],'Frozen reader differs')
    require(complete['checks']==dict(ownership_restored=True,states_unchanged=True,reader_unchanged=True,
                                    cache_unchanged=True,exact_counts=True),'Worker checks differ')
    before,during,after=[complete['identities_'+p] for p in ('before','during','after')]
    require(before==after,'Original ownership not restored')
    owners={'host','writer',*WORLD_IDS}
    names={'host':host_names-{'lm_head.weight'},'writer':{'weight'},
           **{wid:set(ORGAN_SHAPES) for wid in WORLD_IDS}}
    for identity in (before,during,after):
        require(set(identity)=={'requires_grad','training','hooks','forward_methods','grad_none','host_config'},
                'Identity fields differ')
        for field in set(identity)-{'host_config'}:require(set(identity[field])==owners,'Component ownership coverage differs')
        for owner in owners:
            require(set(identity['requires_grad'][owner])==set(identity['grad_none'][owner])==names[owner],
                    'Parameter identity coverage differs')
            require(all(type(v) is bool for v in identity['requires_grad'][owner].values()) and
                    all(v is True for v in identity['grad_none'][owner].values()),'Gradient ownership differs')
            require(identity['hooks'][owner]=={},'Unexpected component hook')
            require(identity['training'][owner] and identity['training'][owner]==before['training'][owner] and
                    all(v is False for v in identity['training'][owner].values()),'Component not in eval mode')
            require(set(identity['forward_methods'][owner])==set(identity['training'][owner]) and
                    identity['forward_methods'][owner]==before['forward_methods'][owner], 'Forward method identity differs')
        require(identity['host_config']['logits_scaling']==6,'Native logit scaling changed')
    require(all(v is False for group in during['requires_grad'].values() for v in group.values()),
            'Trainable parameters during assembly')
    cfg=dict(before['host_config']);cfg['use_cache']=False
    require(during['host_config']==cfg,'Active host configuration differs')
    for key in ('analytical_fits','backwards','optimizer_steps','provider_calls','generated_tokens'):
        require(type(complete[key]) is int and complete[key]==0,'Forbidden operation: '+key)
    require(type(complete['elapsed_seconds']) in (int,float) and math.isfinite(complete['elapsed_seconds']) and
            0<=complete['elapsed_seconds']<=DEADLINE_SECONDS,'Worker duration invalid')


def expected_events(schedule,calls):
    events=[('worker_started',None),('resources','before_loading')]
    for entry,row in zip(schedule,calls):
        events += [('resources','before:'+entry['id']),('forward_started',entry)]
        if entry['phase'] in ('main','wrong'):
            events += [('reader_started',entry),('reader_finished',entry)]
            if row['resolved']:
                events += [('organ_started',entry),('organ_finished',entry)]
        if entry['phase']=='uniform' or row['resolved'] is True:
            events += [('writer_started',entry),('writer_finished',entry)]
        events += [('forward_finished',entry),('resources','after:'+entry['id']),('forward_saved',entry)]
    events += [('resources','complete'),('worker_completed',None)]
    return events


def validate_events(events,schedule,calls,complete,started=None,worker=None):
    expected=expected_events(schedule,calls)
    require(len(events)==len(expected),'Worker journal coverage differs')
    resources=[];previous=-math.inf;last=None
    for event,(kind,payload) in zip(events,expected):
        require(event['event']==kind,'Worker operation order differs')
        moment=datetime.fromisoformat(event['at_utc'])
        require(moment.tzinfo is not None and (last is None or moment>=last),'Event timing differs');last=moment
        if started is not None:
            require(datetime.fromisoformat(started['at_utc'])<=moment<datetime.fromisoformat(started['deadline_utc']),
                    'Event outside original owner deadline')
        if kind=='resources':
            require(event['stage']==payload,'Resource sampling order differs')
            sample={k:v for k,v in event.items() if k not in ('at_utc','event')}
            require(set(sample)=={'stage','elapsed_seconds','rss_high_water_bytes','mps_driver_bytes'},'Resource schema differs')
            elapsed=sample['elapsed_seconds']
            require(type(elapsed) in (int,float) and math.isfinite(elapsed) and previous<=elapsed<=DEADLINE_SECONDS,
                    'Resource duration/order differs');previous=elapsed
            require(all(type(sample[k]) is int and 0<=sample[k]<=MEMORY_LIMIT for k in ('rss_high_water_bytes','mps_driver_bytes')),
                    'Fixed sampled memory ceiling exceeded')
            resources.append(sample)
        elif isinstance(payload,dict):schedule_fields(event,payload)
        elif kind=='worker_completed':require(event['counts']==complete['counts'],'Journal final counters differ')
        elif kind=='worker_started' and worker is not None:
            require(all(event[k]==worker[k] for k in ('worker_pid','owner_pid','deadline_utc')),'Worker journal owner differs')
    require(len(resources)==530 and resources==complete['resource_samples'],'Resource receipt differs')
    return resources


INFO_KEYS=('forward_completed','hook_entries','reader_entered','reader_completed','decisions','resolved',
           'predicted_state','predicted_action','predicted_address','query_state','query_action',
           'organ_entered','organ_completed','writer_entered','writer_completed','patched','unresolved_reason',
           'energy_hook_entries','energy_hook_finished')


def call_shapes(entry,length,resolved):
    shapes={'input_ids':('torch.int64',(1,length)),
        **{k:('torch.bfloat16',(1,length,1024)) for k in ('hidden_before','hidden_after','returned')},
        'full_logits':('torch.bfloat16',(VOCAB,))}
    if entry['phase'] in ('main','wrong'):
        shapes.update({('reader_centered' if k=='centered' else k):('numpy.float64',s)
                       for k,s in READER_OUTPUT_SHAPES.items()})
    if resolved:shapes.update({k:('torch.float32',s) for k,s in ENERGY_SHAPES.items()})
    if entry['phase']=='uniform' or resolved:
        shapes.update({k:('torch.float32',s) for k,s in dict(probabilities_cpu=(8,),probabilities=(8,),
                       centered=(8,),delta32=(1024,)).items()})
        shapes['delta_host']=('torch.bfloat16',(1024,))
    return shapes


def load_call(directory,row,entry,context,plan_sha):
    routed=entry['phase'] in ('main','wrong');resolved=row['resolved']
    require(type(resolved) is bool if routed else resolved is None,'Malformed resolved status')
    stem='calls/'+entry['id']
    require(row['forward_path']==stem+'.npz' and row['forward_metadata_path']==stem+'.json','Call path differs')
    path,meta=[safe(directory,row[k]) for k in ('forward_path','forward_metadata_path')]
    require(digest(path)==row['forward_sha256'] and digest(meta)==row['forward_metadata_sha256'],'Call hash differs')
    values,raw,metadata=load_bundle(path,meta,call_shapes(entry,len(context['input_ids']),resolved is True))
    schedule_fields(row,entry);schedule_fields(metadata,entry)
    require(metadata['plan_sha256']==plan_sha and all(row[k]==metadata[k] for k in INFO_KEYS),'Call metadata binding differs')
    require(row['forward_completed'] is True and type(row['hook_entries']) is int and row['hook_entries']==1 and
            row['controls_pass'] is True and row['error'] is None,'Failed/incomplete forward')
    require(all(row[k] is routed for k in ('reader_entered','reader_completed')),'Reader operation coverage differs')
    writes=entry['phase']=='uniform' or resolved is True
    require(all(row[k] is (resolved is True) for k in ('organ_entered','organ_completed')) and
            all(row[k] is writes for k in ('writer_entered','writer_completed','patched')),'Conditional operation coverage differs')
    require(exact(values['input_ids'],np.array([context['input_ids']],dtype=np.int64)),'Question token bytes differ')
    require(exact(raw['hidden_before'],raw['hidden_after']),'Same-call input hidden changed')
    require(exact(values['returned'][:,:-1],values['hidden_before'][:,:-1]),'Returned nonfinal positions changed')
    if not writes:require(exact(raw['returned'],raw['hidden_before']),'Unpatched branch changed hidden')
    if not routed:
        require(all(row[k] is None for k in ('decisions','predicted_state','predicted_action','predicted_address',
                'query_state','query_action','unresolved_reason','energy_hook_entries','energy_hook_finished')),
                'Control has an unrequested rule query')
    if resolved is True:
        require(row['unresolved_reason'] is None and all(row[k]==dict.fromkeys(('linear1','linear2','linear3','gelu1','gelu2'),1)
                 for k in ('energy_hook_entries','energy_hook_finished')),'Energy operation trace coverage differs')
    else:
        require(row['energy_hook_entries'] is None and row['energy_hook_finished'] is None,'Energy trace present without query')
    return values,raw,metadata


def audit_records(directory,plan,plan_sha,parameters,hashes,started=None,worker=None):
    """Decode the full panel once; no surviving subset or hidden-state refit."""
    directory=Path(directory);schedule=independent_schedule(plan['contexts'])
    require(schedule==plan['schedule'],'Schedule changed')
    calls=jsonl(directory/'calls.jsonl');require(len(calls)==264,'Call coverage differs')
    complete=read(directory/'WORKER_COMPLETE.json')
    require(complete['plan_sha256']==plan_sha,'Worker completion binding differs')
    for row,entry in zip(calls,schedule):schedule_fields(row,entry)
    resolved=sum(row['resolved'] is True for row in calls)
    counts=operation_counts(resolved);validate_ownership(complete,plan,hashes,counts)
    resources=validate_events(jsonl(directory/'worker-events.jsonl'),schedule,calls,complete,started,worker)
    resource_map={r['stage']:r for r in resources};contexts={c['id']:c for c in plan['contexts']}
    tables={w['id']:w['transitions'] for w in plan['worlds']}
    reader_core,writer_core=bound_core(READER_CORE),bound_core(WRITER_CORE)
    prior={};rows=[];controls=[];arithmetic=[];baseline_rows=[]
    for row,entry in zip(calls,schedule):
        context=contexts[entry['context_id']];phase=entry['phase'];world=entry['world_id']
        require(row['resources_before']==resource_map['before:'+entry['id']] and
                row['resources_after']==resource_map['after:'+entry['id']],'Call resource binding differs')
        values,raw,meta=load_call(directory,row,entry,context,plan_sha)
        earlier=prior.setdefault(context['id'],{})
        comparison_phases=list(earlier) if phase in ('native','uniform','restored') else []
        require(set(row['comparisons'])==set(comparison_phases),'Control comparison coverage differs')
        for earlier_phase in comparison_phases:
            old=earlier[earlier_phase]
            output=reader_core.output_comparison(old['full_logits'],values['full_logits'])
            hidden=reader_core.hidden_comparison(old['hidden_before'],values['hidden_before'])
            expected=dict(full_vocabulary_max_absolute_error=output['maximum_absolute_error'],
                full_vocabulary_raw_equal=output['raw_equal'],hidden_raw_equal=hidden['full_raw_equal'],
                hidden_max_absolute_error=hidden['full_maximum_absolute_error'])
            expected['pass']=True
            require(row['comparisons'][earlier_phase]==expected,'Control summary differs from raw arrays')
            controls.append(dict(context_id=context['id'],first_phase=earlier_phase,second_phase=phase,**output,hidden=hidden))
        check=dict(id=entry['id'],reader=None,energy=None,writer=None)
        if phase in ('main','wrong'):
            saved={k:values['reader_centered' if k=='centered' else k] for k in READER_OUTPUT_SHAPES}
            checked=reader_core.check_application(values['hidden_before'][0,-1],parameters['reader'],saved)
            choice=checked['choices'];require(row['decisions']==choice,'Recorded reader exact decisions differ')
            predicted=route_from_decisions(choice,'main');route=route_from_decisions(choice,phase)
            require(row['resolved'] is route['resolved'],'Recorded route resolution differs')
            if route['resolved']:
                require(all(type(row[k]) is int and row[k]==v for k,v in dict(predicted_state=predicted['state'],
                    predicted_action=predicted['action'],predicted_address=predicted['address'],
                    query_state=route['state'],query_action=route['action']).items()),'Queried route differs from decoded reader')
                energy=check_energy(values,parameters[world],route['state'],route['action'])
                target=tables[world][route['action']][route['state']]
                organ_correct=energy['unique_and_equal'] and energy['probability_choice']['winner']==target
                check['energy']=energy
            else:
                reason='tied_choice' if not all(choice[k]['unique'] for k in ('state','action','address')) else 'inconsistent_choices'
                require(row['unresolved_reason']==reason and all(row[k] is None for k in ('predicted_state','predicted_action',
                    'predicted_address','query_state','query_action')),'Unresolved route contains invented query')
                target=None;energy=None;organ_correct=False
            check['reader']=checked
            s,a=context['state'],context['action'];original=tables[world][a][s]
            scores=values['full_logits'][plan['label_ids']];host_choice=strict_choice(scores)
            rows.append(dict(id=entry['id'],context_id=context['id'],split=context['split'],world_id=world,phase=phase,
                state=s,action=a,original_target=original,predicted_route=predicted,route=route,selected_query_target=target,
                reader_choices=choice,reader_state_correct=choice['state']['winner']==s,
                reader_action_correct=choice['action']['winner']==a,reader_address_correct=choice['address']['winner']==3*s+a,
                organ_choice=None if energy is None else {k:energy[k] for k in ('energy_choice','probability_choice','winning_sets_equal','unique_and_equal')},
                organ_correct=bool(organ_correct),host_choice=host_choice,original_task_correct=host_choice['winner']==original,
                selected_query_correct=target is not None and host_choice['winner']==target,scores=scores.tolist()))
        if phase=='uniform' or row['resolved'] is True:
            require(exact(raw['probabilities_cpu'],raw['probabilities']),'Actual probability device transfer changed bytes')
            if phase=='uniform':require(exact(values['probabilities_cpu'],np.full(8,.125,dtype=np.float32)),'Uniform input differs')
            writer_values={k:values[k] for k in ('probabilities','centered','delta32','delta_host','returned')}
            writer_values.update(hidden=values['hidden_before'],writer_weight=parameters['writer']['weight'])
            check['writer']=writer_core.audit_writer_math(writer_values)
        if phase in ('native','uniform','restored'):
            host_choice=strict_choice(values['full_logits'][plan['label_ids']])
            baseline_rows.append(dict(id=entry['id'],context_id=context['id'],phase=phase,choice=host_choice,
                scores=values['full_logits'][plan['label_ids']].tolist(),
                correct=sum(host_choice['winner']==tables[w][context['action']][context['state']] for w in WORLD_IDS)))
            earlier[phase]=values
        arithmetic.append(check)
        if phase=='restored':del prior[context['id']]
    require(not prior and len(rows)==192 and len(controls)==72 and len(baseline_rows)==72,'Full panel incomplete')
    result=summarize(rows,tables)
    result.update(implementation_pass=True,rows=rows,controls=controls,counts=counts,host_forwards=264,
        reader_applications=192,organ_forwards=resolved,writer_forwards=24+resolved,
        baselines={phase:dict(calls=24,world_context_cells=96,correct=sum(r['correct'] for r in baseline_rows if r['phase']==phase),
            ties=sum(4*(not r['choice']['unique']) for r in baseline_rows if r['phase']==phase),
            call_ties=sum(not r['choice']['unique'] for r in baseline_rows if r['phase']==phase))
            for phase in ('native','uniform','restored')},baseline_rows=baseline_rows,arithmetic=arithmetic,
        resources=dict(samples=530,maximum_rss_bytes=max(r['rss_high_water_bytes'] for r in resources),
            maximum_sampled_mps_driver_bytes=max(r['mps_driver_bytes'] for r in resources),worker_elapsed_seconds=complete['elapsed_seconds']),
        same_call_hidden_identity=True,returned_nonfinal_identity=True,frozen_components_unchanged=True)
    return result


def audit(directory=OUT):
    directory=Path(directory)
    require(directory.resolve()==OUT.resolve(),'Unexpected live energy study directory')
    forbidden=('STOPPED.json','WORKER_FAILURE.json','COMPLETE.json','AUDIT_STARTED.json','AUDIT_FAILURE.json',
               'REPORT.json','INDEPENDENT_AUDIT.json')
    require(not any((directory/name).exists() for name in forbidden),'Stopped/terminal/already attempted audit')
    runtime_guard();plan,plan_sha=verify_plan(directory)
    started,worker,owner_events=owner_guard(directory,plan_sha)
    collected=read(directory/'COLLECTED.json')
    require(collected['plan_sha256']==plan_sha and collected['all_controls_pass'] is True,'Incomplete collection')
    check_inventory(directory,collected)
    create(directory/'AUDIT_STARTED.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,
        audit_code_sha256=digest(__file__),pid=os.getpid(),owner_pid=os.getppid(),rerun_allowed=False))
    try:
        validate_lineage(plan)
        cache=bound_core(READER_CORE).validate_cache(plan)
        require(read(directory/'MODEL_CACHE_BEFORE.json')==read(directory/'MODEL_CACHE_AFTER.json')==cache,'Model cache identity differs')
        params,hashes=load_fixed_parameters(directory,plan,plan_sha)
        report=audit_records(directory,plan,plan_sha,params,hashes,started,worker)
        require(collected['counts']==report['counts'],'Collection operation counters differ')
        check_inventory(directory,collected,late=('AUDIT_STARTED.json',));verify_plan(directory)
        require(datetime.now(timezone.utc)<datetime.fromisoformat(started['deadline_utc']),'Audit total deadline expired')
        report.update(status='LIVE_ENERGY_ASSEMBLY_PASSED' if report['gate_pass'] else 'LIVE_ENERGY_ASSEMBLY_FAILED',
            at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,
            scope='One-step assembly on24 exposed question contexts and four existing development worlds; no training or generation.',
            limits=['Eight-label ranking, not free-text generation, multi-step reasoning or planning.',
                'The24 contexts and four worlds were previously exposed; no unseen-world transplantation or novelty is tested.',
                'Finite unresolved/tied/wrong routing is a completed negative; no oracle fallback is used.',
                'All144 cross-world comparisons and96 main/wrong pairs are derived repeated-context comparisons, not independent trials.',
                'World-blind baselines reuse24 actual calls as96 world-context comparisons each.',
                'Reader and writer pure numerical checkers are immutable hash-bound independent sources; no refit.',
                'Per-operation allowances validate saved actual CPU FP32 operands; native host numerical variation has a fixed ln2/8 control bound.',
                'Original writer STOP and retrospective engineering recovery remain separate immutable histories.',
                'Success cannot identify why the earlier jointly trained bridge failed.'],
            model_calls_by_auditor=0,fits_by_auditor=0,provider_calls_by_auditor=0,gradient_updates_by_auditor=0)
        create(directory/'REPORT.json',report)
        receipt=dict(status='PASS',implementation_pass=True,gate_pass=report['gate_pass'],plan_sha256=plan_sha,
            report_sha256=digest(directory/'REPORT.json'),audit_code_sha256=digest(__file__),
            collected_sha256=digest(directory/'COLLECTED.json'),
            input_sha256={**collected['artifact_sha256'],'COLLECTED.json':digest(directory/'COLLECTED.json')},
            owner_journal_prefix_sha256=hashlib.sha256(json.dumps(owner_events,sort_keys=True).encode()).hexdigest(),
            owner_journal_prefix_only=True,counts=report['counts'],reader_applications=192,organ_forwards=report['organ_forwards'],
            writer_forwards=report['writer_forwards'],model_calls=0,analytical_fits=0,provider_calls=0,gradient_updates=0,
            limitations=report['limits'])
        create(directory/'INDEPENDENT_AUDIT.json',receipt);return receipt
    except BaseException as exc:
        create(directory/'AUDIT_FAILURE.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,
            reason=type(exc).__name__+': '+str(exc),audit_code_sha256=digest(__file__),rerun_allowed=False,
            partial_scientific_interpretation=False))
        raise


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,default=OUT)
    answer=audit(parser.parse_args().directory)
    print(json.dumps({k:v for k,v in answer.items() if k not in ('input_sha256','limitations')}),flush=True)
