"""One-step numeric connection of separately frozen reader, energy and writer.

No prompt parser, expected address/answer, world table, fitting or model loader.
The caller provides the environment's selected frozen energy module.
"""
import numpy as np
import torch


def raw(value):
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def query_batch(state, action):
    if type(state) is not int or type(action) is not int or not 0 <= state < 8 or not 0 <= action < 3:
        raise ValueError('Invalid predicted numeric address')
    q=torch.zeros((8,19),dtype=torch.float32,device='cpu')
    q[:,state]=1;q[:,8+action]=1
    q[:,11:]=torch.eye(8,dtype=torch.float32,device='cpu')
    return q


class EnergyObserver:
    """Observe actual native linear/GELU operands; never replace their values."""
    def __init__(self,organ,capture):
        self.organ=organ;self.capture=capture;self.handles=[]
        self.counts={name:0 for name in ('linear1','linear2','linear3','gelu1','gelu2')}
        self.finished={name:0 for name in self.counts};self.activation_index=0
    def _before(self,name,args):
        self.counts[name]+=1
        if self.counts[name]!=1:raise ValueError('Repeated energy operation '+name)
        self.capture[name+'_input']=args[0].detach().cpu().clone()
    def _after(self,name,value):
        self.finished[name]+=1
        if self.finished[name]!=1:raise ValueError('Repeated energy result '+name)
        self.capture[name]=value.detach().cpu().clone()
    def __enter__(self):
        try:
            for name,module in [('linear1',self.organ.input_proj),('linear2',self.organ.hidden_proj),('linear3',self.organ.output_proj)]:
                self.handles.append(module.register_forward_pre_hook(lambda m,a,n=name:self._before(n,a)))
                self.handles.append(module.register_forward_hook(lambda m,a,o,n=name:self._after(n,o)))
            def activation_pre(module,args):
                self.activation_index+=1
                if self.activation_index>2:raise ValueError('Extra GELU operation')
                self._before('gelu'+str(self.activation_index),args)
            def activation_post(module,args,value):
                self._after('gelu'+str(self.activation_index),value)
            self.handles.append(self.organ.activation.register_forward_pre_hook(activation_pre))
            self.handles.append(self.organ.activation.register_forward_hook(activation_post))
            return self
        except BaseException:
            for h in reversed(self.handles):h.remove()
            raise
    def __exit__(self,*exc):
        for h in reversed(self.handles):h.remove()
        return False


class LiveEnergyConnection:
    """Only numeric H, frozen arrays/modules, condition and event callback."""
    def __init__(self, reader_arrays, apply_reader, reader_decisions, writer):
        self.reader_arrays=reader_arrays;self.apply_reader=apply_reader
        self.reader_decisions=reader_decisions;self.writer=writer
        self.last_capture={};self.last_info={}
    def apply(self,hidden,phase,organ=None,on_event=lambda name:None):
        self.last_capture={};self.writer.last_capture=None
        self.last_info=dict(reader_entered=False,reader_completed=False,decisions=None,resolved=None,
            predicted_state=None,predicted_action=None,predicted_address=None,query_state=None,query_action=None,
            organ_entered=False,organ_completed=False,writer_entered=False,writer_completed=False,
            patched=False,unresolved_reason=None,energy_hook_entries=None,energy_hook_finished=None)
        capture,info=self.last_capture,self.last_info
        if phase not in ('native','uniform','main','wrong','restored'):raise ValueError('Unknown condition')
        if hidden.dtype!=torch.bfloat16 or hidden.ndim!=3 or hidden.shape[0]!=1 or hidden.shape[1]<1 or hidden.shape[2]!=1024:
            raise ValueError('Expected native BF16 hidden[1,L>0,1024]')
        if hidden.requires_grad:raise ValueError('Frozen native hidden requires gradients')
        if phase in ('native','restored'):
            if organ is not None:raise ValueError('Energy module supplied to native condition')
            capture['returned']=hidden
            return hidden
        if phase=='uniform':
            if organ is not None:raise ValueError('Energy module supplied to uniform condition')
            probabilities_cpu=torch.full((8,),.125,dtype=torch.float32,device='cpu')
        else:
            if organ is None:raise ValueError('Missing selected energy module')
            info['reader_entered']=True;on_event('reader_started')
            h=hidden.detach().cpu()[0,-1].float().numpy().copy()
            result=self.apply_reader(h,self.reader_arrays['coefficients'],self.reader_arrays['x_mean'],self.reader_arrays['y_mean'])
            capture.update({("reader_centered" if k=="centered" else k):v for k,v in result.items()})
            choice=self.reader_decisions(result['component_scores'],result['address_scores']);info['decisions']=choice
            info['reader_completed']=True;on_event('reader_finished')
            unique=all(choice[k]['unique'] for k in ('state','action','address'))
            consistent=unique and choice['address']['winner']==3*choice['state']['winner']+choice['action']['winner']
            info['resolved']=bool(consistent)
            if not consistent:
                info['unresolved_reason']='tied_choice' if not unique else 'inconsistent_choices'
                capture['returned']=hidden
                return hidden
            state,action,address=[choice[k]['winner'] for k in ('state','action','address')]
            info.update(predicted_state=state,predicted_action=action,predicted_address=address,
                        query_state=(state+1)%8 if phase=='wrong' else state,query_action=action)
            queries=query_batch(info['query_state'],info['query_action']);capture['query']=queries
            observer=EnergyObserver(organ,capture)
            info['organ_entered']=True;on_event('organ_started')
            try:
                with observer:
                    energies=organ(queries)
                capture['energies']=energies.detach().cpu().clone()
                info['organ_completed']=True;on_event('organ_finished')
            finally:
                info['energy_hook_entries']=observer.counts.copy();info['energy_hook_finished']=observer.finished.copy()
            if any(v!=1 for v in observer.counts.values()) or any(v!=1 for v in observer.finished.values()):
                raise ValueError('Energy operation coverage differs')
            if energies.device.type!='cpu' or energies.dtype!=torch.float32 or energies.shape!=(8,):
                raise ValueError('Actual energy output device/dtype/shape differs')
            probabilities_cpu=torch.softmax(-energies,dim=-1)
        capture['probabilities_cpu']=probabilities_cpu.detach().cpu().clone()
        probabilities=probabilities_cpu.to(device=hidden.device,dtype=torch.float32)
        capture['probabilities']=probabilities
        if raw(probabilities)!=raw(probabilities_cpu):raise ValueError('Probability device transfer changed bytes')
        info['writer_entered']=True;on_event('writer_started')
        try:
            returned,actual=self.writer(hidden,probabilities)
            info['writer_completed']=True;info['patched']=True
            capture.update({k:v for k,v in actual.items() if k!='hidden'})
            on_event('writer_finished')
        finally:
            if self.writer.last_capture is not None:
                capture.update({k:v for k,v in self.writer.last_capture.items() if k!='hidden'})
        return returned
