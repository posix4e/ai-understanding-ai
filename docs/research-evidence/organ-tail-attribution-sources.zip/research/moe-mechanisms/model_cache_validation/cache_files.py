"""Prospective model-cache validation; not attached to any stopped study.

Hugging Face snapshot entries normally link to a sibling blobs directory.
The caller must explicitly supply the single model repository cache root and
an expected content SHA256 for each leaf. This helper does not load tensors,
change files, amend registrations, or relax run-artifact containment rules.

The result describes the file observed and hashed here. It is not a promise
that a separate later loader sees unchanged files; that lifecycle must be
bound by the future caller's protocol. No existing audit imports this module.
"""
from pathlib import Path, PureWindowsPath
import hashlib
import os
import re
import stat


class ModelCacheValidationError(ValueError):
    """A requested registered cache leaf failed path or content validation."""


def _leaf(name):
    if (not isinstance(name, str) or not name or name in ('.', '..')
        or '/' in name or '\\' in name or '\x00' in name
        or Path(name).is_absolute() or PureWindowsPath(name).drive):
        raise ModelCacheValidationError('Expected one safe relative filename leaf')
    return name


def _identity(info):
    return dict(device=info.st_dev, inode=info.st_ino, size_bytes=info.st_size,
                modified_ns=info.st_mtime_ns)


def validate_model_cache_file(snapshot_directory, filename, expected_sha256, *, cache_repository):
    """Validate one registered file and return its observed path/hash identity.

    ``cache_repository`` is the explicit *one-model* cache folder, not the
    entire workspace or a general cache parent. Resolved snapshots and file
    targets must stay inside it. Snapshot-local regular files are supported.
    A declared SHA256 is mandatory; containment alone never admits a file.
    """
    name = _leaf(filename)
    if not isinstance(expected_sha256, str) or re.fullmatch(r'[0-9a-f]{64}', expected_sha256) is None:
        raise ModelCacheValidationError('Expected a lowercase 64-character content SHA256')
    try:
        cache = Path(cache_repository).resolve(strict=True)
        snapshot = Path(snapshot_directory).resolve(strict=True)
        if not cache.is_dir() or not snapshot.is_dir() or not snapshot.is_relative_to(cache):
            raise ModelCacheValidationError('Snapshot is outside the explicit model-cache repository')
        logical = snapshot / name
        original_link = logical.lstat()
        link_text = os.readlink(logical) if stat.S_ISLNK(original_link.st_mode) else None
        target = logical.resolve(strict=True)
        if not target.is_relative_to(cache):
            raise ModelCacheValidationError('Resolved target is outside the explicit model-cache repository')
        if not stat.S_ISREG(target.stat().st_mode):
            raise ModelCacheValidationError('Expected a regular target file')
        # Open the resolved file rather than following the snapshot link again.
        # O_NOFOLLOW additionally rejects a replaced final-component symlink.
        flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_CLOEXEC', 0)
        fd = os.open(target, flags)
        with os.fdopen(fd, 'rb') as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode):
                raise ModelCacheValidationError('Expected a regular target file')
            actual_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
            after = os.fstat(stream.fileno())
        if _identity(before) != _identity(after):
            raise ModelCacheValidationError('Target changed while hashing')
        if actual_sha != expected_sha256:
            raise ModelCacheValidationError('Registered content SHA256 differs')
        # This detects ordinary retargeting/replacement during validation. It
        # is not a claim to lock the cache against all later modifications.
        if (logical.resolve(strict=True) != target
            or _identity(logical.lstat()) != _identity(original_link)
            or _identity(target.stat()) != _identity(after)):
            raise ModelCacheValidationError('Cache path changed during validation')
        return dict(filename=name, logical_path=str(logical), resolved_path=str(target),
                    cache_repository=str(cache), snapshot_directory=str(snapshot),
                    is_symlink=link_text is not None, link_text=link_text,
                    expected_sha256=expected_sha256, sha256=actual_sha,
                    target_identity=_identity(after),
                    inside_explicit_model_cache=True,
                    attached_to_existing_study=False)
    except ModelCacheValidationError:
        raise
    except (OSError, RuntimeError) as exc:
        raise ModelCacheValidationError('Cannot resolve/read registered cache leaf: ' + str(exc)) from exc
