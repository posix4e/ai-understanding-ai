"""Independent saved-byte audit of the fixed live address reader.

No model library, primary reader, fitting, or scoring implementation is
imported. Before registration these functions may see invented data only.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import math
import os
import sys
import time

import numpy as np

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'outputs/moe-mechanisms/ORGAN_LIVE_READER_V1'
CONTROL_LIMIT = math.log(2) / 8
DEADLINE_SECONDS = 300
MEMORY_LIMIT = 10 * 1024**3
VOCAB = 49155
EXCLUSIONS = {'owner-events.jsonl', 'worker.log', 'independent_audit.log', 'COLLECTED.json'}
ROLES = ('native', 'reader_only', 'restored')
READER_SHAPES = {'coefficients': (1024, 11), 'x_mean': (1024,), 'y_mean': (11,)}
READER_OUTPUT_SHAPES = {'h64': (1024,), 'rms': (), 'normalized': (1024,),
                        'centered': (1024,), 'component_scores': (11,), 'address_scores': (24,)}
DTYPES = {'torch.bfloat16': ('<u2', 2), 'torch.float32': ('<f4', 4),
          'torch.int64': ('<i8', 8), 'numpy.float64': ('<f8', 8)}


class AuditError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise AuditError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def create(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def exact(a, b):
    a, b = np.asarray(a), np.asarray(b)
    return a.shape == b.shape and a.dtype == b.dtype and a.tobytes() == b.tobytes()


def safe(directory, name):
    require(type(name) is str and bool(name), 'Missing artifact path')
    relative = Path(name)
    require(not relative.is_absolute() and '..' not in relative.parts, 'Unsafe artifact path')
    path = Path(directory) / relative
    require(path.is_file() and path.resolve().is_relative_to(Path(directory).resolve()),
            'Artifact missing or escapes directory')
    return path


def jsonl(path):
    lines = Path(path).read_text().splitlines()
    require(all(line.strip() for line in lines), 'Blank journal record')
    return [json.loads(line) for line in lines]


def strict_choice(values):
    a = np.asarray(values)
    require(a.ndim == 1 and a.size >= 2 and np.isfinite(a).all(), 'Invalid choice scores')
    maxima = np.flatnonzero(a == a.max()).tolist()
    ordered = sorted(map(float, a), reverse=True)
    return {'winner': maxima[0] if len(maxima) == 1 else None,
            'winners': maxima, 'unique': len(maxima) == 1, 'gap': ordered[0] - ordered[1]}


def reference_reader(hidden, coefficients, x_mean, y_mean):
    """Scalar FP64 reference, using independently computed intermediates."""
    raw = np.asarray(hidden)
    require(raw.dtype == np.float32 and raw.shape == (1024,) and np.isfinite(raw).all(),
            'Expected finite decoded FP32 hidden row')
    params = {'coefficients': coefficients, 'x_mean': x_mean, 'y_mean': y_mean}
    for name, value in params.items():
        a = np.asarray(value)
        require(a.dtype == np.float64 and a.shape == READER_SHAPES[name] and np.isfinite(a).all(),
                'Frozen reader dtype/shape/value differs: ' + name)
    h = [float(value) for value in raw]
    rms = math.sqrt(math.fsum(value * value for value in h) / 1024)
    require(math.isfinite(rms) and rms > 0, 'Nonpositive or invalid RMS')
    normalized = [value / rms for value in h]
    centered = [value - float(x_mean[j]) for j, value in enumerate(normalized)]
    components = [math.fsum(centered[j] * float(coefficients[j, k]) for j in range(1024))
                  + float(y_mean[k]) for k in range(11)]
    addresses = [components[s] + components[8 + a] for s in range(8) for a in range(3)]
    out = dict(h64=h, rms=rms, normalized=normalized, centered=centered,
               component_scores=components, address_scores=addresses)
    out = {name: np.array(value, dtype=np.float64) for name, value in out.items()}
    require(all(np.isfinite(value).all() for value in out.values()), 'Nonfinite independent reader')
    return out


def euclidean(values):
    result = math.sqrt(math.fsum(float(x) * float(x) for x in np.asarray(values).ravel()))
    require(math.isfinite(result), 'Nonfinite derived norm')
    return result


def compare_numeric(actual, expected, scores=False):
    a, b = np.asarray(actual), np.asarray(expected)
    require(a.dtype == b.dtype == np.float64 and a.shape == b.shape and
            np.isfinite(a).all() and np.isfinite(b).all(), 'Invalid reader comparison')
    error = euclidean(a - b)
    scale = max(euclidean(a), euclidean(b))
    atol, rtol = (1e-9, 1e-8) if scores else (1e-12, 1e-12)
    allowance = atol + rtol * scale
    require(all(math.isfinite(v) for v in (error, scale, allowance)), 'Nonfinite derived allowance')
    require(error <= allowance, 'Independent reader arithmetic exceeds allowance')
    return dict(error=error, allowance=allowance, scale=scale)


def choices(values):
    p, a = values['component_scores'], values['address_scores']
    return dict(state=strict_choice(p[:8]), action=strict_choice(p[8:]), address=strict_choice(a))


def check_application(hidden, params, saved):
    require(set(saved) == set(READER_OUTPUT_SHAPES), 'Reader output coverage differs')
    for name, shape in READER_OUTPUT_SHAPES.items():
        value = np.asarray(saved[name])
        require(value.dtype == np.float64 and value.shape == shape and np.isfinite(value).all(),
                'Reader output dtype/shape/value differs: ' + name)
    reference = reference_reader(hidden, **params)
    require(exact(saved['h64'], reference['h64']), 'Decoded hidden widening differs')
    errors = {name: compare_numeric(saved[name], reference[name], scores=name.endswith('scores'))
              for name in saved if name != 'h64'}
    primary, independent = choices(saved), choices(reference)
    # Numerical tolerances cannot rescue categorical disagreement or a tie.
    for component in primary:
        require({k: primary[component][k] for k in ('winner', 'winners', 'unique')} ==
                {k: independent[component][k] for k in ('winner', 'winners', 'unique')},
                'Exact independent winner/tie mismatch')
    return dict(choices=primary, independent_choices=independent, arithmetic=errors)


def decode(raw, dtype, shape):
    require(dtype in DTYPES, 'Unregistered tensor dtype')
    storage, width = DTYPES[dtype]
    raw = np.asarray(raw)
    require(raw.dtype == np.uint8 and raw.shape == (math.prod(shape) * width,), 'Malformed raw tensor bytes')
    data = np.frombuffer(raw.tobytes(), dtype=storage)
    if dtype == 'torch.bfloat16':
        data = (data.astype(np.uint32) << 16).view(np.float32)
    return data.reshape(shape)


def load_bundle(path, metadata_path, expected):
    metadata = read(metadata_path)
    require(set(metadata['tensors']) == set(expected), 'Unexpected tensor inventory')
    values, raws, keys = {}, {}, set()
    with np.load(path, allow_pickle=False) as archive:
        for name, (dtype, shape) in expected.items():
            meta = metadata['tensors'][name]
            require(meta['dtype'] == dtype and meta['shape'] == list(shape), 'Recorded tensor shape/type differs')
            rk, vk = name + '__raw_uint8', name + '__value'
            require(meta['raw_key'] == rk and meta['value_key'] == vk, 'Tensor key mapping differs')
            raw, readable = np.asarray(archive[rk]), np.asarray(archive[vk])
            value = decode(raw, dtype, shape)
            require(hashlib.sha256(raw.tobytes()).hexdigest() == meta['raw_sha256'], 'Raw tensor hash differs')
            require(exact(value, readable), 'Raw/readable bytes differ')
            require(np.isfinite(value).all(), 'Nonfinite retained tensor')
            values[name], raws[name] = value.copy(), raw.copy()
            keys.update((rk, vk))
        require(set(archive.files) == keys, 'Unexpected archive array member')
    return values, raws, metadata


def independent_schedule(contexts):
    require(len(contexts) == 24, 'Expected exactly24 contexts')
    rows = []
    for index, c in enumerate(contexts):
        s, a = divmod(index, 3)
        require(c['id'] == f's{s}-a{a}' and type(c['state']) is int and c['state'] == s and
                type(c['action']) is int and c['action'] == a, 'Context order/address differs')
        require(c['split'] == ('held' if a == s % 3 else 'train'), 'Original fit split differs')
        for phase in ROLES:
            rows.append(dict(index=len(rows), id=f'{len(rows):04d}', phase=phase, context_id=c['id']))
    return rows


def output_comparison(first, second):
    for value in (first, second):
        require(np.asarray(value).shape == (VOCAB,) and np.isfinite(value).all(), 'Incomplete vocabulary scores')
    error = float(np.max(np.abs(first.astype(np.float64) - second.astype(np.float64))))
    require(error <= CONTROL_LIMIT, 'Full-vocabulary control exceeded fixed bound')
    return dict(raw_equal=exact(first, second), maximum_absolute_error=error)


def hidden_comparison(first, second):
    require(first.shape == second.shape and first.ndim == 3 and first.shape[0] == 1 and
            first.shape[2] == 1024, 'Hidden comparison shape differs')
    return dict(full_raw_equal=exact(first, second), last_raw_equal=exact(first[:, -1], second[:, -1]),
                full_maximum_absolute_error=float(np.max(np.abs(first.astype(np.float64) - second.astype(np.float64)))),
                last_maximum_absolute_error=float(np.max(np.abs(first[:, -1].astype(np.float64) - second[:, -1].astype(np.float64)))))


def summarize(rows):
    require(len(rows) == 24 and [r['context_id'] for r in rows] ==
            [f's{s}-a{a}' for s in range(8) for a in range(3)], 'Reader scoring coverage differs')
    groups = {}
    for name, indexes in [('train', [i for i in range(24) if i % 3 != (i // 3) % 3]),
                          ('held', [i for i in range(24) if i % 3 == (i // 3) % 3]),
                          ('all', list(range(24)))]:
        rr = [rows[i] for i in indexes]
        group = {'n': len(rr)}
        for kind in ('state', 'action', 'address'):
            group[kind + '_correct'] = sum(r['choices'][kind]['winner'] ==
                (int(r['context_id'][1]) if kind == 'state' else int(r['context_id'][4]) if kind == 'action'
                 else 3 * int(r['context_id'][1]) + int(r['context_id'][4])) for r in rr)
            group[kind + '_unresolved'] = sum(r['choices'][kind]['winner'] is None for r in rr)
        groups[name] = group
    passed = all(groups['all'][kind + '_correct'] == 24 for kind in ('state', 'action', 'address'))
    return dict(groups=groups, gate_pass=passed)


SETTINGS = dict(python='3.12.14', torch='2.8.0', transformers='4.56.2', numpy='2.3.3',
    host_forwards=72, reader_applications=24, contexts=24, analytical_fits=0,
    backwards=0, optimizer_steps=0, organ_forwards=0, writer_forwards=0,
    provider_calls=0, generated_tokens=0, insertion_layer=20, position='last',
    dtype='bfloat16', reader_dtype='float64', reader_device='cpu', device='mps',
    threads=4, batch_size=1, attention='eager', cache=False, logits_scaling=6,
    timeout_seconds=300, max_rss_bytes=10*1024**3, max_mps_driver_bytes=10*1024**3,
    max_control_logit_error=CONTROL_LIMIT, rms_atol=1e-12, rms_rtol=1e-12,
    feature_atol=1e-12, feature_rtol=1e-12, score_atol=1e-9, score_rtol=1e-8)
OLD_PLAN_SHA = '94f2b56135cb3de13a00c0cd20e32e2e376306bf188e95b06610386f908c9eb4'
READER_PLAN_SHA = '0735ac5bbd8e1774f86f7fcd2fc8d7cd05c593f8d98db4d2a8ed9915f8f1ed99'
WRITER_PLAN_SHA = '3fff59be6b320911afa015550731a8ee34c9a07b0dc5771b23bf05466971873c'
WRITER_STOP_SHA = '8adb5448ac62a55671db079c61cd65ebe41ab6f143480ebd3fd5f0f8194fdd60'
RECOVERY_PLAN_SHA = '7257c155ba3b903fe2273d24d33f0acc43c597f52505759572e49567f2d0a811'
HELPER_SHA = '69b3f31e3a471abd0b488ad432a7e559ea31bec7044b77786409f5e6696d893e'
MODEL_REL = 'work/moe-model-cache/models--ibm-granite--granite-3.1-1b-a400m-instruct'
SNAPSHOT_REL = MODEL_REL + '/snapshots/0da7a48b0276d500ce5922fd2b33944091fc6c09'
MODEL_NAMES = {'added_tokens.json', 'config.json', 'generation_config.json', 'merges.txt',
               'model.safetensors', 'special_tokens_map.json', 'tokenizer.json', 'tokenizer_config.json', 'vocab.json'}


def expected_state_keys():
    suffixes = ('self_attn.q_proj.weight', 'self_attn.k_proj.weight', 'self_attn.v_proj.weight',
                'self_attn.o_proj.weight', 'block_sparse_moe.input_linear.weight',
                'block_sparse_moe.output_linear.weight', 'block_sparse_moe.router.layer.weight',
                'input_layernorm.weight', 'post_attention_layernorm.weight')
    return {'model.embed_tokens.weight', 'model.norm.weight', 'lm_head.weight'} | {
        f'model.layers.{i}.{suffix}' for i in range(24) for suffix in suffixes}


def verify_plan(directory, root=ROOT):
    """Independently bind fixed settings, source inventory and exact schedule."""
    directory, root = Path(directory), Path(root)
    plan = read(directory / 'plan.json'); plan_sha = digest(directory / 'plan.json')
    require(read(directory / 'REGISTRATION.json')['plan_sha256'] == plan_sha, 'Registration differs')
    require(plan['settings'] == SETTINGS and set(plan['collection_exclusions']) == EXCLUSIONS,
            'Registered settings/exclusions differ')
    require(plan['schedule'] == independent_schedule(plan['contexts']), 'Registered schedule differs')
    require(plan['gates'] == dict(address_correct=24, state_correct=24, action_correct=24, total=24, allow_ties=False),
            'Registered gates differ')
    own = 'research/moe-mechanisms/organ_live_reader_v1/'
    expected = {own + name for name in ('protocol.py', 'reader.py', 'worker.py', 'audit.py', 'owner.py',
                'launch.py', 'test_reader.py', 'test_worker.py', 'test_audit.py', 'test_protocol.py')}
    expected |= {'research/moe-mechanisms/model_cache_validation/cache_files.py',
                 'research/moe-mechanisms/model_cache_validation/test_cache_files.py',
                 'research/moe-mechanisms/organ_transplant_v2/durable_launch.py'}
    require(set(plan['source_sha256']) == expected, 'Thirteen-source inventory differs')
    for field in ('source_sha256', 'lineage_sha256'):
        require(type(plan[field]) is dict and bool(plan[field]), 'Missing bound source/lineage')
        for name, sha in plan[field].items():
            require(digest(safe(root, name)) == sha, 'Bound source/lineage changed: ' + name)
            if field == 'source_sha256':
                require(digest(safe(directory / 'sources', name)) == sha, 'Archived source changed')
    require(set(plan['expected_host_state']) == expected_state_keys(), 'Incomplete host-state inventory')
    for c in plan['contexts']:
        ids = c['input_ids']
        require(isinstance(ids, list) and 1 <= len(ids) <= 48 and ids[0] == 0 and
                all(type(i) is int and 0 <= i < VOCAB for i in ids), 'Malformed input tokens')
        require(c['prompt'] == f"World state {c['state']}. Actions {'XYZ'[c['action']]}. Next state:",
                'Original prompt text changed')
    return plan, plan_sha


def validate_cache(plan, root=ROOT):
    """Reuse only the reviewed path/hash helper, never primary scientific code."""
    import importlib.util
    root = Path(root)
    require(plan['model_path'] == SNAPSHOT_REL and plan['model_cache_repository'] == MODEL_REL,
            'Pinned model/cache root differs')
    require(set(plan['model_files']) == MODEL_NAMES, 'Pinned nine model filenames differ')
    helper_path = root / 'research/moe-mechanisms/model_cache_validation/cache_files.py'
    require(digest(helper_path) == HELPER_SHA, 'Reviewed cache validator changed')
    spec = importlib.util.spec_from_file_location('independent_reader_bound_cache_helper', helper_path)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    receipts = [helper.validate_model_cache_file(root / SNAPSHOT_REL, name, sha,
                cache_repository=root / MODEL_REL) for name, sha in plan['model_files'].items()]
    installed = root / 'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
    require(digest(installed) == plan['installed_model_source_sha256'], 'Installed model source changed')
    return receipts


def validate_lineage(plan, root=ROOT):
    """Metadata and opaque hashes; no predecessor prediction arrays."""
    root = Path(root)
    old = root / 'outputs/moe-mechanisms/ORGAN_DEVELOPMENT_V2'
    reader = root / 'outputs/moe-mechanisms/ORGAN_ADDRESS_READ_V1'
    writer = root / 'outputs/moe-mechanisms/ORGAN_WRITER_V1'
    recovery = root / 'outputs/moe-mechanisms/ORGAN_WRITER_RECOVERY_V1'
    for directory, sha, status in ((old, OLD_PLAN_SHA, 'DEVELOPMENT_READINESS_FAILED'),
                                  (reader, READER_PLAN_SHA, 'ADDRESS_READER_ADMISSION_PASSED')):
        require(not (directory / 'STOPPED.json').exists() and digest(directory / 'plan.json') == sha,
                'Prerequisite stopped or plan changed')
        complete, receipt, collected = [read(directory / name) for name in ('COMPLETE.json', 'INDEPENDENT_AUDIT.json', 'COLLECTED.json')]
        require(complete['status'] == status and receipt['status'] == 'PASS', 'Prerequisite status differs')
        require(read(directory / 'REGISTRATION.json')['plan_sha256'] == complete['plan_sha256'] ==
                receipt['plan_sha256'] == collected['plan_sha256'] == sha, 'Prerequisite plan links differ')
        require(complete['report_sha256'] == receipt['report_sha256'] == digest(directory / 'REPORT.json') and
                complete['independent_audit_sha256'] == digest(directory / 'INDEPENDENT_AUDIT.json'),
                'Prerequisite report/audit links differ')
        linked = receipt['collected_sha256'] if directory == old else receipt['input_sha256'][str(directory / 'COLLECTED.json')]
        require(linked == digest(directory / 'COLLECTED.json'), 'Prerequisite audit-to-collection link differs')
    require(digest(writer / 'plan.json') == WRITER_PLAN_SHA and digest(writer / 'STOPPED.json') == WRITER_STOP_SHA and
            not (writer / 'COMPLETE.json').exists(), 'Original writer STOP changed')
    complete = read(recovery / 'COMPLETE.json')
    require(digest(recovery / 'plan.json') == RECOVERY_PLAN_SHA and
            read(recovery / 'REGISTRATION.json')['plan_sha256'] == RECOVERY_PLAN_SHA and
            complete['recovery_plan_sha256'] == RECOVERY_PLAN_SHA and
            complete['status'] == 'RECOVERED_ENGINEERING_WRITER_PASS' and
            complete['implementation_pass'] is True and complete['gate_pass'] is True and
            complete['original_study_completed'] is False and not (recovery / 'FAILURE.json').exists(),
            'Separate writer recovery not admitted')
    require(complete['report_sha256'] == digest(recovery / 'RECOVERED_REPORT.json'), 'Recovery report binding differs')
    recount = read(root / 'outputs/moe-mechanisms/ORGAN_WRITER_RECOVERY_V1_PREPARATION/PARENT_TERMINAL_RECOUNT.json')
    require(recount['status'] == 'PASS_PARENT_RECOVERED_RAW_RECOUNT' and recount['gate_pass'] is True and
            recount['complete_sha256'] == digest(recovery / 'COMPLETE.json'), 'Recovery terminal recount differs')
    oldplan, readerplan, writerplan = [read(p / 'plan.json') for p in (old, reader, writer)]
    require(plan['contexts'] == writerplan['contexts'], 'New question panel differs from original writer')
    require(plan['model_files'] == oldplan['model_files'] == writerplan['model_files'], 'Historical model identity differs')
    require(plan['expected_host_state'] == read(old / 'REPORT.json')['host_state_after'], 'Expected frozen host state differs')
    tokens = read(old / 'TOKENIZED_QUESTIONS.json')
    require(read(old / 'COLLECTED.json')['artifact_sha256']['TOKENIZED_QUESTIONS.json'] ==
            digest(old / 'TOKENIZED_QUESTIONS.json'), 'Historical token archive binding differs')
    for c in plan['contexts']:
        copies = [x for x in oldplan['train_cases'] if x['initial_state'] == c['state'] and x['actions'] == [c['action']]]
        require(len(copies) == 4, 'Historical world-copy coverage differs')
        encoded = [tokens['cases'][x['id']] for x in copies]
        require(all(x == encoded[0] for x in encoded) and all(c[k] == v for k, v in encoded[0].items()),
                'Historical context tokens/text differ')
        observations = [x for x in readerplan['cases'] if x['state'] == c['state'] and x['action'] == c['action']]
        require(len(observations) == 4 and {x['id'] for x in observations} == {x['id'] for x in copies} and
                all(x['input_length'] == len(c['input_ids']) for x in observations), 'Offline reader observations differ')
    artifact = plan['reader_artifact']; collection = read(reader / 'COLLECTED.json')
    require(artifact['path'] == 'outputs/moe-mechanisms/ORGAN_ADDRESS_READ_V1/arrays.npz' and
            artifact['metadata_path'] == 'outputs/moe-mechanisms/ORGAN_ADDRESS_READ_V1/arrays.json',
            'Unexpected fitted reader source')
    require(artifact['sha256'] == collection['artifact_sha256']['arrays.npz'] == digest(root / artifact['path']) and
            artifact['metadata_sha256'] == collection['artifact_sha256']['arrays.json'] == digest(root / artifact['metadata_path']),
            'Reader fit-to-collection artifact link differs')
    metadata = read(root / artifact['metadata_path'])['tensors']
    require(set(artifact['members']) == set(artifact['member_sha256']) == set(READER_SHAPES), 'Reader member inventory differs')
    for name, shape in READER_SHAPES.items():
        m = metadata[name]
        require(m == artifact['members'][name] and m['dtype'] == '<f8' and m['shape'] == list(shape) and
                m['raw_sha256'] == artifact['member_sha256'][name], 'Reader member metadata differs')


def load_frozen_reader(plan, root=ROOT):
    """After provenance admission, decode only the three fitted arrays."""
    artifact = plan['reader_artifact']; path = safe(root, artifact['path'])
    require(digest(path) == artifact['sha256'], 'Fitted reader archive changed')
    out = {}
    with np.load(path, allow_pickle=False) as archive:
        for name, shape in READER_SHAPES.items():
            value = archive[name]
            require(value.dtype.str == '<f8' and value.shape == shape and np.isfinite(value).all(), 'Malformed fitted reader member')
            require(hashlib.sha256(value.tobytes()).hexdigest() == artifact['member_sha256'][name], 'Fitted reader member bytes differ')
            out[name] = value.copy()
    return out


def check_inventory(directory, collected, late=()):
    directory = Path(directory)
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*')
              if p.is_file() and str(p.relative_to(directory)) not in EXCLUSIONS | set(late)}
    require(set(collected['artifact_sha256']) == actual, 'Collection has missing or extra files')
    for name, sha in collected['artifact_sha256'].items():
        require(digest(safe(directory, name)) == sha, 'Collected artifact changed: ' + name)


def is_alive(pid):
    require(type(pid) is int and pid > 1, 'Invalid process identity')
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False


def owner_guard(directory, plan_sha):
    directory = Path(directory)
    started, worker = read(directory / 'STARTED.json'), read(directory / 'WORKER_STARTED.json')
    require(started['owner_pid'] == os.getppid() and is_alive(started['owner_pid']), 'Audit has no live original owner')
    require(started['plan_sha256'] == worker['plan_sha256'] == plan_sha and worker['owner_pid'] == started['owner_pid'],
            'Worker/owner plan or PID differs')
    begin, deadline = [datetime.fromisoformat(started[k]) for k in ('at_utc', 'deadline_utc')]
    require(begin.tzinfo is not None and deadline.tzinfo is not None and
            (deadline - begin).total_seconds() == DEADLINE_SECONDS and datetime.now(timezone.utc) < deadline,
            'Invalid or expired300-second deadline')
    require(worker['deadline_utc'] == started['deadline_utc'], 'Worker total deadline differs')
    handshake = time.monotonic() + 2
    while True:
        try:
            events = jsonl(directory / 'owner-events.jsonl')
        except (FileNotFoundError, json.JSONDecodeError):
            events = []
        if len(events) >= 3:
            break
        require(time.monotonic() < handshake and datetime.now(timezone.utc) < deadline, 'Audit dispatch journal unavailable')
        time.sleep(.02)
    require(len(events) == 3 and [(x['event'], x['stage']) for x in events] ==
            [('started', 'worker'), ('exit', 'worker'), ('started', 'independent_audit')], 'Owner lifecycle sequence differs')
    require(events[0]['pid'] == events[1]['pid'] == worker['worker_pid'] and events[1]['code'] == 0 and
            events[2]['pid'] == os.getpid() and not is_alive(worker['worker_pid']), 'Original worker did not exit successfully')
    here = Path(__file__).resolve().parent; python = ROOT / 'work/acquisition-representation-venv/bin/python'
    require(events[0]['command'] == [str(python), str(here / 'worker.py'), '--deadline-utc', started['deadline_utc']] and
            events[2]['command'] == [str(python), str(here / 'audit.py'), '--directory', str(directory)], 'Dispatch command differs')
    prep = ROOT / 'outputs/moe-mechanisms/ORGAN_LIVE_READER_V1_PREPARATION'
    claim, launch = read(prep / 'LAUNCH_REQUESTED.json'), read(prep / 'LAUNCH_PID.json')
    expected = [str(python), '-u', str(here / 'owner.py'), 'run']
    require(claim['command'] == launch['command'] == expected and claim['plan_sha256'] == launch['plan_sha256'] == plan_sha and
            claim['nonce'] == launch['nonce'] == started['launch_nonce'] and launch['owner_pid'] == started['owner_pid'],
            'Original owner launch claim differs')
    require(os.getpgid(started['owner_pid']) == os.getsid(started['owner_pid']) == started['owner_pid'],
            'Original owner detached process identity differs')
    times = [datetime.fromisoformat(x['at_utc']) for x in events]
    require(all(t.tzinfo is not None for t in times) and begin <= times[0] <= times[1] <= times[2] < deadline,
            'Owner journal timing differs')
    return started, worker, events


EXPECTED_COUNTS = dict(forward_attempts=72, forward_finished=72, reader_attempts=24, reader_finished=24,
                       analytical_fits=0, backward_attempts=0, backward_finished=0,
                       optimizer_attempts=0, optimizer_steps=0)


def schedule_fields(record, entry):
    require(all(type(record.get(k)) is type(v) and record.get(k) == v for k, v in entry.items()), 'Record schedule differs')


def validate_ownership(complete, plan, reader_hashes):
    require(complete['status'] == 'WORKER_COMPLETED' and complete['counts'] == EXPECTED_COUNTS,
            'Worker incomplete or operation counts differ')
    require(all(type(value) is int for value in complete['counts'].values()), 'Operation counts must be integers')
    require(set(plan['expected_host_state']) == expected_state_keys() and
            complete['host_state_before'] == plan['expected_host_state'] == complete['host_state_after'],
            'Frozen host state differs')
    require(complete['reader_state_before'] == complete['reader_state_after'] == reader_hashes ==
            plan['reader_artifact']['member_sha256'], 'Frozen reader state differs')
    require(set(complete['checks']) == {'ownership_restored', 'host_state_unchanged', 'reader_unchanged',
                                      'cache_unchanged', 'exact_counts'} and
            all(value is True for value in complete['checks'].values()), 'Worker checks incomplete/failed')
    before, during, after = [complete['identities_' + phase] for phase in ('before', 'during', 'after')]
    require(before == after, 'Original ownership was not restored')
    param_names = expected_state_keys() - {'lm_head.weight'}
    for identity in (before, during, after):
        require(set(identity) == {'requires_grad', 'training', 'hooks', 'forward_methods', 'grad_none', 'host_config'},
                'Incomplete host identity inventory')
        require(set(identity['requires_grad']) == set(identity['grad_none']) == param_names,
                'Incomplete218 named parameter inventory')
        require(identity['hooks'] == {} and all(value is True for value in identity['grad_none'].values()),
                'Unexpected host hook/gradient')
        require(identity['training'] and identity['training'] == before['training'] and
                all(value is False for value in identity['training'].values()), 'Host training flags differ')
        require(set(identity['forward_methods']) == set(identity['training']) and
                identity['forward_methods'] == before['forward_methods'], 'Host forward methods differ')
        require(identity['host_config']['logits_scaling'] == 6, 'Native logit scale changed')
        require(all(type(value) is bool for value in identity['requires_grad'].values()), 'Malformed gradient flag')
    require(all(value is False for value in during['requires_grad'].values()), 'Host gradients enabled during collection')
    expected_config = dict(before['host_config']); expected_config['use_cache'] = False
    require(during['host_config'] == expected_config, 'Active host config differs')
    for key in ('analytical_fits', 'backwards', 'optimizer_steps', 'organ_calls', 'writer_calls', 'provider_calls', 'generated_tokens'):
        require(type(complete[key]) is int and complete[key] == 0, 'Forbidden operation count: ' + key)
    require(type(complete['elapsed_seconds']) in (int, float) and
            math.isfinite(complete['elapsed_seconds']) and 0 <= complete['elapsed_seconds'] <= DEADLINE_SECONDS,
            'Worker resource duration differs')


def expected_events(schedule):
    result = [('worker_started', None), ('resources', 'before_loading')]
    for entry in schedule:
        result.extend([('resources', 'before:' + entry['id']), ('forward_started', entry)])
        if entry['phase'] == 'reader_only':
            result.extend([('reader_started', entry), ('reader_finished', entry)])
        result.extend([('forward_finished', entry), ('resources', 'after:' + entry['id']), ('forward_saved', entry)])
    result.extend([('resources', 'complete'), ('worker_completed', None)])
    return result


def validate_events(events, schedule, complete, started=None, worker=None):
    expected = expected_events(schedule)
    require(len(events) == len(expected) == 412, 'Worker event coverage differs')
    resources = []; previous = -math.inf; last_time = None
    for event, (kind, payload) in zip(events, expected):
        require(event['event'] == kind, 'Worker operation sequence differs')
        moment = datetime.fromisoformat(event['at_utc'])
        require(moment.tzinfo is not None and (last_time is None or moment >= last_time), 'Worker event timestamp differs')
        last_time = moment
        if started is not None:
            require(datetime.fromisoformat(started['at_utc']) <= moment < datetime.fromisoformat(started['deadline_utc']),
                    'Worker event outside owner deadline')
        if kind == 'resources':
            require(event['stage'] == payload, 'Resource sample order differs')
            sample = {k: v for k, v in event.items() if k not in ('event', 'at_utc')}
            require(set(sample) == {'stage', 'elapsed_seconds', 'rss_high_water_bytes', 'mps_driver_bytes'},
                    'Resource metadata schema differs')
            elapsed = sample['elapsed_seconds']
            require(type(elapsed) in (float, int) and math.isfinite(elapsed) and previous <= elapsed <= DEADLINE_SECONDS,
                    'Resource deadline/order differs')
            previous = elapsed
            require(all(type(sample[key]) is int and 0 <= sample[key] <= MEMORY_LIMIT
                        for key in ('rss_high_water_bytes', 'mps_driver_bytes')), 'Sampled resource ceiling differs')
            resources.append(sample)
        elif isinstance(payload, dict):
            schedule_fields(event, payload)
        elif kind == 'worker_completed':
            require(event['counts'] == complete['counts'], 'Journal completion counts differ')
        elif kind == 'worker_started' and worker is not None:
            require(all(event[k] == worker[k] for k in ('worker_pid', 'owner_pid', 'deadline_utc')),
                    'Journal worker ownership differs')
    require(resources == complete['resource_samples'] and len(resources) == 146, 'Resource receipt differs')
    return resources


def call_shapes(entry, length):
    shapes = {'input_ids': ('torch.int64', (1, length)),
              'hidden_before': ('torch.bfloat16', (1, length, 1024)),
              'hidden_after': ('torch.bfloat16', (1, length, 1024)),
              'full_logits': ('torch.bfloat16', (VOCAB,))}
    if entry['phase'] == 'reader_only':
        shapes.update({name: ('numpy.float64', shape) for name, shape in READER_OUTPUT_SHAPES.items()})
    return shapes


def load_call(directory, row, entry, context, plan_sha):
    stem = 'calls/' + entry['id']
    require(row['forward_path'] == stem + '.npz' and row['forward_metadata_path'] == stem + '.json',
            'Call artifact identity differs')
    p, m = safe(directory, row['forward_path']), safe(directory, row['forward_metadata_path'])
    require(digest(p) == row['forward_sha256'] and digest(m) == row['forward_metadata_sha256'], 'Call artifact hash differs')
    values, raw, metadata = load_bundle(p, m, call_shapes(entry, len(context['input_ids'])))
    schedule_fields(row, entry); schedule_fields(metadata, entry)
    require(metadata['plan_sha256'] == plan_sha, 'Call plan binding differs')
    for key in ('forward_completed', 'hook_entries', 'reader_entered', 'reader_completed', 'decisions'):
        require(row[key] == metadata[key], 'Call and metadata disagree: ' + key)
    require(row['forward_completed'] is True and row['hook_entries'] == 1 and type(row['hook_entries']) is int and
            row['controls_pass'] is True and row['error'] is None, 'Incomplete/failed forward capture')
    reader = entry['phase'] == 'reader_only'
    require(row['reader_entered'] is reader and row['reader_completed'] is reader, 'Reader application coverage differs')
    require(exact(values['input_ids'], np.array([context['input_ids']], dtype=np.int64)), 'Captured question tokens differ')
    require(exact(raw['hidden_before'], raw['hidden_after']), 'Same-call hidden input changed')
    return values, raw, metadata


def audit_records(directory, plan, plan_sha, frozen, started=None, worker=None):
    """Complete collection only; never return a surviving subset on failure."""
    directory = Path(directory)
    schedule = independent_schedule(plan['contexts'])
    require(schedule == plan['schedule'], 'Schedule changed')
    complete = read(directory / 'WORKER_COMPLETE.json')
    require(complete['plan_sha256'] == plan_sha, 'Worker complete plan binding differs')
    shapes = {name: ('numpy.float64', shape) for name, shape in READER_SHAPES.items()}
    initial, initial_raw, im = load_bundle(directory / 'reader-initial.npz', directory / 'reader-initial.json', shapes)
    final, final_raw, fm = load_bundle(directory / 'reader-final.npz', directory / 'reader-final.json', shapes)
    require(im['plan_sha256'] == fm['plan_sha256'] == plan_sha, 'Reader state plan binding differs')
    for name in READER_SHAPES:
        require(exact(initial[name], frozen[name]) and exact(initial_raw[name], final_raw[name]), 'Frozen reader changed')
    reader_hashes = {name: hashlib.sha256(initial_raw[name].tobytes()).hexdigest() for name in initial_raw}
    validate_ownership(complete, plan, reader_hashes)
    calls = jsonl(directory / 'calls.jsonl'); require(len(calls) == 72, 'Forward row coverage differs')
    resources = validate_events(jsonl(directory / 'worker-events.jsonl'), schedule, complete, started, worker)
    resource_map = {r['stage']: r for r in resources}
    contexts = {c['id']: c for c in plan['contexts']}
    baseline = {}; rows = []; controls = []; arithmetic = []
    for row, entry in zip(calls, schedule):
        context = contexts[entry['context_id']]; phase = entry['phase']
        require(row['resources_before'] == resource_map['before:' + entry['id']] and
                row['resources_after'] == resource_map['after:' + entry['id']], 'Call resource binding differs')
        values, raw, metadata = load_call(directory, row, entry, context, plan_sha)
        prior = baseline.setdefault(context['id'], {})
        require(set(row['comparisons']) == set(prior), 'Bracket comparison coverage differs')
        for earlier_phase, earlier in prior.items():
            output = output_comparison(earlier['full_logits'], values['full_logits'])
            hidden = hidden_comparison(earlier['hidden_before'], values['hidden_before'])
            expected = dict(full_vocabulary_max_absolute_error=output['maximum_absolute_error'],
                full_vocabulary_raw_equal=output['raw_equal'], hidden_raw_equal=hidden['full_raw_equal'],
                hidden_max_absolute_error=hidden['full_maximum_absolute_error'], pass_=True)
            expected['pass'] = expected.pop('pass_')
            require(row['comparisons'][earlier_phase] == expected, 'Worker bracket summary differs from raw bytes')
            controls.append(dict(context_id=context['id'], first_phase=earlier_phase, second_phase=phase,
                                 **output, hidden=hidden))
        if phase == 'reader_only':
            saved = {name: values[name] for name in READER_OUTPUT_SHAPES}
            checked = check_application(values['hidden_before'][0, -1], frozen, saved)
            require(row['decisions'] == checked['choices'], 'Recorded exact decision/gap differs')
            s, a = context['state'], context['action']; choice = checked['choices']
            rows.append(dict(id=entry['id'], context_id=context['id'], split=context['split'], state=s, action=a,
                address=3*s+a, choices=choice, state_correct=choice['state']['winner'] == s,
                action_correct=choice['action']['winner'] == a, address_correct=choice['address']['winner'] == 3*s+a,
                component_scores=saved['component_scores'].tolist(), address_scores=saved['address_scores'].tolist()))
            arithmetic.append(dict(id=entry['id'], context_id=context['id'], comparisons=checked['arithmetic'],
                                   independent_choices=checked['independent_choices']))
        else:
            require(row['decisions'] is None, 'Reader decision recorded outside reader-only call')
        prior[phase] = values
        if phase == 'restored':
            del baseline[context['id']]
    require(not baseline and len(rows) == 24 and len(controls) == 72 and len(arithmetic) == 24,
            'Incomplete full-panel assessment')
    result = summarize(rows)
    result.update(implementation_pass=True, rows=rows, controls=controls, counts=EXPECTED_COUNTS,
        reader_applications=24, arithmetic=dict(rows=arithmetic, scalar_fsum_reference=True, categorical_agreement_exact=True,
        maximum_error_by_array={name: max(r['comparisons'][name]['error'] for r in arithmetic)
                               for name in READER_OUTPUT_SHAPES if name != 'h64'}),
        resources=dict(samples=146, maximum_rss_bytes=max(r['rss_high_water_bytes'] for r in resources),
                       maximum_sampled_mps_driver_bytes=max(r['mps_driver_bytes'] for r in resources),
                       worker_elapsed_seconds=complete['elapsed_seconds']),
        same_call_hidden_identity=True, frozen_reader_unchanged=True, frozen_host_unchanged=True)
    return result


def runtime_guard():
    import importlib.metadata
    import platform
    require(platform.python_version() == SETTINGS['python'] and np.__version__ == SETTINGS['numpy'], 'Auditor Python/NumPy differs')
    require(Path(sys.executable).resolve() == (ROOT / 'work/acquisition-representation-venv/bin/python').resolve(),
            'Auditor executable differs')
    for package in ('torch', 'transformers'):
        require(importlib.metadata.version(package) == SETTINGS[package], 'Installed package version differs')


def audit(directory=OUT):
    directory = Path(directory)
    require(directory.resolve() == OUT.resolve(), 'Unexpected study directory')
    forbidden = ('STOPPED.json', 'WORKER_FAILURE.json', 'COMPLETE.json', 'AUDIT_STARTED.json',
                 'AUDIT_FAILURE.json', 'REPORT.json', 'INDEPENDENT_AUDIT.json')
    require(not any((directory / name).exists() for name in forbidden), 'Stopped/terminal/audit already attempted')
    runtime_guard()
    plan, plan_sha = verify_plan(directory)
    started, worker, owner_events = owner_guard(directory, plan_sha)
    collected = read(directory / 'COLLECTED.json')
    require(collected['plan_sha256'] == plan_sha and collected['all_controls_pass'] is True and
            collected['counts'] == EXPECTED_COUNTS, 'Incomplete collection')
    check_inventory(directory, collected)
    create(directory / 'AUDIT_STARTED.json', dict(at_utc=datetime.now(timezone.utc).isoformat(), plan_sha256=plan_sha,
        audit_code_sha256=digest(__file__), pid=os.getpid(), owner_pid=os.getppid(), rerun_allowed=False))
    try:
        validate_lineage(plan)
        cache = validate_cache(plan)
        require(read(directory / 'MODEL_CACHE_BEFORE.json') == read(directory / 'MODEL_CACHE_AFTER.json') == cache,
                'Model-cache validation identity changed')
        frozen = load_frozen_reader(plan)
        report = audit_records(directory, plan, plan_sha, frozen, started, worker)
        check_inventory(directory, collected, late=('AUDIT_STARTED.json',))
        verify_plan(directory)
        require(datetime.now(timezone.utc) < datetime.fromisoformat(started['deadline_utc']), 'Audit deadline expired')
        report.update(status='LIVE_READER_ADMISSION_PASSED' if report['gate_pass'] else 'LIVE_READER_ADMISSION_FAILED',
            at_utc=datetime.now(timezone.utc).isoformat(), plan_sha256=plan_sha,
            scope='Read-only fixed reader application to24 exposed one-template live host inputs. No organ/writer assembly.',
            limits=['All24 questions were development-exposed; held refers only to the original16-address fit.',
                    'Independent scalar FP64 arithmetic checks saved live vectors and three frozen fitted arrays; no refit.',
                    'Exact winners/ties must agree despite fixed arithmetic allowances.',
                    'All72 full-vocabulary comparisons use ln2/8; same-call hidden bytes are exact, cross-call variation descriptive.',
                    'No outcome writing, natural semantic mechanism, composition, unseen rules or novelty is established.',
                    'Original writer STOP remains final; separate writer recovery is only a sequencing prerequisite.'],
            model_calls_by_auditor=0, fits_by_auditor=0, provider_calls_by_auditor=0, gradient_updates_by_auditor=0)
        create(directory / 'REPORT.json', report)
        receipt = dict(status='PASS', implementation_pass=True, gate_pass=report['gate_pass'], plan_sha256=plan_sha,
            report_sha256=digest(directory / 'REPORT.json'), audit_code_sha256=digest(__file__),
            collected_sha256=digest(directory / 'COLLECTED.json'),
            input_sha256={**collected['artifact_sha256'], 'COLLECTED.json': digest(directory / 'COLLECTED.json')},
            owner_journal_prefix_sha256=hashlib.sha256(json.dumps(owner_events, sort_keys=True).encode()).hexdigest(),
            owner_journal_prefix_only=True, counts=report['counts'], reader_applications=24,
            model_calls=0, analytical_fits=0, provider_calls=0, gradient_updates=0, limitations=report['limits'])
        create(directory / 'INDEPENDENT_AUDIT.json', receipt)
        return receipt
    except BaseException as exc:
        create(directory / 'AUDIT_FAILURE.json', dict(at_utc=datetime.now(timezone.utc).isoformat(), plan_sha256=plan_sha,
            reason=type(exc).__name__ + ': ' + str(exc), audit_code_sha256=digest(__file__),
            rerun_allowed=False, partial_scientific_interpretation=False))
        raise


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, default=OUT)
    args = parser.parse_args()
    receipt = audit(args.directory)
    print(json.dumps({k: v for k, v in receipt.items() if k not in ('input_sha256', 'limitations')}), flush=True)
