"""Prospective read-only installation of the already fitted FP64 address reader.

Preparation uses metadata and opaque hashes only. No refit, model call, old-run
mutation or unregistered execution is permitted by this module.
"""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/moe-mechanisms/ORGAN_LIVE_READER_V1'
PREP = ROOT / 'outputs/moe-mechanisms/ORGAN_LIVE_READER_V1_PREPARATION'
PYTHON = ROOT / 'work/acquisition-representation-venv/bin/python'
OLD_SOURCE = ROOT / 'research/moe-mechanisms/organ_transplant_v2'
OLD = ROOT / 'outputs/moe-mechanisms/ORGAN_DEVELOPMENT_V2'
READER = ROOT / 'outputs/moe-mechanisms/ORGAN_ADDRESS_READ_V1'
WRITER = ROOT / 'outputs/moe-mechanisms/ORGAN_WRITER_V1'
RECOVERY = ROOT / 'outputs/moe-mechanisms/ORGAN_WRITER_RECOVERY_V1'
HELPER = ROOT / 'research/moe-mechanisms/model_cache_validation/cache_files.py'
MODEL_CACHE = ROOT / 'work/moe-model-cache/models--ibm-granite--granite-3.1-1b-a400m-instruct'
MODEL = MODEL_CACHE / 'snapshots/0da7a48b0276d500ce5922fd2b33944091fc6c09'
INSTALLED_MODEL_SOURCE = ROOT / 'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
OLD_PLAN_SHA = '94f2b56135cb3de13a00c0cd20e32e2e376306bf188e95b06610386f908c9eb4'
READER_PLAN_SHA = '0735ac5bbd8e1774f86f7fcd2fc8d7cd05c593f8d98db4d2a8ed9915f8f1ed99'
WRITER_PLAN_SHA = '3fff59be6b320911afa015550731a8ee34c9a07b0dc5771b23bf05466971873c'
RECOVERY_PLAN_SHA = '7257c155ba3b903fe2273d24d33f0acc43c597f52505759572e49567f2d0a811'
HELPER_SHA = '69b3f31e3a471abd0b488ad432a7e559ea31bec7044b77786409f5e6696d893e'
PRIMITIVE_SHA = '8402a52c467d8571f33b4ee203880ad3348665e591048f64adedbcef417e2a13'
PROPOSAL_SHA = 'd28c059a66056237d8b77d57ad55e596af9e4bd1f6bee56c02142333d6dbaedb'
PROPOSAL_REVIEW_SHA = '4723d46e0468478d0cb4f47f66cfe165e9ecea32ec9a8f3ef5cd7a3acea43147'
SETTINGS = dict(python='3.12.14', torch='2.8.0', transformers='4.56.2', numpy='2.3.3',
    host_forwards=72, reader_applications=24, contexts=24, analytical_fits=0,
    backwards=0, optimizer_steps=0, organ_forwards=0, writer_forwards=0,
    provider_calls=0, generated_tokens=0, insertion_layer=20, position='last',
    dtype='bfloat16', reader_dtype='float64', reader_device='cpu', device='mps',
    threads=4, batch_size=1, attention='eager', cache=False, logits_scaling=6,
    timeout_seconds=300, max_rss_bytes=10*1024**3, max_mps_driver_bytes=10*1024**3,
    max_control_logit_error=0.08664339756999316,
    rms_atol=1e-12, rms_rtol=1e-12, feature_atol=1e-12, feature_rtol=1e-12,
    score_atol=1e-9, score_rtol=1e-8)
SOURCES = ('protocol.py', 'reader.py', 'worker.py', 'audit.py', 'owner.py', 'launch.py',
           'test_reader.py', 'test_worker.py', 'test_audit.py', 'test_protocol.py')
COLLECTION_EXCLUSIONS = ('owner-events.jsonl', 'worker.log', 'independent_audit.log', 'COLLECTED.json')
REVIEW_FILES = ('WORKER_SCHEMA.json', 'SOURCE_REVIEW.json', 'PREPARATION_TESTS.json',
               'SOURCE_IMPLEMENTATION_REVIEW.json', 'AUDITOR_SOURCE_REVIEW.json')


def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def relative(path): return str(Path(path).relative_to(ROOT))
def require(ok, message):
    if not ok: raise ValueError(message)
def create(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
def safe_path(directory, name):
    p = Path(name)
    require(not p.is_absolute() and '..' not in p.parts, 'Unsafe relative artifact path')
    target = Path(directory) / p
    require(target.resolve().is_relative_to(Path(directory).resolve()), 'Artifact escapes directory')
    return target


def validate_contexts(contexts):
    require(len(contexts) == 24, 'Expected exactly24 contexts')
    for i, c in enumerate(contexts):
        s, a = divmod(i, 3)
        require(c['id'] == f's{s}-a{a}' and type(c['state']) is int and type(c['action']) is int
                and c['state'] == s and c['action'] == a, 'Context order/address differs')
        require(c['split'] == ('held' if a == s % 3 else 'train'), 'Original fit split differs')
        require(isinstance(c['input_ids'], list) and 1 <= len(c['input_ids']) <= 48
                and all(type(x) is int and 0 <= x < 49155 for x in c['input_ids'])
                and c['input_ids'][0] == 0, 'Input IDs differ')
        require(c['prompt'] == f"World state {s}. Actions {'XYZ'[a]}. Next state:", 'Prompt differs')


def schedule(contexts):
    validate_contexts(contexts)
    return [dict(index=3*i+j, id=f'{3*i+j:04d}', phase=phase, context_id=c['id'])
            for i, c in enumerate(contexts) for j, phase in enumerate(('native', 'reader_only', 'restored'))]


def build_inputs():
    """Opaque digests/JSON lineage only; never decode an old array."""
    bindings = {}
    def bind(path, expected=None):
        sha = digest(path)
        require(expected is None or sha == expected, 'Changed predecessor: '+str(path))
        bindings[relative(path)] = sha
    for directory, expected, status in ((OLD, OLD_PLAN_SHA, 'DEVELOPMENT_READINESS_FAILED'),
            (READER, READER_PLAN_SHA, 'ADDRESS_READER_ADMISSION_PASSED')):
        require(not (directory/'STOPPED.json').exists(), 'Prerequisite stopped')
        bind(directory/'plan.json', expected)
        require(read(directory/'REGISTRATION.json')['plan_sha256'] == expected, 'Registration link differs')
        c, a, collected = [read(directory/n) for n in ('COMPLETE.json','INDEPENDENT_AUDIT.json','COLLECTED.json')]
        require(c['status'] == status and a['status'] == 'PASS', 'Prerequisite status differs')
        require(c['plan_sha256'] == a['plan_sha256'] == collected['plan_sha256'] == expected, 'Plan links differ')
        require(c['report_sha256'] == a['report_sha256'], 'Report links differ')
        bind(directory/'REPORT.json', c['report_sha256'])
        bind(directory/'INDEPENDENT_AUDIT.json', c['independent_audit_sha256'])
        bound = a['collected_sha256'] if directory == OLD else a['input_sha256'][str(directory/'COLLECTED.json')]
        bind(directory/'COLLECTED.json', bound)
        for name in ('COMPLETE.json','REGISTRATION.json'): bind(directory/name)
    bind(WRITER/'plan.json', WRITER_PLAN_SHA)
    bind(WRITER/'STOPPED.json', '8adb5448ac62a55671db079c61cd65ebe41ab6f143480ebd3fd5f0f8194fdd60')
    require(not (WRITER/'COMPLETE.json').exists(), 'Original writer STOP replaced')
    bind(RECOVERY/'plan.json', RECOVERY_PLAN_SHA)
    rc = read(RECOVERY/'COMPLETE.json')
    require(not (RECOVERY/'FAILURE.json').exists() and rc['status'] == 'RECOVERED_ENGINEERING_WRITER_PASS'
            and rc['gate_pass'] is True and rc['implementation_pass'] is True
            and rc['original_study_completed'] is False and rc['recovery_plan_sha256'] == RECOVERY_PLAN_SHA,
            'Separate recovered writer not admitted')
    require(read(RECOVERY/'REGISTRATION.json')['plan_sha256'] == RECOVERY_PLAN_SHA, 'Recovery registration differs')
    bind(RECOVERY/'RECOVERED_REPORT.json', rc['report_sha256'])
    for name in ('COMPLETE.json','REGISTRATION.json'): bind(RECOVERY/name)
    recount = ROOT/'outputs/moe-mechanisms/ORGAN_WRITER_RECOVERY_V1_PREPARATION/PARENT_TERMINAL_RECOUNT.json'
    qr = read(recount)
    require(qr['status'] == 'PASS_PARENT_RECOVERED_RAW_RECOUNT' and qr['gate_pass'] is True
            and qr['complete_sha256'] == digest(RECOVERY/'COMPLETE.json'), 'Writer parent recount differs')
    bind(recount)
    old, reader, writer = [read(p/'plan.json') for p in (OLD,READER,WRITER)]
    old_collection = read(OLD/'COLLECTED.json')
    bind(OLD/'TOKENIZED_QUESTIONS.json', old_collection['artifact_sha256']['TOKENIZED_QUESTIONS.json'])
    tokens = read(OLD/'TOKENIZED_QUESTIONS.json'); contexts = writer['contexts']
    validate_contexts(contexts)
    for c in contexts:
        copies = [x for x in old['train_cases'] if x['initial_state'] == c['state'] and x['actions'] == [c['action']]]
        require(len(copies) == 4, 'Historical world copies differ')
        encoded = [tokens['cases'][x['id']] for x in copies]
        require(all(t == encoded[0] for t in encoded) and all(c[k] == v for k,v in encoded[0].items()), 'Historical input changed')
        r = [x for x in reader['cases'] if x['state'] == c['state'] and x['action'] == c['action']]
        require(len(r) == 4 and {x['id'] for x in r} == {x['id'] for x in copies}
                and all(x['input_length'] == len(c['input_ids']) for x in r), 'Offline reader case binding differs')
    collected = read(READER/'COLLECTED.json')
    for name in ('arrays.npz','arrays.json'): bind(READER/name, collected['artifact_sha256'][name])
    metadata = read(READER/'arrays.json')['tensors']
    members = {}
    for name, shape in (('coefficients',[1024,11]),('x_mean',[1024]),('y_mean',[11])):
        m = metadata[name]
        require(m['dtype'] == '<f8' and m['shape'] == shape, 'Frozen reader dtype/shape differs')
        members[name] = m
    require(len(old['model_files']) == 9 and old['model_files'] == writer['model_files']
            and relative(MODEL) == writer['model_path'], 'Pinned model differs')
    for filename, sha in (('ORGAN_LIVE_READER_PROPOSAL.json',PROPOSAL_SHA),
                         ('ORGAN_LIVE_READER_PROPOSAL_REVIEW.json',PROPOSAL_REVIEW_SHA)):
        bind(ROOT/'outputs/moe-mechanisms'/filename,sha)
    expected_host = read(OLD/'REPORT.json')['host_state_after']
    require(len(expected_host) == 219, 'Host-state coverage differs')
    return dict(contexts=contexts, schedule=schedule(contexts), lineage_sha256=bindings,
        reader_artifact=dict(path=relative(READER/'arrays.npz'), sha256=digest(READER/'arrays.npz'),
            metadata_path=relative(READER/'arrays.json'), metadata_sha256=digest(READER/'arrays.json'),
            member_sha256={k:v['raw_sha256'] for k,v in members.items()}, members=members),
        model_path=relative(MODEL), model_cache_repository=relative(MODEL_CACHE), model_files=old['model_files'],
        installed_model_source_sha256=old['installed_model_source_sha256'], expected_host_state=expected_host)


def source_hashes():
    paths = [HERE/n for n in SOURCES] + [HELPER, HELPER.with_name('test_cache_files.py'), OLD_SOURCE/'durable_launch.py']
    return {relative(p):digest(p) for p in paths}


def validate_model_files(plan):
    require(digest(HELPER) == HELPER_SHA, 'Reviewed cache helper changed')
    require(plan['model_path'] == relative(MODEL) and plan['model_cache_repository'] == relative(MODEL_CACHE), 'Model/cache root differs')
    require(len(plan['model_files']) == 9, 'Expected nine model files')
    spec = importlib.util.spec_from_file_location('bound_live_reader_cache_validation', HELPER)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    receipts = [helper.validate_model_cache_file(MODEL,n,sha,cache_repository=MODEL_CACHE)
                for n,sha in plan['model_files'].items()]
    require(digest(INSTALLED_MODEL_SOURCE) == plan['installed_model_source_sha256'], 'Installed model source differs')
    return receipts


def prepare():
    require(not OUT.exists(), 'Already registered or interrupted; never recreate')
    hashes = source_hashes(); review = read(PREP/'SOURCE_REVIEW.json')
    require(review.get('status') == 'PASS_SOURCE_REVIEW' and review.get('source_sha256') == hashes
            and review.get('settings') == SETTINGS, 'Source review absent or stale')
    tests = read(PREP/'PREPARATION_TESTS.json')
    require(tests.get('status') == 'PASS' and tests.get('source_sha256') == hashes, 'Tests absent or stale')
    for name in ('SOURCE_IMPLEMENTATION_REVIEW.json','AUDITOR_SOURCE_REVIEW.json'):
        require(read(PREP/name).get('status','').startswith('PASS'), 'Independent review absent')
    require(digest(OLD_SOURCE/'durable_launch.py') == PRIMITIVE_SHA, 'Launch primitive differs')
    inputs = build_inputs()
    for name in REVIEW_FILES: inputs['lineage_sha256'][relative(PREP/name)] = digest(PREP/name)
    plan = dict(status='PROSPECTIVE_LIVE_READER_ADMISSION', created_at_utc=now(), settings=SETTINGS,
        source_sha256=hashes, collection_exclusions=list(COLLECTION_EXCLUSIONS), **inputs,
        gates=dict(address_correct=24,state_correct=24,action_correct=24,total=24,allow_ties=False),
        scope='Read-only fixed FP64 reader installation on24 exposed one-template questions. No fit, writer, organ, state rollout, generated text or provider calls.',
        arithmetic='RMS=sqrt(mean(h*h)); x=h/RMS; centered=x-x_mean; scores=centered@coefficients+y_mean; address[3*s+a]=scores[s]+scores[8+a]. Independent reference uses fsum for squares/dots and its own recomputed intermediate values.',
        controls='Within-call full hidden bytes unchanged. All3 bracket output pairs percontext within ln2/8. Crosscall and historical hidden equality are descriptive only. Exact categorical agreement despite allowed numerical errors.',
        failure='Full fixed panel unless structural/control/resource/deadline failure. Any wrong/tied address after complete checks yields negative admission. No retry, refit, threshold or tolerance rescue; STOP forbids partial grading.',
        automatic_next_study=False)
    validate_model_files(plan)
    OUT.mkdir()
    for name, sha in hashes.items():
        target = OUT/'sources'/name; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(ROOT/name,target)
        require(digest(target) == sha, 'Archived source changed')
    create(OUT/'plan.json',plan)
    create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)


def verify():
    plan = read(OUT/'plan.json')
    require(read(OUT/'REGISTRATION.json')['plan_sha256'] == digest(OUT/'plan.json')
            and plan['settings'] == SETTINGS, 'Plan/settings changed')
    require(plan['schedule'] == schedule(plan['contexts']) and len(plan['schedule']) == 72, 'Schedule changed')
    require(plan['source_sha256'] == source_hashes(), 'Source set changed')
    for field in ('source_sha256','lineage_sha256'):
        for name, sha in plan[field].items(): require(digest(safe_path(ROOT,name)) == sha, 'Bound file changed: '+name)
    for name, sha in plan['source_sha256'].items():
        require(digest(safe_path(OUT/'sources',name)) == sha, 'Archived source changed')
    return plan


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser(); parser.add_argument('mode',choices=['prepare']); parser.parse_args(); prepare()
