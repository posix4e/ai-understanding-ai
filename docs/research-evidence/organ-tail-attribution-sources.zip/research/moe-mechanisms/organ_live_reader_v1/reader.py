"""Apply a frozen address reader on CPU. No fitting, labels or model imports."""
import numpy as np


def _array(value, dtype, shape, name):
    if (not isinstance(value, np.ndarray) or value.dtype != dtype
            or value.shape != shape or not np.isfinite(value).all()):
        raise ValueError('Invalid ' + name + ' dtype, shape or finite values')


def apply_reader(h, coefficients, x_mean, y_mean):
    """Only numeric live hidden values and three frozen arrays enter this API."""
    _array(h, np.dtype('float32'), (1024,), 'hidden vector')
    _array(coefficients, np.dtype('float64'), (1024, 11), 'coefficients')
    _array(x_mean, np.dtype('float64'), (1024,), 'x_mean')
    _array(y_mean, np.dtype('float64'), (11,), 'y_mean')
    h64 = h.astype(np.float64)
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        rms = np.asarray(np.sqrt(np.mean(h64 * h64)), dtype=np.float64)
        if not np.isfinite(rms) or float(rms) <= 0:
            raise ValueError('Nonpositive or nonfinite hidden RMS')
        normalized = h64 / rms
        centered = normalized - x_mean
        components = centered @ coefficients + y_mean
        addresses = (components[:8, None] + components[None, 8:]).reshape(24)
    result = dict(h64=h64, rms=rms, normalized=normalized, centered=centered,
                  component_scores=components, address_scores=addresses)
    if not all(np.isfinite(v).all() for v in result.values()):
        raise ValueError('Nonfinite reader arithmetic')
    return result


def decisions(component_scores, address_scores):
    """Report all exact maxima, never break a tie or inspect expected labels."""
    _array(component_scores, np.dtype('float64'), (11,), 'component scores')
    _array(address_scores, np.dtype('float64'), (24,), 'address scores')
    def one(values):
        winners = np.flatnonzero(values == values.max()).tolist()
        ordered = np.sort(values)
        return dict(winners=winners, unique=len(winners) == 1,
                    winner=winners[0] if len(winners) == 1 else None,
                    gap=float(ordered[-1] - ordered[-2]))
    return dict(state=one(component_scores[:8]), action=one(component_scores[8:]),
                address=one(address_scores))
