"""A new, exposed-panel causal attribution study of the frozen answer writer.

This does not reopen any failed readiness or confirmation study. Preparation
only reads metadata and hashes; no model execution or fitting occurs here.
"""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT/'outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1'
PREP = OUT.with_name(OUT.name+'_PREPARATION')
PYTHON = ROOT/'work/acquisition-representation-venv/bin/python'
ORIGINAL = ROOT/'outputs/moe-mechanisms/ORGAN_LIVE_ENERGY_V1'
ORIGINAL_SHA = {
    'plan.json':'53c52779e8c843e528af04acb1084d531e6f59ab000526ea937571bb100137ce',
    'COMPLETE.json':'e28f55a426529491229637dd7978b240d2daf1f370c10c2474a72657a050f98f',
    'INDEPENDENT_AUDIT.json':'c8ad327da021752c3f1d5f9a550fa6b7c073aa9bc3da3d44ec1610f91c9644ce',
}
LEGACY = {
    'old_protocol':'research/moe-mechanisms/organ_live_energy_v1/protocol.py',
    'worker':'research/moe-mechanisms/organ_live_energy_v1/worker.py',
    'assembly':'research/moe-mechanisms/organ_live_energy_v1/assembly.py',
    'reader':'research/moe-mechanisms/organ_live_reader_v1/reader.py',
    'writer':'research/moe-mechanisms/organ_writer_v1/writer.py',
    'organ':'research/moe-mechanisms/organ_transplant_v2/organ.py',
    'energy_audit':'research/moe-mechanisms/organ_live_energy_v1/audit.py',
    'launch_primitive':'research/moe-mechanisms/organ_transplant_v2/durable_launch.py',
}
WORLD_IDS = ['dev00','dev01','dev02','dev03']
ARMS = ['B','W','S0','D','T','S1']
SETTINGS = dict(python='3.12.14', torch='2.8.0', transformers='4.56.2', numpy='2.3.3',
    host_forwards=576, reader_applications=96, organ_forwards_max=96, writer_forwards_max=576,
    contexts=24, worlds=4, cells=96, analytical_fits=0, backwards=0, optimizer_steps=0,
    provider_calls=0, generated_tokens=0, insertion_layer=20, tail_layers=[20,21,22,23],
    position='last', dtype='bfloat16', device='mps', reader_dtype='float64', reader_device='cpu',
    organ_dtype='float32', organ_device='cpu', organ_query_shape=[8,19], temperature=1.0,
    writer_dtype='float32', writer_device='mps', threads=4, batch_size=1, attention='eager',
    cache=False, logits_scaling=6, timeout_seconds=900, max_rss_bytes=10*1024**3,
    max_mps_driver_bytes=10*1024**3, max_archive_bytes=1024**3, max_control_logit_error=0.0,
    rms_atol=1e-12, rms_rtol=1e-12, feature_atol=1e-12, feature_rtol=1e-12,
    score_atol=1e-9, score_rtol=1e-8, gelu_atol=2e-6, gelu_rtol=2e-6, softmax_atol=2e-7,
    dot_gamma_multiplier=4, dot_reference_u_multiplier=2, dot_tiny_multiplier=8)
SOURCES = ('protocol.py','tail.py','worker.py','audit.py','owner.py','launch.py',
           'test_tail_worker.py','test_audit.py','test_protocol.py')
COLLECTION_EXCLUSIONS = ('owner-events.jsonl','resource-monitor.jsonl','worker.log',
                         'independent_audit.log','COLLECTED.json')
REVIEWS = ('WORKER_SCHEMA.json','PREPARATION_TESTS.json','SOURCE_IMPLEMENTATION_REVIEW.json',
           'PARENT_SOURCE_REVIEW.json')


def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def relative(path): return str(Path(path).relative_to(ROOT))
def require(ok, message):
    if not ok: raise ValueError(message)
def create(path, value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def safe_path(directory, name):
    p=Path(name)
    require(not p.is_absolute() and '..' not in p.parts,'Unsafe bound path')
    result=Path(directory)/p
    require(result.resolve().is_relative_to(Path(directory).resolve()),'Bound path escapes root')
    return result


def original_plan():
    for name,h in ORIGINAL_SHA.items(): require(digest(ORIGINAL/name)==h,'Original record changed: '+name)
    plan=read(ORIGINAL/'plan.json');done=read(ORIGINAL/'COMPLETE.json');audit=read(ORIGINAL/'INDEPENDENT_AUDIT.json')
    require(done['status']=='LIVE_ENERGY_ASSEMBLY_PASSED' and done['gate_pass'] is True and
            audit['status']=='PASS' and audit['gate_pass'] is True,'Working assembly prerequisite absent')
    require(done['plan_sha256']==audit['plan_sha256']==ORIGINAL_SHA['plan.json'] and
            done['report_sha256']==audit['report_sha256']==digest(ORIGINAL/'REPORT.json') and
            done['independent_audit_sha256']==ORIGINAL_SHA['INDEPENDENT_AUDIT.json'],
            'Original completion chain differs')
    require(not (ORIGINAL/'STOPPED.json').exists(),'Original assembly stopped')
    return plan


_MODULES = {}
def load_legacy(name):
    path=ROOT/LEGACY[name]
    expected=original_plan()['source_sha256'][relative(path)]
    require(digest(path)==expected,'Frozen reused source changed: '+name)
    if name not in _MODULES:
        if name=='worker':
            # The old helper module imports only this exact frozen assembly by
            # its unqualified name. Its entry point is never called.
            assembly=load_legacy('assembly')
            if 'assembly' in sys.modules: require(sys.modules['assembly'] is assembly,'Assembly import collision')
            sys.modules['assembly']=assembly
        spec=importlib.util.spec_from_file_location('tail_bound_'+name,path)
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
        spec.loader.exec_module(module);_MODULES[name]=module
    return _MODULES[name]


def schedule(contexts):
    require(len(contexts)==24,'Expected24 contexts')
    rows=[]
    for i,c in enumerate(contexts):
        s,a=divmod(i,3)
        require(c['id']==f's{s}-a{a}' and c['state']==s and c['action']==a and
                c['prompt']==f"World state {s}. Actions {'XYZ'[a]}. Next state:",'Fixed context differs')
        for world in WORLD_IDS:
            for arm in ARMS:
                index=len(rows)
                rows.append(dict(index=index,id=f'{index:04d}',cell_id=c['id']+'-'+world,
                                 context_id=c['id'],world_id=world,arm=arm))
    require(len(rows)==576,'Schedule differs')
    return rows


def source_hashes():
    old=original_plan();sources=dict(old['source_sha256'])
    for name,h in sources.items(): require(digest(ROOT/name)==h,'Original source changed: '+name)
    for name in SOURCES: sources[relative(HERE/name)]=digest(HERE/name)
    return sources


def validate_model_files(plan): return load_legacy('old_protocol').validate_model_files(plan)


def build_plan():
    old=original_plan()
    keep={k:old[k] for k in ('reader_artifact','writer_artifact','organ_artifacts','expected_host_state',
        'model_path','model_cache_repository','model_files','installed_model_source_sha256',
        'contexts','worlds','label_ids')}
    lineage=dict(old['lineage_sha256'])
    for name in (*ORIGINAL_SHA,'REPORT.json','COLLECTED.json'):
        lineage[relative(ORIGINAL/name)]=digest(ORIGINAL/name)
    reset=ROOT/'work/organ-research-reset-v1'
    for name in ('EXISTING_ASSEMBLY_ASSESSMENT.json','RESEARCH_DIRECTION_CRITIQUE.json','PRIMARY_PRIOR_ART_REASSESSMENT.json'):
        lineage[relative(reset/name)]=digest(reset/name)
    budget=ROOT/'outputs/routing-research/BUDGET_AFTER_JEV_FEEDBACK_AMENDED_NEGATIVE.json'
    require(digest(budget)=='8ebcaabedb7bd09cfdf63b9ccbe6c6b60cf2d31e9d753d09e9b7ec4d6975ff58','Budget basis changed')
    lineage[relative(budget)]=digest(budget)
    return dict(status='PROSPECTIVE_EXPOSED_PANEL_TAIL_ATTRIBUTION',created_at_utc=now(),
        settings=SETTINGS,**keep,schedule=schedule(keep['contexts']),source_sha256=source_hashes(),
        lineage_sha256=lineage,collection_exclusions=list(COLLECTION_EXCLUSIONS),
        question='For the working one-step answer writer, are its induced attention/MoE updates in blocks20-23 necessary for the supplied-label ranking, and can those recorded updates transmit that ranking without the original writer displacement?',
        arms={
            'B':dict(writer='uniform',tail='native'),
            'W':dict(writer='live actual reader/energy P',tail='native'),
            'S0':dict(writer='uniform',tail='B'),
            'D':dict(writer='exact W P',tail='B'),
            'T':dict(writer='uniform',tail='W'),
            'S1':dict(writer='exact W P',tail='W')},
        design='All24 already exposed contexts by all4 already exposed organs;96cells with6arms in fixed B,W,S0,D,T,S1 order. No sampling, fits, new modules, wrong-query variants, source/site search, generated tokens or provider calls.',
        intervention='Replace only the final-position first returned tensor of self_attn and block_sparse_moe in blocks20,21,22,23. Preserve other positions and tuple members. Leave all native residual additions, residual_multiplier, norms, lm_head and logits_scaling intact. Replay is from the identical context/world B or W call; the native branches still physically execute.',
        admission=dict(full_vocabulary_raw_shams='B==S0 and W==S1 exactly in every cell; zero tolerance',
            frozen_parameters=True,hook_restoration=True,reader_query_identity=96,
            unique_energy_and_P_match_world=96,unpatched_upstream_equal=True,
            nonfinal_tail_positions_equal_all_arms=True,
            natural_written_supplied_label_correct=96,allow_favorable_subset=False),
        metrics='After complete collection and independent structural audit, report all8scores, strict unique choice/ties and target-vs-best-other margin for every cell/arm. Fixed margin target is the registered world transition for requested state/action; also record actual unique P argmax, or null on ties. Interpretation requires replication admission, where these labels must agree in every cell. If admission fails, retain all fixed-label scores as a complete negative with interpretation disabled. Report direct contrast D-S0, tail contrast T-S0, total S1-S0, interaction S1-D-T+S0 and natural W-B. These are intervention-specific margin contrasts, not unique natural mediation or a normalized causal fraction.',
        interpretation=[
            'If D preserves every W supplied-label choice, writer-dependent updates at these8sites are not necessary for those categorical choices under this clamp. Margin changes and finalnorm/head contributions remain.',
            'A D loss with valid controls shows path dependence in that cell, not semantic reasoning or planning. T measures sufficiency of recorded written branch outputs under zero writer displacement; these outputs may themselves encode the answer.',
            'Mixed results are retained in full. Hybrid inputs and matched baseline writes restrict the counterfactual interpretation. No population inference, fresh confirmation, novelty, energy advantage or autonomous organ-choice claim follows.'],
        stop='Structural, raw replay, source, execution, resource or nonfinite failure preserves STOP and partial traces without mechanistic conclusions or rerun. An unresolved reader stops because no fixed P exists for the paired factorial; never invent an address. A complete valid replication failure closes this attribution admission without favorable-cell analysis.',
        archive='Retain actual and returned branch final rows, pre-writer tensors and writer operands, intermediate energy/reader operands on W, raw full-vocabulary outputs and final pre-normalization residual. Record nonfinal-row hashes, exact source IDs and complete call events.',
        resource='One pinned local Granite load; 900seconds owner deadline including audit; RSS and MPS-driver ceilings10GiB; archive1GiB. Owner monitors child RSS and archive; worker samples MPS usage. No restart or deadline extension.',
        budget_new_usd=0,budget_inclusive_committed_and_reserved_usd='7.6774551949',
        budget_remaining_usd='12.3225448051',novelty_established=False,
        scientific_confirmation=False,automatic_next_study=False)


def prepare():
    require(not OUT.exists(),'Already registered/interrupted; never recreate')
    hashes=source_hashes()
    for name in ('SOURCE_IMPLEMENTATION_REVIEW.json','PARENT_SOURCE_REVIEW.json','PREPARATION_TESTS.json'):
        review=read(PREP/name)
        require(review.get('status','').startswith('PASS'),'Missing passing review: '+name)
        require(review.get('source_sha256')==hashes,'Source-bound review stale: '+name)
    plan=build_plan()
    for name in REVIEWS: plan['lineage_sha256'][relative(PREP/name)]=digest(PREP/name)
    for name,h in plan['lineage_sha256'].items():require(digest(ROOT/name)==h,'Bound lineage changed')
    validate_model_files(plan)
    OUT.mkdir()
    for name,h in hashes.items():
        target=OUT/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/name,target);require(digest(target)==h,'Archived source copy changed')
    create(OUT/'plan.json',plan)
    create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)


def verify():
    plan=read(OUT/'plan.json')
    require(read(OUT/'REGISTRATION.json')['plan_sha256']==digest(OUT/'plan.json'),'Plan changed')
    require(plan['settings']==SETTINGS and plan['schedule']==schedule(plan['contexts']),'Settings/schedule changed')
    require(plan['source_sha256']==source_hashes(),'Bound source inventory changed')
    for field in ('source_sha256','lineage_sha256'):
        for name,h in plan[field].items(): require(digest(safe_path(ROOT,name))==h,'Bound file changed: '+name)
    for name,h in plan['source_sha256'].items():
        require(digest(safe_path(OUT/'sources',name))==h,'Archived source changed')
    return plan


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare']);parser.parse_args();prepare()
