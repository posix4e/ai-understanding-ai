"""Invented tensors/fake hosts only; no checkpoint, tokenizer or real corpus."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest import mock

import numpy as np
import torch

import worker as w
import tail as t

ROOT = Path(__file__).resolve().parents[3]


def source(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


ASSEMBLY = source('assembly', 'research/moe-mechanisms/organ_live_energy_v1/assembly.py')
LEGACY = source('invented_tail_legacy', 'research/moe-mechanisms/organ_live_energy_v1/worker.py')
READER = source('invented_tail_reader', 'research/moe-mechanisms/organ_live_reader_v1/reader.py')
WRITER = source('invented_tail_writer', 'research/moe-mechanisms/organ_writer_v1/writer.py')
ORGAN = source('invented_tail_organ', 'research/moe-mechanisms/organ_transplant_v2/organ.py')
torch.set_num_threads(4)


class Config:
    use_cache = True
    logits_scaling = 6
    residual_multiplier = .22

    def to_dict(self):
        return dict(use_cache=self.use_cache, logits_scaling=self.logits_scaling,
                    residual_multiplier=self.residual_multiplier)


class Branch(torch.nn.Module):
    def __init__(self, coefficient):
        super().__init__()
        self.coefficient = coefficient
        self.aux = None

    def forward(self, hidden):
        self.aux = torch.zeros((hidden.shape[1], 3), dtype=torch.float32)
        return (hidden * self.coefficient, self.aux)


class Block(torch.nn.Module):
    residual_multiplier = .22

    def __init__(self):
        super().__init__()
        self.self_attn = Branch(.125)
        self.block_sparse_moe = Branch(.25)
        self.post_attention_layernorm = torch.nn.Identity()

    def forward(self, hidden):
        attention, _ = self.self_attn(hidden)
        hidden = hidden + attention * self.residual_multiplier
        intermediate = self.post_attention_layernorm(hidden)
        moe, _ = self.block_sparse_moe(intermediate)
        return (hidden + moe * self.residual_multiplier,)


class Model(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.config = Config()
        self.weight = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
        self.model = torch.nn.Module()
        self.model.layers = torch.nn.ModuleList([torch.nn.Identity() for _ in range(20)] + [Block() for _ in range(4)])
        self.model.norm = torch.nn.Identity()
        self.calls = 0
        self.fail_before = None
        self.fail_after = None
        self.nan_at = None
        self.drift_at = None

    def forward(self, *, input_ids, use_cache, logits_to_keep, return_dict):
        if (use_cache, logits_to_keep, return_dict) != (False, 1, True):
            raise AssertionError('Unexpected native invocation')
        self.calls += 1
        if self.calls == self.fail_before:
            raise RuntimeError('invented early host failure')
        s, a = divmod(int(input_ids[0, -1]) - 1, 3)
        hidden = torch.zeros((1, input_ids.shape[1], 1024), dtype=torch.bfloat16)
        hidden[:, :, s] = 1
        hidden[:, :, 8+a] = 1
        hidden[:, :, 30] = -0.0
        for block in self.model.layers[20:]:
            hidden = block(hidden)[0]
        hidden = self.model.norm(hidden)
        if self.calls == self.fail_after:
            raise RuntimeError('invented late host failure')
        logits = torch.zeros((1, 1, 49155), dtype=torch.bfloat16)
        logits[0, 0, :11] = hidden[0, -1, :11]
        if self.calls == self.nan_at:
            logits[0, 0, 20] = float('nan')
        if self.calls == self.drift_at:
            logits[0, 0, 22] = 1
        return types.SimpleNamespace(logits=logits)


def setup(tied=False, model=None):
    coefficients = np.zeros((1024, 11), dtype=np.float64)
    if not tied:
        coefficients[:11] = np.eye(11)
    arrays = dict(coefficients=coefficients, x_mean=np.zeros(1024), y_mean=np.zeros(11))
    writer = WRITER.OutcomeWriter().eval()
    with torch.no_grad():
        writer.weight[:8] = torch.eye(8)
    writer.weight.requires_grad_(False)
    organs = {}
    for i in range(4):
        organ = ORGAN.EnergyOrgan().eval()
        with torch.no_grad():
            for param in organ.parameters():
                param.zero_()
                param.requires_grad_(False)
            organ.input_proj.weight[0, 11] = 1
            organ.hidden_proj.weight[0, 0] = 1
            organ.output_proj.weight[0, 0] = -4
        organs[f'dev{i:02d}'] = organ
    connection = w.Connection(ASSEMBLY.LiveEnergyConnection(arrays, READER.apply_reader, READER.decisions, writer))
    return dict(host=model or Model(), writer=writer, **organs), connection


def panel(full=False):
    contexts = {}
    rows = []
    for s in range(8 if full else 1):
        for a in range(3 if full else 1):
            cid = f's{s}-a{a}'
            contexts[cid] = dict(id=cid, input_ids=[0, 3*s+a+1])
            for world in range(4 if full else 1):
                for arm in t.ARMS:
                    n = len(rows)
                    rows.append(dict(index=n, id=f'{n:04d}', cell_id=f'{cid}-dev{world:02d}',
                        context_id=cid, world_id=f'dev{world:02d}', arm=arm))
    ids = {cid: torch.tensor([c['input_ids']], dtype=torch.int64) for cid, c in contexts.items()}
    return contexts, rows, ids


def run(directory, *, model=None, tied=False, full=False, on_event=None, guard=None):
    modules, connection = setup(tied, model)
    contexts, rows, ids = panel(full)
    events = []
    counts = w.initial_counts()

    def event(name, **fields):
        events.append(dict(event=name, **fields))
        if on_event:
            on_event(name)

    def sample(stage):
        value = dict(stage=stage, elapsed_seconds=0., rss_high_water_bytes=0, mps_driver_bytes=0, archive_bytes=0)
        event('resources', **value)
        return value

    w.run_calls(modules, connection, contexts, rows, ids, directory, 'a'*64,
                LEGACY.identity(modules), LEGACY, event, sample, guard or (lambda v: None), counts)
    return modules, counts, events


class TailTests(unittest.TestCase):
    def test_native_bf16_residual_scalar_semantics_cpu_and_available_mps(self):
        # Model-free backend admission: scalar stays FP32 for multiplication.
        x = torch.cat((torch.linspace(-8, 8, 4097), torch.tensor([-0., 0.]))).to(torch.bfloat16)
        residual = torch.cat((torch.linspace(3, -3, 4097), torch.tensor([-0., -0.]))).to(torch.bfloat16)
        expected_product = (x.float() * torch.tensor(.22, dtype=torch.float32)).to(torch.bfloat16)
        expected_sum = (residual.float() + expected_product.float()).to(torch.bfloat16)
        rounded_scalar = (x.float() * torch.tensor(.22, dtype=torch.bfloat16).float()).to(torch.bfloat16)
        self.assertNotEqual(t.raw(expected_product), t.raw(rounded_scalar))
        devices = ['cpu'] + (['mps'] if torch.backends.mps.is_available() else [])
        for device in devices:
            product = x.to(device) * .22
            actual_sum = residual.to(device) + product
            self.assertEqual(t.raw(product), t.raw(expected_product), device)
            self.assertEqual(t.raw(actual_sum), t.raw(expected_sum), device)

    def test_branch_exact_last_row_and_auxiliary_identity(self):
        model = Model()
        rows = {name: torch.full((1, 1, 1024), -2., dtype=torch.bfloat16) for name in t.SITES}
        hook = t.TailReplay(model, rows)
        actual = torch.zeros((1, 3, 1024), dtype=torch.bfloat16)
        actual[:, :2, 30] = -0.0
        aux = torch.tensor([3.])
        output = hook.branch('b20_attn', (actual, aux))
        self.assertIs(output[1], aux)
        self.assertEqual(t.raw(output[0][:, :-1]), t.raw(actual[:, :-1]))
        self.assertEqual(t.raw(output[0][:, -1:]), t.raw(rows['b20_attn']))
        self.assertEqual(t.raw(actual), t.raw(torch.cat((actual[:, :2], torch.zeros((1, 1, 1024), dtype=torch.bfloat16)), 1)))

    def test_registration_failure_removes_installed_hooks(self):
        model = Model()
        with mock.patch.object(model.model.layers[21].self_attn, 'register_forward_hook', side_effect=OSError('invented register')):
            with self.assertRaises(OSError):
                with t.TailReplay(model):
                    pass
        self.assertTrue(all(not m._forward_hooks and not m._forward_pre_hooks for m in model.modules()))

    def test_actual_malformed_tuple_rejected(self):
        with self.assertRaises(ValueError):
            t.TailReplay(Model()).branch('b20_attn', torch.zeros((1, 1, 1024), dtype=torch.bfloat16))

    def test_nonfinite_branch_preserved_before_validation(self):
        replay = t.TailReplay(Model())
        value = torch.zeros((1, 1, 1024), dtype=torch.bfloat16)
        value[0, 0, 0] = float('nan')
        replay.branch('b20_attn', (value, None))
        self.assertTrue(torch.isnan(replay.capture['b20_attn_actual_final'][0, 0, 0]))

    def test_repeated_branch_does_not_overwrite_first(self):
        replay = t.TailReplay(Model())
        value = torch.zeros((1, 1, 1024), dtype=torch.bfloat16)
        replay.branch('b20_attn', (value, None))
        with self.assertRaises(ValueError):
            replay.branch('b20_attn', (value+1, None))
        self.assertEqual(float(replay.capture['b20_attn_actual_final'].sum()), 0)


class WorkerTests(unittest.TestCase):
    def read_rows(self, directory):
        return [json.loads(s) for s in (directory / 'calls.jsonl').read_text().splitlines()]

    def test_complete_six_arm_control_path_no_scientific_grading(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            modules, counts, events = run(directory)
            rows = self.read_rows(directory)
            self.assertEqual([r['arm'] for r in rows], list(t.ARMS))
            self.assertEqual(counts['forward_finished'], 6)
            self.assertEqual(counts['reader_finished'], 1)
            self.assertEqual(counts['organ_finished'], 1)
            self.assertEqual(counts['writer_finished'], 6)
            self.assertEqual(counts['optimizer_steps'], 0)
            self.assertTrue(all(r['controls_pass'] for r in rows))
            self.assertTrue(rows[2]['comparisons']['exact_full_logits_sham'])
            self.assertTrue(rows[5]['comparisons']['exact_full_logits_sham'])
            self.assertEqual(rows[3]['probability_source_id'], rows[1]['id'])
            self.assertEqual(rows[4]['replay_source_id'], rows[1]['id'])
            self.assertFalse(any(LEGACY.identity(modules)['hooks'].values()))
            with np.load(directory / rows[1]['forward_path'], allow_pickle=False) as z:
                self.assertEqual(z['b20_residual_input__raw_uint8'].tobytes(), z['returned__value'][:, -1:].astype(np.float32).view(np.uint32).__rshift__(16).astype(np.uint16).tobytes())
                self.assertFalse(np.array_equal(z['b20_residual_input__value'], z['hidden_before__value'][:, -1:]))
                self.assertTrue(np.array_equal(z['b23_after_moe__value'], z['final_residual__value'][:, -1:]))

    def test_full_invented_576_panel_counts(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            modules, counts, events = run(directory, full=True)
            self.assertEqual(counts['forward_finished'], 576)
            self.assertEqual(counts['reader_finished'], 96)
            self.assertEqual(counts['organ_finished'], 96)
            self.assertEqual(counts['writer_finished'], 576)
            self.assertEqual(sum(e['event'] == 'forward_saved' for e in events), 576)
            self.assertEqual(len(list((directory / 'calls').glob('*.npz'))), 576)

    def test_unresolved_W_retained_then_stops_without_guessed_P(self):
        model = Model()
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(ValueError, 'Unresolved'):
                run(directory, model=model, tied=True)
            rows = self.read_rows(directory)
            self.assertEqual(model.calls, 2)
            self.assertFalse(rows[-1]['controls_pass'])
            self.assertFalse(rows[-1]['resolved'])
            with np.load(directory / rows[-1]['forward_path'], allow_pickle=False) as z:
                self.assertIn('address_scores__value', z)
                self.assertNotIn('probabilities_cpu__value', z)
                self.assertIn('full_logits__value', z)

    def test_early_failure_never_reuses_previous_capture(self):
        model = Model()
        model.fail_before = 2
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(RuntimeError, 'early'):
                run(directory, model=model)
            last = self.read_rows(directory)[-1]
            with np.load(directory / last['forward_path'], allow_pickle=False) as z:
                self.assertEqual(set(z.files), {'input_ids__raw_uint8', 'input_ids__value'})
            self.assertFalse(last['forward_completed'])
            self.assertEqual(last['tail_sites'], {})
            self.assertTrue(all(not m._forward_hooks and not m._forward_pre_hooks for m in model.modules()))

    def test_late_failure_keeps_writer_branch_residual_evidence(self):
        model = Model()
        model.fail_after = 2
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(RuntimeError, 'late'):
                run(directory, model=model)
            last = self.read_rows(directory)[-1]
            with np.load(directory / last['forward_path'], allow_pickle=False) as z:
                self.assertIn('energies__value', z)
                self.assertIn('final_residual__value', z)
                self.assertNotIn('full_logits__value', z)

    def test_nonfinite_return_saved_before_stop(self):
        model = Model()
        model.nan_at = 1
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(ValueError, 'Nonfinite'):
                run(directory, model=model)
            row = self.read_rows(directory)[0]
            with np.load(directory / row['forward_path'], allow_pickle=False) as z:
                self.assertTrue(np.isnan(z['full_logits__value']).any())
            self.assertTrue(row['forward_completed'])
            self.assertEqual(model.calls, 1)

    def test_exact_full_vocabulary_sham_detects_noncandidate_drift(self):
        model = Model()
        model.drift_at = 3
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(ValueError, 'paired control'):
                run(directory, model=model)
            self.assertEqual(len(self.read_rows(directory)), 3)

    def test_finish_event_failure_preserves_completed_return(self):
        def event(name):
            if name == 'forward_finished':
                raise OSError('invented finish journal')
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(OSError, 'finish journal'):
                run(directory, on_event=event)
            row = self.read_rows(directory)[0]
            self.assertTrue(row['forward_completed'])
            self.assertFalse(row['controls_pass'])
            with np.load(directory / row['forward_path'], allow_pickle=False) as z:
                self.assertIn('full_logits__value', z)

    def test_start_event_failure_removes_all_hooks_without_forward(self):
        model = Model()
        def event(name):
            if name == 'forward_started':
                raise OSError('invented start journal')
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(OSError, 'start journal'):
                run(directory, model=model, on_event=event)
            self.assertEqual(model.calls, 0)
            self.assertTrue(all(not m._forward_hooks and not m._forward_pre_hooks for m in model.modules()))

    def test_postcall_resource_failure_keeps_raw_and_row(self):
        def guard(value):
            if value['stage'].startswith('after:'):
                raise RuntimeError('invented resource')
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            with self.assertRaisesRegex(RuntimeError, 'resource'):
                run(directory, guard=guard)
            row = self.read_rows(directory)[0]
            self.assertTrue((directory / row['forward_path']).exists())
            self.assertTrue(row['forward_completed'])

    def test_component_raw_retention_signed_zero_and_scalar(self):
        values = {'rms': np.asarray(3., dtype=np.float64),
                  'value': torch.tensor([-0., 0., 1.], dtype=torch.bfloat16)}
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            result = LEGACY.retain(directory, 'raw', values, {})
            meta = json.loads((directory / result['forward_metadata_path']).read_text())
            with np.load(directory / result['forward_path'], allow_pickle=False) as z:
                self.assertEqual(z['rms__value'].shape, ())
                self.assertEqual(z['value__raw_uint8'].tobytes(), t.raw(values['value']))
                self.assertEqual(meta['tensors']['value']['raw_sha256'], hashlib.sha256(t.raw(values['value'])).hexdigest())


if __name__ == '__main__':
    unittest.main()
