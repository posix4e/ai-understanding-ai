"""Collect the fixed tail factorial; never score answers or fit a component."""
import argparse
from datetime import datetime, timezone
import inspect
import os
import platform
import resource
import signal
import time

import numpy as np
import torch

from tail import ARMS, BLOCKS, REPLAY, SITES, TailReplay, raw, replay_rows


def initial_counts():
    return dict(forward_attempts=0, forward_finished=0, reader_attempts=0,
        reader_finished=0, organ_attempts=0, organ_finished=0, writer_attempts=0,
        writer_finished=0, analytical_fits=0, backward_attempts=0,
        backward_finished=0, optimizer_attempts=0, optimizer_steps=0)


def blank_info():
    return dict(reader_entered=False, reader_completed=False, decisions=None,
        resolved=None, predicted_state=None, predicted_action=None,
        predicted_address=None, query_state=None, query_action=None,
        organ_entered=False, organ_completed=False, writer_entered=False,
        writer_completed=False, patched=False, unresolved_reason=None,
        energy_hook_entries=None, energy_hook_finished=None)


class Connection:
    """Delegate W/uniform to the frozen connection; replay only W's actual P."""
    def __init__(self, original):
        self.original = original
        self.writer = original.writer
        self.last_capture = {}
        self.last_info = {}

    def reset(self):
        self.last_capture = {}
        self.last_info = blank_info()
        self.original.last_capture = {}
        self.original.last_info = {}
        self.writer.last_capture = None

    def apply(self, hidden, arm, organ, probabilities, event):
        if arm in ('B', 'W', 'S0', 'T'):
            try:
                return self.original.apply(hidden, 'main' if arm == 'W' else 'uniform',
                    organ if arm == 'W' else None, event)
            finally:
                self.last_capture = self.original.last_capture
                self.last_info = self.original.last_info
        if arm not in ('D', 'S1') or organ is not None:
            raise ValueError('Invalid probability replay arm')
        info, capture = self.last_info, self.last_capture
        if (not isinstance(probabilities, torch.Tensor) or probabilities.device.type != 'cpu'
                or probabilities.dtype != torch.float32 or tuple(probabilities.shape) != (8,)):
            raise ValueError('Missing same-cell W probability vector')
        capture['probabilities_cpu'] = probabilities.detach().cpu().clone()
        p = probabilities.to(device=hidden.device, dtype=torch.float32)
        capture['probabilities'] = p
        if raw(p) != raw(probabilities):
            raise ValueError('Probability replay transfer changed bytes')
        info['writer_entered'] = True
        event('writer_started')
        try:
            returned, actual = self.writer(hidden, p)
            info['writer_completed'] = info['patched'] = True
            capture.update({k: v for k, v in actual.items() if k != 'hidden'})
            event('writer_finished')
            return returned
        finally:
            if self.writer.last_capture is not None:
                capture.update({k: v for k, v in self.writer.last_capture.items() if k != 'hidden'})


def collect_forward(model, ids, connection, organ, arm, probabilities, replay,
                    on_start, on_application_event):
    captured = {'input_ids': ids.detach().cpu().clone()}
    connection.reset()
    entered = 0
    finished = False
    failure = None
    handle = None
    tail = TailReplay(model, replay)

    def hook(module, args):
        nonlocal entered
        entered += 1
        if entered != 1:
            raise ValueError('Repeated writer insertion')
        hidden = args[0]
        captured['hidden_before'] = hidden.detach().cpu().clone()
        try:
            returned = connection.apply(hidden, arm, organ, probabilities, on_application_event)
            return (returned, *args[1:]) if connection.last_info['patched'] else None
        finally:
            captured['hidden_after'] = hidden.detach().cpu().clone()
            captured.update(connection.last_capture)

    try:
        # This hook must precede the block20 observation: that observation sees
        # the actual post-writer input consumed by the native residual path.
        handle = model.model.layers[20].register_forward_pre_hook(hook)
        with tail:
            on_start()
            with torch.no_grad():
                logits = model(input_ids=ids, use_cache=False, logits_to_keep=1,
                               return_dict=True).logits[0, -1]
            finished = True
            captured['full_logits'] = logits.detach().cpu().clone()
            if entered != 1:
                raise ValueError('Writer insertion not entered exactly once')
    except BaseException as exc:
        failure = exc
    finally:
        if handle is not None:
            handle.remove()
        captured.update(tail.capture)
    info = dict(connection.last_info, forward_completed=finished, hook_entries=entered,
        tail_entries=tail.entries, tail_sites=tail.sites, tail_observations=tail.observations,
        residual_multipliers=tail.residual_multipliers)
    return captured, info, failure, tail


def validate(values, info, arm, ids, tail, legacy):
    tail.validate()
    tail_names = set(tail.capture)
    core = {k: v for k, v in values.items() if k not in tail_names}
    # Reuse the original validator without mislabelling a replay vector uniform.
    if arm in ('D', 'S1'):
        expected = {'input_ids', 'hidden_before', 'hidden_after', 'returned', 'full_logits',
                    'probabilities_cpu', 'probabilities', 'centered', 'delta32', 'delta_host'}
        if set(core) != expected:
            raise ValueError('Probability replay capture inventory differs')
        shapes = dict(input_ids=(1, len(ids)), hidden_before=(1, len(ids), 1024),
            hidden_after=(1, len(ids), 1024), returned=(1, len(ids), 1024),
            full_logits=(49155,), probabilities_cpu=(8,), probabilities=(8,),
            centered=(8,), delta32=(1024,), delta_host=(1024,))
        for name, shape in shapes.items():
            dtype = torch.int64 if name == 'input_ids' else (
                torch.float32 if name in ('probabilities_cpu', 'probabilities', 'centered', 'delta32') else torch.bfloat16)
            if core[name].dtype != dtype or tuple(core[name].shape) != shape:
                raise ValueError('Replay tensor shape/dtype differs: ' + name)
        if core['input_ids'].tolist() != [ids] or raw(core['hidden_before']) != raw(core['hidden_after']):
            raise ValueError('Replay input mutated')
        if raw(core['returned'][:, :-1]) != raw(core['hidden_before'][:, :-1]):
            raise ValueError('Replay writer changed nonfinal rows')
        if raw(core['probabilities_cpu']) != raw(core['probabilities']):
            raise ValueError('Replay probability bytes differ')
        if any(info[k] for k in ('reader_entered', 'reader_completed', 'organ_entered', 'organ_completed')):
            raise ValueError('Replay reexecuted upstream components')
        if not all(info[k] for k in ('writer_entered', 'writer_completed', 'patched')):
            raise ValueError('Replay writer incomplete')
    else:
        legacy.validate_capture(core, 'main' if arm == 'W' else 'uniform', ids, info)
    if arm == 'W' and info['resolved'] is not True:
        raise ValueError('Unresolved W reader: no fixed probability for the factorial')
    if not info['forward_completed'] or info['hook_entries'] != 1:
        raise ValueError('Incomplete host call')
    for value in values.values():
        finite = np.isfinite(value).all() if isinstance(value, np.ndarray) else bool(torch.isfinite(value).all())
        if not finite:
            raise ValueError('Nonfinite retained call')
    if raw(values['b20_residual_input']) != raw(values['returned'][:, -1:]):
        raise ValueError('Native tail did not consume writer return')
    for i in BLOCKS[:-1]:
        if raw(values[f'b{i}_after_moe']) != raw(values[f'b{i+1}_residual_input']):
            raise ValueError('Native tail layer linkage differs')
    if raw(values['b23_after_moe']) != raw(values['final_residual'][:, -1:]):
        raise ValueError('Final native residual linkage differs')


def compare(values, info, arm, previous, entries):
    comparisons = {}
    if arm != 'B':
        baseline, baseline_info = previous['B']
        comparisons['same_boundary_as_B'] = raw(values['hidden_before']) == raw(baseline['hidden_before'])
        comparisons['same_nonfinal_tail_as_B'] = all(
            x['nonfinal_sha256'] == baseline_info['tail_observations'][name]['nonfinal_sha256']
            for name, x in info['tail_observations'].items())
    if arm in ('D', 'S1'):
        written = previous['W'][0]
        comparisons['same_written_operands_as_W'] = all(raw(values[n]) == raw(written[n]) for n in (
            'probabilities_cpu', 'probabilities', 'centered', 'delta32', 'delta_host', 'returned'))
    source = REPLAY[arm]
    if source is not None:
        comparisons['exact_replayed_rows'] = all(
            raw(values[n + '_returned_final']) == raw(previous[source][0][n + '_actual_final']) for n in SITES)
    if arm in ('S0', 'S1'):
        comparisons['exact_full_logits_sham'] = raw(values['full_logits']) == raw(previous[source][0]['full_logits'])
        comparisons['exact_final_residual_sham'] = raw(values['final_residual']) == raw(previous[source][0]['final_residual'])
    return comparisons


def run_calls(modules, connection, contexts, schedule, input_tensors, directory, plan_sha,
              expected_identity, legacy, event, sample, guard, counts):
    (directory / 'calls').mkdir()
    previous = {}
    entries = {}
    active_cell = None
    reader_before = legacy.reader_hash(connection.original.reader_arrays)
    for active in schedule:
        arm = active['arm']
        if arm not in ARMS or arm != ARMS[len(previous)]:
            raise ValueError('Incomplete/out-of-order factorial cell')
        if arm == 'B':
            active_cell = active['cell_id']
        if active['cell_id'] != active_cell:
            raise ValueError('Factorial cell changed before completion')
        if legacy.identity(modules) != expected_identity or legacy.reader_hash(connection.original.reader_arrays) != reader_before:
            raise ValueError('Precall frozen ownership changed')
        context = contexts[active['context_id']]
        before = sample('before:' + active['id'])
        guard(before)

        def start():
            if counts['forward_attempts'] >= 576:
                raise ValueError('Host attempt ceiling')
            counts['forward_attempts'] += 1
            event('forward_started', **active)

        def application(name):
            prefix, suffix = name.rsplit('_', 1)
            if prefix not in ('reader', 'organ', 'writer') or suffix not in ('started', 'finished'):
                raise ValueError('Unexpected component event')
            key = prefix + ('_attempts' if suffix == 'started' else '_finished')
            counts[key] += 1
            if counts[key] > {'reader': 96, 'organ': 96, 'writer': 576}[prefix]:
                raise ValueError('Component ceiling')
            event(name, **active)

        source = REPLAY[arm]
        replay = replay_rows(previous[source][0]) if source else None
        p = previous['W'][0]['probabilities_cpu'] if arm in ('D', 'S1') else None
        values, info, failure, tail = collect_forward(modules['host'], input_tensors[context['id']],
            connection, modules[active['world_id']] if arm == 'W' else None, arm, p, replay, start, application)
        if info['forward_completed']:
            counts['forward_finished'] += 1
            try:
                event('forward_finished', **active)
            except BaseException as exc:
                if failure is None:
                    failure = exc
        links = dict(replay_source_id=entries[source]['id'] if source else None,
                     probability_source_id=entries['W']['id'] if arm in ('D', 'S1') else (active['id'] if arm == 'W' else None))
        # Includes failed current tensors before finite/control/resource checks.
        paths = legacy.retain(directory, 'calls/' + active['id'], values,
                              dict(**active, plan_sha256=plan_sha, **info, **links))
        after = None
        try:
            after = sample('after:' + active['id'])
        except BaseException as exc:
            if failure is None:
                failure = exc
        row = dict(**active, **paths, **info, **links, resources_before=before,
                   resources_after=after, controls_pass=False, comparisons={}, error=None)
        if failure is None:
            try:
                validate(values, info, arm, context['input_ids'], tail, legacy)
                row['comparisons'] = compare(values, info, arm, previous, entries)
                if not all(row['comparisons'].values()):
                    raise ValueError('Exact paired control failed: ' + str(row['comparisons']))
                guard(after)
                if legacy.identity(modules) != expected_identity or legacy.reader_hash(connection.original.reader_arrays) != reader_before:
                    raise ValueError('Postcall frozen ownership changed')
                row['controls_pass'] = True
            except BaseException as exc:
                failure = exc
        if failure is not None:
            row['error'] = type(failure).__name__ + ': ' + str(failure)
        legacy.append(directory / 'calls.jsonl', row)
        event('forward_saved', **active)
        if failure is not None:
            raise failure
        previous[arm] = (values, info)
        entries[arm] = active
        if arm == 'S1':
            previous = {}
            entries = {}
            active_cell = None
    if previous:
        raise ValueError('Truncated factorial cell')


def main(deadline_utc):
    import protocol as p
    plan = p.verify()
    plan_sha = p.digest(p.OUT / 'plan.json')
    started = p.read(p.OUT / 'STARTED.json')
    if (started['owner_pid'] != os.getppid() or started['plan_sha256'] != plan_sha
            or started['deadline_utc'] != deadline_utc):
        raise ValueError('Original owner binding differs')
    os.kill(os.getppid(), 0)
    if any((p.OUT / name).exists() for name in ('WORKER_STARTED.json', 'COLLECTED.json', 'STOPPED.json', 'COMPLETE.json')):
        raise ValueError('Worker already attempted or terminal')
    deadline = datetime.fromisoformat(deadline_utc)
    if deadline.tzinfo is None:
        raise ValueError('Deadline timezone absent')
    p.create(p.OUT / 'WORKER_STARTED.json', dict(at_utc=p.now(), worker_pid=os.getpid(),
        owner_pid=os.getppid(), plan_sha256=plan_sha, deadline_utc=deadline_utc))
    legacy = p.load_legacy('worker')
    modules = {}
    before_identity = None
    states_before = None
    reader_before = None
    arrays = None
    counts = initial_counts()
    active = None
    start_time = time.monotonic()
    resources = []

    def event(name, **fields):
        legacy.append(p.OUT / 'worker-events.jsonl', dict(at_utc=p.now(), event=name, **fields))

    def sample(stage):
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if platform.system() != 'Darwin':
            rss *= 1024
        value = dict(stage=stage, elapsed_seconds=time.monotonic()-start_time,
            rss_high_water_bytes=int(rss), mps_driver_bytes=int(torch.mps.driver_allocated_memory()),
            archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file()))
        resources.append(value)
        event('resources', **value)
        return value

    def guard(value):
        if os.getppid() != started['owner_pid']:
            raise RuntimeError('Original owner disappeared')
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError('Fixed owner deadline expired')
        for field, limit in (('rss_high_water_bytes', 'max_rss_bytes'),
                             ('mps_driver_bytes', 'max_mps_driver_bytes'), ('archive_bytes', 'max_archive_bytes')):
            if value[field] > p.SETTINGS[limit]:
                raise RuntimeError('Fixed resource ceiling exceeded: ' + field)

    def terminated(signum, frame):
        raise SystemExit(128 + signum)

    previous_signal = signal.signal(signal.SIGTERM, terminated)
    try:
        event('worker_started', worker_pid=os.getpid(), owner_pid=os.getppid(), deadline_utc=deadline_utc)
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError('Deadline before loading')
        import transformers
        from transformers import AutoModelForCausalLM
        from transformers.models.granitemoe import modeling_granitemoe
        if (platform.python_version(), torch.__version__, transformers.__version__, np.__version__) != ('3.12.14', '2.8.0', '4.56.2', '2.3.3'):
            raise ValueError('Pinned runtime differs')
        if not torch.backends.mps.is_available() or p.digest(inspect.getfile(modeling_granitemoe)) != plan['installed_model_source_sha256']:
            raise ValueError('Pinned native implementation differs')
        torch.set_num_threads(4)
        if torch.get_num_threads() != 4:
            raise ValueError('Thread count differs')
        guard(sample('before_loading'))
        cache_before = p.validate_model_files(plan)
        p.create(p.OUT / 'MODEL_CACHE_BEFORE.json', cache_before)
        reader_module = p.load_legacy('reader')
        writer_module = p.load_legacy('writer')
        organ_module = p.load_legacy('organ')
        assembly = p.load_legacy('assembly')
        rd, wd = plan['reader_artifact'], plan['writer_artifact']
        arrays = legacy.load_reader(p.ROOT / rd['path'], p.ROOT / rd['metadata_path'], rd)
        writer = legacy.load_writer(p.ROOT / wd['path'], p.ROOT / wd['metadata_path'], wd,
            writer_module.OutcomeWriter()).to('mps').eval()
        organs = {name: legacy.load_organ(p.ROOT / d['path'], d, organ_module.EnergyOrgan()).eval()
                  for name, d in plan['organ_artifacts'].items()}
        host = AutoModelForCausalLM.from_pretrained(p.ROOT / plan['model_path'], local_files_only=True,
            torch_dtype=torch.bfloat16, attn_implementation='eager').to('mps').eval()
        modules = dict(host=host, writer=writer, **organs)
        before_identity = legacy.identity(modules)
        if any(before_identity['hooks'].values()) or not all(all(v.values()) for v in before_identity['grad_none'].values()):
            raise ValueError('Preexisting hooks or gradients')
        if len(before_identity['requires_grad']['host']) != 218 or len(host.model.layers) != 24:
            raise ValueError('Native architecture differs')
        host.config.use_cache = False
        if host.config.logits_scaling != 6:
            raise ValueError('Native logit scaling differs')
        for module in modules.values():
            for parameter in module.parameters():
                parameter.requires_grad_(False)
        during = legacy.identity(modules)
        states_before = {k: legacy.state_hash(m) for k, m in modules.items()}
        reader_before = legacy.reader_hash(arrays)
        if len(states_before['host']) != 219 or states_before['host'] != plan['expected_host_state']:
            raise ValueError('Host state differs')
        if states_before['writer'] != wd['member_sha256'] or any(states_before[k] != plan['organ_artifacts'][k]['state_sha256'] for k in organs):
            raise ValueError('Frozen auxiliary state differs')
        legacy.retain(p.OUT, 'reader-initial', arrays, dict(plan_sha256=plan_sha))
        for name, module in modules.items():
            if name != 'host':
                legacy.retain(p.OUT, name + '-initial', dict(module.state_dict()), dict(plan_sha256=plan_sha))
        connection = Connection(assembly.LiveEnergyConnection(arrays, reader_module.apply_reader, reader_module.decisions, writer))
        contexts = {c['id']: c for c in plan['contexts']}
        if len(contexts) != 24 or len(plan['schedule']) != 576:
            raise ValueError('Fixed panel differs')
        ids = {name: torch.tensor([c['input_ids']], dtype=torch.int64, device='mps') for name, c in contexts.items()}
        guard(sample('loaded'))

        def tracked_event(name, **fields):
            nonlocal active
            if name == 'forward_started':
                active = dict(fields)
            event(name, **fields)

        run_calls(modules, connection, contexts, plan['schedule'], ids, p.OUT, plan_sha,
                  during, legacy, tracked_event, sample, guard, counts)
        expected = initial_counts()
        expected.update(forward_attempts=576, forward_finished=576, reader_attempts=96,
            reader_finished=96, organ_attempts=96, organ_finished=96, writer_attempts=576, writer_finished=576)
        if counts != expected:
            raise ValueError('Complete operation counts differ')
        states_after = {k: legacy.state_hash(m) for k, m in modules.items()}
        reader_after = legacy.reader_hash(arrays)
        if states_before != states_after or reader_before != reader_after:
            raise ValueError('Frozen parameters changed')
        legacy.retain(p.OUT, 'reader-final', arrays, dict(plan_sha256=plan_sha))
        for name, module in modules.items():
            if name != 'host':
                legacy.retain(p.OUT, name + '-final', dict(module.state_dict()), dict(plan_sha256=plan_sha))
        cache_after = p.validate_model_files(plan)
        p.create(p.OUT / 'MODEL_CACHE_AFTER.json', cache_after)
        after = legacy.restore(modules, before_identity)
        checks = dict(ownership_restored=after == before_identity, states_unchanged=states_before == states_after,
            reader_unchanged=reader_before == reader_after, cache_unchanged=cache_before == cache_after,
            exact_counts=counts == expected)
        if not all(checks.values()):
            raise ValueError('Terminal frozen identity failure')
        guard(sample('complete'))
        p.create(p.OUT / 'WORKER_COMPLETE.json', dict(status='WORKER_COMPLETED', at_utc=p.now(),
            plan_sha256=plan_sha, counts=counts, states_before=states_before, states_after=states_after,
            reader_state_before=reader_before, reader_state_after=reader_after,
            identities_before=before_identity, identities_during=during, identities_after=after,
            checks=checks, resource_samples=resources, elapsed_seconds=time.monotonic()-start_time,
            analytical_fits=0, backwards=0, optimizer_steps=0, provider_calls=0, generated_tokens=0))
        event('worker_completed', counts=counts)
        exclusions = set(plan['collection_exclusions'])
        inventory = {str(f.relative_to(p.OUT)): p.digest(f) for f in sorted(p.OUT.rglob('*'))
                     if f.is_file() and str(f.relative_to(p.OUT)) not in exclusions}
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError('Deadline during collection hashing')
        p.create(p.OUT / 'COLLECTED.json', dict(at_utc=p.now(), plan_sha256=plan_sha, counts=counts,
            all_controls_pass=True, artifact_sha256=inventory))
    except BaseException as exc:
        cleanup = None
        cleanup_error = None
        failure_states = None
        failure_state_error = None
        if modules:
            try:
                failure_states = {k: legacy.state_hash(m) for k, m in modules.items()}
            except BaseException as err:
                failure_state_error = repr(err)
        if modules and before_identity is not None:
            try:
                cleanup = legacy.restore(modules, before_identity)
            except BaseException as err:
                cleanup_error = repr(err)
        reason = type(exc).__name__ + ': ' + str(exc)
        try:
            event('worker_failed', counts=counts, reason=reason)
        finally:
            p.create(p.OUT / 'WORKER_FAILURE.json', dict(at_utc=p.now(), plan_sha256=plan_sha,
                counts=counts, active_schedule_entry=active, reason=reason, identities_before=before_identity,
                cleanup_identities=cleanup, cleanup_error=cleanup_error, states_before=states_before,
                available_failure_states=failure_states, failure_state_error=failure_state_error,
                reader_state_before=reader_before, retry_allowed=False))
        raise
    finally:
        signal.signal(signal.SIGTERM, previous_signal)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--deadline-utc', required=True)
    main(parser.parse_args().deadline_utc)
