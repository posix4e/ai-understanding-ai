"""Raw-first audit of the fixed six-arm exposed-panel tail intervention.

No primary worker/tail/assembly imports, host calls or fits. Hash-bound older
numerical checkers are reused; the writer checker shares this audit author's
provenance, so reuse is not an independently authored duplicate of that math.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
import numpy as np
sys.dont_write_bytecode = True
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1'
PREP=OUT.with_name(OUT.name+'_PREPARATION')
ENERGY_CORE=('research/moe-mechanisms/organ_live_energy_v1/audit.py',
'b955f0e74d426860a5306099ebf8ac7ef1a1ad4b5042e09424fd5a8d997c5c6e')
ARMS=('B','W','S0','D','T','S1')
WORLD_IDS=tuple(f'dev{i:02d}' for i in range(4))
LAYERS=(20,21,22,23)
SITES=tuple(f'b{i}_{kind}' for i in LAYERS for kind in ('attn','moe'))
VOCAB=49155
TIMEOUT=900
MEMORY_LIMIT=10*1024**3
ARCHIVE_LIMIT=1024**3
EXCLUSIONS={'owner-events.jsonl','resource-monitor.jsonl','worker.log','independent_audit.log','COLLECTED.json'}
_CORES={}
class AuditError(ValueError): pass

def require(ok,message):
    if not ok: raise AuditError(message)
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def exact(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()
def raw_hash(value):return hashlib.sha256(np.asarray(value).tobytes()).hexdigest()
def safe(directory,name):
    p=Path(name);require(type(name) is str and name and not p.is_absolute() and '..' not in p.parts,'Unsafe artifact path')
    p=Path(directory)/p
    require(p.is_file() and p.resolve().is_relative_to(Path(directory).resolve()),'Missing/escaping artifact')
    return p
def jsonl(path):
    lines=Path(path).read_text().splitlines();require(all(x.strip() for x in lines),'Blank journal row')
    return [json.loads(x) for x in lines]
def core():
    relative,sha=ENERGY_CORE;path=ROOT/relative
    require(digest(path)==sha,'Frozen numerical core changed')
    if relative not in _CORES:
        spec=importlib.util.spec_from_file_location('tail_independent_energy_core',path)
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);_CORES[relative]=m
    return _CORES[relative]
def strict_choice(scores):
    x=np.asarray(scores);require(x.shape==(8,) and np.isfinite(x).all(),'Invalid eight scores')
    best=max(map(float,x));w=[i for i,v in enumerate(x) if float(v)==best]
    return dict(winners=w,unique=len(w)==1,winner=w[0] if len(w)==1 else None)
def target_margin(scores,target):
    require(type(target) is int and 0<=target<8,'Invalid fixed target')
    strict_choice(scores)
    return float(scores[target])-max(float(v) for i,v in enumerate(scores) if i!=target)
def bf16(x):
    """Finite FP32 -> round-to-nearest-even BF16, returned decoded FP32."""
    a=np.asarray(x,dtype=np.float32);require(np.isfinite(a).all(),'Nonfinite BF16 operand')
    u=a.view(np.uint32);bits=(u+np.uint32(0x7fff)+((u>>16)&1))&np.uint32(0xffff0000)
    y=bits.view(np.float32);require(np.isfinite(y).all(),'BF16 overflow')
    return y

def expected_schedule(contexts):
    require(len(contexts)==24,'Expected all24 contexts');rows=[]
    for i,c in enumerate(contexts):
        s,a=divmod(i,3)
        require(c['id']==f's{s}-a{a}' and c['state']==s and c['action']==a,'Context canonical order differs')
        for wid in WORLD_IDS:
            for arm in ARMS:
                n=len(rows);rows.append(dict(index=n,id=f'{n:04d}',cell_id=f'{c["id"]}-{wid}',context_id=c['id'],world_id=wid,arm=arm))
    return rows

def counts():
    return dict(forward_attempts=576,forward_finished=576,reader_attempts=96,reader_finished=96,
        organ_attempts=96,organ_finished=96,writer_attempts=576,writer_finished=576,
        analytical_fits=0,backward_attempts=0,backward_finished=0,optimizer_attempts=0,optimizer_steps=0)

def schedule_fields(row,entry):
    require(all(type(row.get(k)) is type(v) and row[k]==v for k,v in entry.items()),'Schedule metadata differs')

def check_residual_chain(values,multiplier):
    """Eight actual BF16 multiply/add operations, with rounding at both steps.

    This verifies saved actual operands, not a linear effect decomposition and
    not an independent reexecution of attention/MoE/norm/head.
    """
    require(type(multiplier) is dict and set(multiplier)=={str(i) for i in LAYERS} and all(type(x) in (int,float) and math.isfinite(x) for x in multiplier.values()),'Invalid native residual multipliers')
    previous=values['returned'][:,-1:,:]
    for layer in LAYERS:
        before=values[f'b{layer}_residual_input']
        require(exact(before,previous),'Residual input lost displacement or layer linkage')
        for branch,after_name in (('attn','after_attention'),('moe','after_moe')):
            write=values[f'b{layer}_{branch}_returned_final']
            scaled=bf16(np.multiply(write,np.float32(multiplier[str(layer)]),dtype=np.float32))
            expected=bf16(np.add(before,scaled,dtype=np.float32))
            after=values[f'b{layer}_{after_name}']
            require(exact(after,expected),'Native BF16 residual multiplication/addition differs')
            before=after
        previous=before
    require(exact(previous,values['final_residual'][:,-1:,:]),'Final residual linkage differs')
    return dict(additions=8,multiplications=8,exact=True)

def check_cell(captures,target):
    """Pure six-arm identities and margins; no filtering by categorical effect."""
    require(tuple(captures)==ARMS,'Incomplete or reordered six-arm cell')
    base=captures['B'];written=captures['W']
    for arm,v in captures.items():
        require(exact(v['hidden_before'],base['hidden_before']),'Prewriter upstream hidden differs across arms')
        require(exact(v['hidden_after'],v['hidden_before']),'Same-call original hidden mutated')
        require(exact(v['returned'][:,:-1],v['hidden_before'][:,:-1]),'Writer changed nonfinal positions')
        source=written if arm in ('W','D','S1') else base
        for name in ('probabilities_cpu','probabilities','centered','delta32','delta_host','returned'):
            require(exact(v[name],source[name]),'Probability/writer delta replay differs: '+arm+'/'+name)
        require(exact(v['probabilities_cpu'],v['probabilities']),'Probability device-copy bits differ')
        if arm not in ('B','W'):
            donor=base if arm in ('S0','D') else written
            for site in SITES:
                require(exact(v[site+'_returned_final'],donor[site+'_actual_final']),'Wrong tail replay donor bytes')
        else:
            for site in SITES:require(exact(v[site+'_returned_final'],v[site+'_actual_final']),'Natural branch unexpectedly patched')
    require(exact(base['probabilities_cpu'],np.full(8,.125,dtype=np.float32)),'Uniform writer code differs')
    for a,b in (('B','S0'),('W','S1')):
        require(exact(captures[a]['full_logits'],captures[b]['full_logits']),'Full vocabulary replay sham differs')
        require(exact(captures[a]['final_residual'],captures[b]['final_residual']),'Final residual sham differs')
    out={arm:dict(scores=v['scores'].tolist(),choice=strict_choice(v['scores']),
        margin=target_margin(v['scores'],target),correct=strict_choice(v['scores'])['winner']==target) for arm,v in captures.items()}
    m={a:r['margin'] for a,r in out.items()}
    effects=dict(direct=m['D']-m['S0'],tail=m['T']-m['S0'],total=m['S1']-m['S0'],
        interaction=m['S1']-m['D']-m['T']+m['S0'],natural=m['W']-m['B'])
    return dict(target=target,arms=out,margin_contrasts=effects)

def summarize(cells,replication):
    require(len(cells)==96 and len({x['cell_id'] for x in cells})==96,'Expected all96 cells')
    require(len(replication)==96,'Incomplete replication checks')
    keys=('reader_query_identity','energy_probability_world_identity','written_supplied_answer')
    admission={k:sum(r[k] is True for r in replication) for k in keys}
    groups={a:dict(n=96,correct=sum(c['arms'][a]['correct'] for c in cells),
        ties=sum(not c['arms'][a]['choice']['unique'] for c in cells),
        mean_target_margin=math.fsum(c['arms'][a]['margin'] for c in cells)/96) for a in ARMS}
    effects={k:dict(n=96,mean=math.fsum(c['margin_contrasts'][k] for c in cells)/96,
        minimum=min(c['margin_contrasts'][k] for c in cells),maximum=max(c['margin_contrasts'][k] for c in cells))
        for k in ('direct','tail','total','interaction','natural')}
    return dict(implementation_pass=True,baseline_replication_pass=all(v==96 for v in admission.values()),
        replication=admission,groups=groups,margin_contrasts=effects,cells=cells,
        categorical_changes={a:dict(vs_W=sum(c['arms'][a]['choice']!=c['arms']['W']['choice'] for c in cells),
            correct_W_lost=sum(c['arms']['W']['correct'] and not c['arms'][a]['correct'] for c in cells)) for a in ('D','T')})

def call_shapes(entry,length):
    e=core()
    result={'input_ids':('torch.int64',(1,length)),
        **{k:('torch.bfloat16',(1,length,1024)) for k in ('hidden_before','hidden_after','returned','final_residual')},
        'full_logits':('torch.bfloat16',(VOCAB,)),
        **{k:('torch.float32',s) for k,s in dict(probabilities_cpu=(8,),probabilities=(8,),centered=(8,),delta32=(1024,)).items()},
        'delta_host':('torch.bfloat16',(1024,))}
    for i in LAYERS:
        for suffix in ('residual_input','after_attention','after_moe'):result[f'b{i}_{suffix}']=('torch.bfloat16',(1,1,1024))
    for site in SITES:
        for suffix in ('actual_final','returned_final'):result[site+'_'+suffix]=('torch.bfloat16',(1,1,1024))
    if entry['arm']=='W':
        result.update({('reader_centered' if k=='centered' else k):('numpy.float64',s) for k,s in e.READER_OUTPUT_SHAPES.items()})
        result.update({k:('torch.float32',s) for k,s in e.ENERGY_SHAPES.items()})
    return result


def check_tail_metadata(row,values,length,multipliers):
    expected=set(SITES)|{f'b{i}_{s}' for i in LAYERS for s in ('residual_input','after_attention','after_moe')}|{'final_residual'}
    require(row['tail_entries']==dict.fromkeys(expected,1),'Tail hook coverage differs')
    require(set(row['tail_sites'])==set(SITES),'Branch site inventory differs')
    for site,meta in row['tail_sites'].items():
        require(meta['shape']==[1,length,1024] and meta['dtype']=='torch.bfloat16' and meta['device'] in ('mps','mps:0'),'Tail shape/dtype/device differs')
        require(meta['nonfinal_before_sha256']==meta['nonfinal_after_sha256'] and
            type(meta['nonfinal_before_sha256']) is str and len(meta['nonfinal_before_sha256'])==64,'Branch nonfinal rows changed')
        require(meta['auxiliary_before']==meta['auxiliary_after'] and meta['auxiliary_objects_preserved'] is True,'Branch auxiliary changed')
        require(meta['replayed'] is (row['arm'] not in ('B','W')),'Branch replay mode differs')
    require(row['residual_multipliers']==multipliers,'Native residual multiplier differs')
    observed={f'b{i}_{s}' for i in LAYERS for s in ('residual_input','after_attention','after_moe')}|{'final_residual'}
    require(set(row['tail_observations'])==observed,'Residual observation inventory differs')
    for name,meta in row['tail_observations'].items():
        require(meta['shape']==[1,length,1024] and meta['dtype']=='torch.bfloat16' and meta['device'] in ('mps','mps:0'),'Residual observation type differs')
        require(type(meta['nonfinal_sha256']) is str and len(meta['nonfinal_sha256'])==64,'Missing residual nonfinal hash')
    # Full final residual is saved; its nonfinal digest must agree with observer metadata.
    raw=((values['final_residual'][:,:-1].view(np.uint32)>>16).astype('<u2')).tobytes()
    require(hashlib.sha256(raw).hexdigest()==row['tail_observations']['final_residual']['nonfinal_sha256'],'Final nonfinal hash differs')
    return check_residual_chain(values,multipliers)


def load_call(directory,row,entry,context,plan_sha):
    stem='calls/'+entry['id'];require(row['forward_path']==stem+'.npz' and row['forward_metadata_path']==stem+'.json','Call path differs')
    paths=[safe(directory,row[k]) for k in ('forward_path','forward_metadata_path')]
    require([digest(p) for p in paths]==[row['forward_sha256'],row['forward_metadata_sha256']],'Call artifact changed')
    values,raw,meta=core().load_bundle(*paths,call_shapes(entry,len(context['input_ids'])))
    schedule_fields(row,entry);schedule_fields(meta,entry)
    fields=(*core().INFO_KEYS,'tail_entries','tail_sites','tail_observations','residual_multipliers','replay_source_id','probability_source_id')
    require(meta['plan_sha256']==plan_sha and all(row[k]==meta[k] for k in fields),'Raw metadata binding differs')
    require(row['forward_completed'] is True and row['hook_entries']==1 and type(row['hook_entries']) is int and
        row['controls_pass'] is True and row['error'] is None,'Incomplete or failed call')
    routed=entry['arm']=='W'
    require(all(row[k] is routed for k in ('reader_entered','reader_completed','organ_entered','organ_completed')),'Reader/organ counts differ')
    require(all(row[k] is True for k in ('writer_entered','writer_completed','patched')),'Writer operation missing')
    require(row['unresolved_reason'] is None,'Unresolved route in complete panel')
    if routed:
        require(row['resolved'] is True and all(row[k]==dict.fromkeys(('linear1','linear2','linear3','gelu1','gelu2'),1)
            for k in ('energy_hook_entries','energy_hook_finished')),'Incomplete live energy trace')
    else:
        require(all(row[k] is None for k in ('decisions','resolved','predicted_state','predicted_action','predicted_address',
            'query_state','query_action','energy_hook_entries','energy_hook_finished')),'Non-W arm has a fabricated query')
    require(exact(values['input_ids'],np.array([context['input_ids']],dtype=np.int64)),'Input tokens differ')
    return values,raw,meta


def expected_events(schedule):
    result=[('worker_started',None),('resources','before_loading'),('resources','loaded')]
    for entry in schedule:
        result += [('resources','before:'+entry['id']),('forward_started',entry)]
        if entry['arm']=='W':result += [(x,entry) for x in ('reader_started','reader_finished','organ_started','organ_finished')]
        result += [(x,entry) for x in ('writer_started','writer_finished','forward_finished')]
        result += [('resources','after:'+entry['id']),('forward_saved',entry)]
    return result+[('resources','complete'),('worker_completed',None)]


def validate_events(events,schedule,complete,started,worker):
    expected=expected_events(schedule);require(len(events)==len(expected),'Event count differs')
    resources=[];previous=-math.inf;last=None
    for event,(kind,payload) in zip(events,expected):
        require(event['event']==kind,'Event order differs')
        at=datetime.fromisoformat(event['at_utc'])
        require(at.tzinfo is not None and (last is None or at>=last),'Event timestamp differs');last=at
        if started:require(datetime.fromisoformat(started['at_utc'])<=at<datetime.fromisoformat(started['deadline_utc']),'Event outside deadline')
        if kind=='resources':
            require(event['stage']==payload,'Resource stage differs')
            sample={k:v for k,v in event.items() if k not in ('at_utc','event')}
            require(set(sample)=={'stage','elapsed_seconds','rss_high_water_bytes','mps_driver_bytes','archive_bytes'},'Resource schema differs')
            elapsed=sample['elapsed_seconds'];require(type(elapsed) in (float,int) and math.isfinite(elapsed) and previous<=elapsed<=TIMEOUT,'Invalid sampled time')
            previous=elapsed
            require(all(type(sample[k]) is int and 0<=sample[k]<=MEMORY_LIMIT for k in ('rss_high_water_bytes','mps_driver_bytes')),'Sampled memory ceiling exceeded')
            require(type(sample['archive_bytes']) is int and 0<=sample['archive_bytes']<=ARCHIVE_LIMIT,'Worker archive ceiling exceeded')
            resources.append(sample)
        elif isinstance(payload,dict):schedule_fields(event,payload)
        elif kind=='worker_completed':require(event['counts']==counts(),'Completed journal counters differ')
        elif kind=='worker_started' and worker:require(all(event[k]==worker[k] for k in ('worker_pid','owner_pid','deadline_utc')),'Worker actor differs')
    require(len(resources)==1155 and resources==complete['resource_samples'],'Resource receipt differs')
    return resources


def validate_ownership(complete,plan,hashes):
    # Same inventories as the independently reviewed assembly; duration is the
    # new900-second contract, never silently inherited from the old600 limit.
    require(complete['status']=='WORKER_COMPLETED' and complete['counts']==counts() and all(type(x) is int for x in complete['counts'].values()),'Worker incomplete/counts differ')
    reader=core().bound_core(core().READER_CORE);host_names=reader.expected_state_keys()
    expected={'host':plan['expected_host_state'],'writer':hashes['writer'],**{w:hashes[w] for w in WORLD_IDS}}
    require(set(plan['expected_host_state'])==host_names and complete['states_before']==complete['states_after']==expected,'Frozen states changed')
    require(complete['reader_state_before']==complete['reader_state_after']==hashes['reader']==plan['reader_artifact']['member_sha256'],'Reader changed')
    require(complete['checks']==dict(ownership_restored=True,states_unchanged=True,reader_unchanged=True,cache_unchanged=True,exact_counts=True),'Worker checks differ')
    before,during,after=[complete['identities_'+p] for p in ('before','during','after')]
    require(before==after,'Ownership not restored')
    owners={'host','writer',*WORLD_IDS};names={'host':host_names-{'lm_head.weight'},'writer':{'weight'},**{w:set(core().ORGAN_SHAPES) for w in WORLD_IDS}}
    for identity in (before,during,after):
        require(set(identity)=={'requires_grad','training','hooks','forward_methods','grad_none','host_config'},'Identity inventory differs')
        for k in set(identity)-{'host_config'}:require(set(identity[k])==owners,'Component identity coverage differs')
        for owner in owners:
            require(set(identity['requires_grad'][owner])==set(identity['grad_none'][owner])==names[owner],'Parameter coverage differs')
            require(all(type(x) is bool for x in identity['requires_grad'][owner].values()) and all(x is True for x in identity['grad_none'][owner].values()),'Gradient ownership differs')
            require(identity['hooks'][owner]=={},'Leaked/foreign hook')
            require(identity['training'][owner] and identity['training'][owner]==before['training'][owner] and all(x is False for x in identity['training'][owner].values()),'Eval modes differ')
            require(set(identity['forward_methods'][owner])==set(identity['training'][owner]) and identity['forward_methods'][owner]==before['forward_methods'][owner],'Method identity changed')
        require(identity['host_config']['logits_scaling']==6,'Logit scale changed')
    require(all(x is False for group in during['requires_grad'].values() for x in group.values()),'Trainable parameter during collection')
    cfg=dict(before['host_config']);cfg['use_cache']=False;require(during['host_config']==cfg,'Configured host differs')
    for k in ('analytical_fits','backwards','optimizer_steps','provider_calls','generated_tokens'):require(type(complete[k]) is int and complete[k]==0,'Forbidden operation')
    require(type(complete['elapsed_seconds']) in (float,int) and math.isfinite(complete['elapsed_seconds']) and 0<=complete['elapsed_seconds']<=TIMEOUT,'Worker duration invalid')
    return {str(i):during['host_config']['residual_multiplier'] for i in LAYERS}


def audit_records(directory,plan,plan_sha,parameters,hashes,started=None,worker=None):
    directory=Path(directory);schedule=expected_schedule(plan['contexts']);require(schedule==plan['schedule'],'Schedule differs')
    calls=jsonl(directory/'calls.jsonl');require(len(calls)==576,'Incomplete call panel')
    for row,entry in zip(calls,schedule):schedule_fields(row,entry)
    complete=read(directory/'WORKER_COMPLETE.json');require(complete['plan_sha256']==plan_sha,'Worker plan differs')
    multipliers=validate_ownership(complete,plan,hashes)
    resources=validate_events(jsonl(directory/'worker-events.jsonl'),schedule,complete,started,worker)
    samples={r['stage']:r for r in resources};contexts={c['id']:c for c in plan['contexts']};tables={w['id']:w['transitions'] for w in plan['worlds']}
    ec=core();rc=ec.bound_core(ec.READER_CORE);wc=ec.bound_core(ec.WRITER_CORE)
    cells=[];replication=[];arithmetic=[];current={};current_rows={};details=None
    for row,entry in zip(calls,schedule):
        context=contexts[entry['context_id']];arm=entry['arm']
        require(row['resources_before']==samples['before:'+entry['id']] and row['resources_after']==samples['after:'+entry['id']],'Call resource binding differs')
        values,raw,meta=load_call(directory,row,entry,context,plan_sha)
        replay={'S0':'B','D':'B','T':'W','S1':'W'}.get(arm)
        require(row['replay_source_id']==(None if replay is None else current_rows[replay]['id']),'Tail source ID differs')
        require(row['probability_source_id']==(current_rows['W']['id'] if arm in ('D','S1') else (entry['id'] if arm=='W' else None)),'Probability source ID differs')
        check=dict(id=entry['id'],residual=check_tail_metadata(row,values,len(context['input_ids']),multipliers),reader=None,energy=None)
        writer_values={k:values[k] for k in ('probabilities','centered','delta32','delta_host','returned')}
        writer_values.update(hidden=values['hidden_before'],writer_weight=parameters['writer']['weight'])
        check['writer']=wc.audit_writer_math(writer_values)
        if arm=='W':
            saved={k:values['reader_centered' if k=='centered' else k] for k in ec.READER_OUTPUT_SHAPES}
            checked=rc.check_application(values['hidden_before'][0,-1],parameters['reader'],saved);decisions=checked['choices']
            require(row['decisions']==decisions,'Reader decision metadata differs')
            route=ec.route_from_decisions(decisions,'main');require(route['resolved'],'Unresolved reader cannot define paired P')
            for k,v in dict(predicted_state=route['state'],predicted_action=route['action'],predicted_address=route['address'],query_state=route['state'],query_action=route['action']).items():
                require(type(row[k]) is int and row[k]==v,'Reader/query identity differs')
            energy=ec.check_energy(values,parameters[entry['world_id']],route['state'],route['action'])
            target=tables[entry['world_id']][context['action']][context['state']]
            details=dict(cell_id=entry['cell_id'],reader_query_identity=route['state']==context['state'] and route['action']==context['action'],
                energy_probability_world_identity=bool(energy['unique_and_equal'] and energy['probability_choice']['winner']==target),
                written_supplied_answer=strict_choice(values['full_logits'][plan['label_ids']])['winner']==energy['probability_choice']['winner'] and energy['probability_choice']['unique'],
                supplied_target=energy['probability_choice']['winner'],registered_target=target,route=route,energy_choices={k:energy[k] for k in ('energy_choice','probability_choice','unique_and_equal')})
            check['reader']=checked;check['energy']=energy
        comparisons={}
        if arm!='B':
            comparisons['same_boundary_as_B']=exact(values['hidden_before'],current['B']['hidden_before'])
            comparisons['same_nonfinal_tail_as_B']=all(v['nonfinal_sha256']==current_rows['B']['tail_observations'][k]['nonfinal_sha256'] for k,v in row['tail_observations'].items())
        if arm in ('D','S1'):
            comparisons['same_written_operands_as_W']=all(exact(values[k],current['W'][k]) for k in ('probabilities_cpu','probabilities','centered','delta32','delta_host','returned'))
        if replay:
            comparisons['exact_replayed_rows']=all(exact(values[k+'_returned_final'],current[replay][k+'_actual_final']) for k in SITES)
        if arm in ('S0','S1'):
            comparisons['exact_full_logits_sham']=exact(values['full_logits'],current[replay]['full_logits'])
            comparisons['exact_final_residual_sham']=exact(values['final_residual'],current[replay]['final_residual'])
        require(all(comparisons.values()) and row['comparisons']==comparisons,'Exact comparison claims differ')
        values['scores']=values['full_logits'][plan['label_ids']]
        current[arm]=values;current_rows[arm]=row;arithmetic.append(check)
        if arm=='S1':
            require(details is not None,'Missing W replication record')
            cell=check_cell(current,details['registered_target']);cell.update(cell_id=entry['cell_id'],context_id=entry['context_id'],world_id=entry['world_id'],supplied_target=details['supplied_target'])
            cells.append(cell);replication.append(details);current={};current_rows={};details=None
    require(not current,'Trailing incomplete cell')
    report=summarize(cells,replication)
    report.update(counts=counts(),replication_rows=replication,arithmetic=arithmetic,
        exact_full_vocabulary_shams=192,resources=dict(samples=len(resources),maximum_rss_bytes=max(x['rss_high_water_bytes'] for x in resources),
        maximum_sampled_mps_driver_bytes=max(x['mps_driver_bytes'] for x in resources),worker_elapsed_seconds=complete['elapsed_seconds']))
    report['interpretation_allowed']=report['implementation_pass'] and report['baseline_replication_pass']
    return report

SETTINGS=dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',
    host_forwards=576,reader_applications=96,organ_forwards_max=96,writer_forwards_max=576,
    contexts=24,worlds=4,cells=96,analytical_fits=0,backwards=0,optimizer_steps=0,
    provider_calls=0,generated_tokens=0,insertion_layer=20,tail_layers=[20,21,22,23],
    position='last',dtype='bfloat16',device='mps',reader_dtype='float64',reader_device='cpu',
    organ_dtype='float32',organ_device='cpu',organ_query_shape=[8,19],temperature=1.0,
    writer_dtype='float32',writer_device='mps',threads=4,batch_size=1,attention='eager',
    cache=False,logits_scaling=6,timeout_seconds=900,max_rss_bytes=MEMORY_LIMIT,
    max_mps_driver_bytes=MEMORY_LIMIT,max_archive_bytes=ARCHIVE_LIMIT,max_control_logit_error=0.0,
    rms_atol=1e-12,rms_rtol=1e-12,feature_atol=1e-12,feature_rtol=1e-12,
    score_atol=1e-9,score_rtol=1e-8,gelu_atol=2e-6,gelu_rtol=2e-6,softmax_atol=2e-7,
    dot_gamma_multiplier=4,dot_reference_u_multiplier=2,dot_tiny_multiplier=8)
ORIGINAL_PLAN_SHA='53c52779e8c843e528af04acb1084d531e6f59ab000526ea937571bb100137ce'
ORIGINAL_COMPLETE_SHA='e28f55a426529491229637dd7978b240d2daf1f370c10c2474a72657a050f98f'
ORIGINAL_AUDIT_SHA='c8ad327da021752c3f1d5f9a550fa6b7c073aa9bc3da3d44ec1610f91c9644ce'

def verify_plan(directory,root=ROOT):
    directory,root=Path(directory),Path(root);plan=read(directory/'plan.json');sha=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==sha,'Registration changed')
    require(plan['settings']==SETTINGS and set(plan['collection_exclusions'])==EXCLUSIONS,'Settings/exclusions differ')
    require(plan['schedule']==expected_schedule(plan['contexts']),'Fixed576 schedule differs')
    old=root/'outputs/moe-mechanisms/ORGAN_LIVE_ENERGY_V1'
    require(digest(old/'plan.json')==ORIGINAL_PLAN_SHA and digest(old/'COMPLETE.json')==ORIGINAL_COMPLETE_SHA and digest(old/'INDEPENDENT_AUDIT.json')==ORIGINAL_AUDIT_SHA,'Assembly predecessor changed')
    op=read(old/'plan.json');done=read(old/'COMPLETE.json');oa=read(old/'INDEPENDENT_AUDIT.json')
    require(done['status']=='LIVE_ENERGY_ASSEMBLY_PASSED' and done['gate_pass'] is True and oa['status']=='PASS' and oa['gate_pass'] is True and not (old/'STOPPED.json').exists(),'Assembly prerequisite not passed')
    require(done['plan_sha256']==oa['plan_sha256']==ORIGINAL_PLAN_SHA and done['report_sha256']==oa['report_sha256']==digest(old/'REPORT.json') and done['independent_audit_sha256']==ORIGINAL_AUDIT_SHA and oa['collected_sha256']==digest(old/'COLLECTED.json'),'Assembly provenance chain differs')
    keep=('reader_artifact','writer_artifact','organ_artifacts','expected_host_state','model_path','model_cache_repository','model_files','installed_model_source_sha256','contexts','worlds','label_ids')
    require(all(plan[k]==op[k] for k in keep),'Frozen scientific inputs differ')
    names=('protocol.py','tail.py','worker.py','audit.py','owner.py','launch.py','test_tail_worker.py','test_audit.py','test_protocol.py')
    require(set(plan['source_sha256'])==set(op['source_sha256'])|{'research/moe-mechanisms/organ_tail_attribution_v1/'+n for n in names},'Source inventory differs')
    require(all(plan['source_sha256'][n]==h for n,h in op['source_sha256'].items()),'Frozen predecessor source binding differs')
    for field in ('source_sha256','lineage_sha256'):
        require(type(plan[field]) is dict and plan[field],'Missing source/lineage inventory')
        for name,h in plan[field].items():
            require(digest(safe(root,name))==h,'Live source/lineage differs: '+name)
            if field=='source_sha256':require(digest(safe(directory/'sources',name))==h,'Archived source differs')
    require(plan['label_ids']==list(range(34,42)),'Candidate label order differs')
    for c in plan['contexts']:
        ids=c['input_ids'];require(type(ids) is list and 1<=len(ids)<=48 and ids[0]==0 and all(type(x) is int and 0<=x<VOCAB for x in ids),'Invalid input token list')
    require([w['id'] for w in plan['worlds']]==list(WORLD_IDS),'World identity order differs')
    for w in plan['worlds']:
        require(len(w['transitions'])==3 and all(type(r) is list and len(r)==8 and all(type(x) is int for x in r) and sorted(r)==list(range(8)) for r in w['transitions']),'World table invalid')
    return plan,sha


def check_inventory(directory,collected,late=()):
    directory=Path(directory)
    actual={str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file() and str(p.relative_to(directory)) not in EXCLUSIONS|set(late)}
    require(actual==set(collected['artifact_sha256']),'Collected inventory differs')
    for name,h in collected['artifact_sha256'].items():require(digest(safe(directory,name))==h,'Collected artifact changed')
    require(sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())<=ARCHIVE_LIMIT,'Archive cap exceeded')


def owner_guard(directory,plan_sha):
    directory=Path(directory);started=read(directory/'STARTED.json');worker=read(directory/'WORKER_STARTED.json')
    require(started['owner_pid']==os.getppid() and core().is_alive(started['owner_pid']),'Not original live owner')
    require(started['plan_sha256']==worker['plan_sha256']==plan_sha and worker['owner_pid']==started['owner_pid'],'Actor/plan binding differs')
    begin,deadline=[datetime.fromisoformat(started[k]) for k in ('at_utc','deadline_utc')]
    require(begin.tzinfo is not None and deadline.tzinfo is not None and (deadline-begin).total_seconds()==TIMEOUT and datetime.now(timezone.utc)<deadline,'Invalid/expired900-second deadline')
    require(worker['deadline_utc']==started['deadline_utc'],'Worker deadline changed')
    until=time.monotonic()+2
    while True:
        try:events=jsonl(directory/'owner-events.jsonl')
        except (FileNotFoundError,json.JSONDecodeError):events=[]
        if len(events)>=3:break
        require(time.monotonic()<until and datetime.now(timezone.utc)<deadline,'Audit dispatch handshake absent');time.sleep(.02)
    require(len(events)==3 and [(x['event'],x['stage']) for x in events]==[('started','worker'),('exit','worker'),('started','independent_audit')],'Owner lifecycle differs')
    require(events[0]['pid']==events[1]['pid']==worker['worker_pid'] and events[1]['returncode']==0 and events[1]['process_group_absent'] is True and not core().is_alive(worker['worker_pid']) and events[2]['pid']==os.getpid(),'Worker not inactive/successful')
    try:os.killpg(worker['worker_pid'],0)
    except ProcessLookupError:pass
    else:raise AuditError('Original worker process group survives')
    python=ROOT/'work/acquisition-representation-venv/bin/python'
    require(events[0]['command']==[str(python),str(HERE/'worker.py'),'--deadline-utc',started['deadline_utc']] and events[2]['command']==[str(python),str(HERE/'audit.py'),'--directory',str(directory)],'Dispatch commands differ')
    claim,launch=read(PREP/'LAUNCH_REQUESTED.json'),read(PREP/'LAUNCH_PID.json');command=[str(python),'-u',str(HERE/'owner.py'),'run']
    require(claim['command']==launch['command']==command and claim['plan_sha256']==launch['plan_sha256']==plan_sha and claim['nonce']==launch['nonce']==started['launch_nonce'] and launch['owner_pid']==started['owner_pid'],'Original launch claim differs')
    require(os.getpgid(started['owner_pid'])==os.getsid(started['owner_pid'])==started['owner_pid'],'Detached owner identity differs')
    times=[datetime.fromisoformat(x['at_utc']) for x in events]
    require(begin<=times[0]<=times[1]<=times[2]<deadline,'Owner chronology differs')
    # Owner monitor remains live. Validate a complete-line prefix; never bind its
    # changing file hash as though final. Parent closure binds its final bytes.
    lines=(directory/'resource-monitor.jsonl').read_text().splitlines(keepends=True)
    records=[json.loads(x) for x in lines if x.endswith('\n')]
    require(records and any(r['stage']=='worker' for r in records),'No owner resource samples')
    previous=-math.inf
    for r in records:
        require(r['stage'] in ('worker','independent_audit') and r['pid']==(worker['worker_pid'] if r['stage']=='worker' else os.getpid()),'Monitor actor differs')
        require(type(r['elapsed_seconds']) in (int,float) and math.isfinite(r['elapsed_seconds']) and previous<=r['elapsed_seconds']<TIMEOUT,'Owner sample time invalid');previous=r['elapsed_seconds']
        require(type(r['child_tree_rss_bytes']) is int and 0<=r['child_tree_rss_bytes']<=MEMORY_LIMIT and type(r['archive_bytes']) is int and 0<=r['archive_bytes']<=ARCHIVE_LIMIT,'Owner resource cap exceeded')
    ws=[r for r in records if r['stage']=='worker'];exitrow=events[1]
    require(exitrow['samples']==len(ws) and exitrow['peak_child_tree_rss_bytes']==max(r['child_tree_rss_bytes'] for r in ws) and exitrow['peak_archive_bytes']==max(r['archive_bytes'] for r in ws),'Closed worker resource receipt differs')
    return started,worker,events,records


def preserve_invalid_publications(directory):
    preserved={}
    for name in ('REPORT.json','INDEPENDENT_AUDIT.json'):
        path=Path(directory)/name
        if path.exists():
            invalid=Path(directory)/('INVALID_'+name)
            require(not invalid.exists(),'Invalid publication archive already exists')
            preserved[name]=dict(sha256=digest(path),preserved_as=invalid.name)
            path.rename(invalid)
    return preserved


def audit(directory=OUT):
    directory=Path(directory);require(directory.resolve()==OUT.resolve(),'Wrong study directory')
    forbidden=('STOPPED.json','WORKER_FAILURE.json','COMPLETE.json','AUDIT_STARTED.json','AUDIT_FAILURE.json','REPORT.json','INDEPENDENT_AUDIT.json')
    require(not any((directory/n).exists() for n in forbidden),'Stopped/already audited/terminal study; no retry')
    core().runtime_guard();plan,plan_sha=verify_plan(directory)
    started,worker,owner_events,monitor=owner_guard(directory,plan_sha)
    collected=read(directory/'COLLECTED.json');require(collected['plan_sha256']==plan_sha and collected['all_controls_pass'] is True and collected['counts']==counts(),'Incomplete collection')
    check_inventory(directory,collected)
    create(directory/'AUDIT_STARTED.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,pid=os.getpid(),owner_pid=os.getppid(),audit_code_sha256=digest(__file__),rerun_allowed=False))
    try:
        core().validate_lineage(plan)
        cache=core().bound_core(core().READER_CORE).validate_cache(plan)
        require(read(directory/'MODEL_CACHE_BEFORE.json')==read(directory/'MODEL_CACHE_AFTER.json')==cache,'Model cache changed')
        params,hashes=core().load_fixed_parameters(directory,plan,plan_sha)
        report=audit_records(directory,plan,plan_sha,params,hashes,started,worker)
        check_inventory(directory,collected,late=('AUDIT_STARTED.json',));verify_plan(directory)
        require(datetime.now(timezone.utc)<datetime.fromisoformat(started['deadline_utc']),'Deadline expired before publication')
        report.update(status='TAIL_ATTRIBUTION_REPORTED',plan_sha256=plan_sha,at_utc=datetime.now(timezone.utc).isoformat(),
            model_calls_by_auditor=0,fits_by_auditor=0,provider_calls_by_auditor=0,
            limits=['All96 exposed cells over24 language contexts and four known worlds; no independent population sample or new-world generalization.',
                'Scores are eight-candidate rankings; no generated-answer competence, planning, energy advantage or novelty claim.',
                'Fixed margins use registered requested-world targets. Only after full replication do these equal unique supplied probability targets.',
                'D/T are controlled hybrid branch replays. Native norms/head/residual arithmetic remain; tail writes themselves may encode the answer.',
                'Finite margin contrasts describe interventions and their interaction; no additive mechanism, natural mediation, p-value or normalized causal fraction is inferred.',
                'The raw audit is separate code. Frozen reader/energy/writer numerical cores are reused; writer-core authorship overlaps this auditor.',
                'Native host attention/MoE/norm/head are not independently reexecuted. Captured BF16 multiply/add chains and replay byte identities are checked exactly.',
                'Resource maxima are sampled, not continuous peak guarantees. Original owner remains responsible for closure and final monitor/log hashes.'])
        create(directory/'REPORT.json',report)
        receipt=dict(status='PASS',implementation_pass=True,baseline_replication_pass=report['baseline_replication_pass'],
            interpretation_allowed=report['interpretation_allowed'],plan_sha256=plan_sha,report_sha256=digest(directory/'REPORT.json'),
            audit_code_sha256=digest(__file__),collected_sha256=digest(directory/'COLLECTED.json'),counts=counts(),
            input_sha256={**collected['artifact_sha256'],'COLLECTED.json':digest(directory/'COLLECTED.json')},
            owner_journal_prefix=owner_events,owner_resource_prefix=monitor,live_owner_logs_final_hash_not_claimed=True,
            model_calls=0,analytical_fits=0,provider_calls=0,gradient_updates=0)
        create(directory/'INDEPENDENT_AUDIT.json',receipt);return receipt
    except BaseException as exc:
        removed=preserve_invalid_publications(directory)
        create(directory/'AUDIT_FAILURE.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,reason=type(exc).__name__+': '+str(exc),
            preserved_invalid_publications=removed,rerun_allowed=False,partial_scientific_interpretation=False))
        raise

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,default=OUT)
    result=audit(parser.parse_args().directory)
    print(json.dumps({k:v for k,v in result.items() if k not in ('input_sha256','owner_journal_prefix','owner_resource_prefix')}),flush=True)
