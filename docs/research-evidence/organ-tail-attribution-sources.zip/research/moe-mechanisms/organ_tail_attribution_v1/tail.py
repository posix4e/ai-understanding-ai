"""Final-position branch replay, without changing native residual arithmetic.

No model loading, answer scoring, source selection or automatic execution.
"""
import hashlib
import torch

BLOCKS = (20, 21, 22, 23)
SITES = tuple(f'b{i}_{part}' for i in BLOCKS for part in ('attn', 'moe'))
ARMS = ('B', 'W', 'S0', 'D', 'T', 'S1')
REPLAY = dict(B=None, W=None, S0='B', D='B', T='W', S1='W')


def raw(value):
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def sha(value):
    return hashlib.sha256(raw(value)).hexdigest()


def tensor(value):
    if (not isinstance(value, torch.Tensor) or value.dtype != torch.bfloat16
            or value.ndim != 3 or value.shape[0] != 1 or value.shape[1] < 1
            or value.shape[2] != 1024 or value.requires_grad):
        raise ValueError('Expected frozen BF16[1,L,1024] tail tensor')
    return value


def auxiliary(value):
    """Describe only native tuple auxiliaries; preserve the actual objects."""
    if value is None:
        return None
    if isinstance(value, torch.Tensor):
        return dict(dtype=str(value.dtype), shape=list(value.shape), raw_sha256=sha(value))
    if isinstance(value, (tuple, list)):
        return [auxiliary(v) for v in value]
    raise TypeError('Unexpected native branch tuple auxiliary')


class TailReplay:
    def __init__(self, model, replay=None):
        self.model = model
        self.replay = replay
        self.capture = {}
        self.sites = {}
        self.observations = {}
        self.residual_multipliers = {}
        self.entries = {}
        self.handles = []

    def enter_once(self, name):
        self.entries[name] = self.entries.get(name, 0) + 1
        if self.entries[name] != 1:
            raise ValueError('Repeated tail observation: ' + name)

    def observe(self, name, value, full=False):
        self.enter_once(name)
        value = tensor(value)
        self.capture[name] = (value if full else value[:, -1:]).detach().cpu().clone()
        self.observations[name] = dict(shape=list(value.shape), dtype=str(value.dtype),
            device=str(value.device), nonfinal_sha256=sha(value[:, :-1]))

    def branch(self, name, output):
        self.enter_once(name)
        if not isinstance(output, tuple) or len(output) != 2:
            raise ValueError('Native branch must return its two-member tuple')
        actual = tensor(output[0])
        # Record the actual finite or nonfinite return before validating/replaying it.
        self.capture[name + '_actual_final'] = actual[:, -1:].detach().cpu().clone()
        before = sha(actual[:, :-1])
        aux_before = auxiliary(output[1:])
        returned = actual
        if self.replay is not None:
            source = tensor(self.replay[name])
            if tuple(source.shape) != (1, 1, 1024):
                raise ValueError('Replay must contain exactly one final row')
            source = source.to(device=actual.device, dtype=actual.dtype)
            if raw(source) != raw(self.replay[name]):
                raise ValueError('Replay transfer changed bytes')
            returned = torch.cat((actual[:, :-1], source), dim=1)
        result = output if self.replay is None else (returned, *output[1:])
        self.capture[name + '_returned_final'] = returned[:, -1:].detach().cpu().clone()
        after = sha(returned[:, :-1])
        aux_after = auxiliary(result[1:])
        self.sites[name] = dict(shape=list(actual.shape), dtype=str(actual.dtype),
            device=str(actual.device), nonfinal_before_sha256=before,
            nonfinal_after_sha256=after, auxiliary_before=aux_before,
            auxiliary_after=aux_after, auxiliary_objects_preserved=all(
                a is b for a, b in zip(output[1:], result[1:])),
            replayed=self.replay is not None)
        if before != after or aux_before != aux_after or not self.sites[name]['auxiliary_objects_preserved']:
            raise ValueError('Replay changed other rows or tuple auxiliary')
        return result if self.replay is not None else None

    def __enter__(self):
        if self.replay is not None and set(self.replay) != set(SITES):
            raise ValueError('Replay site inventory differs')
        try:
            for i in BLOCKS:
                block = self.model.model.layers[i]
                self.residual_multipliers[str(i)] = block.residual_multiplier
                self.handles.append(block.register_forward_pre_hook(
                    lambda m, a, n=f'b{i}_residual_input': self.observe(n, a[0])))
                self.handles.append(block.post_attention_layernorm.register_forward_pre_hook(
                    lambda m, a, n=f'b{i}_after_attention': self.observe(n, a[0])))
                self.handles.append(block.register_forward_hook(
                    lambda m, a, o, n=f'b{i}_after_moe': self.observe(n, o[0])))
                for part, module in (('attn', block.self_attn), ('moe', block.block_sparse_moe)):
                    self.handles.append(module.register_forward_hook(
                        lambda m, a, o, n=f'b{i}_{part}': self.branch(n, o)))
            self.handles.append(self.model.model.norm.register_forward_pre_hook(
                lambda m, a: self.observe('final_residual', a[0], full=True)))
            return self
        except BaseException:
            self.close()
            raise

    def close(self):
        for handle in reversed(self.handles):
            handle.remove()
        self.handles = []

    def __exit__(self, *exc):
        self.close()
        return False

    def validate(self):
        expected = set(SITES) | {'final_residual'} | {
            f'b{i}_{part}' for i in BLOCKS for part in ('residual_input', 'after_attention', 'after_moe')}
        if set(self.entries) != expected or any(v != 1 for v in self.entries.values()):
            raise ValueError('Incomplete native tail observations')
        if set(self.sites) != set(SITES):
            raise ValueError('Incomplete tail site metadata')
        for value in self.capture.values():
            if not bool(torch.isfinite(value).all()):
                raise ValueError('Nonfinite retained tail tensor')


def replay_rows(values):
    """Take the actual B/W branch returns, not externally supplied values."""
    return {name: values[name + '_actual_final'].detach().cpu().clone() for name in SITES}
