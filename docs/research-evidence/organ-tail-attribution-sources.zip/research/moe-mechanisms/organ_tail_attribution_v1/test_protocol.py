"""No model, archive arrays, tokenizer or registration in these tests."""
import unittest
from unittest.mock import Mock,patch
import protocol as p
from owner import validate_owner_receipt,terminate_and_reap


class ContractTests(unittest.TestCase):
    def test_complete_factorial_and_sources(self):
        contexts=[dict(id=f's{s}-a{a}',state=s,action=a,
                      prompt=f"World state {s}. Actions {'XYZ'[a]}. Next state:") for s in range(8) for a in range(3)]
        rows=p.schedule(contexts)
        self.assertEqual(len(rows),576)
        self.assertEqual(len({r['cell_id'] for r in rows}),96)
        for i in range(0,576,6):
            self.assertEqual([r['arm'] for r in rows[i:i+6]],['B','W','S0','D','T','S1'])
            self.assertEqual(len({r['cell_id'] for r in rows[i:i+6]}),1)
        contexts[0]['state']=1
        with self.assertRaises(ValueError):p.schedule(contexts)

    def test_owner_rejects_cross_claim(self):
        command=['bound','owner'];claim=dict(command=command,nonce='original',plan_sha256='plan')
        receipt=dict(claim,owner_pid=17)
        validate_owner_receipt(claim,receipt,command,'plan',17)
        for key,value in [('nonce','another'),('owner_pid',18),('plan_sha256','other')]:
            changed=dict(receipt);changed[key]=value
            with self.assertRaises(ValueError):validate_owner_receipt(claim,changed,command,'plan',17)

    def test_bound_paths(self):
        for name in ('../outside','/tmp/outside'):
            with self.assertRaises(ValueError):p.safe_path(p.OUT,name)

    def test_exited_leader_does_not_skip_descendant_cleanup(self):
        child=Mock(pid=1729);child.poll.return_value=0
        with patch('owner.group_members',side_effect=[[1730],[],[],[]]),patch('owner.os.killpg') as kill:
            terminate_and_reap(child)
        self.assertEqual(kill.call_count,1)
        self.assertEqual(kill.call_args.args[0],1729)


if __name__=='__main__':unittest.main()
