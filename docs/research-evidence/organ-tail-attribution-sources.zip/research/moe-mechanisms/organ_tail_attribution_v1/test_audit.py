"""Invented NumPy evidence only. Never loads a pretrained model or study arrays."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
spec=importlib.util.spec_from_file_location('tail_audit_under_test',Path(__file__).with_name('audit.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)


def values(arm='B',state=0,action=0,length=2):
    h=np.zeros((1,length,1024),np.float32);h[0,-1,state]=1;h[0,-1,8+action]=1
    v={k:h.copy() for k in ('hidden_before','hidden_after','returned','final_residual')}
    v.update(input_ids=np.array([[0,5]],np.int64),full_logits=np.zeros(a.VOCAB,np.float32),
        probabilities_cpu=np.full(8,.125,np.float32),probabilities=np.full(8,.125,np.float32),
        centered=np.zeros(8,np.float32),delta32=np.zeros(1024,np.float32),delta_host=np.zeros(1024,np.float32))
    for i in a.LAYERS:
        for suffix in ('residual_input','after_attention','after_moe'):v[f'b{i}_{suffix}']=h[:,-1:].copy()
    for site in a.SITES:
        for suffix in ('actual_final','returned_final'):v[site+'_'+suffix]=np.zeros((1,1,1024),np.float32)
    v['scores']=v['full_logits'][34:42].copy()
    return v


def six():
    panel={x:values(x) for x in a.ARMS}
    for arm in ('W','S1'):
        panel[arm]['full_logits'][34]=2;panel[arm]['scores'][0]=2
    panel['D']['full_logits'][35]=1;panel['D']['scores'][1]=1
    panel['T']['full_logits'][34]=1;panel['T']['scores'][0]=1
    return panel


def bundle(path,metadata,vals,shapes):
    stored={};meta={}
    for name,(dtype,shape) in shapes.items():
        value=np.asarray(vals[name]);assert value.shape==shape
        raw=((value.view(np.uint32)>>16).astype('<u2')).tobytes() if dtype=='torch.bfloat16' else value.tobytes()
        rk,vk=name+'__raw_uint8',name+'__value';stored[rk]=np.frombuffer(raw,np.uint8).copy();stored[vk]=value.copy()
        meta[name]=dict(dtype=dtype,shape=list(shape),raw_key=rk,value_key=vk,raw_sha256=a.hashlib.sha256(raw).hexdigest())
    with path.open('xb') as f:np.savez_compressed(f,**stored)
    a.create(path.with_suffix('.json'),dict(**metadata,tensors=meta))


class PureTests(unittest.TestCase):
    def test_ties_signed_zero_and_wrong_preserved(self):
        self.assertIsNone(a.strict_choice(np.zeros(8))['winner'])
        self.assertFalse(a.exact(np.array([0.],np.float32),np.array([-0.],np.float32)))
        x=six();r=a.check_cell(x,0)
        self.assertFalse(r['arms']['D']['correct']);self.assertTrue(r['arms']['T']['correct'])
        self.assertEqual(r['margin_contrasts'],dict(direct=-1.,tail=1.,total=2.,interaction=2.,natural=2.))
    def test_full_sham_corruption_rejected(self):
        x=six();x['S0']['full_logits'][300]=1
        with self.assertRaisesRegex(a.AuditError,'vocabulary'):a.check_cell(x,0)
    def test_source_row_corruption_rejected(self):
        x=six();x['D']['b23_moe_returned_final'][0,0,0]=1
        with self.assertRaisesRegex(a.AuditError,'donor'):a.check_cell(x,0)
    def test_written_delta_corruption_rejected(self):
        x=six();x['D']['delta_host'][0]=1
        with self.assertRaisesRegex(a.AuditError,'delta'):a.check_cell(x,0)
    def test_upstream_change_rejected(self):
        x=six();x['T']['hidden_before'][0,0,0]=1
        with self.assertRaisesRegex(a.AuditError,'upstream'):a.check_cell(x,0)
    def test_residual_chain_nontrivial_multiplier_and_rounds(self):
        v=values();mult=dict.fromkeys(map(str,a.LAYERS),.22);prev=v['returned'][:,-1:].copy()
        for i in a.LAYERS:
            v[f'b{i}_residual_input']=prev.copy()
            for branch,suffix in (('attn','after_attention'),('moe','after_moe')):
                w=a.bf16(np.linspace(-20,20,1024,dtype=np.float32).reshape(1,1,1024))
                v[f'b{i}_{branch}_returned_final']=w
                prev=a.bf16(prev+a.bf16(w*np.float32(.22)))
                v[f'b{i}_{suffix}']=prev.copy()
        v['final_residual'][:,-1:]=prev
        self.assertEqual(a.check_residual_chain(v,mult)['additions'],8)
        v['b21_after_attention'][0,0,3]+=1
        with self.assertRaisesRegex(a.AuditError,'addition'):a.check_residual_chain(v,mult)
    def test_delta_retention_required(self):
        v=values();v['returned'][0,-1,0]+=1
        with self.assertRaisesRegex(a.AuditError,'displacement'):a.check_residual_chain(v,dict.fromkeys(map(str,a.LAYERS),.22))
    def test_bf16_tie_round_even(self):
        x=np.array([1+2**-8,1+3*2**-8,-0.],np.float32)
        self.assertTrue(a.exact(a.bf16(x),np.array([1,1+2**-6,-0.],np.float32)))
    def test_all_negative_replication_not_structural(self):
        cells=[dict(cell_id=str(i),**a.check_cell(six(),0)) for i in range(96)]
        reps=[dict(reader_query_identity=True,energy_probability_world_identity=False,written_supplied_answer=False) for _ in cells]
        r=a.summarize(cells,reps);self.assertTrue(r['implementation_pass']);self.assertFalse(r['baseline_replication_pass'])
        self.assertEqual(r['groups']['D']['correct'],0);self.assertEqual(r['groups']['S0']['ties'],96)
    def test_no_partial_or_duplicate_cells(self):
        cells=[dict(cell_id='same',**a.check_cell(six(),0)) for _ in range(96)]
        with self.assertRaisesRegex(a.AuditError,'all96'):a.summarize(cells,[])
    def test_raw_bundle_mutation_and_dtype(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.npz';bundle(p,{}, {'x':np.array([-0.,1.],np.float32)}, {'x':('torch.bfloat16',(2,))})
            e=a.core();v,raw,_=e.load_bundle(p,p.with_suffix('.json'),{'x':('torch.bfloat16',(2,))})
            self.assertTrue(a.exact(v['x'],np.array([-0.,1.],np.float32)))
            m=a.read(p.with_suffix('.json'));m['tensors']['x']['raw_sha256']='0'*64;p.with_suffix('.json').write_text(json.dumps(m))
            with self.assertRaisesRegex(ValueError,'hash'):e.load_bundle(p,p.with_suffix('.json'),{'x':('torch.bfloat16',(2,))})
    def test_schedule_and_journal_exact_counts(self):
        contexts=[dict(id=f's{s}-a{act}',state=s,action=act) for s in range(8) for act in range(3)]
        schedule=a.expected_schedule(contexts);self.assertEqual(len(schedule),576)
        ev=a.expected_events(schedule);self.assertEqual(len(ev),4421)
        self.assertEqual(sum(x[0]=='resources' for x in ev),1155)
        self.assertEqual(sum(x[0]=='organ_started' for x in ev),96)
        self.assertEqual(sum(x[0]=='writer_started' for x in ev),576)
    def test_partial_publication_preserved_not_regraded(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);payload=b'{"incomplete":';(p/'REPORT.json').write_bytes(payload)
            result=a.preserve_invalid_publications(p)
            self.assertEqual((p/'INVALID_REPORT.json').read_bytes(),payload)
            self.assertEqual(result['REPORT.json']['sha256'],a.hashlib.sha256(payload).hexdigest())
            self.assertFalse((p/'REPORT.json').exists())
    def test_stopped_archive_rejected_before_numeric_loading(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'STOPPED.json').write_text('{}')
            with patch.object(a,'OUT',p),patch.object(a,'core') as numerical:
                with self.assertRaisesRegex(a.AuditError,'Stopped'):a.audit(p)
                numerical.assert_not_called()
    def test_positive_replication_is_not_effect_threshold(self):
        cells=[dict(cell_id=str(i),**a.check_cell(six(),0)) for i in range(96)]
        reps=[dict(reader_query_identity=True,energy_probability_world_identity=True,written_supplied_answer=True) for _ in cells]
        result=a.summarize(cells,reps)
        self.assertTrue(result['baseline_replication_pass'])
        self.assertEqual(result['groups']['D']['correct'],0)
        self.assertNotIn('gate_pass',result)
    def test_inventory_extra_file_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'x').write_text('x');manifest={'artifact_sha256':{'x':a.digest(p/'x')}}
            a.check_inventory(p,manifest);(p/'unexpected').write_text('z')
            with self.assertRaisesRegex(a.AuditError,'inventory'):a.check_inventory(p,manifest)


def fixture(directory):
    """Full576 raw calls, real old pure arithmetic, no primary imports or fits.

    Deliberately zero energy/writer weights create probability/host ties and a
    complete negative replication. Reader is a fixed hand-written identity map.
    """
    directory=Path(directory);(directory/'calls').mkdir()
    ec=a.core();rc=ec.bound_core(ec.READER_CORE)
    reader=dict(coefficients=np.zeros((1024,11),np.float64),x_mean=np.zeros(1024,np.float64),y_mean=np.zeros(11,np.float64))
    reader['coefficients'][:11]=np.eye(11)
    params={'reader':reader,'writer':{'weight':np.zeros((1024,8),np.float32)}}
    for wid in a.WORLD_IDS:params[wid]={k:np.zeros(v,np.float32) for k,v in ec.ORGAN_SHAPES.items()}
    hashes={owner:{k:a.raw_hash(v) for k,v in x.items()} for owner,x in params.items()}
    hostnames=rc.expected_state_keys();hosts={k:'f'*64 for k in hostnames}
    contexts=[dict(id=f's{s}-a{act}',state=s,action=act,input_ids=[0,5]) for s in range(8) for act in range(3)]
    plan=dict(contexts=contexts,schedule=a.expected_schedule(contexts),worlds=[dict(id=w,transitions=[list(range(8))]*3) for w in a.WORLD_IDS],label_ids=list(range(34,42)),expected_host_state=hosts,reader_artifact={'member_sha256':hashes['reader']})
    keys={'host':hostnames-{'lm_head.weight'},'writer':{'weight'},**{w:set(ec.ORGAN_SHAPES) for w in a.WORLD_IDS}}
    identity=dict(requires_grad={o:dict.fromkeys(n,False) for o,n in keys.items()},training={o:{'':False} for o in keys},
        hooks={o:{} for o in keys},forward_methods={o:{'':[False,123]} for o in keys},grad_none={o:dict.fromkeys(n,True) for o,n in keys.items()},
        host_config=dict(logits_scaling=6,use_cache=False,residual_multiplier=.22))
    states={'host':hosts,**{w:hashes[w] for w in keys if w!='host'}}
    complete=dict(status='WORKER_COMPLETED',counts=a.counts(),plan_sha256='invented',states_before=states,states_after=states,
        reader_state_before=hashes['reader'],reader_state_after=hashes['reader'],checks=dict(ownership_restored=True,states_unchanged=True,reader_unchanged=True,cache_unchanged=True,exact_counts=True),
        identities_before=identity,identities_during=identity,identities_after=identity,elapsed_seconds=8.,analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)
    events=[];resources={};time=0.
    for kind,payload in a.expected_events(plan['schedule']):
        row=dict(event=kind,at_utc='2026-01-01T00:00:01+00:00')
        if kind=='resources':
            time+=.001;sample=dict(stage=payload,elapsed_seconds=time,rss_high_water_bytes=1,mps_driver_bytes=1,archive_bytes=1)
            row.update(sample);resources[payload]=sample
        elif isinstance(payload,dict):row.update(payload)
        elif kind=='worker_completed':row['counts']=a.counts()
        events.append(row)
    complete['resource_samples']=list(resources.values())
    (directory/'worker-events.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in events));a.create(directory/'WORKER_COMPLETE.json',complete)
    rows=[]
    for entry in plan['schedule']:
        index=entry['index'];s,act=divmod(index//24,3);arm=entry['arm'];v=values(arm,s,act);v.pop('scores')
        query=a.core().canonical_queries(s,act)
        if arm=='W':
            derived=rc.reference_reader(v['hidden_before'][0,-1],**reader)
            v.update({('reader_centered' if k=='centered' else k):x for k,x in derived.items()})
            v.update({k:np.zeros(shape,np.float32) for k,shape in ec.ENERGY_SHAPES.items()})
            v['query']=query;v['linear1_input']=query.copy();v['probabilities_cpu']=np.full(8,.125,np.float32)
        else:derived=None
        observations={n:dict(shape=[1,2,1024],dtype='torch.bfloat16',device='mps:0',nonfinal_sha256=a.hashlib.sha256(bytes(2048)).hexdigest()) for n in [f'b{i}_{suf}' for i in a.LAYERS for suf in ('residual_input','after_attention','after_moe')]+['final_residual']}
        sites={n:dict(shape=[1,2,1024],dtype='torch.bfloat16',device='mps:0',nonfinal_before_sha256='a'*64,nonfinal_after_sha256='a'*64,auxiliary_before=[None],auxiliary_after=[None],auxiliary_objects_preserved=True,replayed=arm not in ('B','W')) for n in a.SITES}
        routed=arm=='W';row=dict(**entry,forward_completed=True,hook_entries=1,reader_entered=routed,reader_completed=routed,organ_entered=routed,organ_completed=routed,
            decisions=rc.choices(derived) if routed else None,resolved=True if routed else None,predicted_state=s if routed else None,predicted_action=act if routed else None,predicted_address=3*s+act if routed else None,
            query_state=s if routed else None,query_action=act if routed else None,writer_entered=True,writer_completed=True,patched=True,unresolved_reason=None,
            energy_hook_entries=dict.fromkeys(('linear1','linear2','linear3','gelu1','gelu2'),1) if routed else None,
            energy_hook_finished=dict.fromkeys(('linear1','linear2','linear3','gelu1','gelu2'),1) if routed else None,
            tail_entries=dict.fromkeys(set(a.SITES)|set(observations),1),tail_sites=sites,tail_observations=observations,residual_multipliers=dict.fromkeys(map(str,a.LAYERS),.22))
        base=index-index%6;source={'S0':base,'D':base,'T':base+1,'S1':base+1}.get(arm)
        row.update(replay_source_id=None if source is None else f'{source:04d}',probability_source_id=f'{base+1:04d}' if arm in ('W','D','S1') else None)
        path=directory/'calls'/f'{index:04d}.npz';bundle(path,dict(**row,plan_sha256='invented'),v,a.call_shapes(entry,2))
        comps={}
        if arm!='B':comps.update(same_boundary_as_B=True,same_nonfinal_tail_as_B=True)
        if arm in ('D','S1'):comps['same_written_operands_as_W']=True
        if source is not None:comps['exact_replayed_rows']=True
        if arm in ('S0','S1'):comps.update(exact_full_logits_sham=True,exact_final_residual_sham=True)
        row.update(forward_path=str(path.relative_to(directory)),forward_sha256=a.digest(path),forward_metadata_path=str(path.with_suffix('.json').relative_to(directory)),forward_metadata_sha256=a.digest(path.with_suffix('.json')),
            controls_pass=True,error=None,comparisons=comps,resources_before=resources['before:'+entry['id']],resources_after=resources['after:'+entry['id']])
        rows.append(row)
    (directory/'calls.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in rows))
    return plan,params,hashes


class CompleteFixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.path=Path(cls.temp.name);cls.plan,cls.params,cls.hashes=fixture(cls.path)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_full576_valid_negative_all_old_arithmetic(self):
        report=a.audit_records(self.path,self.plan,'invented',self.params,self.hashes)
        self.assertTrue(report['implementation_pass']);self.assertFalse(report['baseline_replication_pass'])
        self.assertEqual(report['replication']['reader_query_identity'],96)
        self.assertEqual(report['replication']['energy_probability_world_identity'],0)
        self.assertEqual(report['exact_full_vocabulary_shams'],192)
        self.assertEqual(len(report['cells']),96);self.assertEqual(len(report['arithmetic']),576)
        self.assertTrue(all(report['groups'][x]['ties']==96 for x in a.ARMS))
    def test_missing_call_before_arrays(self):
        path=self.path/'calls.jsonl';old=path.read_text();path.write_text('\n'.join(old.splitlines()[:-1])+'\n')
        try:
            with self.assertRaisesRegex(a.AuditError,'Incomplete call'):a.audit_records(self.path,self.plan,'invented',self.params,self.hashes)
        finally:path.write_text(old)
    def test_corrupt_replay_source_before_arithmetic(self):
        path=self.path/'calls.jsonl';old=path.read_text();rows=[json.loads(x) for x in old.splitlines()];rows[3]['replay_source_id']='0001';path.write_text(''.join(json.dumps(x)+'\n' for x in rows))
        try:
            with self.assertRaisesRegex(a.AuditError,'metadata binding'):a.audit_records(self.path,self.plan,'invented',self.params,self.hashes)
        finally:path.write_text(old)

if __name__=='__main__':unittest.main()
