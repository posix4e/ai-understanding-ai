"""Detach the registered V2 owner from this short-lived launcher.

The real CLI has no arbitrary command option: it launches only the sibling
development_run.py run. This addresses launcher lifetime, not arbitrary owner
crashes, machine loss, or termination of every process in an external job.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def create(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def process_identity(pid):
    """Read-only OS identity. lstart has ps precision, not a kernel nonce."""
    try:
        result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "pid=", "-o", "ppid=",
                                 "-o", "pgid=", "-o", "stat=", "-o", "lstart=", "-o", "command="],
                                capture_output=True, text=True, check=True, timeout=2)
        fields = result.stdout.strip().split(None, 9)
        if len(fields) != 10:
            return None
        return {"pid": int(fields[0]), "ppid": int(fields[1]), "pgid": int(fields[2]),
                "state": fields[3], "start_time_ps": " ".join(fields[4:9]),
                "command_ps": fields[9], "session_id": os.getsid(pid)}
    except (OSError, subprocess.SubprocessError, ValueError):
        return None


def command_payload_matches(command, observed):
    """Keep the exact script/argument suffix across a Python argv0 re-exec.

    macOS framework Python can replace its venv executable display during
    startup. PID/start/group/session remain bound separately. Preserve both
    executable-path observations rather than mistaking that for a new owner.
    """
    return len(command) > 1 and observed.endswith(" " + " ".join(command[1:]))


def _launch_owner(command, root, output, preparation, plan_sha256, timeout_seconds, handshake_seconds=5.0):
    """Generic private primitive; invented-process tests supply toy commands."""
    root, output, preparation = map(Path, (root, output, preparation))
    if not command or not 0 < handshake_seconds <= 10 or timeout_seconds <= 0:
        raise ValueError("Invalid fixed launch bounds")
    if any((output / name).exists() for name in ("STARTED.json", "COLLECTED.json", "COMPLETE.json", "STOPPED.json")):
        raise ValueError("Study already started or terminal; never launch again")
    preparation.mkdir(parents=True, exist_ok=True)
    if (preparation / "LAUNCH_REQUESTED.json").exists():
        raise FileExistsError("A launch was already claimed; inspect it, never retry")
    nonce = uuid.uuid4().hex
    requested_at = datetime.now(timezone.utc)
    claim = {"status": "LAUNCH_REQUESTED", "nonce": nonce, "at_utc": requested_at.isoformat(),
             "launcher_pid": os.getpid(), "launcher_identity": process_identity(os.getpid()),
             "command": command, "cwd": str(root.resolve()), "plan_sha256": plan_sha256,
             "owner_timeout_seconds": timeout_seconds,
             "request_based_deadline_utc": (requested_at + timedelta(seconds=timeout_seconds)).isoformat(),
             "owner_deadline_note": "Actual owner deadline starts at its STARTED receipt; confirmed separately.",
             "launcher_source_sha256": digest(__file__), "retry_allowed": False}
    # Claim is deliberately before Popen. Even an uncertain dispatch is retained.
    create(preparation / "LAUNCH_REQUESTED.json", claim)
    process = None
    try:
        log = preparation / "DETACHED_OWNER.log"
        with log.open("xb", buffering=0) as stream:
            process = subprocess.Popen(command, cwd=root, stdin=subprocess.DEVNULL,
                                       stdout=stream, stderr=subprocess.STDOUT,
                                       close_fds=True, start_new_session=True)
        identity = process_identity(process.pid)
        create(preparation / "LAUNCH_PID.json", {"at_utc": now(), "nonce": nonce,
               "plan_sha256": plan_sha256, "owner_pid": process.pid, "identity": identity,
               "command": command, "log": str(log.resolve())})
        if identity is None or identity["pgid"] != process.pid or identity["session_id"] != process.pid:
            raise RuntimeError("Detached owner identity not confirmed; inspect original dispatch")
        deadline = time.monotonic() + handshake_seconds
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError(f"Owner exited during handshake: {process.returncode}")
            started = output / "STARTED.json"
            if started.exists():
                try:
                    raw = started.read_bytes()
                    receipt = json.loads(raw)
                except json.JSONDecodeError:
                    time.sleep(0.05)
                    continue
                if receipt.get("owner_pid") != process.pid or receipt.get("plan_sha256") != plan_sha256:
                    raise RuntimeError("Owner STARTED binding differs")
                current = process_identity(process.pid)
                if (current is None or "Z" in current["state"] or any(
                        current[k] != identity[k] for k in ("pid", "pgid", "session_id", "start_time_ps"))):
                    raise RuntimeError("Owner identity changed during handshake")
                if not all(command_payload_matches(command, observed["command_ps"]) for observed in (identity, current)):
                    raise RuntimeError("Owner script/argument payload changed during handshake")
                owner_start = datetime.fromisoformat(receipt["at_utc"])
                if owner_start.tzinfo is None:
                    raise ValueError("Owner STARTED time must include timezone")
                confirmed = {"status": "DETACHED_OWNER_CONFIRMED", "at_utc": now(), "nonce": nonce,
                             "plan_sha256": plan_sha256, "owner_pid": process.pid,
                             "owner_identity": current, "owner_initial_identity": identity, "command": command,
                             "python_executable_display_changed": identity["command_ps"] != current["command_ps"],
                             "exact_command_payload_verified": True,
                             "started_sha256": hashlib.sha256(raw).hexdigest(),
                             "owner_started_at_utc": receipt["at_utc"],
                             "owner_deadline_utc": (owner_start + timedelta(seconds=timeout_seconds)).isoformat(),
                             "owner_timeout_seconds": timeout_seconds, "log": str(log.resolve()),
                             "meaning": "Owner live and detached; not worker completion or scientific success.",
                             "retry_allowed": False}
                create(preparation / "LAUNCH_CONFIRMED.json", confirmed)
                return confirmed
            time.sleep(0.05)
        raise TimeoutError("Owner handshake unconfirmed; preserve dispatch and inspect PID/terminal receipts")
    except BaseException as exc:
        # An unconfirmed owner may still be running. Never silently dispatch a
        # replacement or kill it merely because this launcher lost confirmation.
        failure = {"status": "LAUNCH_FAILED_OR_UNCONFIRMED", "at_utc": now(), "nonce": nonce,
                   "plan_sha256": plan_sha256, "reason": f"{type(exc).__name__}: {exc}",
                   "owner_pid": process.pid if process else None,
                   "owner_returncode": process.poll() if process else None,
                   "owner_identity": process_identity(process.pid) if process else None,
                   "retry_allowed": False, "action": "Inspect original owner and terminal receipts; no resubmission."}
        create(preparation / "LAUNCH_FAILURE.json", failure)
        raise


def launch():
    # Deferred import: toy tests never load the scientific protocol or its data.
    import development_protocol as protocol
    here = Path(__file__).resolve().parent
    if Path(protocol.HERE).resolve() != here:
        raise ValueError("Only the sibling V2 protocol may be launched")
    plan = protocol.verify()
    plan_sha = digest(protocol.OUT / "plan.json")
    registration = json.loads((protocol.OUT / "REGISTRATION.json").read_text())
    if registration["plan_sha256"] != plan_sha or plan["settings"] != protocol.SETTINGS:
        raise ValueError("Registered plan/settings binding differs")
    command = [sys.executable, "-u", str(here / "development_run.py"), "run"]
    return _launch_owner(command, protocol.ROOT, protocol.OUT, protocol.PREP, plan_sha,
                         protocol.SETTINGS["timeout_seconds"])


if __name__ == "__main__":
    if len(sys.argv) != 1:
        raise SystemExit("No command overrides: launch only registered sibling development_run.py run")
    print(json.dumps(launch()), flush=True)
