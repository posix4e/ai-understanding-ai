"""Small one-step energy organ; no world, oracle, question or training loop.

Each input contains three canonical one-hot blocks: state (8), action (3),
candidate next state (8). Lower output energy is preferred. The complete query
grid is fixed independently of any language question or target. This numeric
API cannot certify the provenance of parameters or a caller's surrounding code.

All parameters and forward arithmetic are FP32, including under autocast.
Snapshot construction preserves gradients; the training/export worker owns
freezing, detaching, calibration, provenance and post-cast interface checks.
"""

import torch
from torch import nn


STATE_COUNT = 8
ACTION_COUNT = 3
INPUT_WIDTH = 19
HIDDEN_WIDTH = 32
PARAMETER_COUNT = 1_664


def _finite(tensor, label):
    if not bool(torch.isfinite(tensor).all()):
        raise FloatingPointError(f"Non-finite {label}")


class EnergyOrgan(nn.Module):
    """Bias-free 19→32→32→1 MLP with exact GELU hidden activations.

    forward: canonical dense FP32 [N>0, 19] → FP32 [N]. All inputs and
    parameters must share a device. No dropout, normalization or hidden state.
    """

    def __init__(self):
        super().__init__()
        self.input_proj = nn.Linear(INPUT_WIDTH, HIDDEN_WIDTH, bias=False, dtype=torch.float32)
        self.hidden_proj = nn.Linear(HIDDEN_WIDTH, HIDDEN_WIDTH, bias=False, dtype=torch.float32)
        self.output_proj = nn.Linear(HIDDEN_WIDTH, 1, bias=False, dtype=torch.float32)
        self.activation = nn.GELU(approximate="none")

    def _validate(self, queries):
        if not isinstance(queries, torch.Tensor):
            raise TypeError("queries must be a tensor")
        if queries.ndim != 2 or queries.shape[0] < 1 or queries.shape[1] != INPUT_WIDTH:
            raise ValueError("Expected queries shape [N>0, 19]")
        if queries.dtype != torch.float32:
            raise TypeError("Organ queries must be float32")
        if queries.layout != torch.strided:
            raise TypeError("Organ queries must be dense strided tensors")
        _finite(queries, "queries")
        if not bool(((queries == 0) | (queries == 1)).all()):
            raise ValueError("Queries must contain only canonical one-hot values")
        for start, end in ((0, 8), (8, 11), (11, 19)):
            if not bool((queries[:, start:end].sum(dim=1) == 1).all()):
                raise ValueError("Each query must have one state, action and candidate")
        for name, parameter in self.named_parameters():
            if parameter.dtype != torch.float32:
                raise TypeError(f"Organ parameter {name} must remain float32")
            if parameter.device != queries.device:
                raise ValueError(f"Organ parameter {name} and queries must share a device")
            _finite(parameter, f"parameter {name}")

    def forward(self, queries):
        self._validate(queries)
        with torch.autocast(device_type=queries.device.type, enabled=False):
            hidden = self.activation(self.input_proj(queries))
            _finite(hidden, "first hidden activation")
            hidden = self.activation(self.hidden_proj(hidden))
            _finite(hidden, "second hidden activation")
            energy = self.output_proj(hidden).squeeze(-1)
            _finite(energy, "energy output")
        return energy


def canonical_queries(*, device=None):
    """Return FP32 [24, 8, 19], ordered state, action, then candidate.

    Row index is 3*state+action. This helper accepts no question, world, target,
    rule identifier or sequence. Every organ receives the same 192 queries.
    """
    queries = torch.zeros((STATE_COUNT * ACTION_COUNT, STATE_COUNT, INPUT_WIDTH),
                          dtype=torch.float32, device=device)
    for state in range(STATE_COUNT):
        for action in range(ACTION_COUNT):
            row = ACTION_COUNT * state + action
            queries[row, :, state] = 1
            queries[row, :, STATE_COUNT + action] = 1
            for candidate in range(STATE_COUNT):
                queries[row, candidate, STATE_COUNT + ACTION_COUNT + candidate] = 1
    return queries


def snapshot_energies(organ):
    """Evaluate all one-step queries as [24,8], without labels or rollout.

    The result remains connected to the organ's parameters for independent
    one-step training. Exporters must explicitly freeze/detach and bind it.
    """
    if not isinstance(organ, EnergyOrgan):
        raise TypeError("Expected an EnergyOrgan")
    queries = canonical_queries(device=organ.input_proj.weight.device)
    return organ(queries.reshape(-1, INPUT_WIDTH)).reshape(STATE_COUNT * ACTION_COUNT, STATE_COUNT)
