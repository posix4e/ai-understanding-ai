"""Outcome-only residual writer. No host, data, optimizer or model execution.

The caller supplies an eight-state probability vector. This is an explicit
answer-code positive control, not a learned world model or a reasoning test.
Only the last prefix position is changed, before native block 20 in the worker.
"""
import torch
from torch import nn


class OutcomeWriter(nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = nn.Parameter(torch.zeros((1024, 8), dtype=torch.float32))
        self.last_capture = None

    def forward(self, hidden, probabilities):
        self.last_capture = None
        if hidden.ndim != 3 or hidden.shape[0] != 1 or hidden.shape[1] < 1 or hidden.shape[2] != 1024:
            raise ValueError('Expected hidden [1,L>0,1024]')
        if hidden.dtype not in (torch.float32, torch.bfloat16):
            raise TypeError('Unsupported host dtype')
        if probabilities.shape != (8,) or probabilities.dtype != torch.float32:
            raise TypeError('Expected FP32 probability vector [8]')
        if self.weight.dtype != torch.float32:
            raise TypeError('Writer parameters must stay FP32')
        if len({hidden.device, probabilities.device, self.weight.device}) != 1:
            raise ValueError('Writer inputs and parameter must share device')
        if not all(bool(torch.isfinite(x).all()) for x in (hidden, probabilities, self.weight)):
            raise ValueError('Nonfinite input or parameter')
        if bool((probabilities < 0).any()) or bool((probabilities > 1).any()):
            raise ValueError('Invalid probability range')
        if abs(float(probabilities.sum().detach().cpu()) - 1.0) > 2e-6:
            raise ValueError('Invalid probability sum')
        with torch.autocast(device_type=hidden.device.type, enabled=False):
            centered = probabilities - 0.125
            delta32 = self.weight @ centered
            delta = delta32.to(hidden.dtype)
            last = hidden[:, -1:, :] + delta.reshape(1, 1, 1024)
            returned = torch.cat((hidden[:, :-1, :], last), dim=1)
        # These are the exact tensors consumed in this call, not a replay.
        capture = dict(centered=centered, delta32=delta32, delta_host=delta,
                       hidden=hidden, returned=returned, probabilities=probabilities)
        self.last_capture = capture
        if not bool(torch.isfinite(returned).all()) or not bool(torch.isfinite(delta32).all()):
            raise ValueError('Nonfinite writer output')
        return returned, capture
