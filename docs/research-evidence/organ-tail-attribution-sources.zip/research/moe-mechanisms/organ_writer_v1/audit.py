"""Independent saved-array audit of the supplied-outcome writer.

No model library, worker metrics, backward pass, optimizer, or training is used.
Before registration only invented inputs may be passed to these functions.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import os
import random
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_WRITER_V1'
CONTROL_LIMIT=math.log(2)/8
FLOAT_U=2.**-24
DOT_GAMMA=(8*FLOAT_U)/(1-8*FLOAT_U)
VOCAB=49155
PHASE_COUNTS={'native':24,'zero_init':24,'train':2048,'train_eval':128,'held_eval':128,'organ_eval':768,'uniform':24,'restored':24}
EXCLUSIONS={'owner-events.jsonl','worker.log','independent_audit.log','COLLECTED.json'}

class AuditError(ValueError):pass

def require(ok,message):
    if not ok:raise AuditError(message)

def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def read(path):return json.loads(Path(path).read_text())

def exact(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return a.shape==b.shape and a.dtype==b.dtype and a.tobytes()==b.tobytes()

def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())

def bf16_round(x):
    """Exact IEEE round-to-nearest-even of finite FP32, preserves signed zero."""
    a=np.ascontiguousarray(np.asarray(x,dtype=np.float32));bits=a.view(np.uint32)
    require(np.isfinite(a).all(),'Nonfinite cast input')
    rounded=((bits+np.uint32(0x7fff)+((bits>>16)&1))>>16).astype(np.uint16)
    return (rounded.astype(np.uint32)<<16).view(np.float32).reshape(a.shape)

def strict_choice(values):
    a=np.asarray(values)
    require(a.shape==(8,) and np.isfinite(a).all(),'Expected eight finite scores')
    tied=np.flatnonzero(a==a.max()).tolist()
    return {'winner':tied[0] if len(tied)==1 else None,'ties':tied}

def code_vector(alpha,label):
    require(alpha in (1.,.75,.5) and type(label) is int and 0<=label<8,'Invalid synthetic code')
    x=np.full(8,(1-alpha)/8,dtype=np.float32);x[label]+=np.float32(alpha)
    return x

def probability_target(p):
    x=np.asarray(p)
    require(x.dtype==np.float32 and x.shape==(8,) and np.isfinite(x).all(),'Invalid probability tensor')
    require(np.all(x>=0) and np.all(x<=1) and abs(float(x.astype(np.float64).sum())-1)<=2e-6,'Invalid probability simplex')
    c=strict_choice(x);require(c['winner'] is not None,'Supplied code has no unique target')
    return c['winner']

def check_loss(scores,target,recorded):
    x=np.asarray(scores,dtype=np.float64);require(x.shape==(8,) and np.isfinite(x).all(),'Invalid loss scores')
    m=float(x.max());reference=m+math.log(math.fsum(math.exp(float(v)-m) for v in x))-float(x[target])
    error=abs(float(recorded)-reference);allowance=1e-5+1e-5*abs(reference)
    require(math.isfinite(float(recorded)) and error<=allowance,'Recorded CE not supplied-code objective')
    return dict(reference=reference,absolute_error=error,allowance=allowance)

def independent_schedule(contexts,codes):
    require(len(contexts)==24 and [c['id'] for c in contexts]==[f's{s}-a{a}' for s in range(8) for a in range(3)],'Noncanonical contexts')
    for i,c in enumerate(contexts):
        s,a=divmod(i,3)
        require(c['state']==s and c['action']==a and c['split']==('held' if a==s%3 else 'train'),'Context split changed')
    train=[c for c in contexts if c['split']=='train'];held=[c for c in contexts if c['split']=='held']
    org=[c for c in codes if c['id'].startswith('organ-')]
    require([c['id'] for c in org]==[f'organ-dev{w:02d}-row{r:02d}' for w in range(4) for r in range(24)],'Organ vector identity grid changed')
    rows=[]
    def put(phase,c,code=None,**extra):rows.append(dict(index=len(rows),id=f'{len(rows):04d}',phase=phase,context_id=c['id'],code_id=code,**extra))
    for c in contexts:put('native',c);put('zero_init',c,'uniform')
    generator=random.Random(70500)
    for epoch in range(16):
        pairs=list(itertools.product(train,range(8)));generator.shuffle(pairs);alpha=1. if epoch%2==0 else .75
        for c,y in pairs:put('train',c,f'alpha{alpha:g}-label{y}',epoch=epoch+1,label=y,alpha=alpha)
    for c in train:
        for y in range(8):put('train_eval',c,'alpha0.75-label'+str(y),label=y,alpha=.75)
    for alpha in (.75,.5):
        for c in held:
            for y in range(8):put('held_eval',c,f'alpha{alpha:g}-label{y}',label=y,alpha=alpha)
    for code in org:
        for c in held:put('organ_eval',c,code['id'],label=code['label'])
    for c in contexts:put('uniform',c,'uniform');put('restored',c)
    require(Counter(r['phase'] for r in rows)==PHASE_COUNTS and len(rows)==3168,'Internal schedule error')
    return rows

def validate_codes(codes,actual):
    require(len(codes)==121 and np.asarray(actual).shape==(121,8) and actual.dtype==np.float32,'Code panel shape differs')
    expected_ids=['uniform']+[f'alpha{a:g}-label{y}' for a in (1.,.75,.5) for y in range(8)]+[f'organ-dev{w:02d}-row{r:02d}' for w in range(4) for r in range(24)]
    require([c['id'] for c in codes]==expected_ids,'Code order/identity differs')
    targets={}
    for i,c in enumerate(codes):
        desired=np.asarray(c['p'],dtype=np.float32)
        require(exact(actual[i],desired),'Consumed probability bytes differ from fixed code')
        if i==0:require(exact(desired,np.full(8,.125,dtype=np.float32)) and c['label'] is None,'Uniform code changed');continue
        target=probability_target(actual[i]);require(target==c['label'],'Plan label differs from FP32 supplied code')
        if i<=24:
            a=(1.,.75,.5)[(i-1)//8];y=(i-1)%8
            require(exact(desired,code_vector(a,y)) and c['alpha']==a and target==y,'Synthetic code changed')
        else:
            w,r=divmod(i-25,24)
            require(c['world_id']==f'dev{w:02d}' and c['source_row']==r,'Organ code source address changed')
        targets[c['id']]=target
    return targets

def audit_writer_math(values):
    h,p,w=values['hidden'],values['probabilities'],values['writer_weight']
    require(h.ndim==3 and h.shape[0]==1 and h.shape[2]==1024 and h.shape[1]>0,'Invalid host shape')
    require(p.shape==(8,) and w.shape==(1024,8),'Invalid writer dimensions')
    centered=(p-np.float32(.125)).astype(np.float32)
    require(exact(centered,values['centered']),'Centering bytes differ')
    reference=np.einsum('ij,j->i',w.astype(np.float64),centered.astype(np.float64),optimize=False)
    absolute=np.einsum('ij,j->i',np.abs(w.astype(np.float64)),np.abs(centered.astype(np.float64)),optimize=False)
    bound=4*DOT_GAMMA*absolute+2*FLOAT_U*np.abs(reference)+8*np.finfo(np.float32).tiny
    error=np.abs(values['delta32'].astype(np.float64)-reference)
    require(values['delta32'].shape==(1024,) and np.all(error<=bound),'FP32 writer dot outside fixed allowance')
    cast=bf16_round(values['delta32']);require(exact(cast,values['delta_host']),'BF16 delta cast differs')
    expected=bf16_round((h[:,-1,:]+cast[None,:]).astype(np.float32))
    returned=values['returned'];require(returned.shape==h.shape,'Returned H shape differs')
    require(exact(returned[:,:-1,:],h[:,:-1,:]),'Nonfinal prefix changed')
    require(exact(returned[:,-1,:],expected),'BF16 addition differs')
    return dict(maximum_dot_error=float(error.max()),maximum_dot_allowance=float(bound.max()),nonfinal_rows_exact=True,cast_add_exact=True)

def count_group(rows):
    return dict(n=len(rows),correct=sum(r['correct'] for r in rows),ties=sum(r['choice']['winner'] is None for r in rows))

def summarize(rows):
    require(len(rows)==1024 and len({r['id'] for r in rows})==1024,'Final scoring coverage differs')
    phases=('train_eval','held_eval','organ_eval');groups={}
    for phase,n in zip(phases,(128,128,768)):
        rr=[r for r in rows if r['phase']==phase];require(len(rr)==n,'Final phase count differs')
        group=count_group(rr);group['pass']=group['correct']==n
        for key in ('context_id','target')+(() if phase=='organ_eval' else ('alpha',))+(('code_id',) if phase=='organ_eval' else ()):
            group['by_'+key]={str(value):count_group([r for r in rr if r[key]==value]) for value in sorted({r[key] for r in rr})}
        groups[phase]=group
    held=[r for r in rows if r['phase']=='held_eval'];switches=[]
    for context in sorted({r['context_id'] for r in held}):
        for alpha in (.75,.5):
            rr={r['target']:r for r in held if r['context_id']==context and r['alpha']==alpha}
            require(set(rr)==set(range(8)),'Held label grid differs')
            for a,b in itertools.combinations(range(8),2):switches.append(dict(context_id=context,alpha=alpha,labels=[a,b],both_followed=rr[a]['correct'] and rr[b]['correct']))
    require(len(switches)==448,'Switch grid differs')
    return dict(groups=groups,paired_switches=dict(n=448,both_followed=sum(r['both_followed'] for r in switches),rows=switches),gate_pass=all(g['pass'] for g in groups.values()))

DTYPES={'torch.bfloat16':('<u2',2),'torch.float32':('<f4',4),'torch.int64':('<i8',8)}

def load_bundle(path,metadata,expected):
    """Decode original tensor bytes independently; expected fixes original dtypes."""
    meta=read(metadata);require(set(meta['tensors'])==set(expected),'Unexpected tensor coverage')
    values={};raws={};keys=set()
    with np.load(path,allow_pickle=False) as arrays:
        for name,(dtype,shape) in expected.items():
            m=meta['tensors'][name]
            require(m['dtype']==dtype and m['shape']==list(shape),'Recorded original tensor dtype/shape differs: '+name)
            rk,vk=name+'__raw_uint8',name+'__value'
            require(m['raw_key']==rk and m['value_key']==vk,'Tensor key mapping changed')
            keys.update((rk,vk));raw=np.asarray(arrays[rk]);value=np.asarray(arrays[vk]);dt,size=DTYPES[dtype]
            require(raw.dtype==np.uint8 and raw.shape==(math.prod(shape)*size,),'Malformed raw bytes')
            require(hashlib.sha256(raw.tobytes()).hexdigest()==m['raw_sha256'],'Raw tensor hash differs')
            decoded=np.frombuffer(raw.tobytes(),dtype=dt)
            if dtype=='torch.bfloat16':decoded=(decoded.astype(np.uint32)<<16).view(np.float32)
            decoded=decoded.reshape(shape)
            require(exact(decoded,value),'Raw and readable tensor differ')
            require(np.isfinite(decoded).all(),'Nonfinite retained tensor')
            values[name]=value.copy();raws[name]=raw.copy()
        require(set(arrays.files)==keys,'Unexpected NPZ member')
    return values,raws,meta

def jsonl(path):
    lines=Path(path).read_text().splitlines();require(all(x.strip() for x in lines),'Blank journal record')
    return [json.loads(x) for x in lines]

def safe_path(directory,name):
    p=Path(name);require(not p.is_absolute() and '..' not in p.parts,'Unsafe artifact path')
    target=Path(directory)/p
    require(target.resolve().is_relative_to(Path(directory).resolve()),'Artifact escapes directory')
    return target

def check_inventory(directory,collected,late=()):
    require(set(collected['artifact_sha256'])=={str(p.relative_to(directory)) for p in Path(directory).rglob('*') if p.is_file() and str(p.relative_to(directory)) not in EXCLUSIONS|set(late)},'Collection inventory missing/extra files')
    for name,sha in collected['artifact_sha256'].items():require(digest(safe_path(directory,name))==sha,'Collected artifact hash differs: '+name)

def schedule_fields(record,entry):
    require(all(record.get(k)==v for k,v in entry.items()),'Record schedule binding differs')
    # Optional schedule fields from another phase must not quietly leak through.
    for k in ('epoch','alpha','label'):
        require((k in record)==(k in entry),'Extra/missing schedule field')

def load_bound_bundle(directory,row,stem,expected,plan_sha,entry=None):
    require(row['forward_path']==stem+'.npz' and row['forward_metadata_path']==stem+'.json','Raw bundle path changed')
    path,meta=safe_path(directory,row['forward_path']),safe_path(directory,row['forward_metadata_path'])
    require(digest(path)==row['forward_sha256'] and digest(meta)==row['forward_metadata_sha256'],'Row raw bundle hash differs')
    values,raw,m=load_bundle(path,meta,expected)
    require(m['plan_sha256']==plan_sha,'Bundle plan differs')
    if entry is not None:schedule_fields(m,entry)
    return values,raw,m

def call_shapes(entry,length):
    shapes={'input_ids':('torch.int64',(1,length)),'hidden':('torch.bfloat16',(1,length,1024)),'scores':('torch.bfloat16',(8,))}
    if entry['phase'] in ('native','zero_init','uniform','restored'):shapes['full_logits']=('torch.bfloat16',(VOCAB,))
    if entry['phase'] not in ('native','restored'):
        shapes.update(probabilities=('torch.float32',(8,)),writer_weight=('torch.float32',(1024,8)),centered=('torch.float32',(8,)),delta32=('torch.float32',(1024,)),delta_host=('torch.bfloat16',(1024,)),returned=('torch.bfloat16',(1,length,1024)))
    return shapes

def expected_events(schedule):
    out=[('worker_started',None),('resources','before_loading')]
    trained=False
    for e in schedule:
        if e['phase'] not in ('native','zero_init','train') and not trained:
            out.append(('training_complete',None));trained=True
        out.extend([('resources','before:'+e['id']),('forward_started',e),('forward_finished',e),('resources','after:'+e['id'])])
        if e['phase']=='train':out.extend([('backward_started',e),('backward_finished',e),('resources','before_update:'+e['id']),('optimizer_started',e),('optimizer_finished',e),('resources','after_update:'+e['id'])])
    out.extend([('resources','complete'),('worker_completed',None)])
    return out

def validate_events(events,schedule,complete):
    expected=expected_events(schedule);require(len(events)==len(expected)==24965,'Work journal coverage differs')
    resources=[];previous=-math.inf
    for row,(kind,payload) in zip(events,expected):
        require(row['event']==kind,'Work journal operation order differs')
        if kind=='resources':
            require(row['stage']==payload,'Resource stage order differs')
            value={k:v for k,v in row.items() if k not in ('event','at_utc')};resources.append(value)
            require(set(value)=={'stage','elapsed_seconds','rss_high_water_bytes','mps_driver_bytes'},'Resource schema differs')
            require(math.isfinite(value['elapsed_seconds']) and previous<=value['elapsed_seconds']<=1200,'Invalid resource time')
            previous=value['elapsed_seconds']
            require(all(type(value[k]) is int and 0<=value[k]<=10*1024**3 for k in ('rss_high_water_bytes','mps_driver_bytes')),'Resource ceiling or type differs')
        elif isinstance(payload,dict):schedule_fields(row,payload)
        elif kind=='training_complete':
            require(row['counts']==dict(forward_attempts=2096,forward_finished=2096,backward_attempts=2048,backward_finished=2048,optimizer_attempts=2048,optimizer_steps=2048),'Training-complete journal counts differ')
        elif kind=='worker_completed':require(row['counts']==complete['counts'],'Terminal journal counts differ')
    require(resources==complete['resource_samples'] and len(resources)==10434,'Resource receipt differs')
    return resources

def validate_ownership(complete,plan,initial_raw,final_raw):
    counts=dict(forward_attempts=3168,forward_finished=3168,backward_attempts=2048,backward_finished=2048,optimizer_attempts=2048,optimizer_steps=2048)
    require(complete['status']=='WORKER_COMPLETED' and complete['counts']==counts,'Incomplete worker')
    require(complete['host_state_before']==plan['expected_host_state']==complete['host_state_after'],'Frozen host changed')
    require(len(plan['expected_host_state'])==219,'Incomplete host state inventory')
    initial={'weight':hashlib.sha256(initial_raw['weight'].tobytes()).hexdigest()};final={'weight':hashlib.sha256(final_raw['weight'].tobytes()).hexdigest()}
    require(complete['writer_state_initial']==initial and complete['writer_state_final']==final,'Writer raw state hashes differ')
    require(set(complete['checks'])=={'ownership_restored','host_state_unchanged','final_writer_unchanged','exact_counts'} and all(v is True for v in complete['checks'].values()),'Worker checks not all true')
    require(all(complete[k]==0 for k in ('organ_calls','bypass_calls','reader_calls','provider_calls','generated_tokens')),'Unexpected execution class')
    before,train,evaluation,after=[complete['identities_'+s] for s in ('before','training','evaluation','after')]
    require(before==after,'Full original ownership not restored')
    for identity in (before,train,evaluation,after):
        require(set(identity)=={'requires_grad','training','hooks','forward_methods','grad_none','host_config'},'Incomplete identity inventory')
        require(identity['hooks']=={'host':{},'writer':{}},'Residual hooks')
        require(identity['forward_methods']==before['forward_methods'],'Forward method changed')
        require(identity['training']==before['training'] and all(v is False for m in identity['training'].values() for v in m.values()),'Training/eval flags differ')
        require(set(identity['requires_grad'])==set(identity['grad_none'])=={'host','writer'},'Parameter owner inventory differs')
        require(set(identity['requires_grad']['writer'])=={'weight'} and set(identity['grad_none']['writer'])=={'weight'},'Unexpected writer parameter')
        require(len(identity['requires_grad']['host'])==218 and set(identity['requires_grad']['host'])==set(identity['grad_none']['host']),'Host parameter coverage differs')
        require(all(v is True for m in identity['grad_none'].values() for v in m.values()),'Leaked gradient buffer')
        require(identity['host_config']['logits_scaling']==6,'Native logit scaling changed')
    require(train['requires_grad']['writer']=={'weight':True} and evaluation['requires_grad']['writer']=={'weight':False},'Writer gradient mode differs')
    require(all(v is False for v in train['requires_grad']['host'].values()) and evaluation['requires_grad']['host']==train['requires_grad']['host'],'Host trained')
    cfg=dict(before['host_config']);cfg['use_cache']=False
    require(train['host_config']==evaluation['host_config']==cfg,'Active host config differs')
    require(0<=complete['elapsed_seconds']<=1200,'Worker duration exceeded')
    return counts

def validate_training_boundary(directory,plan_sha,final_values,final_raw):
    tc=read(Path(directory)/'TRAINING_COMPLETE.json')
    require(tc['plan_sha256']==plan_sha and tc['counts']==dict(forward_attempts=2096,forward_finished=2096,backward_attempts=2048,backward_finished=2048,optimizer_attempts=2048,optimizer_steps=2048),'Training/evaluation separation differs')
    require(tc['writer_state_sha256']=={'weight':hashlib.sha256(final_raw['weight'].tobytes()).hexdigest()},'Final state boundary differs')
    require(tc['writer_weights_sha256']==digest(Path(directory)/'writer-final.pt'),'Final checkpoint hash differs')
    require(tc['forward_path']=='writer-final.npz' and tc['forward_metadata_path']=='writer-final.json' and tc['forward_sha256']==digest(Path(directory)/'writer-final.npz') and tc['forward_metadata_sha256']==digest(Path(directory)/'writer-final.json'),'Final raw weight boundary differs')
    return tc

def audit_records(directory,plan,plan_sha):
    """Saved arrays only; all implementation checks finish before any report write."""
    directory=Path(directory);schedule=independent_schedule(plan['contexts'],plan['codes'])
    require(schedule==plan['schedule'] and plan['label_ids']==list(range(34,42)),'Plan schedule or labels differ')
    complete=read(directory/'WORKER_COMPLETE.json');require(complete['plan_sha256']==plan_sha,'Worker complete plan differs')
    initial,initial_raw,im=load_bundle(directory/'writer-initial.npz',directory/'writer-initial.json',{'weight':('torch.float32',(1024,8))})
    final,final_raw,fm=load_bundle(directory/'writer-final.npz',directory/'writer-final.json',{'weight':('torch.float32',(1024,8))})
    require(im['plan_sha256']==fm['plan_sha256']==plan_sha and exact(initial['weight'],np.zeros((1024,8),dtype=np.float32)),'Zero initialization differs')
    counts=validate_ownership(complete,plan,initial_raw,final_raw);tc=validate_training_boundary(directory,plan_sha,final,final_raw)
    codes,cr,cm=load_bundle(directory/'codes.npz',directory/'codes.json',{'probabilities':('torch.float32',(121,8))})
    require(cm['plan_sha256']==plan_sha and cm['code_ids']==[c['id'] for c in plan['codes']],'Code identity binding differs')
    targets=validate_codes(plan['codes'],codes['probabilities']);code_values={c['id']:codes['probabilities'][i] for i,c in enumerate(plan['codes'])}
    calls=jsonl(directory/'calls.jsonl');updates=jsonl(directory/'updates.jsonl');events=jsonl(directory/'worker-events.jsonl')
    require(len(calls)==3168 and len(updates)==2048,'Execution record count differs')
    resources=validate_events(events,schedule,complete)
    resource_map={r['stage']:r for r in resources};contexts={c['id']:c for c in plan['contexts']}
    baselines={};current=initial['weight'];ui=0;final_rows=[];controls=[];mathmax=0.;norm_error_max=0.;loss_error_max=0.;epoch_losses={e:[] for e in range(1,17)}
    hsets={c['id']:set() for c in plan['contexts']};hmax={c['id']:0. for c in plan['contexts']};hlastsets={c['id']:set() for c in plan['contexts']};first_step=None
    for row,entry in zip(calls,schedule):
        schedule_fields(row,entry);require(row['forward_completed'] is True and row['controls_pass'] is True and row['error'] is None,'Incomplete/failed call in successful collection')
        phase=entry['phase'];context=contexts[entry['context_id']];length=len(context['input_ids'])
        require(row['resources_before']==resource_map['before:'+entry['id']] and row['resources_after']==resource_map['after:'+entry['id']],'Call resource binding differs')
        values,raw,meta=load_bound_bundle(directory,row,'calls/'+entry['id'],call_shapes(entry,length),plan_sha,entry)
        writer=phase not in ('native','restored');require(row['writer_entered'] is writer and meta['writer_entered'] is writer,'Wrong implementation entered')
        require(exact(values['input_ids'],np.asarray([context['input_ids']],dtype=np.int64)),'Question tokens differ')
        h=values['hidden'];cid=entry['context_id'];hsets[cid].add(hashlib.sha256(raw['hidden'].tobytes()).hexdigest());hlastsets[cid].add(hashlib.sha256(h[:,-1,:].tobytes()).hexdigest())
        if phase=='native':baselines[cid]=dict(hidden=h.copy(),full_logits=values['full_logits'].copy())
        require(cid in baselines,'No preceding native context reference')
        hd=float(np.max(np.abs(h.astype(np.float64)-baselines[cid]['hidden'].astype(np.float64))));hmax[cid]=max(hmax[cid],hd)
        if writer:
            require(exact(values['probabilities'],code_values[entry['code_id']]),'Actual supplied code differs')
            require(exact(values['writer_weight'],current if phase in ('zero_init','train') else final['weight']),'Actual weight chain/final checkpoint differs')
            mathrow=audit_writer_math(values);mathmax=max(mathmax,mathrow['maximum_dot_error'])
        if phase in ('native','zero_init','uniform','restored'):
            require(exact(values['scores'],values['full_logits'][34:42]),'Eight labels not native vocabulary slice')
            if phase=='native':require(row['control_comparison'] is None,'Native comparison should be absent')
            else:
                error=float(np.max(np.abs(values['full_logits'].astype(np.float64)-baselines[cid]['full_logits'].astype(np.float64))))
                require(error<=CONTROL_LIMIT,'Fixed output control exceeded')
                expected=dict(full_vocabulary_max_absolute_error=error,hidden_raw_equal=exact(h,baselines[cid]['hidden']),hidden_max_absolute_error=hd)
                require(row['control_comparison']==expected,'Worker control summary differs')
                controls.append(dict(id=entry['id'],context_id=cid,phase=phase,**expected))
        else:require(row['control_comparison'] is None,'Unexpected control summary')
        if phase=='train':
            update=updates[ui];ui+=1;schedule_fields(update,entry)
            uv,ur,um=load_bound_bundle(directory,update,'updates/'+entry['id'],{'loss':('torch.float32',()),'gradient':('torch.float32',(1024,8)),'weight_after':('torch.float32',(1024,8))},plan_sha,entry)
            require(update['error'] is None,'Failed update')
            nonzero=bool(np.any(uv['gradient']!=0));changed=not exact(current,uv['weight_after']);norm=float(np.linalg.norm(uv['gradient'].astype(np.float64).ravel()))
            for rec in (update,um):
                require(rec['backward_completed'] is True and rec['optimizer_completed'] is True and rec['finite_gradient'] is True,'Incomplete gradient/update')
                require(rec['nonzero_gradient'] is nonzero and rec['parameter_changed'] is changed,'Gradient/update flags disagree')
                error=abs(float(rec['gradient_norm'])-norm);require(error<=1e-9+1e-9*norm,'Gradient norm summary differs');norm_error_max=max(norm_error_max,error)
            if ui==1:
                require(nonzero and changed,'Zero-init first update ineffective');first_step=dict(nonzero_gradient=True,parameter_changed=True,gradient_norm=norm)
            require(float(uv['loss'])>=0,'Negative cross-entropy loss')
            target=targets[entry['code_id']];require(target==entry['label'],'Training supplied-code target differs')
            loss_error_max=max(loss_error_max,check_loss(values['scores'],target,uv['loss'])['absolute_error'])
            epoch_losses[entry['epoch']].append(float(uv['loss']));current=uv['weight_after'].copy()
        elif phase.endswith('_eval'):
            target=targets[entry['code_id']];require(target==entry['label'],'Endpoint target differs')
            choice=strict_choice(values['scores']);final_rows.append(dict(entry,target=target,choice=choice,correct=choice['winner']==target,scores=values['scores'].astype(float).tolist()))
    require(ui==2048 and exact(current,final['weight']),'Final update weight does not bind final checkpoint')
    epoch_summary=[]
    for e,losses in epoch_losses.items():
        record=read(directory/f'epoch-{e:02d}.json');mean=math.fsum(losses)/128
        require(record['epoch']==e and record['training_examples']==128 and len(losses)==128 and abs(record['mean_loss']-mean)<=1e-12+1e-12*abs(mean),'Epoch mean/count differs')
        epoch_summary.append(dict(epoch=e,training_examples=128,mean_loss=mean))
    require(len(controls)==72,'Control comparison count differs')
    result=summarize(final_rows)
    result.update(implementation_pass=True,counts=counts,rows=final_rows,controls=controls,epoch_losses=epoch_summary,
        first_update=first_step,arithmetic=dict(writer_calls=3120,maximum_observed_dot_error=mathmax,maximum_gradient_norm_summary_error=norm_error_max,maximum_training_loss_error=loss_error_max,cast_add_and_nonfinal_exact=True),
        prewriter_context_variation={c:dict(full_hidden_unique=len(hsets[c]),last_hidden_unique=len(hlastsets[c]),maximum_absolute_difference_from_native=hmax[c]) for c in contexts},
        resources=dict(samples=len(resources),maximum_rss_bytes=max(r['rss_high_water_bytes'] for r in resources),maximum_mps_driver_bytes=max(r['mps_driver_bytes'] for r in resources),worker_elapsed_seconds=complete['elapsed_seconds']))
    return result

def validate_lineage(plan):
    """Hash/JSON provenance only: no model/checkpoint tensor loading."""
    for field in ('source_sha256','lineage_sha256'):
        for name,sha in plan[field].items():require(digest(safe_path(ROOT,name))==sha,'Frozen source/lineage differs: '+name)
    model=safe_path(ROOT,plan['model_path'])
    require(len(plan['model_files'])==9,'Pinned model-file coverage differs')
    for name,sha in plan['model_files'].items():require(digest(safe_path(model,name))==sha,'Pinned checkpoint/tokenizer file differs')
    installed=ROOT/'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
    require(digest(installed)==plan['installed_model_source_sha256'],'Installed native implementation differs')
    old=ROOT/'outputs/moe-mechanisms/ORGAN_DEVELOPMENT_V2';reader=ROOT/'outputs/moe-mechanisms/ORGAN_ADDRESS_READ_V1'
    for directory,sha,status in ((old,'94f2b56135cb3de13a00c0cd20e32e2e376306bf188e95b06610386f908c9eb4','DEVELOPMENT_READINESS_FAILED'),(reader,'0735ac5bbd8e1774f86f7fcd2fc8d7cd05c593f8d98db4d2a8ed9915f8f1ed99','ADDRESS_READER_ADMISSION_PASSED')):
        require(not (directory/'STOPPED.json').exists() and digest(directory/'plan.json')==sha,'Prerequisite terminal/plan differs')
        complete,audit,collected=[read(directory/name) for name in ('COMPLETE.json','INDEPENDENT_AUDIT.json','COLLECTED.json')]
        require(complete['status']==status and audit['status']=='PASS','Prerequisite status differs')
        require(complete['plan_sha256']==audit['plan_sha256']==collected['plan_sha256']==sha,'Prerequisite plan links differ')
        require(complete['independent_audit_sha256']==digest(directory/'INDEPENDENT_AUDIT.json') and complete['report_sha256']==audit['report_sha256']==digest(directory/'REPORT.json'),'Prerequisite report/audit links differ')
        bound=audit['collected_sha256'] if directory==old else audit['input_sha256'][str(directory/'COLLECTED.json')]
        require(bound==digest(directory/'COLLECTED.json'),'Prerequisite audit-to-collection link differs')
    previous=read(old/'plan.json');old_collected=read(old/'COLLECTED.json');tokens=read(old/'TOKENIZED_QUESTIONS.json')
    require(old_collected['artifact_sha256']['TOKENIZED_QUESTIONS.json']==digest(old/'TOKENIZED_QUESTIONS.json'),'Historical input tokens changed')
    require(tokens['label_ids']==plan['label_ids']==list(range(34,42)),'Token label order differs')
    for context in plan['contexts']:
        copies=[c for c in previous['train_cases'] if c['initial_state']==context['state'] and c['actions']==[context['action']]]
        require(len(copies)==4,'Context does not have four historical world copies')
        selected=[tokens['cases'][c['id']] for c in copies]
        require(all(x==selected[0] for x in selected),'Historical context world copies differ')
        require(all(context[k]==v for k,v in selected[0].items()),'Context differs from original tokenized prompt')
    for code in plan['codes'][25:]:
        path=safe_path(ROOT,code['source']);require(path==old/f"organ-{code['world_id']}.json",'Unexpected organ source file')
        require(old_collected['artifact_sha256'][path.name]==digest(path),'Saved organ code binding differs')
        record=read(path);require(record['strict_correct']==record['memory_strict_correct']==24,'Saved code source lacks admission')
        require(code['p']==record['probabilities'][code['source_row']],'Saved organ vector was changed')

def is_alive(pid):
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False

def owner_guard(directory,plan_sha):
    started=read(directory/'STARTED.json');ws=read(directory/'WORKER_STARTED.json')
    require(started['owner_pid']==os.getppid() and is_alive(started['owner_pid']),'Audit is not owned by live original owner')
    require(started['plan_sha256']==ws['plan_sha256']==plan_sha and ws['owner_pid']==started['owner_pid'],'Worker/owner identity binding differs')
    deadline=datetime.fromisoformat(started['deadline_utc']);start=datetime.fromisoformat(started['at_utc'])
    require(deadline.tzinfo is not None and (deadline-start).total_seconds()==1200 and datetime.now(timezone.utc)<deadline,'Owner deadline differs or expired')
    require(ws['deadline_utc']==started['deadline_utc'],'Worker deadline differs')
    # Popen dispatch precedes the parent's durable started event. This bounded
    # handshake waits only for that journal suffix, never reruns any operation.
    handshake=time.monotonic()+2
    while True:
        try:events=jsonl(directory/'owner-events.jsonl')
        except (FileNotFoundError,json.JSONDecodeError):events=None
        if events is not None and len(events)>=3:break
        require(time.monotonic()<handshake and datetime.now(timezone.utc)<deadline,'Owner audit-start journal handshake missing')
        time.sleep(.02)
    require(len(events)==3 and [(x['event'],x['stage']) for x in events]==[('started','worker'),('exit','worker'),('started','independent_audit')],'Owner stage prefix differs')
    require(events[0]['pid']==events[1]['pid']==ws['worker_pid'] and events[1]['code']==0 and events[2]['pid']==os.getpid(),'Worker terminal/audit ownership differs')
    require(not is_alive(ws['worker_pid']),'Worker still alive during audit')
    source=Path(__file__).resolve().parent;python=ROOT/'work/acquisition-representation-venv/bin/python'
    require(events[0]['command']==[str(python),str(source/'worker.py'),'--deadline-utc',started['deadline_utc']],'Worker command differs')
    require(events[2]['command']==[str(python),str(source/'audit.py'),'--directory',str(directory)],'Auditor command differs')
    return started,ws,events

def stop_accounting(directory):
    """Metadata only. Never decode arrays, score predictions, or fit anything."""
    require((directory/'STOPPED.json').exists() and not (directory/'COMPLETE.json').exists(),'No closed STOP to account')
    plan=read(directory/'plan.json');sha=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==sha,'Stopped plan changed')
    schedule=independent_schedule(plan['contexts'],plan['codes']);events=jsonl(directory/'worker-events.jsonl') if (directory/'worker-events.jsonl').exists() else []
    attempts=[e for e in events if e['event']=='forward_started'];finished=[e for e in events if e['event']=='forward_finished']
    require(len(attempts)<=3168 and len(finished)<=len(attempts),'Stopped execution counts impossible')
    for e,s in zip(attempts,schedule):schedule_fields(e,s)
    require([e['id'] for e in finished]==[e['id'] for e in attempts[:len(finished)]],'Stopped finishes not prefix')
    completed_training=[e['id'] for e in finished if e['phase']=='train']
    backward_attempts=[e['id'] for e in events if e['event']=='backward_started'];backward_finished=[e['id'] for e in events if e['event']=='backward_finished']
    optimizer_attempts=[e['id'] for e in events if e['event']=='optimizer_started'];optimizer_finished=[e['id'] for e in events if e['event']=='optimizer_finished']
    require(backward_attempts==completed_training[:len(backward_attempts)] and len(backward_attempts)<=len(completed_training)<=2048,'Stopped backward attempt sequence differs')
    require(backward_finished==backward_attempts[:len(backward_finished)] and len(backward_finished)<=len(backward_attempts),'Stopped backward finish sequence differs')
    require(optimizer_attempts==backward_finished[:len(optimizer_attempts)] and len(optimizer_attempts)<=len(backward_finished),'Stopped optimizer attempt sequence differs')
    require(optimizer_finished==optimizer_attempts[:len(optimizer_finished)] and len(optimizer_finished)<=len(optimizer_attempts),'Stopped optimizer finish sequence differs')
    counts=dict(forward_attempted=len(attempts),forward_finished=len(finished),forward_unattempted=3168-len(attempts),backward_attempted=sum(e['event']=='backward_started' for e in events),backward_finished=sum(e['event']=='backward_finished' for e in events),optimizer_attempted=sum(e['event']=='optimizer_started' for e in events),optimizer_finished=sum(e['event']=='optimizer_finished' for e in events))
    receipt=dict(status='STOP_METADATA_ACCOUNTING',plan_sha256=sha,stop_sha256=digest(directory/'STOPPED.json'),counts=counts,scientific_interpretation=False,arrays_decoded=0,audit_code_sha256=digest(__file__))
    create(directory/'STOP_ACCOUNTING.json',receipt);return receipt

def audit(directory=OUT):
    directory=Path(directory);require(directory.resolve()==OUT.resolve(),'Unexpected study directory')
    require(not any((directory/name).exists() for name in ('STOPPED.json','WORKER_FAILURE.json','COMPLETE.json','AUDIT_STARTED.json','REPORT.json','INDEPENDENT_AUDIT.json','AUDIT_FAILURE.json')),'Audit already attempted or study stopped/terminal')
    import protocol as p  # Binding/IO constants only; never scientific metrics.
    plan=p.verify();sha=digest(directory/'plan.json');started,ws,oe=owner_guard(directory,sha)
    require(set(plan['collection_exclusions'])==EXCLUSIONS,'Collection exclusions differ')
    collected=read(directory/'COLLECTED.json');require(collected['plan_sha256']==sha and collected['all_controls_pass'] is True,'Collection not admitted')
    check_inventory(directory,collected)
    create(directory/'AUDIT_STARTED.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=sha,audit_code_sha256=digest(__file__),pid=os.getpid(),owner_pid=os.getppid(),rerun_allowed=False))
    try:
        validate_lineage(plan)
        for name,h in plan['source_sha256'].items():require(digest(safe_path(directory/'sources',name))==h,'Source archive differs')
        report=audit_records(directory,plan,sha)
        require(collected['counts']==report['counts'],'Collection counts differ')
        check_inventory(directory,collected,late=('AUDIT_STARTED.json',))
        require(datetime.now(timezone.utc)<datetime.fromisoformat(started['deadline_utc']),'Audit deadline expired')
        report.update(status='WRITER_ADMISSION_PASSED' if report['gate_pass'] else 'WRITER_ADMISSION_FAILED',at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=sha,
            scope='Supplied-outcome eight-label transduction, not reasoning, free-generation, probability calibration, reader-writer assembly or novel-world transfer.',
            limits=['All24 contexts and96 organ vectors were development-exposed; held contexts were excluded only from this writer fit.',
                    '768 real-code compatibility cells repeat96 vectors across8 contexts;448 switches derive from128 cells.',
                    'All writer dot/cast/add captures and W update chain checked; gradients/Adam computation are source-bound and not independently replayed.',
                    'Full-vocabulary no-op controls use the fixed ln2/8 bound; cross-call H variation is descriptive. Within-call nonfinal locality/cast/add are exact.',
                    'Eight-label argmax following does not establish full-vocabulary top1, text generation or probability-distribution fidelity.'],
            numerical_allowances=dict(dot='4*gamma8*sumabs+2*u*abs(reference)+8*tiny32;u=2^-24',control_max_absolute=CONTROL_LIMIT,gradient_norm_summary_atol=1e-9,gradient_norm_summary_rtol=1e-9,epoch_mean_atol=1e-12,epoch_mean_rtol=1e-12,training_loss_atol=1e-5,training_loss_rtol=1e-5),
            model_calls_by_auditor=0,backwards_by_auditor=0,optimizer_steps_by_auditor=0)
        create(directory/'REPORT.json',report)
        inputs=dict(collected['artifact_sha256']);inputs['COLLECTED.json']=digest(directory/'COLLECTED.json')
        receipt=dict(status='PASS',implementation_pass=True,gate_pass=report['gate_pass'],plan_sha256=sha,report_sha256=digest(directory/'REPORT.json'),audit_code_sha256=digest(__file__),collected_sha256=digest(directory/'COLLECTED.json'),input_sha256=inputs,
            owner_journal_observed_prefix_sha256=hashlib.sha256(('\n'.join(json.dumps(e,sort_keys=True) for e in oe)).encode()).hexdigest(),owner_journal_prefix_only=True,
            counts=report['counts'],model_calls=0,provider_calls=0,gradient_updates=0,limitations=report['limits'])
        create(directory/'INDEPENDENT_AUDIT.json',receipt);return receipt
    except BaseException as exc:
        create(directory/'AUDIT_FAILURE.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=sha,reason=type(exc).__name__+': '+str(exc),audit_code_sha256=digest(__file__),rerun_allowed=False,partial_scientific_interpretation=False));raise

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,default=OUT);parser.add_argument('--stop-accounting',action='store_true');args=parser.parse_args()
    require(args.directory.resolve()==OUT.resolve(),'Unexpected output directory')
    result=stop_accounting(args.directory) if args.stop_accounting else audit(args.directory)
    print(json.dumps({k:v for k,v in result.items() if k not in ('input_sha256','limitations')},allow_nan=False),flush=True)
