"""Outcome-exposed same-prompt continuation diagnosis; explicit registration only."""
import sys
sys.dont_write_bytecode=True
from datetime import datetime,timezone
from pathlib import Path,PureWindowsPath
import hashlib
import json
import shutil
import os

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_CHAT_INTERFACE_V1'
PREP=ROOT/'work/organ-chat-interface-v1'
ORIGINAL=ROOT/'outputs/moe-mechanisms/ORGAN_PRIVATE_NATIVE_V1'
PREVIOUS=ROOT/'outputs/moe-mechanisms/ORGAN_READOUT_DIAGNOSIS_V1'
TOKENS=PREP/'tokenizer-v1'
PYTHON=ROOT/'work/acquisition-representation-venv/bin/python'
DECISION=PREP/'ROOT_DECISION.json'
DECISION_SHA='295bd60d61b1673caeb7ebbcccb0011ad39fed35e3af3e439b0c12f255f703de'
MODEL_SOURCE=ROOT/'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
MODEL_SOURCE_SHA='db9858ac0c9666a22d460e8a798df8086394e9084e45df93129d1474df1db40a'
SOURCES=('protocol.py','worker.py','owner.py','audit.py','test_native.py','test_audit.py')
SETTINGS=dict(timeout_seconds=900,max_rss_bytes=10*1024**3,max_mps_bytes=10*1024**3,
 max_archive_bytes=1024**3,minimum_free_bytes=1024**3,max_tokens=256,retained_tokens_max=257,
 seed=42,threads=4,device='mps',dtype='bfloat16',attention='eager',cache=False,batch_size=1,
 logits_to_keep=1,paths=20,primary=16,repeats=4,total_generated_token_cap=16,
 new_forwards_per_path_max=16,total_new_forwards_max=320,eos_id=0)
VERSIONS=dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',tokenizers='0.22.2')
EXCLUSIONS=('COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl')

def require(ok, message):
    if not ok: raise ValueError(message)
def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def object_sha(value): return hashlib.sha256(canonical(value)).hexdigest()
def create(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
def append(path, value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value, allow_nan=False)+'\n'); f.flush(); os.fsync(f.fileno())
def inventory(path, excluded=()):
    return {str(p.relative_to(path)):digest(p) for p in sorted(Path(path).rglob('*'))
            if p.is_file() and str(p.relative_to(path)) not in excluded}
def safe(root, name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe archive path')
    p=root/name; require(p.is_file() and p.resolve().is_relative_to(root.resolve()), 'Missing/escaping archive path'); return p


def model_payload(snapshot, repository, name):
    require(type(name) is str and name not in ('', '.', '..') and '/' not in name and '\\' not in name
            and not PureWindowsPath(name).drive and '\0' not in name, 'Expected model filename leaf')
    repo=Path(repository).resolve(strict=True); snap=Path(snapshot).resolve(strict=True)
    require(snap.is_dir() and snap.is_relative_to(repo), 'Snapshot outside bound model repository')
    path=snap/name; target=path.resolve(strict=True)
    require(target.is_file() and target.is_relative_to(repo), 'Model payload outside bound repository')
    return path


def validate_model_files(plan, weights=True):
    result={}
    for name, expected in plan['model_files'].items():
        if not weights and name == 'model.safetensors': continue
        path=model_payload(ROOT/plan['model_path'], ROOT/plan['model_cache_repository'], name)
        target=path.resolve(); before=target.stat(); actual=digest(target); after=target.stat()
        require((before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
                and path.resolve()==target and actual==expected, 'Model payload changed: '+name)
        result[name]=dict(sha256=actual, size_bytes=after.st_size, resolved_path=str(target))
    return result


def source_hashes():return {str((HERE/n).relative_to(ROOT)):digest(HERE/n) for n in SOURCES}


def fixed_decision():
    require(digest(DECISION)==DECISION_SHA,'Root decision changed')
    decision=read(DECISION)
    lineage=dict(decision['source_sha256'])
    lineage[str(DECISION.relative_to(ROOT))]=DECISION_SHA
    for name,h in lineage.items():require(digest(safe(ROOT,name))==h,'Decision lineage changed: '+name)
    require(decision['parser']['strip_characters']==[32,9,13,10] and decision['decoding']['eos_id']==0,'Readout contract differs')
    return decision,lineage


def original_evidence():
    decision,lineage=fixed_decision()
    old=read(ORIGINAL/'plan.json');complete=read(ORIGINAL/'COMPLETE.json')
    collected=read(ORIGINAL/'COLLECTED.json');audit=read(ORIGINAL/'INDEPENDENT_AUDIT.json')
    old_sha=digest(ORIGINAL/'plan.json')
    require(complete['status']=='NATIVE_PRIVATE_INPUT_COMPLETE' and complete['implementation_pass'] is True
        and complete['native_gate_pass'] is False and complete['native_forwards']==20,'Original not the closed negative')
    require(audit['status']=='PASS' and audit['implementation_pass'] is True and audit['native_gate_pass'] is False
        and complete['plan_sha256']==audit['plan_sha256']==collected['plan_sha256']==old_sha
        and complete['report_sha256']==audit['report_sha256']==digest(ORIGINAL/'REPORT.json')
        and complete['independent_audit_sha256']==digest(ORIGINAL/'INDEPENDENT_AUDIT.json')
        and audit['collected_sha256']==digest(ORIGINAL/'COLLECTED.json'),'Original terminal linkage changed')
    expected=dict(collected['artifact_sha256'])
    for name,h in expected.items():require(digest(safe(ORIGINAL,name))==h,'Original collection changed')
    for name,h in complete['final_log_sha256'].items():require(digest(safe(ORIGINAL,name))==h,'Original operational logs changed')
    actual=inventory(ORIGINAL)
    require(set(actual)==set(expected)|set(old['collection_exclusions'])|{'COMPLETE.json','REPORT.json','INDEPENDENT_AUDIT.json'},'Unexpected original archive file')
    for group in ('source_sha256','lineage_sha256','review_sha256'):
        for name,h in old[group].items():require(digest(safe(ROOT,name))==h,'Original frozen binding changed');lineage[name]=h
    require(old['versions']==VERSIONS and old['installed_model_source_sha256']==MODEL_SOURCE_SHA
        and digest(MODEL_SOURCE)==MODEL_SOURCE_SHA,'Original runtime/source differs')
    calls=[json.loads(line) for line in (ORIGINAL/'calls.jsonl').read_text().splitlines()]
    require(len(calls)==len(old['cases'])==20,'Original paths incomplete')
    keys=('index','id','phase','repeat_of','carrier','a','b')
    for i,(case,row) in enumerate(zip(old['cases'],calls)):
        require(case['index']==i and case['id']==f'n{i:02d}' and canonical({k:row[k] for k in keys})==canonical({k:case[k] for k in keys})
            and row['forward_completed'] is True and row['controls_pass'] is True and row['error'] is None,'Original call identity/control differs')
        for pk,hk,ext in (('forward_path','forward_sha256','npz'),('forward_metadata_path','forward_metadata_sha256','json')):
            require(row[pk]==f'calls/{i:02d}.{ext}' and row[hk]==actual[row[pk]],'Original raw reference differs')
    return old,calls,actual,lineage,decision


def previous_evidence():
    done=read(PREVIOUS/'COMPLETE.json');a=read(PREVIOUS/'INDEPENDENT_AUDIT.json');c=read(PREVIOUS/'COLLECTED.json')
    require(done['status']=='READOUT_DIAGNOSIS_COMPLETE' and done['implementation_pass'] is True and a['status']=='PASS'
        and done['original_native_gate_pass'] is False,'Previous diagnosis closure differs')
    require(done['plan_sha256']==a['plan_sha256']==c['plan_sha256']==digest(PREVIOUS/'plan.json')
        and done['report_sha256']==a['report_sha256']==digest(PREVIOUS/'REPORT.json')
        and done['independent_audit_sha256']==digest(PREVIOUS/'INDEPENDENT_AUDIT.json')
        and a['collected_sha256']==digest(PREVIOUS/'COLLECTED.json'),'Previous diagnosis bindings differ')
    for group in (c['artifact_sha256'],done['final_log_sha256']):
        for name,h in group.items():require(digest(safe(PREVIOUS,name))==h,'Previous diagnosis changed')
    result=inventory(PREVIOUS)
    require(set(result)==set(c['artifact_sha256'])|set(read(PREVIOUS/'plan.json')['collection_exclusions'])|
        {'COMPLETE.json','REPORT.json','INDEPENDENT_AUDIT.json'},'Previous archive inventory differs')
    return result


def reviews():
    hashes=source_hashes();result={}
    for name in ('SOURCE_REVIEW.json','PREPARATION_TESTS.json'):
        file=PREP/name;record=read(file)
        require(record['status'].startswith('PASS') and record['source_sha256']==hashes,'Missing/stale source review')
        result[str(file.relative_to(ROOT))]=digest(file)
    return result


def literal_chat(case,decision):
    system=decision['package']['system_text'];user=decision['package']['instruction_prefix']+case['input_text']
    messages=[dict(role='system',content=system),dict(role='user',content=user)]
    text=''.join('<|start_of_role|>'+m['role']+'<|end_of_role|>'+m['content']+'<|end_of_text|>\n' for m in messages)
    return messages,text+'<|start_of_role|>assistant<|end_of_role|>'


def tokenize_cases(tokenizer,cases,decision):
    rows=[]
    for case in cases:
        messages,literal=literal_chat(case,decision)
        rendered=tokenizer.apply_chat_template(messages,add_generation_prompt=True,tokenize=False,controls=[])
        ids=tokenizer.apply_chat_template(messages,add_generation_prompt=True,tokenize=True,controls=[])
        require(rendered==literal,'Official template differs from literal role serialization')
        require(ids==tokenizer.encode(literal,add_special_tokens=False),'Official chat IDs differ from raw encoding')
        require(tokenizer.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)==literal,'Chat input does not roundtrip')
        require(type(ids) is list and 1<=len(ids)<=241 and all(type(i) is int and 0<=i<49155 for i in ids),'Initial chat token bound/schema failed')
        rows.append(dict(case,original_input_ids=case['input_ids'],input_ids=ids,chat_messages=messages,chat_text=literal))
    require(len(rows)==20,'Fixed panel size changed')
    for row in rows[16:]:
        original=rows[int(row['repeat_of'][1:])]
        require(row['input_ids']==original['input_ids'] and row['chat_text']==original['chat_text'],'Chat repeat input changed')
    return rows


def prepare_tokens():
    require(not TOKENS.exists(),'Tokenizer preparation already attempted');review=reviews()
    decision,_=fixed_decision();old,*_=original_evidence();previous_evidence()
    TOKENS.mkdir();create(TOKENS/'STARTED.json',dict(at_utc=now(),source_sha256=source_hashes(),review_sha256=review))
    try:
        require(Path(sys.executable).resolve()==PYTHON.resolve(),'Pinned Python required')
        cache=validate_model_files(old,weights=False)
        import importlib.metadata
        require(all(importlib.metadata.version(n)==VERSIONS[n] for n in ('transformers','tokenizers')),'Pinned tokenizer versions differ')
        from transformers import AutoTokenizer
        tokenizer=AutoTokenizer.from_pretrained(str(ROOT/old['model_path']),local_files_only=True,trust_remote_code=False)
        require(tokenizer.eos_token_id==0 and hashlib.sha256(tokenizer.chat_template.encode()).hexdigest()==decision['model']['chat_template_sha256'],'Pinned template/EOS changed')
        rows=tokenize_cases(tokenizer,old['cases'],decision)
        require(validate_model_files(old,weights=False)==cache and review==reviews(),'Tokenizer inputs/sources changed')
        create(TOKENS/'TOKENS.json',rows)
        create(TOKENS/'COMPLETE.json',dict(status='TOKENIZER_PREFLIGHT_PASS',at_utc=now(),tokens_sha256=digest(TOKENS/'TOKENS.json'),
            source_sha256=source_hashes(),review_sha256=review,lengths=[len(r['input_ids']) for r in rows],
            literal_template_match=True,raw_encoding_match=True,decode_roundtrip=True,all4_repeat_inputs_exact=True,
            model_calls=0,weights_loaded=False,alternatives_tried=0))
        print(json.dumps(read(TOKENS/'COMPLETE.json')),flush=True)
    except BaseException as exc:
        create(TOKENS/'STOPPED.json',dict(status='TOKENIZER_PREFLIGHT_STOPPED',at_utc=now(),reason=repr(exc),model_calls=0,retry_allowed=False));raise


def build_plan():
    old,calls,original_inventory,lineage,decision=original_evidence();prior=previous_evidence()
    require((TOKENS/'COMPLETE.json').is_file() and not (TOKENS/'STOPPED.json').exists(),'No complete tokenizer preparation')
    token=read(TOKENS/'COMPLETE.json');cases=read(TOKENS/'TOKENS.json')
    require(token['status']=='TOKENIZER_PREFLIGHT_PASS' and token['tokens_sha256']==digest(TOKENS/'TOKENS.json')
        and token['source_sha256']==source_hashes() and len(cases)==20,'Tokenizer/source binding differs')
    for row,original in zip(cases,old['cases']):
        require({k:(row['original_input_ids'] if k=='input_ids' else row[k]) for k in original}==original,'Original semantic case changed')
        messages,text=literal_chat(original,decision)
        require(row['chat_messages']==messages and row['chat_text']==text and 1<=len(row['input_ids'])<=241,'Frozen chat rendering differs')
    for name in ('STARTED.json','TOKENS.json','COMPLETE.json'):lineage[str((TOKENS/name).relative_to(ROOT))]=digest(TOKENS/name)
    metadata={k:old[k] for k in ('model_path','model_cache_repository','model_files','expected_host_state')};validate_model_files(metadata)
    return dict(status='FIXED_OUTCOME_EXPOSED_CHAT_INTERFACE',created_at_utc=now(),settings=SETTINGS,versions=VERSIONS,
        **metadata,source_sha256=source_hashes(),lineage_sha256=lineage,review_sha256=reviews(),
        installed_model_source_path=str(MODEL_SOURCE.relative_to(ROOT)),installed_model_source_sha256=MODEL_SOURCE_SHA,
        original_directory=str(ORIGINAL.relative_to(ROOT)),original_plan_sha256=digest(ORIGINAL/'plan.json'),
        original_inventory=original_inventory,original_calls=calls,previous_directory=str(PREVIOUS.relative_to(ROOT)),
        previous_diagnostic_inventory=prior,cases=cases,decision=decision,decoding=decision['decoding'],parser=decision['parser'],
        collection_exclusions=list(EXCLUSIONS),original_native_gate_pass=False,automatic_transfer=False,
        scientific_confirmation=False,novelty_established=False,no_retry=True,scope=decision['scope'])


def register():
    require(not OUT.exists(),'Registration already exists');plan=build_plan();OUT.mkdir(parents=True);(OUT/'sources').mkdir()
    for name in SOURCES:shutil.copyfile(HERE/name,OUT/'sources'/name)
    create(OUT/'plan.json',plan);create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)


def verify(directory=OUT):
    directory=Path(directory);plan=read(directory/'plan.json');h=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==h,'Registration changed')
    require(plan['settings']==SETTINGS and plan['versions']==VERSIONS and plan['source_sha256']==source_hashes(),'Plan/source changed')
    require(plan['installed_model_source_sha256']==MODEL_SOURCE_SHA and digest(MODEL_SOURCE)==MODEL_SOURCE_SHA,'Native source changed')
    for name,expected in plan['source_sha256'].items():require(digest(directory/'sources'/Path(name).name)==expected,'Archived source changed')
    for group in ('lineage_sha256','review_sha256'):
        for name,expected in plan[group].items():require(digest(safe(ROOT,name))==expected,'Lineage/review changed')
    require(plan['original_directory']==str(ORIGINAL.relative_to(ROOT)) and inventory(ORIGINAL)==plan['original_inventory'],'Original archive changed')
    require(plan['previous_directory']==str(PREVIOUS.relative_to(ROOT)) and inventory(PREVIOUS)==plan['previous_diagnostic_inventory'],'Previous diagnosis changed')
    require(plan['cases']==read(TOKENS/'TOKENS.json') and plan['decision']==read(DECISION) and plan['decoding']==plan['decision']['decoding']
        and plan['parser']==plan['decision']['parser'] and plan['collection_exclusions']==list(EXCLUSIONS),'Scientific contract changed')
    require(plan['original_native_gate_pass'] is False and plan['automatic_transfer'] is False,'Old closure changed')
    return plan,h


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['tokenize','register']);args=parser.parse_args()
    {'tokenize':prepare_tokens,'register':register}[args.mode]()

