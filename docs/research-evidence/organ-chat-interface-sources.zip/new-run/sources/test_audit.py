"""Invented BF16 archives and a literal fake tokenizer; no model/real data."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib
import importlib.util
import json
from datetime import datetime,timedelta,timezone
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
spec=importlib.util.spec_from_file_location('chat_independent_audit',Path(__file__).with_name('audit.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

WORDS={0:'<EOS>',102:'on',103:'off',104:'.',105:' maybe',106:' and',107:'\n',112:' x',115:' \t',116:'\r\n',117:'<OTHER>',118:'ON'}
def save(path,value):path.write_text(json.dumps(value,allow_nan=False)+'\n')
def jsonl(path,rows):path.write_text(''.join(json.dumps(x,allow_nan=False)+'\n' for x in rows))
def logits(tokens):
    x=np.full((1,1,a.VOCAB),-16,dtype='<f4')
    for t in tokens:x[0,0,t]=1
    return x
def raw_pair(ids,x):return dict(input_ids=np.array([ids],dtype='<i8').tobytes(),full_logits=(x.view('<u4')>>16).astype('<u2').tobytes())


class Fixture:
    def __init__(self,directory,variant=None,raw_variant=None):
        self.root=Path(directory);(self.root/'calls').mkdir();self.sha='f'*64
        self.cases=a.expected_cases();self.paths=[];self.calls=[];self.encodings={};self.texts={}
        self.prior=dict(native=dict(native_gate_pass=False,primary=dict(n=16,correct=7,ties=0),rows=[]),
            readout=dict(original_native_gate_pass=False,primary=dict(n=16,correct=0,wrong=8,unresolved=8),rows=[]))
        for case in self.cases:
            old=[0]+[20]*39;old[1]=30+a.CARRIERS.index(case['carrier']);old[2]=40+case['a'];old[-1]=50+case['b']
            text=a.literal_chat(case['input_text']);base=int(case['repeat_of'][1:]) if case['phase']=='repeat' else case['index']
            ids=[200+base];self.texts[tuple(ids)]=text;self.encodings[text]=ids
            case.update(input_ids=ids,original_input_ids=old,prefix_index=20,candidate_ids={'on':544,'off':2126},
                chat_text=text,chat_messages=[dict(role='system',content=a.SYSTEM),dict(role='user',content=a.INSTRUCTION+case['input_text'])])
            sequence=[[102 if case['a']^case['b'] else 103],[0]]
            if variant is not None:sequence=variant(case,sequence)
            generated=[];indices=[];decisions=[];reason=None
            for local,winners in enumerate(sequence):
                index=len(self.calls);x=logits(winners)
                if raw_variant is not None:raw_variant(case,local,x)
                identity=dict(index=index,path_id=case['id'],path_index=case['index'],step=local+1)
                row=self.write_call(identity,ids+generated,x);self.calls.append(row);indices.append(index)
                selected=winners[0] if len(winners)==1 else None
                decisions.append(dict(source='new',call_index=index,maximizers=winners,selected_token=selected))
                if selected is None:reason='tie';text=self.decode(generated);parsed=text;break
                generated.append(selected);reason,text,parsed=a.terminal(generated,self.decode)
                if reason is not None:break
            assert reason is not None
            path={k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
            path.update(generated_ids=generated,decoded_text=text,parser_text=parsed,stop_reason=reason,
                call_indices=indices,forward_count=len(indices),decisions=decisions)
            self.paths.append(path)
            target='on' if case['a']^case['b'] else 'off'
            self.prior['native']['rows'].append(dict(id=case['id'],target=target,correct=case['index']<7))
            self.prior['readout']['rows'].append(dict(id=case['id'],target=target,outcome='wrong' if case['b']==0 else 'unresolved'))

    def decode(self,ids):
        if tuple(ids) in self.texts:return self.texts[tuple(ids)]
        return ''.join(WORDS[i] for i in ids)
    def encode(self,text):return self.encodings[text]
    def write_call(self,identity,ids,x):
        raw=raw_pair(ids,x);arrays={};descriptors={}
        for name,value in (('input_ids',np.array([ids],dtype='<i8')),('full_logits',x)):
            rb=np.frombuffer(raw[name],dtype='uint8');arrays[name+'__raw_uint8']=rb;arrays[name+'__value']=value
            descriptors[name]=dict(dtype='torch.int64' if name=='input_ids' else 'torch.bfloat16',shape=list(value.shape),
                raw_key=name+'__raw_uint8',value_key=name+'__value',raw_sha256=hashlib.sha256(raw[name]).hexdigest(),finite=bool(np.isfinite(value).all()))
        fp=f"calls/{identity['index']:04d}.npz";mp=fp[:-4]+'.json';np.savez_compressed(self.root/fp,**arrays)
        save(self.root/mp,dict(identity,plan_sha256=self.sha,tensors=descriptors))
        return dict(identity,forward_path=fp,forward_metadata_path=mp,forward_sha256=a.digest(self.root/fp),
                    forward_metadata_sha256=a.digest(self.root/mp),forward_completed=True,controls_pass=True,error=None)

    def chains(self):
        a.validate_cases(self.cases,self.decode,self.encode)
        return [a.validate_chain(c,p,self.calls,self.root,self.sha,self.decode) for c,p in zip(self.cases,self.paths)]
    def grade(self):return a.grade_complete(self.chains(),self.prior)
    def seal_archive(self):
        sources={f'invented/{name}':'0'*64 for name in ('protocol.py','worker.py','owner.py','audit.py','test_native.py','test_audit.py')}
        states={f'p{i}':'a'*64 for i in range(219)}
        plan=dict(cases=self.cases,source_sha256=sources,
            expected_host_state=states,model_files={'config.json':'b'*64},versions={'numpy':np.__version__},installed_model_source_sha256='c'*64,
            settings=dict(max_rss_bytes=10*1024**3,max_mps_bytes=10*1024**3,max_archive_bytes=1024**3),
            parser=dict(require_eos=True,strip_characters=[32,9,13,10],body_values=['on','off']),
            decoding=dict(max_generated_tokens_per_path=16,max_total_forwards=320,eos_id=0),
            collection_exclusions=['COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl'])
        save(self.root/'plan.json',plan);save(self.root/'REGISTRATION.json',{'plan_sha256':self.sha})
        (self.root/'sources').mkdir()
        for name in sources:(self.root/'sources'/Path(name).name).write_text('invented\n')
        for name in ('worker.log','independent_audit.log','owner-events.jsonl'):(self.root/name).write_text('')
        base=datetime(2026,1,1,tzinfo=timezone.utc);at=lambda x:(base+timedelta(seconds=x)).isoformat()
        save(self.root/'STARTED.json',dict(at_utc=at(0),deadline_utc=at(900),owner_pid=111,plan_sha256=self.sha))
        save(self.root/'WORKER_STARTED.json',dict(at_utc=at(.1),deadline_utc=at(900),owner_pid=111,worker_pid=112,plan_sha256=self.sha))
        jsonl(self.root/'calls.jsonl',self.calls);jsonl(self.root/'paths.jsonl',self.paths)
        identity=dict(training={'':True},requires_grad={f'p{i}':True for i in range(218)},parameters={f'p{i}':[i+1,i+1000,'mps:0','torch.bfloat16'] for i in range(218)},
            buffers={},grads_none={f'p{i}':True for i in range(218)},hooks={},forward_methods={'':[False,999]},generation_config={},
            config=dict(hidden_size=1024,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,vocab_size=a.VOCAB,logits_scaling=6.,use_cache=True))
        for name in ('IDENTITY_BEFORE.json','IDENTITY_AFTER.json'):save(self.root/name,identity)
        configured=json.loads(json.dumps(identity));configured.update(training={'':False},requires_grad={k:False for k in identity['parameters']});configured['config']['use_cache']=False
        save(self.root/'IDENTITY_CONFIGURED.json',configured)
        for name in ('STATE_BEFORE.json','STATE_AFTER.json'):save(self.root/name,states)
        for name in ('MODEL_CACHE_BEFORE.json','MODEL_CACHE_AFTER.json'):save(self.root/name,{'config.json':{'sha256':'b'*64}})
        save(self.root/'RUNTIME.json',dict(versions=plan['versions'],device='mps',dtype='torch.bfloat16',threads=4,initial_seed=42,
            attention='eager',cache=False,no_task_hooks=True,logits_to_keep=1,model_source_sha256='c'*64,decoder='tokenizers.Tokenizer.decode',skip_special_tokens=False))
        events=[dict(event='worker_started'),dict(event='model_load_started'),dict(event='model_load_finished')]
        resources=[('before_load',None,None),('after_load',None,None)]
        for path in self.paths:
            events.append(dict(event='path_started',id=path['id'],index=path['index']))
            for j,index in enumerate(path['call_indices']):
                for kind in ('forward_started','forward_returned','call_saved'):
                    e=dict(event=kind,index=index,path_id=path['id'],step=j+1)
                    if kind=='call_saved':e['controls_pass']=True
                    events.append(e)
                resources.extend((s,path['id'],index) for s in ('before_forward','after_forward'))
            events.append(dict(event='path_completed',id=path['id'],index=path['index'],forward_count=path['forward_count'],stop_reason=path['stop_reason']))
        events.append(dict(event='worker_completed'));resources.append(('complete',None,None))
        for i,event in enumerate(events):event['at_utc']=at(1+i*.1)
        jsonl(self.root/'worker-events.jsonl',events)
        samples=[dict(stage=s,call_id=p,call_index=i,at_utc=at(1+k*.1),elapsed_seconds=1+k*.1,rss_high_water_bytes=1000,
            mps_driver_bytes=2000,mps_allocated_bytes=1000,archive_bytes=3000) for k,(s,p,i) in enumerate(resources)]
        jsonl(self.root/'worker-resources.jsonl',samples)
        jsonl(self.root/'resource-monitor.jsonl',[dict(stage=s,pid=112,at_utc=at(t),elapsed_seconds=t,child_tree_rss_bytes=2000,archive_bytes=3000)
            for s,t in (('worker',1),('worker',800),('independent_audit',801))])
        counts=a.operation_counts(self.chains())
        save(self.root/'WORKER_COMPLETE.json',dict(status='WORKER_COLLECTED_UNGRADED',at_utc=at(800),plan_sha256=self.sha,counts=counts,
            resource_samples=samples,all_structural_controls_pass=True,state_unchanged=True,ownership_restored=True,cache_unchanged=True,
            paths_completed=20,task_scores_computed=False))
        excluded=set(plan['collection_exclusions'])
        hashes={str(p.relative_to(self.root)):a.digest(p) for p in self.root.rglob('*') if p.is_file() and str(p.relative_to(self.root)) not in excluded}
        save(self.root/'COLLECTED.json',dict(status='COLLECTED_UNGRADED',plan_sha256=self.sha,counts=counts,artifact_sha256=hashes,task_scores_computed=False))
        return plan


class ParserTests(unittest.TestCase):
    def test_eos_required_exact_outer_ascii_strip(self):
        for word in ('on','off'):
            for outer in ('',' ','\t\r\n'):
                self.assertEqual(a.parse_answer(outer+word+outer,'eos'),(word,'accepted'))
            for reason in ('tie','cap'):self.assertIsNone(a.parse_answer(word,reason)[0])

    def test_no_punctuation_explanation_or_other_token_rescue(self):
        for text in ('on.','on!','on or off','ON','on\noff','o n','on<EOS>','<OTHER>on','\u00a0on','on\v'):
            with self.subTest(text=text):self.assertEqual(a.parse_answer(text,'eos'),(None,'unresolved_format'))

    def test_only_eos_tie_cap_not_state_or_punctuation_stops(self):
        decode=lambda ids:''.join(WORDS[i] for i in ids)
        for ids in ([102],[102,104],[102,107]):self.assertIsNone(a.terminal(ids,decode)[0])
        self.assertEqual(a.terminal([102,0],decode),('eos','on<EOS>','on'))
        self.assertEqual(a.terminal([112]*15+[0],decode)[0],'eos')
        self.assertEqual(a.terminal([112]*16,decode)[0],'cap')


class ArchiveTests(unittest.TestCase):
    def fixture(self,variant=None,raw_variant=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);return Fixture(temp.name,variant,raw_variant)

    def test_complete20_fresh_truth_quartets_and_repeats(self):
        f=self.fixture();r=f.grade()
        self.assertEqual(r['primary'],dict(n=16,correct=16,wrong=0,unresolved=0))
        self.assertTrue(r['behavioral_success']);self.assertTrue(r['repeat_answer_consistency_pass'])
        self.assertTrue(r['repeat_raw_stability_pass']);self.assertTrue(r['repeat_text_path_pass'])
        self.assertTrue(all(g['quartet_complete_correct'] for g in r['groups'].values()))
        self.assertEqual(r['operations']['copy']['correct'],8);self.assertEqual(r['operations']['invert']['correct'],8)
        self.assertFalse(r['original_native_gate_pass']);self.assertFalse(r['automatic_transfer'])
        self.assertTrue(all(x['decisions'][0]['source']=='new' for x in f.paths))

    def test_wrong_tie_cap_unmatched_stay_in_denominator(self):
        def change(c,s):
            return {0:[[102],[0]],1:[[102,103]],2:[[112]]*16,3:[[102],[104],[0]]}.get(c['index'],s)
        r=self.fixture(change).grade()
        self.assertEqual(r['primary'],dict(n=16,correct=12,wrong=1,unresolved=3))
        self.assertFalse(r['behavioral_success']);self.assertEqual(len(r['rows']),20)
        self.assertEqual(r['rows'][2]['forward_count'],16)

    def test_finite_raw_repeat_variation_does_not_fail_behavior(self):
        def vary(c,step,x):
            if c['index']==16:x[0,0,400]=-8
        r=self.fixture(raw_variant=vary).grade()
        self.assertTrue(r['behavioral_success']);self.assertFalse(r['repeat_raw_stability_pass'])
        self.assertTrue(r['repeat_text_path_pass']);self.assertEqual(r['repeats']['full_raw_exact_matches'],3)

    def test_outer_whitespace_repeat_same_answer_despite_text_change(self):
        r=self.fixture(lambda c,s:[[115]]+s if c['index']==16 else s).grade()
        self.assertTrue(r['behavioral_success']);self.assertTrue(r['repeat_answer_consistency_pass'])
        self.assertFalse(r['repeat_text_path_pass']);self.assertFalse(r['repeat_raw_stability_pass'])

    def test_repeat_different_accepted_state_does_not_replace_primary(self):
        r=self.fixture(lambda c,s:[[102],[0]] if c['index']==16 else s).grade()
        self.assertEqual(r['primary']['correct'],16);self.assertFalse(r['behavioral_success'])
        self.assertFalse(r['repeat_answer_consistency_pass']);self.assertEqual(r['repeats']['same_accepted_states'],3)

    def test_chat_role_and_independent_token_roundtrip_guards(self):
        f=self.fixture();f.cases[0]['chat_messages'][0]['role']='user'
        with self.assertRaisesRegex(a.AuditError,'serialization'):f.chains()
        f=self.fixture();f.cases[0]['chat_text']+=' '
        with self.assertRaisesRegex(a.AuditError,'serialization'):f.chains()
        f=self.fixture();f.encodings[f.cases[0]['chat_text']]=[999]
        with self.assertRaisesRegex(a.AuditError,'roundtrip'):f.chains()

    def test_forced_answer_and_reused_first_selection_rejected(self):
        f=self.fixture();f.paths[0]['generated_ids'][0]=102
        with self.assertRaisesRegex(a.AuditError,'Recorded greedy'):f.chains()
        f=self.fixture();f.paths[0]['decisions'][0]['source']='original'
        with self.assertRaisesRegex(a.AuditError,'Recorded greedy'):f.chains()

    def test_incomplete_chain_and_call_after_terminal_rejected(self):
        f=self.fixture();f.paths[0]['call_indices']=f.paths[0]['call_indices'][:1]
        with self.assertRaisesRegex(a.AuditError,'Incomplete path'):f.chains()
        f=self.fixture();f.paths[0]['call_indices'].append(2)
        with self.assertRaisesRegex(a.AuditError,'Extra call'):f.chains()

    def test_actual_growing_ids_rejected(self):
        f=self.fixture();row=f.calls[1];identity={k:row[k] for k in ('index','path_id','path_index','step')}
        f.calls[1]=f.write_call(identity,f.cases[0]['input_ids']+[102],logits([0]))
        with self.assertRaisesRegex(a.AuditError,'Growing input'):f.chains()

    def test_last_path_nonfinite_prevents_any_grade(self):
        f=self.fixture();i=len(f.calls)-1;row=f.calls[i];identity={k:row[k] for k in ('index','path_id','path_index','step')}
        x=logits([0]);x[0,0,200]=np.inf
        f.calls[i]=f.write_call(identity,f.cases[-1]['input_ids']+[103],x)
        with patch.object(a,'parse_answer',side_effect=AssertionError('must not grade')) as spy:
            with self.assertRaisesRegex(a.AuditError,'Nonfinite'):f.grade()
            spy.assert_not_called()

    def test_raw_readable_hash_and_shape_guards(self):
        for kind in ('shape','raw_sha256'):
            f=self.fixture();p=f.root/f.calls[0]['forward_metadata_path'];m=a.read(p)
            m['tensors']['full_logits'][kind]=[a.VOCAB] if kind=='shape' else '0'*64;save(p,m)
            f.calls[0]['forward_metadata_sha256']=a.digest(p)
            with self.assertRaises(a.AuditError):f.chains()
        f=self.fixture();row=f.calls[0];p=f.root/row['forward_path']
        with np.load(p) as z:arrays={k:z[k].copy() for k in z.files}
        arrays['full_logits__value'][0,0,400]=-8;np.savez_compressed(p,**arrays);row['forward_sha256']=a.digest(p)
        with self.assertRaisesRegex(a.AuditError,'Readable/raw'):f.chains()

    def test_closed_prior_gate_cannot_be_repaired(self):
        f=self.fixture();f.prior['native']['native_gate_pass']=True
        with self.assertRaisesRegex(a.AuditError,'Closed prior'):f.grade()

    def test_complete_saved_archive_then_all20_grade(self):
        f=self.fixture();plan=f.seal_archive()
        r=a.audit_records(f.root,plan,f.sha,f.decode,f.encode,f.prior)
        self.assertEqual(r['physical_counts']['forward_finished'],40)
        self.assertEqual(r['physical_counts']['generated_tokens'],40)
        self.assertEqual(r['resources']['worker_events'],164)
        self.assertEqual(r['resources']['worker_resource_samples'],83)
        self.assertTrue(r['behavioral_success']);self.assertFalse(r['controls']['original_logits_reused'])

    def test_saved_final_journal_corruption_prevents_any_grade(self):
        f=self.fixture();plan=f.seal_archive();path=f.root/'worker-events.jsonl'
        events=a.lines(path);events[-1]['event']='not_complete';jsonl(path,events)
        c=a.read(f.root/'COLLECTED.json');c['artifact_sha256']['worker-events.jsonl']=a.digest(path);save(f.root/'COLLECTED.json',c)
        with patch.object(a,'parse_answer',side_effect=AssertionError('must not grade')) as spy:
            with self.assertRaisesRegex(a.AuditError,'Journal order'):a.audit_records(f.root,plan,f.sha,f.decode,f.encode,f.prior)
            spy.assert_not_called()


if __name__=='__main__':unittest.main()
