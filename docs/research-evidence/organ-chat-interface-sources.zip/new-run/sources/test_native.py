"""Invented tests for the new chat input and fresh generation paths; no model."""
from pathlib import Path
from unittest import mock
import json
import tempfile
import unittest
import numpy as np
import protocol as p
import worker
import owner


def cases():
    rows=[dict(index=i,id=f'n{i:02d}',phase='primary',repeat_of=None,
        carrier=('lamp','light','sign','indicator')[i//4],a=(i//2)%2,b=i%2,
        input_ids=[0,100+i],input_text=f'invented passage {i}') for i in range(16)]
    return rows+[dict(rows[j],index=16+k,id=f'n{16+k:02d}',phase='repeat',repeat_of=f'n{j:02d}')
                 for k,j in enumerate((0,5,10,15))]


class FakeTokenizer:
    def __init__(self):self.strings={};self.reverse={};self.calls=[]
    def encode(self,text,add_special_tokens=False):
        assert add_special_tokens is False
        if text not in self.strings:
            n=len(self.strings)+1;self.strings[text]=[n];self.reverse[n]=text
        return self.strings[text]
    def decode(self,ids,**kwargs):return self.reverse[ids[0]]
    def apply_chat_template(self,messages,**kwargs):
        self.calls.append(kwargs)
        assert kwargs['add_generation_prompt'] is True and kwargs['controls']==[]
        text=''.join('<|start_of_role|>'+m['role']+'<|end_of_role|>'+m['content']+'<|end_of_text|>\n' for m in messages)
        text+='<|start_of_role|>assistant<|end_of_role|>'
        return self.encode(text) if kwargs['tokenize'] else text


class InputTests(unittest.TestCase):
    def test_exact_literal_package_and_repeats(self):
        decision={'package':{'system_text':'fixed system','instruction_prefix':'Complete:\n\n'}}
        tok=FakeTokenizer();rows=p.tokenize_cases(tok,cases(),decision)
        self.assertEqual(len(rows),20);self.assertEqual(len(tok.calls),40)
        self.assertEqual(rows[0]['chat_messages'],[{'role':'system','content':'fixed system'},
            {'role':'user','content':'Complete:\n\ninvented passage 0'}])
        self.assertEqual(rows[0]['original_input_ids'],[0,100]);self.assertEqual(rows[0]['input_ids'],[1])
        self.assertEqual(rows[0]['input_ids'],rows[16]['input_ids'])
        self.assertFalse(rows[0]['chat_text'].startswith('<|end_of_text|>'))
    def test_reject_changed_template_before_model(self):
        tok=FakeTokenizer();original=tok.apply_chat_template
        tok.apply_chat_template=lambda m,**kw: original(m,**kw)+'extra' if not kw['tokenize'] else original(m,**kw)
        with self.assertRaisesRegex(ValueError,'literal'):
            p.tokenize_cases(tok,cases(),{'package':{'system_text':'s','instruction_prefix':'i'}})
    def test_reject_roundtrip_or_overlength(self):
        tok=FakeTokenizer();tok.decode=lambda ids,**kw:'changed'
        with self.assertRaisesRegex(ValueError,'roundtrip'):
            p.tokenize_cases(tok,cases(),{'package':{'system_text':'s','instruction_prefix':'i'}})
    def test_reviews_reject_stale_source_binding(self):
        with tempfile.TemporaryDirectory() as tmp:
            prep=Path(tmp)
            for n in ('SOURCE_REVIEW.json','PREPARATION_TESTS.json'):
                p.create(prep/n,{'status':'PASS','source_sha256':{'wrong':'hash'}})
            with mock.patch.object(p,'PREP',prep),mock.patch.object(p,'source_hashes',return_value={'right':'hash'}):
                with self.assertRaisesRegex(ValueError,'stale'):p.reviews()


class PathsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.out=Path(self.tmp.name)
        patch=mock.patch.object(p,'OUT',self.out);patch.start();self.addCleanup(patch.stop)
        self.counts=worker.initial_counts();self.trace=[];self.last={};self.progress={};self.rows=cases()
    def forward(self,c):self.trace.append(('forward',c['index'],c['input_ids']));return {'ids':c['input_ids'],'step':c['step']}
    def store(self,c,v):self.trace.append(('retain',c['index']));return {'invented_retained':True}
    def validate(self,c,v):self.trace.append(('validate',c['index']))
    def choose(self,v):return dict(maximizers=[1 if v['step']==1 else 0],selected_token=1 if v['step']==1 else 0)
    def decode(self,ids):return ''.join({0:'<EOS>',1:'on',2:'.',3:'\n',4:'off'}[i] for i in ids)
    def event(self,name,**kw):self.trace.append((name,kw.get('index')))
    def run_paths(self,**kwargs):
        args=dict(cases=self.rows,forward=self.forward,retain_call=self.store,validate=self.validate,
            choose=self.choose,decode=self.decode,event=self.event,guard=lambda *a:None,
            counts=self.counts,last=self.last,progress=self.progress)
        args.update(kwargs);return worker.run_paths(**args)
    def test_all20_fresh_first_calls_and_whole_repeats(self):
        rows=self.run_paths();self.assertEqual(len(rows),20);self.assertEqual(self.counts['forward_finished'],40)
        self.assertEqual(self.counts['generated_tokens'],40);self.assertEqual(self.counts['new_tokens_selected'],40)
        self.assertNotIn('reused_tokens',self.counts)
        for row,case in zip(rows,self.rows):
            self.assertEqual(row['generated_ids'],[1,0]);self.assertEqual(row['stop_reason'],'eos')
            self.assertEqual(row['parser_text'],'on');self.assertEqual(row['decoded_text'],'on<EOS>')
            self.assertTrue(all(d['source']=='new' for d in row['decisions']))
            self.assertIn(('forward',row['call_indices'][0],case['input_ids']),self.trace)
            for i in row['call_indices']:self.assertLess(self.trace.index(('retain',i)),self.trace.index(('validate',i)))
        self.assertEqual([r['call_indices'] for r in rows[16:]],[[32,33],[34,35],[36,37],[38,39]])
    def test_full320_call_cap_and_no_punctuation_stop(self):
        rows=self.run_paths(choose=lambda v:dict(maximizers=[2],selected_token=2))
        self.assertEqual(self.counts['forward_finished'],320)
        self.assertTrue(all(r['stop_reason']=='cap' and r['forward_count']==16 and len(r['generated_ids'])==16 for r in rows))
        self.assertIsNone(worker.text_state([1,3],self.decode)[2])
    def test_first_tie_retained_without_token_or_retry(self):
        rows=self.run_paths(choose=lambda v:dict(maximizers=[1,4],selected_token=None))
        self.assertEqual(self.counts['forward_finished'],20);self.assertEqual(self.counts['generated_tokens'],0)
        self.assertTrue(all(r['generated_ids']==[] and r['stop_reason']=='tie' and r['decisions'][0]['maximizers']==[1,4] for r in rows))
    def test_immediate_eos_kept_but_empty_parser_text(self):
        rows=self.run_paths(choose=lambda v:dict(maximizers=[0],selected_token=0))
        self.assertTrue(all(r['generated_ids']==[0] and r['decoded_text']=='<EOS>' and r['parser_text']=='' for r in rows))
    def test_last_possible_input_length(self):
        self.rows=[dict(r,input_ids=[7]*241) for r in self.rows]
        self.run_paths(choose=lambda v:dict(maximizers=[1],selected_token=1))
        self.assertEqual(max(len(x[2]) for x in self.trace if x[0]=='forward'),256)
    def test_failed_return_journal_preserves_raw_before_stop(self):
        def broken(name,**kw):
            if name=='forward_returned':raise OSError('invented journal')
        with self.assertRaisesRegex(OSError,'journal'):self.run_paths(event=broken)
        self.assertEqual(self.counts['forward_finished'],1);self.assertIn(('retain',0),self.trace)
        self.assertFalse(json.loads((self.out/'calls.jsonl').read_text())['controls_pass'])
    def test_nonfinite_validation_preserves_return(self):
        def broken(*a):raise ValueError('invented nonfinite')
        with self.assertRaisesRegex(ValueError,'nonfinite'):self.run_paths(validate=broken)
        self.assertIn(('retain',0),self.trace);self.assertEqual(self.counts['forward_finished'],1)
        self.assertFalse((self.out/'paths.jsonl').exists())
    def test_forward_failure_is_not_a_return(self):
        def broken(*a):raise RuntimeError('invented forward')
        with self.assertRaisesRegex(RuntimeError,'forward'):self.run_paths(forward=broken)
        self.assertEqual(self.counts['forward_attempts'],1);self.assertEqual(self.counts['forward_finished'],0)
    def test_exact_greedy_ties_and_nonfinite(self):
        x=np.zeros(49155,dtype=np.float32);x[7]=x[8]=1
        self.assertEqual(worker.strict_max(x,np),dict(maximizers=[7,8],selected_token=None))
        x[8]=2;self.assertEqual(worker.strict_max(x,np)['selected_token'],8)
        x[49154]=np.nan
        with self.assertRaisesRegex(ValueError,'nonfinite'):worker.strict_max(x,np)


if __name__=='__main__':unittest.main()
