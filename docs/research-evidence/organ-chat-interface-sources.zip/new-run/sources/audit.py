"""Independent official-chat greedy/EOS audit. No model imports or calls.
All20 complete raw chains and control evidence precede every semantic grade.
Source-level metadata validation is adapted from the closed readout auditor;
chat serialization, fresh-call chains and behavior/repeat gates are implemented here.
"""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import math
import os
import re
import subprocess
import time
import numpy as np
VOCAB=49155
CARRIERS=('lamp','light','sign','indicator')
SYSTEM="Knowledge Cutoff Date: April 2024.\nToday's Date: October 06, 2026.\nYou are Granite, developed by IBM. You are a helpful AI assistant."
INSTRUCTION='Complete the final sentence in the passage below. Reply with exactly one lowercase word, on or off, and no punctuation or explanation.\n\n'


def literal_chat(text):
    return ('<|start_of_role|>system<|end_of_role|>'+SYSTEM+'<|end_of_text|>\n'
        '<|start_of_role|>user<|end_of_role|>'+INSTRUCTION+text+'<|end_of_text|>\n'
        '<|start_of_role|>assistant<|end_of_role|>')


def validate_cases(cases,decode,encode):
    require(len(cases)==20,'Missing semantic cases')
    for case,expected in zip(cases,expected_cases()):
        require(same({k:case[k] for k in expected},expected),'Semantic case/text/order differs')
        require(set(case)==set(expected)|{'input_ids','original_input_ids','prefix_index','candidate_ids','chat_messages','chat_text'},'Case field set differs')
        messages=[{'role':'system','content':SYSTEM},{'role':'user','content':INSTRUCTION+case['input_text']}]
        require(same(case['chat_messages'],messages) and case['chat_text']==literal_chat(case['input_text']),'Official literal role serialization differs')
        ids=case['input_ids'];old=case['original_input_ids']
        require(type(ids) is list and 1<=len(ids)<=241 and all(type(x) is int and 0<=x<VOCAB for x in ids),'Invalid chat IDs')
        require(type(old) is list and len(old) in (40,44) and old[0]==0 and all(type(x) is int and 0<=x<VOCAB for x in old),'Invalid original token binding')
        require(same(case['candidate_ids'],{'on':544,'off':2126}) and type(case['prefix_index']) is int,'Original metadata changed')
        require(decode(ids)==case['chat_text'] and encode(case['chat_text'])==ids,'Chat raw encode/roundtrip differs')
        if case['phase']=='repeat':
            donor=cases[int(case['repeat_of'][1:])]
            require(ids==donor['input_ids'] and old==donor['original_input_ids'],'Repeat input differs')


def terminal(ids,decode):
    text=decode(ids)
    if ids and ids[-1]==0:return 'eos',text,decode(ids[:-1])
    if len(ids)==16:return 'cap',text,text
    return None,text,text


def parse_answer(text,reason):
    if reason!='eos':
        require(reason in ('tie','cap'),'Unknown path stop reason')
        return None,'unresolved_'+reason
    answer=text.strip(' \t\r\n')
    return (answer,'accepted') if answer in ('on','off') else (None,'unresolved_format')


def validate_chain(case,path,calls,directory,plan_sha,decode):
    keys=('index','id','phase','repeat_of','carrier','a','b')
    require(same({k:path[k] for k in keys},{k:case[k] for k in keys}),'Path identity differs')
    indices=path['call_indices']
    require(type(indices) is list and 1<=len(indices)<=16 and all(type(i) is int and 0<=i<len(calls) for i in indices),'Invalid path call indices')
    ids=[];steps=[];decisions=[];reason=None;text='';parser_text=''
    for local,index in enumerate(indices):
        require(reason is None,'Extra call after declared terminal')
        row=calls[index];identity=dict(index=index,path_id=case['id'],path_index=case['index'],step=local+1)
        require(same({k:row[k] for k in identity},identity),'Call order/identity differs')
        expected=case['input_ids']+ids;require(len(expected)<=256,'Maximum forward input length exceeded')
        loaded=bundle(directory,row,identity,expected,plan_sha);steps.append(loaded)
        winners=maximal_ids(loaded['values']['full_logits']);selected=winners[0] if len(winners)==1 else None
        decisions.append(dict(source='new',call_index=index,maximizers=winners,selected_token=selected))
        if selected is None:reason='tie';text=decode(ids);parser_text=text
        else:ids.append(selected);reason,text,parser_text=terminal(ids,decode)
    require(reason is not None,'Incomplete path before EOS/tie/cap')
    expected=dict(generated_ids=ids,decoded_text=text,parser_text=parser_text,stop_reason=reason,forward_count=len(steps),decisions=decisions)
    require(same({k:path[k] for k in expected},expected),'Recorded greedy chain differs')
    return dict(case=case,path=path,steps=steps,**expected)


def grade_complete(chains,prior):
    require(len(chains)==20,'No grading incomplete panel')
    rows=[]
    for c in chains:
        case=c['case'];state,why=parse_answer(c['parser_text'],c['stop_reason']);target='on' if case['a']^case['b'] else 'off'
        row={k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
        row.update(target=target,parsed_state=state,outcome='unresolved' if state is None else 'correct' if state==target else 'wrong',
            parser_reason=why,**{k:c[k] for k in ('generated_ids','decoded_text','parser_text','stop_reason','forward_count')})
        rows.append(row)
    def counts(selected):return dict(n=len(selected),**{k:sum(r['outcome']==k for r in selected) for k in ('correct','wrong','unresolved')})
    groups={}
    for carrier in CARRIERS:
        selected=[r for r in rows[:16] if r['carrier']==carrier]
        groups[carrier]=dict(**counts(selected),quartet_complete_correct=all(r['outcome']=='correct' for r in selected),
            operations={name:counts([r for r in selected if r['b']==b]) for b,name in ((0,'copy'),(1,'invert'))})
    repeats=[]
    for i in range(16,20):
        j=int(rows[i]['repeat_of'][1:]);x,y=chains[i],chains[j]
        raw=len(x['steps'])==len(y['steps']) and all(u['raw']==v['raw'] for u,v in zip(x['steps'],y['steps']))
        keys=('generated_ids','decoded_text','parser_text','stop_reason','forward_count')
        path=same({k:x[k] for k in keys},{k:y[k] for k in keys})
        parsed=rows[i]['parsed_state'] is not None and rows[i]['parsed_state']==rows[j]['parsed_state']
        repeats.append(dict(id=rows[i]['id'],repeat_of=rows[j]['id'],full_raw_exact=raw,full_path_exact=path,same_accepted_state=parsed))
    primary=counts(rows[:16]);repeat_answer=all(r['same_accepted_state'] for r in repeats)
    require(prior['native']['primary']=={'n':16,'correct':7,'ties':0} and prior['native']['native_gate_pass'] is False
        and prior['readout']['primary']=={'n':16,'correct':0,'wrong':8,'unresolved':8}
        and prior['readout']['original_native_gate_pass'] is False,'Closed prior measurements differ')
    paired={name:{} for name in ('native_candidate','bounded_continuation')}
    for name,oldkey in (('native_candidate','native'),('bounded_continuation','readout')):
        labels=('correct','wrong') if oldkey=='native' else ('correct','wrong','unresolved')
        for label in labels:
            selected=[]
            for row,old in zip(rows[:16],prior[oldkey]['rows'][:16]):
                require(old['id']==row['id'] and old['target']==row['target'],'Prior report row differs')
                oldout=('correct' if old['correct'] else 'wrong') if oldkey=='native' else old['outcome']
                if oldout==label:selected.append(row)
            paired[name][label]=counts(selected)
    return dict(status='CHAT_INTERFACE_COMPLETE',implementation_pass=True,original_native_gate_pass=False,old_diagnostic_closed=True,
        automatic_transfer=False,novelty_established=False,primary=primary,groups=groups,rows=rows,
        operations={name:counts([r for r in rows[:16] if r['b']==b]) for b,name in ((0,'copy'),(1,'invert'))},
        behavioral_success=primary['correct']==16 and repeat_answer,repeat_answer_consistency_pass=repeat_answer,
        repeat_raw_stability_pass=all(r['full_raw_exact'] for r in repeats),repeat_text_path_pass=all(r['full_path_exact'] for r in repeats),
        repeats=dict(n=4,same_accepted_states=sum(r['same_accepted_state'] for r in repeats),full_raw_exact_matches=sum(r['full_raw_exact'] for r in repeats),
            full_path_exact_matches=sum(r['full_path_exact'] for r in repeats),rows=repeats),
        paired_closed_measures=paired,
        stop_reasons={k:sum(r['stop_reason']==k for r in rows[:16]) for k in ('eos','tie','cap')},
        parser_reasons={k:sum(r['parser_reason']==k for r in rows[:16]) for k in ('accepted','unresolved_format','unresolved_tie','unresolved_cap')},
        scope=['One outcome-exposed official-chat interface package on16 fixed semantic cases plus4 repeats.',
            'Role delimiters, system context, completion instruction and answer boundary change together; no isolated formatting-cause inference.',
            'EOS-terminated lowercase whole-answer behavior is measured; raw repeatability is separately descriptive.',
            'Both original closed results remain unchanged. No automatic transfer, internal mechanism, novelty, p-value or general competence claim.'])


def operation_counts(chains):
    n=sum(len(x['steps']) for x in chains);generated=sum(len(x['generated_ids']) for x in chains)
    return dict(model_load_attempts=1,model_load_finished=1,paths_started=20,paths_finished=20,forward_attempts=n,
        forward_finished=n,calls_saved=n,generated_tokens=generated,new_tokens_selected=generated,
        hooks=0,fits=0,backwards=0,optimizer_steps=0,provider_calls=0)
class AuditError(ValueError):pass


def require(ok,message):
    if not ok:raise AuditError(message)


def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def same(a,b):return canonical(a)==canonical(b)


def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def read(path):return json.loads(Path(path).read_text(),parse_constant=lambda x:(_ for _ in ()).throw(AuditError(x)))


def lines(path):return [json.loads(x) for x in Path(path).read_text().splitlines()]


def live_lines(path):
    data=Path(path).read_bytes();end=data.rfind(b'\n')
    return [json.loads(x) for x in data[:end+1].splitlines()] if end>=0 else []


def create(path,value):
    with Path(path).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def safe(root,name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe archive path')
    p=Path(root)/name;require(p.is_file() and p.resolve().is_relative_to(Path(root).resolve()),'Missing/escaping archive file');return p


def timestamp(v):return datetime.fromisoformat(v.replace('Z','+00:00')).timestamp()


def finite_number(v):return type(v) in (int,float) and math.isfinite(v)


def expected_cases():
    cases=[]
    for carrier in CARRIERS:
        for a in (0,1):
            for b in (0,1):
                prefix=f'The {carrier} has exactly two states: on and off.\nInitially, the {carrier} is '+('on' if a else 'off')+'.'
                suffix=f'\n\nThe {carrier} is then '+('left in the same state' if b==0 else 'switched to the opposite state')+f'.\nAfter this, the {carrier} is'
                cases.append(dict(index=len(cases),id=f'n{len(cases):02d}',phase='primary',repeat_of=None,
                    carrier=carrier,a=a,b=b,prefix_text=prefix,suffix_text=suffix,input_text=prefix+suffix))
    for i in range(4):cases.append(dict(cases[4*i+2*(i//2)+i%2],index=16+i,id=f'n{16+i:02d}',phase='repeat',repeat_of=f'n{4*i+2*(i//2)+i%2:02d}'))
    return cases


def bundle(root,row,identity,expected_ids,plan_sha):
    fp,mp=(safe(root,row[k]) for k in ('forward_path','forward_metadata_path'))
    require(digest(fp)==row['forward_sha256'] and digest(mp)==row['forward_metadata_sha256'],'Bundle file hash differs')
    meta=read(mp)
    require(meta['plan_sha256']==plan_sha and same({k:meta[k] for k in identity},identity),'Bundle identity differs')
    require(set(meta['tensors'])=={'input_ids','full_logits'},'Tensor set differs')
    result={};raw={}
    with np.load(fp,allow_pickle=False) as z:
        require(set(z.files)=={k+s for k in meta['tensors'] for s in ('__raw_uint8','__value')},'NPZ members differ')
        for name in ('input_ids','full_logits'):
            m=meta['tensors'][name];shape=[1,len(expected_ids)] if name=='input_ids' else [1,1,VOCAB]
            dtype='torch.int64' if name=='input_ids' else 'torch.bfloat16'
            require(m['dtype']==dtype and same(m['shape'],shape) and m['raw_key']==name+'__raw_uint8'
                and m['value_key']==name+'__value','Tensor descriptor differs')
            r=z[m['raw_key']];value=z[m['value_key']]
            require(r.dtype==np.dtype('uint8') and r.ndim==1 and r.size==int(np.prod(shape))*(8 if name=='input_ids' else 2),'Raw tensor shape/size differs')
            bits=r.tobytes();require(hashlib.sha256(bits).hexdigest()==m['raw_sha256'],'Raw tensor hash differs')
            if name=='input_ids':decoded=np.frombuffer(bits,dtype='<i8').reshape(shape)
            else:decoded=(np.frombuffer(bits,dtype='<u2').astype('<u4')<<16).view('<f4').reshape(shape)
            require(value.dtype.str==decoded.dtype.str and list(value.shape)==shape and value.tobytes()==decoded.tobytes(),'Readable/raw bytes differ')
            require(np.isfinite(decoded).all() and m['finite'] is True,'Nonfinite raw tensor')
            result[name]=decoded.copy();raw[name]=bits
    require(result['input_ids'].tolist()==[expected_ids],'Growing input chain differs')
    require(row['forward_completed'] is True and row['controls_pass'] is True and row['error'] is None,'Incomplete/uncontrolled raw return')
    return dict(values=result,raw=raw,metadata=meta)


def maximal_ids(values):
    require(values.dtype==np.dtype('float32') and values.shape==(1,1,VOCAB) and np.isfinite(values).all(),'Malformed logits')
    x=values.reshape(-1);return np.flatnonzero(x==x.max()).tolist()


def state_and_runtime(directory,plan,plan_sha):
    # Same source-level state/ownership contract as native admission; no model import.
    before,after=(read(directory/n) for n in ('STATE_BEFORE.json','STATE_AFTER.json'))
    require(before==after==plan['expected_host_state'] and len(before)==219,'Host content changed')
    require(all(type(v) is str and re.fullmatch('[0-9a-f]{64}',v) for v in before.values()),'Malformed state hash')
    initial,configured,restored=(read(directory/n) for n in ('IDENTITY_BEFORE.json','IDENTITY_CONFIGURED.json','IDENTITY_AFTER.json'))
    require(same(initial,restored) and len(initial['parameters'])==218,'Ownership not restored')
    for key in ('parameters','buffers','grads_none','hooks','forward_methods','generation_config'):
        require(same(initial[key],configured[key]),'Configured ownership changed: '+key)
    require(initial['hooks']=={} and all(v is True for v in initial['grads_none'].values()),'Hooks/gradients present')
    require(set(initial['requires_grad'])==set(configured['requires_grad'])==set(initial['parameters']),'Parameter flag inventory differs')
    require(set(initial['training'])==set(configured['training'])==set(initial['forward_methods']),'Module inventory differs')
    require(all(type(v) is bool for v in initial['training'].values()) and all(type(v) is bool for v in initial['requires_grad'].values()),'Invalid original flags')
    require(all(v is False for v in configured['training'].values()) and all(v is False for v in configured['requires_grad'].values()),'Not frozen/eval')
    for value in initial['parameters'].values():
        require(len(value)==4 and all(type(x) is int and x>0 for x in value[:2])
            and value[2] in ('mps','mps:0') and value[3]=='torch.bfloat16','Native parameter placement differs')
    require(same(configured['config'],dict(initial['config'],use_cache=False)),'Configuration changed')
    for key,value in dict(hidden_size=1024,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,vocab_size=VOCAB).items():
        require(type(initial['config'][key]) is int and initial['config'][key]==value,'Architecture changed')
    require(finite_number(initial['config']['logits_scaling']) and initial['config']['logits_scaling']==6,'Head scaling changed')
    runtime=read(directory/'RUNTIME.json')
    expected=dict(versions=plan['versions'],device='mps',dtype='torch.bfloat16',threads=4,initial_seed=42,attention='eager',cache=False,
        no_task_hooks=True,logits_to_keep=1,model_source_sha256=plan['installed_model_source_sha256'],decoder='tokenizers.Tokenizer.decode',skip_special_tokens=False)
    require(same({k:runtime[k] for k in expected},expected),'Runtime changed')
    c1,c2=(read(directory/n) for n in ('MODEL_CACHE_BEFORE.json','MODEL_CACHE_AFTER.json'))
    require(same(c1,c2) and set(c1)==set(plan['model_files']),'Cache receipt inventory differs')
    for name,h in plan['model_files'].items():require(c1[name]['sha256']==h,'Cache hash differs')
    complete=read(directory/'WORKER_COMPLETE.json')
    require(complete['status']=='WORKER_COLLECTED_UNGRADED' and complete['plan_sha256']==plan_sha
        and complete['task_scores_computed'] is False and type(complete['paths_completed']) is int and complete['paths_completed']==20,'Worker incomplete')
    for key in ('all_structural_controls_pass','state_unchanged','ownership_restored','cache_unchanged'):
        require(complete[key] is True,'Worker control failed')
    return complete


def owner_guard(directory,plan_sha):
    start=read(directory/'STARTED.json');worker=read(directory/'WORKER_STARTED.json')
    require(start['plan_sha256']==worker['plan_sha256']==plan_sha and start['owner_pid']==worker['owner_pid']==os.getppid(),'Wrong owner identity')
    require(worker['deadline_utc']==start['deadline_utc'] and time.time()<timestamp(start['deadline_utc']),'Deadline differs/expired')
    os.kill(start['owner_pid'],0);require(not any((directory/n).exists() for n in ('STOPPED.json','COMPLETE.json')),'Owner already closed')
    until=time.monotonic()+2
    while True:
        try:events=lines(directory/'owner-events.jsonl')
        except (FileNotFoundError,json.JSONDecodeError):events=[]
        if len(events)>=3 or time.monotonic()>=until:break
        time.sleep(.02)
    require(len(events)==3,'Wrong original dispatch count')
    a,b,c=events
    require(a['event']=='started' and a['stage']=='worker' and b['event']=='exit' and b['stage']=='worker'
        and a['pid']==b['pid']==worker['worker_pid'] and b['returncode']==0 and b['process_group_absent'] is True
        and c['event']=='started' and c['stage']=='independent_audit' and c['pid']==os.getpid(),'Original stage lifecycle differs')
    require(Path(a['command'][2]).name=='worker.py' and a['command'][3:]==['--deadline-utc',start['deadline_utc']]
        and Path(c['command'][2]).name=='audit.py' and c['command'][3:]==['--directory',str(directory)],'Original command differs')
    processes=subprocess.run(['/bin/ps','-axo','pid=,pgid='],check=True,capture_output=True,text=True,timeout=5)
    require(not any(int(line.split()[1])==worker['worker_pid'] for line in processes.stdout.splitlines()),'Worker group still present')


def collection_inputs(directory,plan,plan_sha):
    require(not any((directory/n).exists() for n in ('STOPPED.json','COMPLETE.json','WORKER_FAILURE.json','LIFETIME_STOP.json')),'Closed/failed collection')
    collected=read(directory/'COLLECTED.json');count=collected['counts']['forward_attempts']
    require(type(count) is int and 0<=count<=320 and collected['status']=='COLLECTED_UNGRADED'
        and collected['plan_sha256']==plan_sha and collected['task_scores_computed'] is False,'Incomplete collection')
    expected={'plan.json','REGISTRATION.json','STARTED.json','WORKER_STARTED.json','MODEL_CACHE_BEFORE.json','MODEL_CACHE_AFTER.json',
        'IDENTITY_BEFORE.json','IDENTITY_CONFIGURED.json','IDENTITY_AFTER.json','STATE_BEFORE.json','STATE_AFTER.json',
        'RUNTIME.json','calls.jsonl','paths.jsonl','worker-events.jsonl','worker-resources.jsonl','WORKER_COMPLETE.json'}
    expected|={'sources/'+Path(n).name for n in plan['source_sha256']}
    expected|={f'calls/{i:04d}.{ext}' for i in range(count) for ext in ('npz','json')}
    excluded={'COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl'}
    require(set(plan['collection_exclusions'])==excluded and set(collected['artifact_sha256'])==expected,'Collection manifest coverage differs')
    require({str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}==expected|excluded,'Unexpected/missing archive file')
    for name,h in collected['artifact_sha256'].items():require(digest(safe(directory,name))==h,'Immutable artifact differs: '+name)
    calls=lines(directory/'calls.jsonl');paths=lines(directory/'paths.jsonl')
    require(len(calls)==count and len(paths)==20,'Incomplete new calls or paths')
    for i,row in enumerate(calls):
        require(type(row['index']) is int and row['index']==i,'Call index not sequential')
        for pk,hk,ext in (('forward_path','forward_sha256','npz'),('forward_metadata_path','forward_metadata_sha256','json')):
            require(row[pk]==f'calls/{i:04d}.{ext}' and row[hk]==collected['artifact_sha256'][row[pk]],'Raw path/hash differs')
    return collected,calls,paths


def check_journals(directory,plan,chains,complete):
    n=sum(len(c['steps']) for c in chains);start=read(directory/'STARTED.json')
    begin=timestamp(start['at_utc']);deadline=timestamp(start['deadline_utc']);require(deadline-begin==900,'Deadline changed')
    specs=[dict(event='worker_started'),dict(event='model_load_started'),dict(event='model_load_finished')]
    resources=[('before_load',None,None),('after_load',None,None)]
    for c in chains:
        case=c['case'];specs.append(dict(event='path_started',id=case['id'],index=case['index']))
        for j,index in enumerate(c['path']['call_indices']):
            for event in ('forward_started','forward_returned','call_saved'):
                item=dict(event=event,index=index,path_id=case['id'],step=j+1)
                if event=='call_saved':item['controls_pass']=True
                specs.append(item)
            resources.extend((stage,case['id'],index) for stage in ('before_forward','after_forward'))
        specs.append(dict(event='path_completed',id=case['id'],index=case['index'],forward_count=len(c['steps']),stop_reason=c['stop_reason']))
    specs.append(dict(event='worker_completed'));resources.append(('complete',None,None))
    events=lines(directory/'worker-events.jsonl');require(len(events)==44+3*n==len(specs),'Event coverage differs')
    previous=begin
    for row,spec in zip(events,specs):
        require(same({k:row[k] for k in spec},spec),'Journal order/identity differs')
        t=timestamp(row['at_utc']);require(previous<=t<=deadline,'Journal time outside deadline');previous=t
    samples=lines(directory/'worker-resources.jsonl')
    require(len(samples)==3+2*n and same(samples,complete['resource_samples']),'Worker samples differ')
    previous=begin
    for sample,(stage,path,index) in zip(samples,resources):
        require(sample['stage']==stage and sample['call_id']==path and same(sample['call_index'],index),'Resource order differs')
        t=timestamp(sample['at_utc']);require(previous<=t<=deadline,'Resource time differs');previous=t
        for key,cap in (('rss_high_water_bytes','max_rss_bytes'),('mps_driver_bytes','max_mps_bytes'),('archive_bytes','max_archive_bytes')):
            require(type(sample[key]) is int and 0<=sample[key]<=plan['settings'][cap],'Resource ceiling failed: '+key)
        require(type(sample['mps_allocated_bytes']) is int and 0<=sample['mps_allocated_bytes']<=sample['mps_driver_bytes'],'MPS counter differs')
        require(finite_number(sample['elapsed_seconds']) and 0<=sample['elapsed_seconds']<=900,'Resource elapsed differs')
    require(begin<=timestamp(complete['at_utc'])<=deadline,'Worker completed after deadline')
    monitor=live_lines(directory/'resource-monitor.jsonl');require(monitor,'Missing owner monitor')
    for s in monitor:
        require(s['stage'] in ('worker','independent_audit') and begin<=timestamp(s['at_utc'])<=deadline,'Owner resource scope differs')
        require(type(s['child_tree_rss_bytes']) is int and 0<=s['child_tree_rss_bytes']<=plan['settings']['max_rss_bytes'],'Owner RSS exceeded')
        require(type(s['archive_bytes']) is int and 0<=s['archive_bytes']<=plan['settings']['max_archive_bytes'],'Owner archive exceeded')
    times=[timestamp(s['at_utc']) for s in monitor];require(times==sorted(times),'Owner chronology differs')
    return dict(worker_events=len(events),worker_resource_samples=len(samples),owner_samples_observed=len(monitor),
        peak_worker_rss_bytes=max(s['rss_high_water_bytes'] for s in samples),peak_mps_driver_bytes=max(s['mps_driver_bytes'] for s in samples),
        peak_owner_child_tree_rss_bytes=max(s['child_tree_rss_bytes'] for s in monitor),
        maximum_owner_sample_gap_seconds=max((b-a for a,b in zip(times,times[1:])),default=0),
        scope='Observed live owner prefix and boundary worker samples; not continuous memory-peak proof. Owner binds final logs after child exit.')


def audit_records(directory,plan,plan_sha,decode,encode,prior):
    directory=Path(directory)
    require(plan['parser']['require_eos'] is True and plan['parser']['strip_characters']==[32,9,13,10]
        and plan['parser']['body_values']==['on','off'],'EOS parser contract differs')
    require(plan['decoding']['eos_id']==0 and plan['decoding']['max_generated_tokens_per_path']==16
        and plan['decoding']['max_total_forwards']==320,'Decoding contract differs')
    validate_cases(plan['cases'],decode,encode)
    collection,calls,paths=collection_inputs(directory,plan,plan_sha);complete=state_and_runtime(directory,plan,plan_sha)
    chains=[validate_chain(case,path,calls,directory,plan_sha,decode) for case,path in zip(plan['cases'],paths)]
    indices=[i for c in chains for i in c['path']['call_indices']]
    require(indices==list(range(len(calls))),'Call coverage missing/duplicated/reordered')
    counts=operation_counts(chains)
    require(same(counts,collection['counts']) and same(counts,complete['counts']),'Physical operation counts differ')
    resources=check_journals(directory,plan,chains,complete)
    # The EOS parser and reference grades are used only after all20 complete chains.
    result=grade_complete(chains,prior)
    result.update(plan_sha256=plan_sha,collected_sha256=digest(directory/'COLLECTED.json'),physical_counts=counts,
        resources=resources,controls=dict(fresh_paths=20,all_paths_validated=20,original_logits_reused=False,
        state_entries=219,parameter_entries=218,state_includes_buffers=True,states_unchanged=True,ownership_restored=True))
    collection_inputs(directory,plan,plan_sha)
    return result


def main(directory):
    import protocol as p
    directory=Path(directory).resolve();require(directory==p.OUT.resolve(),'Wrong registered directory')
    require(not any((directory/n).exists() for n in ('REPORT.json','INDEPENDENT_AUDIT.json','AUDIT_FAILURE.json')),'Audit already attempted')
    plan,plan_sha=p.verify(directory)
    try:
        require(Path(sys.executable).resolve()==p.PYTHON.resolve() and np.__version__==plan['versions']['numpy'],'Audit runtime differs')
        owner_guard(directory,plan_sha);cache=p.validate_model_files(plan)
        import tokenizers
        require(tokenizers.__version__==plan['versions']['tokenizers'],'Tokenizer runtime differs')
        tokenizer=tokenizers.Tokenizer.from_file(str(p.ROOT/plan['model_path']/'tokenizer.json'))
        old_paths={'native':('outputs/moe-mechanisms/ORGAN_PRIVATE_NATIVE_V1/REPORT.json','94f4c5020488071f16728a06a817d269719bee2969c4b11b8ced8bff14c87495'),
            'readout':('outputs/moe-mechanisms/ORGAN_READOUT_DIAGNOSIS_V1/REPORT.json','94190161b83f6d2a8122055a9f3d03f0b92b889d678d1ee147360e80eaf39c57')}
        prior={}
        for key,(name,h) in old_paths.items():
            path=safe(p.ROOT,name);require(digest(path)==h,'Bound closed report changed');prior[key]=read(path)
        report=audit_records(directory,plan,plan_sha,lambda ids:tokenizer.decode(ids,skip_special_tokens=False),
            lambda text:tokenizer.encode(text,add_special_tokens=False).ids,prior)
        report['prior_report_sha256']={key:h for key,(_,h) in old_paths.items()}
        require(p.validate_model_files(plan)==cache and p.verify(directory)[1]==plan_sha,'Frozen inputs changed during audit')
        owner_guard(directory,plan_sha);create(directory/'REPORT.json',report)
        audit=dict(status='PASS',implementation_pass=True,original_native_gate_pass=False,automatic_transfer=False,
            behavioral_success=report['behavioral_success'],repeat_answer_consistency_pass=report['repeat_answer_consistency_pass'],
            repeat_raw_stability_pass=report['repeat_raw_stability_pass'],repeat_text_path_pass=report['repeat_text_path_pass'],
            plan_sha256=plan_sha,report_sha256=digest(directory/'REPORT.json'),audit_code_sha256=digest(__file__),
            collected_sha256=report['collected_sha256'],source_sha256=plan['source_sha256'],pid=os.getpid(),owner_pid=os.getppid(),
            started_sha256=digest(directory/'STARTED.json'),at_utc=datetime.now(timezone.utc).isoformat(),
            scope='Independent literal chat serialization, raw greedy-chain and EOS answer audit; protocol source/cache checks reused. Old reports copied only for paired descriptive comparisons.')
        create(directory/'INDEPENDENT_AUDIT.json',audit);print(json.dumps(audit),flush=True)
    except BaseException as exc:
        invalid={}
        for name in ('REPORT.json','INDEPENDENT_AUDIT.json'):
            path=directory/name
            if path.exists():invalid[name]=digest(path);os.rename(path,directory/('INVALID_'+name))
        create(directory/'AUDIT_FAILURE.json',dict(status='AUDIT_FAILED_UNGRADED',plan_sha256=plan_sha,reason=repr(exc),
            at_utc=datetime.now(timezone.utc).isoformat(),invalid_publication_sha256=invalid,retry_allowed=False));raise


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',required=True);main(**vars(parser.parse_args()))
