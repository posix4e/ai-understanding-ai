Reading archive for an outcome-exposed official-chat interface control.
Both prior closed results remain unchanged: original forced one-token 7/16; bounded continuation 0 correct, 8 wrong, 8 unresolved.
Contains six registered source files, plan/decision/reviews/tokenizer proof, all new raw traces and terminal evidence.
Prior reports and source-binding records are included; old raw arrays are not duplicated. Every chat forward is fresh.
Raw arrays are copied opaquely; the publisher does not decode or regrade them.
The role/system/instruction/answer-boundary package changes together. No isolated formatting cause, organ composition or novelty is established.
No model weights or installed runtime. This is not a self-contained reproduction or new execution authorization.
