"""Bounded greedy continuation; no candidate/state grading or task hooks."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
from pathlib import Path
import copy
import hashlib
import importlib.metadata
import json
import os
import platform
import resource
import signal
import threading
import time
import protocol as p

HOOKS=('_forward_pre_hooks','_forward_hooks','_backward_pre_hooks','_backward_hooks')


def owner_guard(start,plan_sha,deadline):
    p.require(start['plan_sha256']==plan_sha and start['owner_pid']==os.getppid() and start['deadline_utc']==deadline,
              'Not the original owner/deadline')
    os.kill(start['owner_pid'],0)
    p.require(datetime.now(timezone.utc)<datetime.fromisoformat(deadline), 'Worker deadline expired')
    p.require(not any((p.OUT/n).exists() for n in ('STOPPED.json','COMPLETE.json')), 'Owner terminal already exists')


def raw_bytes(value,torch):
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def state_hash(model,torch):
    return {n:hashlib.sha256(raw_bytes(v,torch)).hexdigest() for n,v in model.state_dict().items()}


def identity(model):
    return dict(training={n:m.training for n,m in model.named_modules()},
        requires_grad={n:v.requires_grad for n,v in model.named_parameters()},
        parameters={n:[id(v),v.data_ptr(),str(v.device),str(v.dtype)] for n,v in model.named_parameters()},
        buffers={n:[id(v),v.data_ptr(),str(v.device),str(v.dtype)] for n,v in model.named_buffers()},
        grads_none={n:v.grad is None for n,v in model.named_parameters()},
        hooks={n:{k:list(getattr(m,k,{})) for k in HOOKS if getattr(m,k,{})} for n,m in model.named_modules()
               if any(getattr(m,k,{}) for k in HOOKS)},
        forward_methods={n:['forward' in m.__dict__,id(getattr(m.forward,'__func__',m.forward))] for n,m in model.named_modules()},
        config=copy.deepcopy(model.config.to_dict()),generation_config=copy.deepcopy(model.generation_config.to_dict()))


def restore(model,before):
    for n,v in model.named_parameters():v.requires_grad_(before['requires_grad'][n])
    for n,m in model.named_modules():m.training=before['training'][n]
    model.config.use_cache=before['config']['use_cache']
    return identity(model)


def retain(directory,stem,values,metadata,torch,np):
    arrays={}; descriptions={}
    for name,value in values.items():
        cpu=value.detach().cpu().contiguous()
        raw=cpu.reshape(-1).view(torch.uint8).numpy().copy()
        readable=(cpu.float() if cpu.dtype==torch.bfloat16 else cpu).numpy().copy()
        rk,vk=name+'__raw_uint8',name+'__value';arrays[rk]=raw;arrays[vk]=readable
        descriptions[name]=dict(dtype=str(cpu.dtype),shape=list(cpu.shape),raw_key=rk,value_key=vk,
            raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),finite=bool(np.isfinite(readable).all()))
    file,side=directory/(stem+'.npz'),directory/(stem+'.json')
    with file.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
    p.create(side,dict(metadata,tensors=descriptions))
    return dict(forward_path=str(file.relative_to(p.OUT)),forward_sha256=p.digest(file),
                forward_metadata_path=str(side.relative_to(p.OUT)),forward_metadata_sha256=p.digest(side))


def strict_max(logits,np):
    flat=np.asarray(logits).reshape(-1)
    p.require(flat.size==49155 and bool(np.isfinite(flat).all()),'Malformed/nonfinite greedy logits')
    winners=np.flatnonzero(flat==flat.max()).tolist()
    return dict(maximizers=winners,selected_token=winners[0] if len(winners)==1 else None)


def original_first_rows(plan,np):
    """Decode all original raw rows before loading the model; no candidate scoring."""
    first=[]
    for case,row in zip(plan['cases'],plan['original_calls']):
        f=p.safe(p.ORIGINAL,row['forward_path']);s=p.safe(p.ORIGINAL,row['forward_metadata_path'])
        p.require(p.digest(f)==row['forward_sha256']==plan['original_inventory'][row['forward_path']]
            and p.digest(s)==row['forward_metadata_sha256']==plan['original_inventory'][row['forward_metadata_path']], 'Original raw bytes changed')
        meta=p.read(s)
        p.require(meta['plan_sha256']==plan['original_plan_sha256'] and p.canonical({k:meta[k] for k in
            ('index','id','phase','repeat_of','carrier','a','b')})==p.canonical({k:case[k] for k in
            ('index','id','phase','repeat_of','carrier','a','b')}),'Original sidecar identity differs')
        specs={'input_ids':('torch.int64',[1,len(case['input_ids'])],'<i8',8),
               'full_logits':('torch.bfloat16',[1,1,49155],'<f4',2)}
        p.require(set(meta['tensors'])==set(specs),'Original tensor inventory differs')
        decoded={};hashes={}
        with np.load(f,allow_pickle=False) as z:
            p.require(set(z.files)=={n+k for n in specs for k in ('__raw_uint8','__value')},'Original NPZ inventory differs')
            for name,(dtype,shape,readable,width) in specs.items():
                desc=meta['tensors'][name];raw=z[name+'__raw_uint8'];value=z[name+'__value']
                p.require(desc['dtype']==dtype and desc['shape']==shape and desc['raw_key']==name+'__raw_uint8'
                    and desc['value_key']==name+'__value' and desc['finite'] is True,'Original descriptor differs')
                p.require(raw.dtype==np.uint8 and raw.ndim==1 and raw.size==int(np.prod(shape))*width
                    and value.dtype.str==readable and list(value.shape)==shape,'Original array schema differs')
                bits=raw.tobytes();h=hashlib.sha256(bits).hexdigest()
                p.require(h==desc['raw_sha256'],'Original raw tensor hash differs')
                x=(np.frombuffer(bits,dtype='<i8') if width==8 else
                   (np.frombuffer(bits,dtype='<u2').astype('<u4')<<16).view('<f4')).reshape(shape)
                p.require(x.tobytes()==value.tobytes() and bool(np.isfinite(x).all()),'Original raw/readable/nonfinite failure')
                decoded[name]=x.copy();hashes[name]=h
        p.require(decoded['input_ids'].tolist()==[case['input_ids']],'Original input tokens differ')
        first.append(dict(id=case['id'],original={k:row[k] for k in
            ('forward_path','forward_sha256','forward_metadata_path','forward_metadata_sha256')},
            input_ids_raw_sha256=hashes['input_ids'],full_logits_raw_sha256=hashes['full_logits'],
            **strict_max(decoded['full_logits'],np)))
    p.require(len(first)==20,'Original first-row panel incomplete')
    return first


def text_state(ids,decode):
    """Only literal stopping and decoding, never grammatical or target grading."""
    text=decode(ids)
    parser_text=decode(ids[:-1]) if ids and ids[-1]==0 else text
    if ids and ids[-1]==0:return text,parser_text,'eos'
    if any(mark in text for mark in ('.','!','\n')):return text,parser_text,'text_terminator'
    if len(ids)==16:return text,parser_text,'cap'
    return text,parser_text,None


def run_paths(cases,first,forward,retain_call,validate,choose,decode,event,guard,counts,last,progress):
    """Injected model-free control-flow surface. All new raw returns precede decisions."""
    results=[]
    for case,initial in zip(cases,first):
        guard('before_path',case,False);counts['paths_started']+=1
        event('path_started',id=case['id'],index=case['index'])
        p.require(case['id']==initial['id'],'Original first-row order differs')
        ids=[];decisions=[dict(source='original',call_index=None,maximizers=initial['maximizers'],selected_token=initial['selected_token'])]
        calls=[];stop=None;text='';parser_text=''
        progress.clear();progress.update(path_id=case['id'],generated_ids=ids,decisions=decisions,new_call_indices=calls)
        if initial['selected_token'] is None:stop='tie'
        else:
            ids.append(initial['selected_token']);counts['reused_tokens']+=1;counts['generated_tokens']+=1
            text,parser_text,stop=text_state(ids,decode)
        while stop is None:
            p.require(len(ids)<16 and len(calls)<15,'Per-path generation bound exceeded')
            index=counts['forward_attempts'];step=len(calls)+1
            call=dict(index=index,path_id=case['id'],path_index=case['index'],step=step,
                      input_ids=case['input_ids']+ids)
            p.require(len(call['input_ids'])<=59 and index<300,'Global call/input bound exceeded')
            guard('before_forward',call,True);counts['forward_attempts']+=1
            event('forward_started',index=index,path_id=case['id'],step=step)
            values={};error=None;returned=False;artifact={}
            try:
                values=forward(call);returned=True;counts['forward_finished']+=1
                last.clear();last.update(values)
                try:event('forward_returned',index=index,path_id=case['id'],step=step)
                except BaseException as exc:error=exc
            except BaseException as exc:error=exc
            try:
                artifact=retain_call(call,values)
                if error is None:validate(call,values)
            except BaseException as exc:
                if error is None:error=exc
            row={k:call[k] for k in ('index','path_id','path_index','step')}
            row.update(artifact,forward_completed=returned,controls_pass=error is None,error=None if error is None else repr(error))
            p.append(p.OUT/'calls.jsonl',row);counts['calls_saved']+=1;calls.append(index)
            event('call_saved',index=index,path_id=case['id'],step=step,controls_pass=row['controls_pass'])
            if error is not None:raise error
            # Shape/finiteness is validated only after raw persistence; the maximum is not a target comparison.
            selection=choose(values)
            decisions.append(dict(source='new',call_index=index,**selection))
            guard('after_forward',call,True)
            if selection['selected_token'] is None:stop='tie'
            else:
                ids.append(selection['selected_token']);counts['new_tokens_selected']+=1;counts['generated_tokens']+=1
                text,parser_text,stop=text_state(ids,decode)
        row={k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
        row.update(original_first=initial,generated_ids=list(ids),decoded_text=text,parser_text=parser_text,
            stop_reason=stop,decisions=decisions,new_call_indices=calls,new_forward_count=len(calls))
        p.append(p.OUT/'paths.jsonl',row);counts['paths_finished']+=1
        event('path_completed',id=case['id'],index=case['index'],new_forward_count=len(calls),stop_reason=stop)
        results.append(row);progress.clear()
    return results


def initial_counts():
    return dict(model_load_attempts=0,model_load_finished=0,original_rows_validated=0,paths_started=0,paths_finished=0,
        forward_attempts=0,forward_finished=0,calls_saved=0,reused_tokens=0,new_tokens_selected=0,generated_tokens=0,
        hooks=0,fits=0,backwards=0,optimizer_steps=0,provider_calls=0)


def main(deadline_utc):
    plan,plan_sha=p.verify();start=p.read(p.OUT/'STARTED.json');owner_guard(start,plan_sha,deadline_utc)
    p.require(Path(sys.executable).resolve()==p.PYTHON.resolve(),'Pinned Python required')
    p.require(not any((p.OUT/n).exists() for n in ('WORKER_STARTED.json','WORKER_COMPLETE.json','WORKER_FAILURE.json','calls.jsonl')),'Worker already attempted')
    p.create(p.OUT/'WORKER_STARTED.json',dict(at_utc=p.now(),worker_pid=os.getpid(),owner_pid=os.getppid(),plan_sha256=plan_sha,deadline_utc=deadline_utc))
    stop_thread=threading.Event();model=None;before=None;torch=None;np=None;last={};progress={};samples=[];counts=initial_counts()
    def event(kind,**fields):p.append(p.OUT/'worker-events.jsonl',dict(event=kind,at_utc=p.now(),**fields))
    def watchdog():
        while not stop_thread.wait(.25):
            try:owner_guard(start,plan_sha,deadline_utc)
            except BaseException:
                try:p.create(p.OUT/'LIFETIME_STOP.json',dict(at_utc=p.now(),reason='Owner/deadline watchdog failed'))
                finally:os.kill(os.getpid(),signal.SIGTERM)
                return
    thread=threading.Thread(target=watchdog,daemon=True);thread.start()
    def guard(stage,case=None,measure=True):
        owner_guard(start,plan_sha,deadline_utc)
        if not measure:return
        sample=dict(at_utc=p.now(),stage=stage,call_id=None if case is None else case.get('path_id',case.get('id')),
            call_index=None if case is None else case.get('index'),
            elapsed_seconds=(datetime.now(timezone.utc)-datetime.fromisoformat(start['at_utc'])).total_seconds(),
            rss_high_water_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            mps_driver_bytes=torch.mps.driver_allocated_memory(),mps_allocated_bytes=torch.mps.current_allocated_memory(),
            archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file()))
        p.append(p.OUT/'worker-resources.jsonl',sample);samples.append(sample)
        p.require(sample['rss_high_water_bytes']<=p.SETTINGS['max_rss_bytes'] and sample['mps_driver_bytes']<=p.SETTINGS['max_mps_bytes']
            and sample['archive_bytes']+1024**2<=p.SETTINGS['max_archive_bytes'],'Worker resource ceiling exceeded')
    try:
        event('worker_started')
        import numpy as np
        import torch
        import tokenizers
        from transformers import AutoModelForCausalLM
        versions=dict(python=platform.python_version(),**{n:importlib.metadata.version(n) for n in ('torch','transformers','numpy','tokenizers')})
        p.require(versions==p.VERSIONS and torch.backends.mps.is_available(),'Pinned runtime unavailable')
        torch.set_num_threads(4);torch.manual_seed(42)
        cache_before=p.validate_model_files(plan);p.create(p.OUT/'MODEL_CACHE_BEFORE.json',cache_before)
        first=original_first_rows(plan,np);counts['original_rows_validated']=20
        p.create(p.OUT/'ORIGINAL_FIRST.json',dict(plan_sha256=plan_sha,original_plan_sha256=plan['original_plan_sha256'],rows=first))
        event('original_validated',rows=20)
        tokenizer=tokenizers.Tokenizer.from_file(str(p.ROOT/plan['model_path']/'tokenizer.json'))
        decode=lambda ids:tokenizer.decode(ids,skip_special_tokens=False)
        guard('before_load');counts['model_load_attempts']+=1;event('model_load_started')
        model=AutoModelForCausalLM.from_pretrained(str(p.ROOT/plan['model_path']),local_files_only=True,trust_remote_code=False,
            dtype=torch.bfloat16,attn_implementation='eager').to('mps')
        counts['model_load_finished']+=1;event('model_load_finished');before=identity(model)
        p.create(p.OUT/'IDENTITY_BEFORE.json',before)
        p.require(not before['hooks'] and all(v[2] in ('mps','mps:0') and v[3]=='torch.bfloat16' for v in before['parameters'].values()),'Non-native model placement/hooks')
        states_before=state_hash(model,torch);p.create(p.OUT/'STATE_BEFORE.json',states_before)
        p.require(states_before==plan['expected_host_state'] and len(states_before)==219,'Loaded state differs from pinned state')
        model.eval();model.requires_grad_(False);model.config.use_cache=False
        configured=identity(model);p.create(p.OUT/'IDENTITY_CONFIGURED.json',configured)
        p.create(p.OUT/'RUNTIME.json',dict(versions=versions,device='mps',dtype='torch.bfloat16',threads=torch.get_num_threads(),
            initial_seed=torch.initial_seed(),attention=model.config._attn_implementation,cache=model.config.use_cache,
            no_task_hooks=True,logits_to_keep=1,model_source_sha256=p.digest(p.MODEL_SOURCE),
            decoder='tokenizers.Tokenizer.decode',skip_special_tokens=False,
            resource_scope='Owner samples whole child-tree RSS; worker samples RSS/MPS before/after load and calls. Samples do not prove continuous peaks.'))
        guard('after_load');(p.OUT/'calls').mkdir();(p.OUT/'calls.jsonl').touch(exist_ok=False);(p.OUT/'paths.jsonl').touch(exist_ok=False)
        def forward(call):
            ids=torch.tensor([call['input_ids']],dtype=torch.int64,device='mps');last.clear();last['input_ids']=ids
            with torch.inference_mode():output=model(input_ids=ids,use_cache=False,logits_to_keep=1,return_dict=True)
            return dict(input_ids=ids,full_logits=output.logits)
        def store(call,values):
            return retain(p.OUT/'calls',f"{call['index']:04d}",values,dict(plan_sha256=plan_sha,
                **{k:call[k] for k in ('index','path_id','path_index','step')}),torch,np)
        def validate(call,values):
            ids,logits=values['input_ids'],values['full_logits']
            p.require(ids.dtype==torch.int64 and ids.tolist()==[call['input_ids']],'Input mutation')
            p.require(logits.dtype==torch.bfloat16 and tuple(logits.shape)==(1,1,49155) and logits.device.type=='mps'
                and bool(torch.isfinite(logits).all()),'Malformed/nonfinite returned logits')
        rows=run_paths(plan['cases'],first,forward,store,validate,lambda v:strict_max(v['full_logits'].detach().float().cpu().numpy(),np),
                      decode,event,guard,counts,last,progress)
        p.require(identity(model)==configured,'Configured ownership changed')
        after=restore(model,before);p.create(p.OUT/'IDENTITY_AFTER.json',after)
        states_after=state_hash(model,torch);p.create(p.OUT/'STATE_AFTER.json',states_after)
        cache_after=p.validate_model_files(plan);p.create(p.OUT/'MODEL_CACHE_AFTER.json',cache_after)
        p.require(after==before and states_before==states_after and cache_before==cache_after,'State/cache/restoration changed')
        p.verify();guard('complete')
        n=counts['forward_attempts']
        p.require(0<=n<=300 and counts['forward_finished']==counts['calls_saved']==n and counts['paths_finished']==counts['paths_started']==20
            and counts['generated_tokens']==counts['reused_tokens']+counts['new_tokens_selected'],'Physical counts differ')
        event('worker_completed')
        p.create(p.OUT/'WORKER_COMPLETE.json',dict(status='WORKER_COLLECTED_UNGRADED',at_utc=p.now(),plan_sha256=plan_sha,
            counts=counts,resource_samples=samples,all_structural_controls_pass=True,state_unchanged=True,
            ownership_restored=True,cache_unchanged=True,paths_completed=len(rows),task_scores_computed=False))
        p.create(p.OUT/'COLLECTED.json',dict(status='COLLECTED_UNGRADED',at_utc=p.now(),plan_sha256=plan_sha,counts=counts,
            artifact_sha256=p.inventory(p.OUT,p.EXCLUSIONS),task_scores_computed=False))
    except BaseException as exc:
        evidence_errors=[]
        if model is not None and before is not None:
            for name,fn in (('IDENTITY_FAILURE.json',lambda:restore(model,before)),('STATE_FAILURE.json',lambda:state_hash(model,torch))):
                try:p.create(p.OUT/name,fn())
                except BaseException as error:evidence_errors.append(name+': '+repr(error))
        if last and torch is not None and np is not None:
            try:retain(p.OUT,'failure-last',last,dict(plan_sha256=plan_sha,failure_only=True),torch,np)
            except BaseException as error:evidence_errors.append('last_raw: '+repr(error))
        p.create(p.OUT/'WORKER_FAILURE.json',dict(at_utc=p.now(),status='WORKER_STOPPED_UNGRADED',plan_sha256=plan_sha,
            reason=repr(exc),counts=counts,active_path=progress,evidence_errors=evidence_errors,retry_allowed=False,task_scores_computed=False));raise
    finally:stop_thread.set();thread.join(timeout=2)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--deadline-utc',required=True);main(**vars(parser.parse_args()))
