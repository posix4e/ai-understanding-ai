"""One foreground owner, one fresh worker and one independent audit; no retry."""
import sys
sys.dont_write_bytecode=True
from datetime import datetime,timedelta,timezone
from pathlib import Path
import json
import os
import signal
import subprocess
import shutil
import time
import protocol as p


def group_members(pgid):
    result=subprocess.run(['/bin/ps','-axo','pid=,pgid='],check=True,capture_output=True,text=True,timeout=5)
    return [int(v[0]) for v in (line.split() for line in result.stdout.splitlines()) if int(v[1])==pgid]


def cleanup(child):
    if child is None:return
    for sig in (signal.SIGTERM,signal.SIGKILL):
        child.poll()
        if not group_members(child.pid):break
        try:os.killpg(child.pid,sig)
        except ProcessLookupError:pass
        until=time.monotonic()+3
        while time.monotonic()<until:
            child.poll()
            if not group_members(child.pid):break
            time.sleep(.05)
    if child.poll() is None:child.wait(timeout=5)
    p.require(not group_members(child.pid),'Child process group survived cleanup')


def process_tree_rss(rows,pid):
    tree={pid}
    while True:
        expanded=tree|{r[0] for r in rows if r[1] in tree}
        if expanded==tree:break
        tree=expanded
    return sum(kib*1024 for child,_,kib in rows if child in tree)


def boundary(start,deadline):
    p.require(time.monotonic()-start<p.SETTINGS['timeout_seconds'] and datetime.now(timezone.utc)<deadline,'Inclusive owner deadline exceeded')
    size=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file())
    p.require(size+1024**2<=p.SETTINGS['max_archive_bytes'],'Archive/reserved closure ceiling exceeded')
    p.require(shutil.disk_usage(p.OUT).free>=p.SETTINGS['minimum_free_bytes'],'Free disk below one GiB')
    return size


def monitor(child,stage,start,deadline):
    samples=[]
    while True:
        size=boundary(start,deadline)
        ps=subprocess.run(['/bin/ps','-axo','pid=,ppid=,rss='],check=True,capture_output=True,text=True,timeout=5)
        rows=[tuple(map(int,line.split())) for line in ps.stdout.splitlines()]
        rss=process_tree_rss(rows,child.pid)
        sample=dict(at_utc=p.now(),stage=stage,pid=child.pid,elapsed_seconds=time.monotonic()-start,
                    child_tree_rss_bytes=rss,archive_bytes=size)
        p.append(p.OUT/'resource-monitor.jsonl',sample);samples.append(sample)
        p.require(rss<=p.SETTINGS['max_rss_bytes'],'Child-tree RSS ceiling exceeded')
        code=child.poll()
        if code is not None:
            return dict(returncode=code,samples=len(samples),peak_child_tree_rss_bytes=max(s['child_tree_rss_bytes'] for s in samples),
                        peak_archive_bytes=max(s['archive_bytes'] for s in samples))
        time.sleep(.25)


def run():
    p.require(Path(sys.executable).resolve()==p.PYTHON.resolve(),'Pinned Python required')
    p.require(not any((p.OUT/n).exists() for n in ('STARTED.json','STOPPED.json','COMPLETE.json','COLLECTED.json')),'Owner already attempted')
    start=time.monotonic();begin=datetime.now(timezone.utc);deadline=begin+timedelta(seconds=p.SETTINGS['timeout_seconds'])
    plan,plan_sha=p.verify();child=None;stage=None;resources={}
    p.create(p.OUT/'STARTED.json',dict(at_utc=begin.isoformat(),deadline_utc=deadline.isoformat(),owner_pid=os.getpid(),plan_sha256=plan_sha))
    def interrupt(signum,frame):raise SystemExit(128+signum)
    handlers={sig:signal.signal(sig,interrupt) for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM)}
    signal.setitimer(signal.ITIMER_REAL,max(.001,p.SETTINGS['timeout_seconds']-(time.monotonic()-start)))
    try:
        boundary(start,deadline);p.validate_model_files(plan);boundary(start,deadline)
        for stage,command in (
            ('worker',[str(p.PYTHON),'-B',str(p.HERE/'worker.py'),'--deadline-utc',deadline.isoformat()]),
            ('independent_audit',[str(p.PYTHON),'-B',str(p.HERE/'audit.py'),'--directory',str(p.OUT)])):
            boundary(start,deadline)
            with (p.OUT/(stage+'.log')).open('x') as log:
                child=subprocess.Popen(command,cwd=p.ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                p.append(p.OUT/'owner-events.jsonl',dict(event='started',at_utc=p.now(),stage=stage,pid=child.pid,command=command))
                resources[stage]=monitor(child,stage,start,deadline)
            if group_members(child.pid):
                cleanup(child);raise RuntimeError('Descendants survived stage leader')
            resources[stage]['process_group_absent']=True
            p.append(p.OUT/'owner-events.jsonl',dict(event='exit',at_utc=p.now(),stage=stage,pid=child.pid,**resources[stage]))
            p.require(resources[stage]['returncode']==0,stage+' failed; no partial grading or retry')
            p.verify();boundary(start,deadline)
        audit,report=p.read(p.OUT/'INDEPENDENT_AUDIT.json'),p.read(p.OUT/'REPORT.json')
        worker=p.read(p.OUT/'WORKER_COMPLETE.json');counts=worker['counts']
        p.require(audit['status']=='PASS' and report['status']=='READOUT_DIAGNOSIS_COMPLETE'
            and audit['implementation_pass'] is True and report['implementation_pass'] is True
            and audit['plan_sha256']==report['plan_sha256']==plan_sha and audit['report_sha256']==p.digest(p.OUT/'REPORT.json')
            and audit['audit_code_sha256']==p.digest(p.HERE/'audit.py')
            and audit['original_native_gate_pass'] is report['original_native_gate_pass'] is False
            and audit['automatic_transfer'] is report['automatic_transfer'] is False
            and type(audit['repeat_stability_pass']) is bool and audit['repeat_stability_pass']==report['repeat_stability_pass']
            and report['physical_counts']==counts,'Audit/report binding differs')
        p.require(worker['status']=='WORKER_COLLECTED_UNGRADED' and worker['plan_sha256']==plan_sha
            and counts['paths_finished']==20 and counts['forward_finished']<=300,'Incomplete worker')
        p.validate_model_files(plan);boundary(start,deadline)
        p.create(p.OUT/'COMPLETE.json',dict(at_utc=p.now(),status='READOUT_DIAGNOSIS_COMPLETE',plan_sha256=plan_sha,
            implementation_pass=True,original_native_gate_pass=False,repeat_stability_pass=audit['repeat_stability_pass'],
            report_sha256=p.digest(p.OUT/'REPORT.json'),independent_audit_sha256=p.digest(p.OUT/'INDEPENDENT_AUDIT.json'),
            elapsed_seconds=time.monotonic()-start,resources=resources,final_log_sha256={n:p.digest(p.OUT/n) for n in
                ('owner-events.jsonl','resource-monitor.jsonl','worker.log','independent_audit.log')},
            native_forwards=counts['forward_finished'],paths=20,reused_tokens=counts['reused_tokens'],
            new_tokens_selected=counts['new_tokens_selected'],generated_tokens=counts['generated_tokens'],
            fits=0,hooks=0,provider_calls=0,automatic_transfer=False,
            scope='Outcome-exposed same-prompt greedy readout diagnosis. Original native gate remains failed; no mechanism, novelty or transfer admission.'))
        boundary(start,deadline);print(json.dumps(p.read(p.OUT/'COMPLETE.json')),flush=True)
    except BaseException as exc:
        # Disable the alarm during bounded cleanup so a second signal cannot erase failure evidence.
        signal.setitimer(signal.ITIMER_REAL,0);error=None
        try:cleanup(child)
        except BaseException as err:error=repr(err)
        if (p.OUT/'COMPLETE.json').exists():os.rename(p.OUT/'COMPLETE.json',p.OUT/'INVALID_COMPLETE.json')
        if not (p.OUT/'STOPPED.json').exists():
            p.create(p.OUT/'STOPPED.json',dict(at_utc=p.now(),status='READOUT_DIAGNOSIS_STOPPED',plan_sha256=plan_sha,
                reason=repr(exc),stage=stage,elapsed_seconds=time.monotonic()-start,child_pid=None if child is None else child.pid,
                child_returncode=None if child is None else child.poll(),cleanup_error=error,retry_allowed=False,partial_grading_allowed=False))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        for sig,handler in handlers.items():signal.signal(sig,handler)


if __name__=='__main__':run()
