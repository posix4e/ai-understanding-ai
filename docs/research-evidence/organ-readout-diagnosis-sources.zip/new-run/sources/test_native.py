"""Invented control-flow/archive tests. No pretrained model or tokenizer execution."""
from datetime import datetime,timedelta,timezone
from pathlib import Path
from unittest import mock
import ast
import hashlib
import json
import sys
import tempfile
import unittest
import numpy as np
import protocol as p
import worker
import owner


def cases():
    rows=[dict(index=i,id=f'n{i:02d}',phase='primary',repeat_of=None,carrier=('lamp','light','sign','indicator')[i//4],
        a=(i//2)%2,b=i%2,input_ids=[0,100+i]) for i in range(16)]
    rows += [dict(rows[j],index=16+k,id=f'n{16+k:02d}',phase='repeat',repeat_of=f'n{j:02d}') for k,j in enumerate((0,5,10,15))]
    return rows


def first_rows(rows):
    return [dict(id=r['id'],original={},input_ids_raw_sha256='a'*64,full_logits_raw_sha256='b'*64,
        maximizers=[1],selected_token=1) for r in rows]


class PathsTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.out=Path(self.tmp.name)
        patch=mock.patch.object(p,'OUT',self.out);patch.start();self.addCleanup(patch.stop)
        self.counts=worker.initial_counts();self.trace=[];self.last={};self.progress={};self.rows=cases()
    def forward(self,c):self.trace.append(('forward',c['index']));return {'ids':c['input_ids'],'step':c['step']}
    def store(self,c,v):self.trace.append(('retain',c['index']));return {'invented_retained':True}
    def validate(self,c,v):self.trace.append(('validate',c['index']))
    def choose(self,v):return dict(maximizers=[2 if v['step']==1 else 3],selected_token=2 if v['step']==1 else 3)
    def decode(self,ids):return ''.join({0:'<EOS>',1:' turned',2:' on',3:'.',4:' off',5:'!',6:'\n',7:'?'}[i] for i in ids)
    def event(self,name,**kw):self.trace.append((name,kw.get('index')))
    def run_paths(self,**kw):
        args=dict(cases=self.rows,first=first_rows(self.rows),forward=self.forward,retain_call=self.store,
            validate=self.validate,choose=self.choose,decode=self.decode,event=self.event,guard=lambda *a:None,
            counts=self.counts,last=self.last,progress=self.progress)
        args.update(kw);return worker.run_paths(**args)
    def test_all20_paths_and_full_repeats_fixed_no_original_forward(self):
        rows=self.run_paths();self.assertEqual(len(rows),20);self.assertEqual(self.counts['forward_finished'],40)
        self.assertEqual(self.counts['reused_tokens'],20);self.assertEqual(self.counts['new_tokens_selected'],40)
        self.assertEqual(self.counts['generated_tokens'],60)
        for row in rows:
            self.assertEqual(row['generated_ids'],[1,2,3]);self.assertEqual(row['stop_reason'],'text_terminator')
            self.assertEqual(len(row['decisions']),3)
            for i in row['new_call_indices']:
                self.assertLess(self.trace.index(('retain',i)),self.trace.index(('validate',i)))
        # Each repeat was physically dispatched; no result copy from its primary.
        self.assertEqual([r['repeat_of'] for r in rows[16:]],['n00','n05','n10','n15'])
        self.assertEqual([r['new_call_indices'] for r in rows[16:]],[[32,33],[34,35],[36,37],[38,39]])
    def test_full300_call_cap_no_implicit_extra_forward(self):
        rows=self.run_paths(choose=lambda v:dict(maximizers=[2],selected_token=2))
        self.assertEqual(self.counts['forward_attempts'],300)
        self.assertEqual(self.counts['generated_tokens'],320)
        self.assertTrue(all(r['stop_reason']=='cap' and r['new_forward_count']==15 and len(r['generated_ids'])==16 for r in rows))
    def test_new_tie_retained_no_fallback_or_further_call(self):
        rows=self.run_paths(choose=lambda v:dict(maximizers=[2,4],selected_token=None))
        self.assertEqual(self.counts['forward_finished'],20);self.assertEqual(self.counts['new_tokens_selected'],0)
        self.assertTrue(all(r['stop_reason']=='tie' and r['generated_ids']==[1] and r['decisions'][-1]['maximizers']==[2,4] for r in rows))
    def test_original_tie_emits_nothing_and_is_retained(self):
        first=first_rows(self.rows)
        for r in first:r.update(maximizers=[1,4],selected_token=None)
        rows=self.run_paths(first=first)
        self.assertEqual(self.counts['forward_attempts'],0)
        self.assertTrue(all(r['stop_reason']=='tie' and r['generated_ids']==[] for r in rows))
    def test_eos_kept_in_ids_and_fulltext_omitted_only_for_parser(self):
        rows=self.run_paths(choose=lambda v:dict(maximizers=[0],selected_token=0))
        self.assertTrue(all(r['generated_ids']==[1,0] and r['decoded_text']==' turned<EOS>'
            and r['parser_text']==' turned' and r['stop_reason']=='eos' for r in rows))
    def test_literal_text_termination_does_not_stop_at_state_or_question(self):
        self.assertIsNone(worker.text_state([1,2],self.decode)[2]);self.assertIsNone(worker.text_state([7],self.decode)[2])
        for ids in ([1,2,3],[1,2,5],[1,2,6]):self.assertEqual(worker.text_state(ids,self.decode)[2],'text_terminator')
        self.assertEqual(worker.text_state([2]*15+[5],self.decode)[2],'text_terminator')
    def test_return_event_failure_retains_raw_before_stop(self):
        def broken(name,**kw):
            if name=='forward_returned':raise OSError('invented journal')
        with self.assertRaisesRegex(OSError,'journal'):self.run_paths(event=broken)
        self.assertEqual(self.counts['forward_finished'],1);self.assertIn(('retain',0),self.trace)
        self.assertFalse(json.loads((self.out/'calls.jsonl').read_text())['controls_pass'])
    def test_nonfinite_validation_preserves_return(self):
        def broken(*a):raise ValueError('invented nonfinite')
        with self.assertRaisesRegex(ValueError,'nonfinite'):self.run_paths(validate=broken)
        self.assertEqual(self.counts['forward_finished'],1);self.assertIn(('retain',0),self.trace)
        self.assertFalse((self.out/'paths.jsonl').exists())
    def test_storage_failure_counts_return_and_never_retries(self):
        def broken(*a):raise OSError('invented storage')
        with self.assertRaisesRegex(OSError,'storage'):self.run_paths(retain_call=broken)
        self.assertEqual(self.counts['forward_attempts'],1);self.assertEqual(self.counts['forward_finished'],1)
        self.assertEqual(self.counts['paths_finished'],0)
    def test_forward_failure_is_attempt_not_return(self):
        def broken(*a):raise RuntimeError('invented forward')
        with self.assertRaisesRegex(RuntimeError,'forward'):self.run_paths(forward=broken)
        self.assertEqual(self.counts['forward_attempts'],1);self.assertEqual(self.counts['forward_finished'],0)


class RawFirstTests(unittest.TestCase):
    def test_strict_max_retains_all_ties_and_rejects_nonfinite(self):
        x=np.zeros(49155,dtype=np.float32);x[7]=x[8]=1
        self.assertEqual(worker.strict_max(x,np),dict(maximizers=[7,8],selected_token=None))
        x[8]=2;self.assertEqual(worker.strict_max(x,np)['selected_token'],8)
        x[49154]=np.nan
        with self.assertRaisesRegex(ValueError,'nonfinite'):worker.strict_max(x,np)
    def fixture(self,root):
        (root/'calls').mkdir();rows=cases();calls=[];inventory={}
        for case in rows:
            arrays={};desc={}
            inputs=np.asarray([case['input_ids']],dtype='<i8');bits=np.zeros((1,1,49155),dtype='<u2');bits[0,0,1]=0x3f80
            for name,rawvalue,dtype in [('input_ids',inputs,'torch.int64'),('full_logits',bits,'torch.bfloat16')]:
                value=rawvalue if name=='input_ids' else (rawvalue.astype('<u4')<<16).view('<f4')
                raw=np.frombuffer(rawvalue.tobytes(),dtype=np.uint8).copy();rk=name+'__raw_uint8';vk=name+'__value'
                arrays[rk]=raw;arrays[vk]=value
                desc[name]=dict(dtype=dtype,shape=list(rawvalue.shape),raw_key=rk,value_key=vk,raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),finite=True)
            stem=f"calls/{case['index']:02d}";f=root/(stem+'.npz');side=root/(stem+'.json')
            with f.open('xb') as handle:np.savez_compressed(handle,**arrays)
            p.create(side,dict(plan_sha256='old',**{k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')},tensors=desc))
            row=dict(forward_path=stem+'.npz',forward_sha256=p.digest(f),forward_metadata_path=stem+'.json',forward_metadata_sha256=p.digest(side))
            calls.append(row);inventory[stem+'.npz']=row['forward_sha256'];inventory[stem+'.json']=row['forward_metadata_sha256']
        return dict(cases=rows,original_calls=calls,original_inventory=inventory,original_plan_sha256='old')
    def test_actual_loader_full20_manufactured_and_last_readable_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=self.fixture(root)
            with mock.patch.object(p,'ORIGINAL',root):
                got=worker.original_first_rows(plan,np)
                self.assertEqual(len(got),20);self.assertTrue(all(x['selected_token']==1 for x in got))
                f=root/'calls/19.npz'
                with np.load(f,allow_pickle=False) as z:arrays={n:z[n].copy() for n in z.files}
                arrays['full_logits__value'][0,0,2]=-0.0
                with f.open('wb') as handle:np.savez_compressed(handle,**arrays)
                plan['original_calls'][19]['forward_sha256']=plan['original_inventory']['calls/19.npz']=p.digest(f)
                with self.assertRaisesRegex(ValueError,'raw/readable'):worker.original_first_rows(plan,np)


class ContractTests(unittest.TestCase):
    def test_normal_blob_allowed_external_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);repo=root/'repo';snap=repo/'snapshots'/'rev';snap.mkdir(parents=True);(repo/'blobs').mkdir()
            blob=repo/'blobs'/'asset';blob.write_text('invented');(snap/'file').symlink_to('../../blobs/asset')
            self.assertEqual(p.model_payload(snap,repo,'file').resolve(),blob.resolve())
            outside=root/'outside';outside.write_text('invented');(snap/'escape').symlink_to(outside)
            with self.assertRaises(ValueError):p.model_payload(snap,repo,'escape')
            with self.assertRaises(ValueError):p.model_payload(snap,repo,'../x')
    def test_exclusive_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'a';p.create(f,{'a':1})
            with self.assertRaises(FileExistsError):p.create(f,{'a':2})
    def test_no_top_level_model_or_tokenizer_import_or_generation_wrapper(self):
        text=(p.HERE/'worker.py').read_text();tree=ast.parse(text)
        for node in tree.body:
            if isinstance(node,ast.Import):self.assertTrue(all(a.name not in ('torch','transformers','tokenizers') for a in node.names))
            if isinstance(node,ast.ImportFrom):self.assertNotIn(node.module,('torch','transformers','tokenizers'))
        for forbidden in ('register_forward','.generate(','.encode(','a ^ b','a^b'):self.assertNotIn(forbidden,text)
    def test_registration_requires_bound_reviews_and_is_exclusive(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);prep=root/'prep';prep.mkdir();code=root/'code';code.mkdir();out=root/'out'
            sources={}
            for n in p.SOURCES:(code/n).write_text('invented');sources['code/'+n]=p.digest(code/n)
            plan={'source_sha256':sources}
            with mock.patch.object(p,'ROOT',root),mock.patch.object(p,'OUT',out),mock.patch.object(p,'PREP',prep),mock.patch.object(p,'HERE',code),mock.patch.object(p,'build_plan',return_value=plan):
                for n in ('SOURCE_REVIEW.json','PREPARATION_TESTS.json'):p.create(prep/n,{'status':'PASS','source_sha256':{}})
                with self.assertRaisesRegex(ValueError,'Stale'):p.register()
                self.assertFalse(out.exists())
                for n in ('SOURCE_REVIEW.json','PREPARATION_TESTS.json'):(prep/n).write_text(json.dumps({'status':'PASS','source_sha256':sources}))
                with mock.patch('builtins.print'):p.register()
                self.assertEqual(len(list((out/'sources').iterdir())),6)
                with self.assertRaisesRegex(ValueError,'already'):p.register()


class LifecycleTests(unittest.TestCase):
    def test_process_tree(self):self.assertEqual(owner.process_tree_rss([(10,1,3),(11,10,5),(12,11,7),(20,1,100)],10),15*1024)
    def test_deadline(self):
        with mock.patch.object(owner.time,'monotonic',return_value=901):
            with self.assertRaisesRegex(ValueError,'deadline'):owner.boundary(0,datetime.now(timezone.utc)+timedelta(seconds=900))
    def test_unrelated_parent(self):
        deadline=(datetime.now(timezone.utc)+timedelta(seconds=10)).isoformat()
        with mock.patch.object(worker.os,'getppid',return_value=99):
            with self.assertRaisesRegex(ValueError,'owner'):worker.owner_guard({'plan_sha256':'x','owner_pid':98,'deadline_utc':deadline},'x',deadline)
    def test_group_cleanup_after_exited_leader(self):
        child=mock.Mock(pid=123);child.poll.return_value=0
        with mock.patch.object(owner,'group_members',side_effect=[[124],[],[],[]]),mock.patch.object(owner.os,'killpg') as kill:
            owner.cleanup(child);kill.assert_called_once_with(123,owner.signal.SIGTERM)
    def fixture(self,codeval):
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);out=Path(tmp.name);code=out/'code';code.mkdir();(code/'audit.py').write_text('invented')
        counts=worker.initial_counts();counts.update(paths_finished=20,forward_finished=40,reused_tokens=20,new_tokens_selected=40,generated_tokens=60)
        p.create(out/'WORKER_COMPLETE.json',dict(status='WORKER_COLLECTED_UNGRADED',plan_sha256='x',counts=counts))
        p.create(out/'REPORT.json',dict(status='READOUT_DIAGNOSIS_COMPLETE',implementation_pass=True,plan_sha256='x',
            original_native_gate_pass=False,automatic_transfer=False,repeat_stability_pass=False,physical_counts=counts))
        p.create(out/'INDEPENDENT_AUDIT.json',dict(status='PASS',implementation_pass=True,plan_sha256='x',original_native_gate_pass=False,
            automatic_transfer=False,repeat_stability_pass=False,report_sha256=p.digest(out/'REPORT.json'),audit_code_sha256=p.digest(code/'audit.py')))
        child=mock.Mock(pid=123);child.poll.return_value=codeval
        patches=[mock.patch.object(p,'OUT',out),mock.patch.object(p,'HERE',code),mock.patch.object(p,'PYTHON',Path(sys.executable)),
            mock.patch.object(p,'verify',return_value=({},'x')),mock.patch.object(p,'validate_model_files',return_value={}),
            mock.patch.object(owner,'boundary',return_value=0),mock.patch.object(owner,'group_members',return_value=[]),
            mock.patch.object(owner.signal,'signal'),mock.patch.object(owner.signal,'setitimer'),mock.patch.object(owner.subprocess,'Popen',return_value=child),
            mock.patch.object(owner,'monitor',return_value=dict(returncode=codeval,samples=1,peak_child_tree_rss_bytes=0,peak_archive_bytes=0))]
        mocks=[q.start() for q in patches]
        for q in patches:self.addCleanup(q.stop)
        (out/'resource-monitor.jsonl').write_text('{}\n')
        return out,mocks[-2]
    def test_valid_unstable_completion_no_transfer(self):
        out,popen=self.fixture(0)
        with mock.patch('builtins.print'):owner.run()
        done=p.read(out/'COMPLETE.json');self.assertFalse(done['repeat_stability_pass']);self.assertFalse(done['original_native_gate_pass'])
        self.assertEqual(popen.call_count,2);self.assertEqual(done['native_forwards'],40);self.assertEqual(done['generated_tokens'],60)
    def test_worker_failure_prevents_audit(self):
        out,popen=self.fixture(1)
        with self.assertRaisesRegex(ValueError,'worker failed'):owner.run()
        self.assertEqual(popen.call_count,1);self.assertTrue((out/'STOPPED.json').exists());self.assertFalse((out/'COMPLETE.json').exists())


if __name__=='__main__':unittest.main()
