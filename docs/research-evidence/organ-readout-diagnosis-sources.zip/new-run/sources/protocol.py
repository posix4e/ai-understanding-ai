"""Outcome-exposed same-prompt continuation diagnosis; explicit registration only."""
import sys
sys.dont_write_bytecode=True
from datetime import datetime,timezone
from pathlib import Path,PureWindowsPath
import hashlib
import json
import shutil
import os

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_READOUT_DIAGNOSIS_V1'
PREP=ROOT/'work/organ-readout-diagnosis-v1'
ORIGINAL=ROOT/'outputs/moe-mechanisms/ORGAN_PRIVATE_NATIVE_V1'
PYTHON=ROOT/'work/acquisition-representation-venv/bin/python'
DECISION=PREP/'ROOT_DECISION_V2.json'
DECISION_SHA='d71731620321b2fc6068f768efa47aca260e40cda0990483978068b55f37df82'
MODEL_SOURCE=ROOT/'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
MODEL_SOURCE_SHA='db9858ac0c9666a22d460e8a798df8086394e9084e45df93129d1474df1db40a'
SOURCES=('protocol.py','worker.py','owner.py','audit.py','test_native.py','test_audit.py')
SETTINGS=dict(timeout_seconds=900,max_rss_bytes=10*1024**3,max_mps_bytes=10*1024**3,
 max_archive_bytes=1024**3,minimum_free_bytes=1024**3,max_tokens=59,retained_tokens_max=60,
 seed=42,threads=4,device='mps',dtype='bfloat16',attention='eager',cache=False,batch_size=1,
 logits_to_keep=1,paths=20,primary=16,repeats=4,total_generated_token_cap=16,
 new_forwards_per_path_max=15,total_new_forwards_max=300,eos_id=0)
VERSIONS=dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',tokenizers='0.22.2')
EXCLUSIONS=('COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl')

def require(ok, message):
    if not ok: raise ValueError(message)
def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def object_sha(value): return hashlib.sha256(canonical(value)).hexdigest()
def create(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
def append(path, value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value, allow_nan=False)+'\n'); f.flush(); os.fsync(f.fileno())
def inventory(path, excluded=()):
    return {str(p.relative_to(path)):digest(p) for p in sorted(Path(path).rglob('*'))
            if p.is_file() and str(p.relative_to(path)) not in excluded}
def safe(root, name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe archive path')
    p=root/name; require(p.is_file() and p.resolve().is_relative_to(root.resolve()), 'Missing/escaping archive path'); return p


def model_payload(snapshot, repository, name):
    require(type(name) is str and name not in ('', '.', '..') and '/' not in name and '\\' not in name
            and not PureWindowsPath(name).drive and '\0' not in name, 'Expected model filename leaf')
    repo=Path(repository).resolve(strict=True); snap=Path(snapshot).resolve(strict=True)
    require(snap.is_dir() and snap.is_relative_to(repo), 'Snapshot outside bound model repository')
    path=snap/name; target=path.resolve(strict=True)
    require(target.is_file() and target.is_relative_to(repo), 'Model payload outside bound repository')
    return path


def validate_model_files(plan, weights=True):
    result={}
    for name, expected in plan['model_files'].items():
        if not weights and name == 'model.safetensors': continue
        path=model_payload(ROOT/plan['model_path'], ROOT/plan['model_cache_repository'], name)
        target=path.resolve(); before=target.stat(); actual=digest(target); after=target.stat()
        require((before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
                and path.resolve()==target and actual==expected, 'Model payload changed: '+name)
        result[name]=dict(sha256=actual, size_bytes=after.st_size, resolved_path=str(target))
    return result


def source_hashes():return {str((HERE/n).relative_to(ROOT)):digest(HERE/n) for n in SOURCES}


def fixed_decision():
    require(digest(DECISION)==DECISION_SHA,'Root decision changed')
    decision=read(DECISION)
    lineage=dict(decision['source_sha256'])
    lineage[str(DECISION.relative_to(ROOT))]=DECISION_SHA
    lineage[decision['supersedes']['path']]=decision['supersedes']['sha256']
    for name,h in lineage.items():require(digest(safe(ROOT,name))==h,'Decision lineage changed: '+name)
    require(decision['parser']['terminal_text']==['.','!','\n','\n\n'],'Literal terminators differ')
    return decision,lineage


def original_evidence():
    decision,lineage=fixed_decision()
    old=read(ORIGINAL/'plan.json');complete=read(ORIGINAL/'COMPLETE.json')
    collected=read(ORIGINAL/'COLLECTED.json');audit=read(ORIGINAL/'INDEPENDENT_AUDIT.json')
    old_sha=digest(ORIGINAL/'plan.json')
    require(complete['status']=='NATIVE_PRIVATE_INPUT_COMPLETE' and complete['implementation_pass'] is True
        and complete['native_gate_pass'] is False and complete['native_forwards']==20,'Original not the closed negative')
    require(audit['status']=='PASS' and audit['implementation_pass'] is True and audit['native_gate_pass'] is False
        and complete['plan_sha256']==audit['plan_sha256']==collected['plan_sha256']==old_sha
        and complete['report_sha256']==audit['report_sha256']==digest(ORIGINAL/'REPORT.json')
        and complete['independent_audit_sha256']==digest(ORIGINAL/'INDEPENDENT_AUDIT.json')
        and audit['collected_sha256']==digest(ORIGINAL/'COLLECTED.json'),'Original terminal linkage changed')
    expected=dict(collected['artifact_sha256'])
    for name,h in expected.items():require(digest(safe(ORIGINAL,name))==h,'Original collection changed')
    for name,h in complete['final_log_sha256'].items():require(digest(safe(ORIGINAL,name))==h,'Original operational logs changed')
    actual=inventory(ORIGINAL)
    require(set(actual)==set(expected)|set(old['collection_exclusions'])|{'COMPLETE.json','REPORT.json','INDEPENDENT_AUDIT.json'},'Unexpected original archive file')
    for group in ('source_sha256','lineage_sha256','review_sha256'):
        for name,h in old[group].items():require(digest(safe(ROOT,name))==h,'Original frozen binding changed');lineage[name]=h
    require(old['versions']==VERSIONS and old['installed_model_source_sha256']==MODEL_SOURCE_SHA
        and digest(MODEL_SOURCE)==MODEL_SOURCE_SHA,'Original runtime/source differs')
    calls=[json.loads(line) for line in (ORIGINAL/'calls.jsonl').read_text().splitlines()]
    require(len(calls)==len(old['cases'])==20,'Original paths incomplete')
    keys=('index','id','phase','repeat_of','carrier','a','b')
    for i,(case,row) in enumerate(zip(old['cases'],calls)):
        require(case['index']==i and case['id']==f'n{i:02d}' and canonical({k:row[k] for k in keys})==canonical({k:case[k] for k in keys})
            and row['forward_completed'] is True and row['controls_pass'] is True and row['error'] is None,'Original call identity/control differs')
        for pk,hk,ext in (('forward_path','forward_sha256','npz'),('forward_metadata_path','forward_metadata_sha256','json')):
            require(row[pk]==f'calls/{i:02d}.{ext}' and row[hk]==actual[row[pk]],'Original raw reference differs')
    return old,calls,actual,lineage,decision


def build_plan():
    old,calls,original_inventory,lineage,decision=original_evidence()
    metadata={k:old[k] for k in ('model_path','model_cache_repository','model_files','expected_host_state')}
    validate_model_files(metadata)
    return dict(status='FIXED_OUTCOME_EXPOSED_READOUT_DIAGNOSIS',created_at_utc=now(),settings=SETTINGS,
        versions=VERSIONS,**metadata,installed_model_source_path=str(MODEL_SOURCE.relative_to(ROOT)),
        installed_model_source_sha256=MODEL_SOURCE_SHA,source_sha256=source_hashes(),lineage_sha256=lineage,
        original_directory=str(ORIGINAL.relative_to(ROOT)),original_plan_sha256=digest(ORIGINAL/'plan.json'),
        original_inventory=original_inventory,original_calls=calls,cases=old['cases'],decision=decision,
        collection_exclusions=list(EXCLUSIONS),original_native_gate_pass=False,automatic_transfer=False,
        scientific_confirmation=False,novelty_established=False,no_retry=True,
        scope=decision['scope'],decoding=decision['decoding'],parser=decision['parser'])


def register():
    require(not OUT.exists(),'Registration already exists')
    plan=build_plan();reviews={}
    for name in ('SOURCE_REVIEW.json','PREPARATION_TESTS.json'):
        path=PREP/name;record=read(path)
        require(record['status'].startswith('PASS') and record['source_sha256']==plan['source_sha256'],'Stale/missing review')
        reviews[str(path.relative_to(ROOT))]=digest(path)
    plan['review_sha256']=reviews
    OUT.mkdir(parents=True);(OUT/'sources').mkdir()
    for name in SOURCES:shutil.copyfile(HERE/name,OUT/'sources'/name)
    create(OUT/'plan.json',plan);create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)


def verify(directory=OUT):
    directory=Path(directory);plan=read(directory/'plan.json');h=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==h,'Registration changed')
    require(plan['settings']==SETTINGS and plan['versions']==VERSIONS and plan['source_sha256']==source_hashes(),'Plan/source changed')
    require(plan['installed_model_source_sha256']==MODEL_SOURCE_SHA and digest(MODEL_SOURCE)==MODEL_SOURCE_SHA,'Native source changed')
    for name,expected in plan['source_sha256'].items():require(digest(directory/'sources'/Path(name).name)==expected,'Archived source changed')
    for group in ('lineage_sha256','review_sha256'):
        for name,expected in plan[group].items():require(digest(safe(ROOT,name))==expected,'Lineage/review changed')
    require(plan['original_directory']==str(ORIGINAL.relative_to(ROOT)) and inventory(ORIGINAL)==plan['original_inventory'],'Original archive changed')
    old=read(ORIGINAL/'plan.json')
    require(digest(ORIGINAL/'plan.json')==plan['original_plan_sha256'] and plan['cases']==old['cases']
        and plan['original_calls']==[json.loads(line) for line in (ORIGINAL/'calls.jsonl').read_text().splitlines()],'Original schedule changed')
    require(plan['decision']==read(DECISION) and plan['decoding']==plan['decision']['decoding']
        and plan['parser']==plan['decision']['parser'] and plan['collection_exclusions']==list(EXCLUSIONS),'Scientific contract changed')
    require(plan['original_native_gate_pass'] is False and plan['automatic_transfer'] is False,'Original closure changed')
    return plan,h


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['register']);parser.parse_args();register()
