"""Invented BF16 archives and a literal fake tokenizer; no model/real data."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib
import importlib.util
import json
from datetime import datetime,timedelta,timezone
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
spec=importlib.util.spec_from_file_location('readout_independent_audit',Path(__file__).with_name('audit.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

WORDS={0:'<EOS>',100:' turned',101:' switched',102:' on',103:' off',104:'.',105:' maybe',106:' and',107:'\n',108:' to',109:' the',110:' state',111:'!',112:' x',113:'?',114:'\n\n'}
def decode(ids):return ''.join(WORDS[i] for i in ids)
def save(path,value):path.write_text(json.dumps(value,allow_nan=False)+'\n')
def jsonl(path,rows):path.write_text(''.join(json.dumps(x,allow_nan=False)+'\n' for x in rows))
def logits(tokens):
    x=np.full((1,1,a.VOCAB),-16,dtype='<f4')
    for t in tokens:x[0,0,t]=1
    return x
def raw_pair(ids,x):return dict(input_ids=np.array([ids],dtype='<i8').tobytes(),full_logits=(x.view('<u4')>>16).astype('<u2').tobytes())


class Fixture:
    def __init__(self,directory,variant=None):
        self.root=Path(directory);(self.root/'calls').mkdir();self.sha='f'*64
        self.cases=a.expected_cases();self.paths=[];self.first=[];self.calls=[]
        self.old=dict(implementation_pass=True,native_gate_pass=False,primary=dict(n=16,correct=7,ties=0),rows=[])
        for case in self.cases:
            ids=[0]+[20]*39;ids[1]=30+a.CARRIERS.index(case['carrier']);ids[2]=40+case['a'];ids[-1]=50+case['b']
            case.update(input_ids=ids,prefix_index=20,candidate_ids={'on':544,'off':2126})
            first_token=101 if case['b'] else 100;x=logits([first_token])
            first=dict(values={'input_ids':np.array([ids],dtype='<i8'),'full_logits':x},raw=raw_pair(ids,x),metadata={})
            self.first.append(first)
            sequence=[[102 if case['a']^case['b'] else 103],[104]]
            if variant is not None:sequence=variant(case,sequence)
            generated=[first_token];indices=[];steps=[]
            decisions=[dict(source='original',call_index=None,maximizers=[first_token],selected_token=first_token)]
            for local,winners in enumerate(sequence):
                index=len(self.calls);x=logits(winners)
                identity=dict(index=index,path_id=case['id'],path_index=case['index'],step=local+1)
                row=self.write_call(identity,ids+generated,x);self.calls.append(row);indices.append(index)
                selected=winners[0] if len(winners)==1 else None
                decisions.append(dict(source='new',call_index=index,maximizers=winners,selected_token=selected))
                if selected is None:reason='tie';text=decode(generated);parsed=text;break
                generated.append(selected);reason,text,parsed=a.terminal(generated,decode)
                if reason is not None:break
            assert reason is not None
            path={k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
            path.update(generated_ids=generated,decoded_text=text,parser_text=parsed,stop_reason=reason,
                new_call_indices=indices,new_forward_count=len(indices),decisions=decisions)
            self.paths.append(path)
            self.old['rows'].append(dict(id=case['id'],target='on' if case['a']^case['b'] else 'off',correct=case['index']<7))

    def write_call(self,identity,ids,x):
        raw=raw_pair(ids,x);arrays={};descriptors={}
        for name,value in (('input_ids',np.array([ids],dtype='<i8')),('full_logits',x)):
            rb=np.frombuffer(raw[name],dtype='uint8');arrays[name+'__raw_uint8']=rb;arrays[name+'__value']=value
            descriptors[name]=dict(dtype='torch.int64' if name=='input_ids' else 'torch.bfloat16',shape=list(value.shape),
                raw_key=name+'__raw_uint8',value_key=name+'__value',raw_sha256=hashlib.sha256(raw[name]).hexdigest(),finite=bool(np.isfinite(value).all()))
        fp=f"calls/{identity['index']:04d}.npz";mp=fp[:-4]+'.json';np.savez_compressed(self.root/fp,**arrays)
        save(self.root/mp,dict(identity,plan_sha256=self.sha,tensors=descriptors))
        return dict(identity,forward_path=fp,forward_metadata_path=mp,forward_sha256=a.digest(self.root/fp),
                    forward_metadata_sha256=a.digest(self.root/mp),forward_completed=True,controls_pass=True,error=None)

    def chains(self):
        a.validate_cases(self.cases)
        return [a.validate_chain(c,p,f,self.calls,self.root,self.sha,decode) for c,p,f in zip(self.cases,self.paths,self.first)]
    def grade(self):return a.grade_complete(self.chains(),self.old,decode)

    def seal_archive(self,original):
        """Produce all lifecycle/state records from invented values, no primary imports."""
        original=Path(original);(original/'calls').mkdir()
        save(original/'plan.json',{'cases':self.cases});old_sha=a.digest(original/'plan.json')
        oldrows=[];proofs=[]
        for c,first in zip(self.cases,self.first):
            stem=f"calls/{c['index']:02d}";arrays={};descs={}
            for name in ('input_ids','full_logits'):
                value=first['values'][name];raw=first['raw'][name]
                arrays[name+'__raw_uint8']=np.frombuffer(raw,dtype='uint8');arrays[name+'__value']=value
                descs[name]=dict(dtype='torch.int64' if name=='input_ids' else 'torch.bfloat16',shape=list(value.shape),
                    raw_key=name+'__raw_uint8',value_key=name+'__value',raw_sha256=hashlib.sha256(raw).hexdigest(),finite=True)
            identity={k:c[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
            np.savez_compressed(original/(stem+'.npz'),**arrays);save(original/(stem+'.json'),dict(identity,plan_sha256=old_sha,tensors=descs))
            refs=dict(forward_path=stem+'.npz',forward_sha256=a.digest(original/(stem+'.npz')),
                forward_metadata_path=stem+'.json',forward_metadata_sha256=a.digest(original/(stem+'.json')))
            oldrows.append(dict(identity,**refs,forward_completed=True,controls_pass=True,error=None))
            maxima=a.maximal_ids(first['values']['full_logits'])
            proof=dict(id=c['id'],original=refs,input_ids_raw_sha256=descs['input_ids']['raw_sha256'],
                full_logits_raw_sha256=descs['full_logits']['raw_sha256'],maximizers=maxima,selected_token=maxima[0])
            proofs.append(proof);self.paths[c['index']]['original_first']=proof
        jsonl(original/'calls.jsonl',oldrows);save(original/'REPORT.json',self.old)
        save(original/'INDEPENDENT_AUDIT.json',dict(status='PASS',implementation_pass=True,native_gate_pass=False,
            plan_sha256=old_sha,report_sha256=a.digest(original/'REPORT.json')))
        save(original/'COMPLETE.json',dict(status='NATIVE_PRIVATE_INPUT_COMPLETE',implementation_pass=True,native_gate_pass=False,
            native_forwards=20,plan_sha256=old_sha,report_sha256=a.digest(original/'REPORT.json'),independent_audit_sha256=a.digest(original/'INDEPENDENT_AUDIT.json')))
        sources={f'invented/{name}':'0'*64 for name in ('protocol.py','worker.py','owner.py','audit.py','test_native.py','test_audit.py')}
        states={f'p{i}':'a'*64 for i in range(219)}
        plan=dict(cases=self.cases,source_sha256=sources,original_calls=oldrows,original_plan_sha256=old_sha,
            original_inventory={str(p.relative_to(original)):a.digest(p) for p in original.rglob('*') if p.is_file()},
            expected_host_state=states,model_files={'config.json':'b'*64},versions={'numpy':np.__version__},installed_model_source_sha256='c'*64,
            settings=dict(max_rss_bytes=10*1024**3,max_mps_bytes=10*1024**3,max_archive_bytes=1024**3),
            parser=dict(body_regex=a.BODY,terminal_text=['.','!','\n','\n\n']),decoding=dict(total_generated_token_cap=16,eos_id=0),
            collection_exclusions=['COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl'])
        save(self.root/'plan.json',plan);save(self.root/'REGISTRATION.json',{'plan_sha256':self.sha})
        (self.root/'sources').mkdir()
        for name in sources:(self.root/'sources'/Path(name).name).write_text('invented\n')
        for name in ('worker.log','independent_audit.log','owner-events.jsonl'):(self.root/name).write_text('')
        base=datetime(2026,1,1,tzinfo=timezone.utc);at=lambda x:(base+timedelta(seconds=x)).isoformat()
        save(self.root/'STARTED.json',dict(at_utc=at(0),deadline_utc=at(900),owner_pid=111,plan_sha256=self.sha))
        save(self.root/'WORKER_STARTED.json',dict(at_utc=at(.1),deadline_utc=at(900),owner_pid=111,worker_pid=112,plan_sha256=self.sha))
        jsonl(self.root/'calls.jsonl',self.calls);jsonl(self.root/'paths.jsonl',self.paths)
        save(self.root/'ORIGINAL_FIRST.json',dict(plan_sha256=self.sha,original_plan_sha256=old_sha,rows=proofs))
        identity=dict(training={'':True},requires_grad={f'p{i}':True for i in range(218)},parameters={f'p{i}':[i+1,i+1000,'mps:0','torch.bfloat16'] for i in range(218)},
            buffers={},grads_none={f'p{i}':True for i in range(218)},hooks={},forward_methods={'':[False,999]},generation_config={},
            config=dict(hidden_size=1024,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,vocab_size=a.VOCAB,logits_scaling=6.,use_cache=True))
        for name in ('IDENTITY_BEFORE.json','IDENTITY_AFTER.json'):save(self.root/name,identity)
        configured=json.loads(json.dumps(identity));configured.update(training={'':False},requires_grad={k:False for k in identity['parameters']});configured['config']['use_cache']=False
        save(self.root/'IDENTITY_CONFIGURED.json',configured)
        for name in ('STATE_BEFORE.json','STATE_AFTER.json'):save(self.root/name,states)
        for name in ('MODEL_CACHE_BEFORE.json','MODEL_CACHE_AFTER.json'):save(self.root/name,{'config.json':{'sha256':'b'*64}})
        save(self.root/'RUNTIME.json',dict(versions=plan['versions'],device='mps',dtype='torch.bfloat16',threads=4,initial_seed=42,
            attention='eager',cache=False,no_task_hooks=True,logits_to_keep=1,model_source_sha256='c'*64,decoder='tokenizers.Tokenizer.decode',skip_special_tokens=False))
        events=[dict(event='worker_started'),dict(event='original_validated',rows=20),dict(event='model_load_started'),dict(event='model_load_finished')]
        resources=[('before_load',None,None),('after_load',None,None)]
        for path in self.paths:
            events.append(dict(event='path_started',id=path['id'],index=path['index']))
            for j,index in enumerate(path['new_call_indices']):
                for kind in ('forward_started','forward_returned','call_saved'):
                    e=dict(event=kind,index=index,path_id=path['id'],step=j+1)
                    if kind=='call_saved':e['controls_pass']=True
                    events.append(e)
                resources.extend((s,path['id'],index) for s in ('before_forward','after_forward'))
            events.append(dict(event='path_completed',id=path['id'],index=path['index'],new_forward_count=path['new_forward_count'],stop_reason=path['stop_reason']))
        events.append(dict(event='worker_completed'));resources.append(('complete',None,None))
        for i,event in enumerate(events):event['at_utc']=at(1+i*.1)
        jsonl(self.root/'worker-events.jsonl',events)
        samples=[dict(stage=s,call_id=p,call_index=i,at_utc=at(1+k*.1),elapsed_seconds=1+k*.1,rss_high_water_bytes=1000,
            mps_driver_bytes=2000,mps_allocated_bytes=1000,archive_bytes=3000) for k,(s,p,i) in enumerate(resources)]
        jsonl(self.root/'worker-resources.jsonl',samples)
        jsonl(self.root/'resource-monitor.jsonl',[dict(stage=s,pid=112,at_utc=at(t),elapsed_seconds=t,child_tree_rss_bytes=2000,archive_bytes=3000)
            for s,t in (('worker',1),('worker',800),('independent_audit',801))])
        counts=a.operation_counts(self.chains())
        save(self.root/'WORKER_COMPLETE.json',dict(status='WORKER_COLLECTED_UNGRADED',at_utc=at(800),plan_sha256=self.sha,counts=counts,
            resource_samples=samples,all_structural_controls_pass=True,state_unchanged=True,ownership_restored=True,cache_unchanged=True,
            paths_completed=20,task_scores_computed=False))
        excluded=set(plan['collection_exclusions'])
        hashes={str(p.relative_to(self.root)):a.digest(p) for p in self.root.rglob('*') if p.is_file() and str(p.relative_to(self.root)) not in excluded}
        save(self.root/'COLLECTED.json',dict(status='COLLECTED_UNGRADED',plan_sha256=self.sha,counts=counts,artifact_sha256=hashes,task_scores_computed=False))
        return plan


class ParserTests(unittest.TestCase):
    def test_exact_root_body_and_terminals(self):
        for body in ('on','off','turned on','switched off','turned to on','switched to the off state'):
            state='off' if 'off' in body else 'on'
            for end in ('.','!','\n','\n\n'):
                with self.subTest(body=body,end=end):self.assertEqual(a.parse_clause(' \t'+body+end+' \t','text_terminator'),(state,'accepted'))
            self.assertEqual(a.parse_clause(body,'eos'),(state,'accepted'))

    def test_no_substring_negation_echo_or_unfinished_rescue(self):
        for text in ('not on.','turned on or off.','turned on. More','The lamp is on.','on?','turned  on.','on\n\n\n','turned to the on state,','maybe on.'):
            with self.subTest(text=text):self.assertIsNone(a.parse_clause(text,'text_terminator')[0])
        self.assertEqual(a.parse_clause('turned on','cap'),(None,'unresolved_cap'))
        self.assertEqual(a.parse_clause('turned','eos'),(None,'unresolved_grammar'))

    def test_eos_preserved_but_excluded_from_parser(self):
        self.assertEqual(a.terminal([100,102,0],decode),('eos',' turned on<EOS>',' turned on'))
        self.assertEqual(a.terminal([100,102],decode),(None,' turned on',' turned on'))


class ArchiveTests(unittest.TestCase):
    def fixture(self,variant=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);return Fixture(temp.name,variant)
    def test_complete20_truth_first_reuse_and_repeats(self):
        f=self.fixture();r=f.grade();self.assertEqual(r['primary'],dict(n=16,correct=16,wrong=0,unresolved=0))
        self.assertTrue(r['repeat_stability_pass']);self.assertEqual(r['repeats']['exact_matches'],4)
        self.assertFalse(r['original_native_gate_pass']);self.assertFalse(r['automatic_transfer'])
        self.assertEqual(r['rows'][0]['first_state_token_position'],2)

    def test_wrong_tie_and_cap_retained(self):
        def variant(c,s):
            if c['index']==0:return [[102],[104]]
            if c['index']==1:return [[102,103]]
            if c['index']==2:return [[112]]*15
            return s
        r=self.fixture(variant).grade();self.assertEqual(r['primary'],dict(n=16,correct=13,wrong=1,unresolved=2))
        self.assertEqual(len(r['rows']),20);self.assertEqual(r['rows'][2]['new_forward_count'],15)

    def test_unparsed_completed_phrase_remains_denominator(self):
        f=self.fixture(lambda c,s:[[105],[102],[104]] if c['index']==0 else s)
        r=f.grade();self.assertEqual(r['primary']['unresolved'],1)
        self.assertEqual(r['rows'][0]['parser_reason'],'unresolved_grammar')

    def test_finite_repeat_wrong_path_does_not_replace_primary(self):
        r=self.fixture(lambda c,s:[[102],[104]] if c['index']==16 else s).grade()
        self.assertEqual(r['primary']['correct'],16);self.assertFalse(r['repeat_stability_pass'])
        self.assertEqual(r['repeats']['exact_matches'],3)

    def test_candidate_forcing_and_metadata_changes_rejected(self):
        f=self.fixture();f.paths[0]['generated_ids'][1]=102
        with self.assertRaisesRegex(a.AuditError,'Recorded generated'):f.chains()

    def test_incomplete_chain_and_extra_after_terminal_rejected(self):
        f=self.fixture();f.paths[0]['new_call_indices']=f.paths[0]['new_call_indices'][:1]
        with self.assertRaisesRegex(a.AuditError,'Truncated'):f.chains()
        f=self.fixture();f.paths[0]['new_call_indices'].append(2)
        with self.assertRaisesRegex(a.AuditError,'Extra new call'):f.chains()

    def test_changed_actual_growing_ids_rejected(self):
        f=self.fixture();row=f.calls[0]
        identity={k:row[k] for k in ('index','path_id','path_index','step')}
        f.calls[0]=f.write_call(identity,f.cases[0]['input_ids']+[101],logits([103]))
        with self.assertRaisesRegex(a.AuditError,'Growing input'):f.chains()

    def test_last_path_nonfinite_no_earlier_parse(self):
        f=self.fixture();i=len(f.calls)-1;row=f.calls[i];identity={k:row[k] for k in ('index','path_id','path_index','step')}
        x=logits([104]);x[0,0,200]=np.inf
        f.calls[i]=f.write_call(identity,f.cases[-1]['input_ids']+[101,103],x)
        with patch.object(a,'parse_clause',side_effect=AssertionError('must not grade')) as spy:
            with self.assertRaisesRegex(a.AuditError,'Nonfinite'):f.grade()
            spy.assert_not_called()

    def test_raw_readable_and_hash_shape_guards(self):
        f=self.fixture();p=f.root/f.calls[0]['forward_metadata_path'];m=a.read(p);m['tensors']['full_logits']['shape']=[a.VOCAB];save(p,m)
        f.calls[0]['forward_metadata_sha256']=a.digest(p)
        with self.assertRaisesRegex(a.AuditError,'descriptor'):f.chains()

    def test_original_closure_must_not_be_repaired(self):
        f=self.fixture();f.old['native_gate_pass']=True
        with self.assertRaisesRegex(a.AuditError,'Original negative'):f.grade()

    def test_complete_saved_archive_metadata_then_all20_grade(self):
        f=self.fixture();original=tempfile.TemporaryDirectory();self.addCleanup(original.cleanup)
        plan=f.seal_archive(original.name)
        r=a.audit_records(f.root,original.name,plan,f.sha,decode)
        self.assertEqual(r['physical_counts']['forward_finished'],40)
        self.assertEqual(r['resources']['worker_events'],165)
        self.assertEqual(r['resources']['worker_resource_samples'],83)
        self.assertEqual(r['primary']['correct'],16);self.assertFalse(r['original_native_gate_pass'])

    def test_saved_final_event_corruption_prevents_any_grade(self):
        f=self.fixture();original=tempfile.TemporaryDirectory();self.addCleanup(original.cleanup)
        plan=f.seal_archive(original.name);path=f.root/'worker-events.jsonl';events=a.lines(path);events[-1]['event']='not_complete';jsonl(path,events)
        c=a.read(f.root/'COLLECTED.json');c['artifact_sha256']['worker-events.jsonl']=a.digest(path);save(f.root/'COLLECTED.json',c)
        with patch.object(a,'parse_clause',side_effect=AssertionError('must not grade')) as spy:
            with self.assertRaisesRegex(a.AuditError,'Journal order'):a.audit_records(f.root,original.name,plan,f.sha,decode)
            spy.assert_not_called()


if __name__=='__main__':unittest.main()
