"""Supplementary saved-checkpoint inference replay, never optimization replay.

Independent explicit linear/GELU networks and feature construction. No import of
production models/world/selectors/auditor. Writes work receipts only; phase inputs
are read-only. Evaluation requires both complete acquisition and collection.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import platform
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT/'outputs/world-model-planning/ACQUISITION_V1'
WORK = Path(__file__).resolve().parent
SEEDS = [11, 29, 47]
ARMS = ['random', 'uncertainty', 'decision', 'replay']


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')


def ints(values):
    return type(values) is list and all(type(v) is int for v in values)


def inputs(states):
    """Build every current-state/action feature and public candidate independently."""
    require(len(states) == 30 and len({tuple(s) for s in states}) == 30, 'State count/uniqueness')
    candidates = np.zeros((30, 12), dtype=np.float32)
    queries = np.zeros((120, 16), dtype=np.float32)
    for i, state in enumerate(states):
        require(ints(state) and len(state) == 3, 'State format')
        x, y, key = state
        require(0 <= x < 5 and 0 <= y < 5 and key in (0, 1), 'State support')
        for index in (x, 5+y, 10+key): candidates[i, index] = 1.0
        for action in range(4):
            queries[4*i+action, :12] = candidates[i]
            queries[4*i+action, 12+action] = 1.0
    return torch.from_numpy(queries), torch.from_numpy(candidates)


def parameter_shapes(kind):
    widths = [16, 64, 64, 30] if kind == 'direct' else [28, 71, 71, 1]
    shapes = {}
    for pos, (n, m) in zip((0, 2, 4), zip(widths[:-1], widths[1:])):
        shapes[f'net.{pos}.weight'] = (m, n)
        shapes[f'net.{pos}.bias'] = (m,)
    return shapes


def check_tensor(t, shape, label):
    require(isinstance(t, torch.Tensor) and tuple(t.shape) == tuple(shape), label+' shape')
    require(t.dtype == torch.float32 and t.device.type == 'cpu', label+' dtype/device')
    require(not t.requires_grad and bool(torch.isfinite(t).all()), label+' finite/no-grad')


def forward(kind, weights, queries, candidates):
    """The complete independent network, preserving native batch shape and dtype."""
    if kind == 'direct':
        h = queries
    else:
        h = torch.cat((queries[:, None, :].expand(120, 30, 16),
                       candidates[None, :, :].expand(120, 30, 12)), dim=2)
    h = F.linear(h, weights['net.0.weight'], weights['net.0.bias'])
    h = F.gelu(h, approximate='none')
    h = F.linear(h, weights['net.2.weight'], weights['net.2.bias'])
    h = F.gelu(h, approximate='none')
    h = F.linear(h, weights['net.4.weight'], weights['net.4.bias'])
    if kind == 'energy': h = -h[..., 0]
    return h.reshape(30, 4, 30)


def optimizer_check(optimizer, weights, kind, round_number):
    require(type(optimizer) is dict and set(optimizer) == {'state', 'param_groups'}, 'Optimizer schema')
    groups = optimizer['param_groups']; require(len(groups) == 1, 'Optimizer groups')
    group = groups[0]
    require(group['lr'] == .003 and group['weight_decay'] == 0, 'Optimizer lr/decay')
    require(tuple(group['betas']) == (.9, .999) and group['eps'] == 1e-8, 'Adam defaults')
    require(group['amsgrad'] is False and group['maximize'] is False, 'Optimizer mode')
    require(group.get('decoupled_weight_decay', False) is False, 'Not AdamW')
    require(group['params'] == list(range(6)) and set(optimizer['state']) == set(range(6)), 'Optimizer parameter identities')
    expected = 1500 + 250*round_number
    for i, name in enumerate(parameter_shapes(kind)):
        state = optimizer['state'][i]
        require(set(state) == {'step', 'exp_avg', 'exp_avg_sq'}, 'Adam state keys')
        check_tensor(state['step'], (), 'Adam step')
        require(float(state['step']) == expected, 'Wrong Adam step')
        for key in ['exp_avg', 'exp_avg_sq']:
            check_tensor(state[key], weights[name].shape, 'Adam '+key)
        require(bool((state['exp_avg_sq'] >= 0).all()), 'Negative second moment')
    return expected


def checkpoint(path, kind, round_number, acquired, train, query, audit_ids,
               features, target_rows, phase_dir, bindings):
    def bound(p):
        rel = str(p.relative_to(phase_dir))
        require(rel in bindings and sha(p) == bindings[rel], 'Unbound artifact '+rel)
        return bindings[rel]
    before = bound(path)
    record = torch.load(path, map_location='cpu', weights_only=True)
    require(type(record) is dict and set(record) == {'model', 'optimizer', 'metadata'}, 'Checkpoint schema')
    weights = record['model']; shapes = parameter_shapes(kind)
    require(set(weights) == set(shapes), 'Weight names')
    for name, shape in shapes.items(): check_tensor(weights[name], shape, name)
    require(sum(v.numel() for v in weights.values()) == {'direct': 7198, 'energy': 7243}[kind], 'Parameter count')
    require(len(set(acquired)) == len(acquired) and set(acquired) <= set(query), 'Query permissions')
    allowed = sorted(set(train) | set(acquired))
    require(not set(allowed) & set(audit_ids), 'Audit target exposed')
    metadata = record['metadata']
    require(type(metadata) is dict and set(metadata) == {'round', 'queries', 'observed'}, 'Metadata schema')
    require(type(metadata['round']) is int and metadata['round'] == round_number, 'Metadata round')
    require(ints(metadata['queries']) and metadata['queries'] == acquired, 'Metadata queries')
    require(ints(metadata['observed']) and metadata['observed'] == allowed, 'Metadata observed IDs')
    step = optimizer_check(record['optimizer'], weights, kind, round_number)
    stem = path.with_suffix(''); raw_path = stem.with_suffix('.npy')
    batch_path = Path(str(stem)+'_batches.npy'); train_path = Path(str(stem)+'_training.json')
    raw_sha = bound(raw_path); batch_sha = bound(batch_path); training_sha = bound(train_path)
    batches = np.load(batch_path, allow_pickle=False)
    require(batches.dtype == np.int64 and batches.shape == (1500 if round_number == 0 else 250, 32), 'Batch shape/dtype')
    require(set(map(int, batches.reshape(-1))) <= set(allowed), 'Unobserved target in batch')
    training = read(train_path)
    require(training['updates'] == (1500 if round_number == 0 else 250), 'Training update record')
    used_targets = np.asarray([[target_rows[int(i)] for i in row] for row in batches], dtype=np.int64)
    require(hashlib.sha256(used_targets.tobytes()).hexdigest() == training['used_targets_sha256'], 'Used target digest')
    if round_number:
        require(training['round'] == round_number and training['queries'] == len(acquired), 'Training round/query count')
    saved = np.load(raw_path, allow_pickle=False)
    require(saved.shape == (30, 4, 30) and saved.dtype == np.float32 and np.isfinite(saved).all(), 'Archived logits')
    with torch.inference_mode(): result = forward(kind, weights, *features)
    check_tensor(result, (30, 4, 30), 'Replay output')
    actual = result.numpy()
    require(actual.tobytes(order='C') == saved.tobytes(order='C'), 'Saved logits do not match weights exactly: '+str(path))
    require(sha(path) == before and sha(raw_path) == raw_sha, 'Checkpoint/prediction modified during replay')
    return {'checkpoint': str(path.relative_to(STUDY)), 'checkpoint_sha256': before,
            'prediction_sha256': raw_sha, 'batches_sha256': batch_sha, 'training_sha256': training_sha,
            'round': round_number, 'adam_step': step, 'queries': acquired, 'observed_count': len(allowed),
            'exact_float32_bytes': True, 'logit_values': 3600,
            'replayed_raw_sha256': hashlib.sha256(actual.tobytes()).hexdigest()}


def run(phase):
    require(phase in ['engineering', 'evaluation'], 'Unknown phase')
    folder = STUDY/phase
    # This guard runs before any phase checkpoint, raw prediction or query is read.
    require((folder/'ACQUISITION_COMPLETE.json').is_file() and (folder/'COLLECTED.json').is_file()
            and not (folder/'STOP.json').exists(), 'Phase is incomplete or stopped')
    final = WORK/f'{phase.upper()}_WEIGHT_REVIEW.json'
    started = WORK/f'{phase.upper()}_STARTED_WEIGHT_REVIEW.json'
    require(not final.exists() and not started.exists(), 'Refuse replay/check retries')
    plan = read(STUDY/'plan.json'); plan_sha = sha(STUDY/'plan.json')
    require(plan['schema'] == 'world-model-acquisition-v1' and plan['seeds'] == SEEDS and plan['arms'] == ARMS, 'Plan panel')
    require(plan['training']['device'] == 'cpu' and plan['training']['dtype'] == 'float32' and plan['training']['threads'] == 2, 'CPU FP32 two-thread contract')
    runtime = {'python': sys.version.split()[0], 'torch': torch.__version__, 'numpy': np.__version__}
    require(runtime == plan['runtime'], 'Runtime differs; exact same-runtime replay required')
    if phase == 'engineering':
        audit = read(folder/'AUDIT.json')
        require(audit['status'] == 'PASS' and audit['plan_sha256'] == plan_sha and audit['collected_sha256'] == sha(folder/'COLLECTED.json'), 'Engineering audit binding')
    else:
        freeze = read(folder/'FREEZE.json'); old_audit = STUDY/'engineering/AUDIT.json'
        require(read(old_audit)['status'] == 'PASS' and freeze['engineering_audit_sha256'] == sha(old_audit), 'Evaluation admission')
    collected = read(folder/'COLLECTED.json'); acquisition = read(folder/'ACQUISITION_COMPLETE.json')
    require(collected['status'] == 'COLLECTED_PENDING_AUDIT', 'Collection status')
    bindings = collected['files_sha256']; acquisition_bindings = acquisition['files_sha256']
    require(bindings['ACQUISITION_COMPLETE.json'] == sha(folder/'ACQUISITION_COMPLETE.json'), 'Acquisition seal')
    require(all(bindings.get(k) == v for k, v in acquisition_bindings.items()), 'Acquisition/collection bindings differ')
    save(started, {'status': 'SAVED_INFERENCE_REPLAY_STARTED', 'at_utc': datetime.now(timezone.utc).isoformat(),
                  'phase': phase, 'code_sha256': sha(__file__), 'plan_sha256': plan_sha,
                  'acquisition_complete_sha256': sha(folder/'ACQUISITION_COMPLETE.json'),
                  'collected_sha256': sha(folder/'COLLECTED.json')})
    t0 = time.monotonic(); rows = []
    try:
        torch.set_num_threads(2); torch.use_deterministic_algorithms(True)
        require(torch.get_num_threads() == 2, 'Thread count')
        maps = [m for m in plan['maps'] if m['phase'] == phase]
        require(len(maps) == (4 if phase == 'engineering' else 8), 'Map count')
        expected_checkpoints = set()
        for m in maps:
            features = inputs(m['states']); train = m['splits']['train']; query = m['splits']['query']; audit_ids = m['splits']['audit']
            require(ints(train) and ints(query) and ints(audit_ids), 'Split IDs')
            require(len(train) == 72 and len(query) == len(audit_ids) == 24 and len(set(train+query+audit_ids)) == 120, 'Split support')
            targets = np.asarray(m['transitions'], dtype=np.int64).reshape(120)
            for seed in SEEDS:
                for kind in ['direct', 'energy']:
                    model_dir = folder/m['id']/f'{kind}_{seed}'
                    path = model_dir/'base.pt'; expected_checkpoints.add(str(path.relative_to(folder)))
                    rows.append(checkpoint(path, kind, 0, [], train, query, audit_ids, features, targets, folder, bindings))
                    for arm in ARMS:
                        acquired = []; previous = model_dir/'base.npy'
                        for rnd in range(1, 5):
                            require(time.monotonic()-t0 < 300, 'Saved replay timeout')
                            qpath = model_dir/arm/f'round_{rnd}_query.json'
                            rel = str(qpath.relative_to(folder)); require(bindings.get(rel) == sha(qpath), 'Query binding')
                            q = read(qpath)
                            require(q['round'] == rnd and q['method'] == arm and q['seed'] == seed and q['map'] == m['id'], 'Query identity')
                            require(q['prediction_sha256'] == sha(previous) and q['remaining_before'] == sorted(set(query)-set(acquired)), 'Query prefix')
                            if arm == 'replay':
                                require(q['selected'] is None and q['revealed_target'] is None and q['acquired'] == [], 'Replay observes no queries')
                            else:
                                require(type(q['selected']) is int and q['selected'] in set(query)-set(acquired), 'Query not permitted')
                                acquired.append(q['selected'])
                                require(type(q['revealed_target']) is int and q['revealed_target'] == int(targets[q['selected']]), 'Queried target')
                            require(ints(q['acquired']) and q['acquired'] == acquired, 'Acquired history')
                            path = model_dir/arm/f'round_{rnd}.pt'; expected_checkpoints.add(str(path.relative_to(folder)))
                            rows.append(checkpoint(path, kind, rnd, list(acquired), train, query, audit_ids, features, targets, folder, bindings))
                            previous = path.with_suffix('.npy')
        require(expected_checkpoints == {k for k in acquisition_bindings if k.endswith('.pt')}, 'Checkpoint inventory')
        require(len(rows) == len(maps)*102, 'Incomplete checkpoint census')
        for rel, h in bindings.items(): require(sha(folder/rel) == h, 'Phase changed at closure: '+rel)
        require(sha(STUDY/'plan.json') == plan_sha, 'Plan changed')
        result = {'status': 'PASS_SAVED_WEIGHT_INFERENCE_REPLAY', 'at_utc': datetime.now(timezone.utc).isoformat(),
                  'phase': phase, 'plan_sha256': plan_sha, 'checker_sha256': sha(__file__),
                  'acquisition_complete_sha256': sha(folder/'ACQUISITION_COMPLETE.json'),
                  'collected_sha256': sha(folder/'COLLECTED.json'), 'started_sha256': sha(started),
                  'arithmetic_audit_sha256_if_present': sha(folder/'AUDIT.json') if (folder/'AUDIT.json').is_file() else None,
                  'runtime': runtime, 'platform': platform.platform(), 'torch_threads': torch.get_num_threads(),
                  'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                  'maps': len(maps), 'checkpoints_per_map': 102, 'checkpoints': len(rows),
                  'neural_saved_inference_replays': len(rows), 'exact_raw_logit_values': len(rows)*3600,
                  'all_float32_logits_byte_exact': True, 'all_optimizer_step_lr_decay_checks': True,
                  'all_observed_query_and_used_target_checks': True, 'phase_files_unchanged': True,
                  'rows': rows, 'elapsed_seconds': time.monotonic()-t0,
                  'independence': 'Explicit feature construction and linear/GELU direct and negative-energy forwards; no production models.py or scientific helpers imported. Same pinned CPU FP32/two-thread runtime, exact byte comparison, no numerical allowance.',
                  'scope': 'Saved-checkpoint inference and optimizer/observation metadata provenance only. This does not reproduce gradients, validate every historical optimizer update, or independently establish how the checkpoints were trained. No scientific prediction or selection is changed.',
                  'gradients': 0, 'fits': 0, 'optimizer_updates': 0, 'provider_calls': 0, 'new_spending_usd': 0}
        save(final, result)
        return {k: result[k] for k in ['status', 'phase', 'checkpoints', 'exact_raw_logit_values', 'elapsed_seconds']}
    except BaseException as exc:
        save(final, {'status': 'FAIL_SAVED_WEIGHT_INFERENCE_REPLAY', 'phase': phase, 'plan_sha256': plan_sha,
                     'checker_sha256': sha(__file__), 'type': type(exc).__name__, 'reason': str(exc),
                     'verified_checkpoint_prefix': rows, 'elapsed_seconds': time.monotonic()-t0,
                     'no_retry': True, 'fits': 0, 'provider_calls': 0})
        raise


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--phase', choices=['engineering', 'evaluation'], required=True)
    print(json.dumps(run(ap.parse_args().phase)), flush=True)
