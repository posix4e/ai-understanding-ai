"""Separate arithmetic/path checker; same author as diagnostic.py, no imports from it.

Uses literal world closure, forward BFS, scalar fsum Bellman reductions and its own
controller simulation/summary/census. No neural library or original helper imports.
"""
from collections import deque, Counter
from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import math
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'outputs/world-model-planning/ACQUISITION_DIAGNOSTIC_V1'


def need(ok, msg):
    if not ok: raise ValueError(msg)


def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())


def save(p, value):
    with Path(p).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n')


def compare(a, b, where='root'):
    if isinstance(a, dict):
        need(isinstance(b, dict) and a.keys() == b.keys(), where+' keys')
        for k in a: compare(a[k], b[k], where+'.'+k)
    elif isinstance(a, list):
        need(isinstance(b, list) and len(a) == len(b), where+' length')
        for i, (x, y) in enumerate(zip(a, b)): compare(x, y, where+f'[{i}]')
    elif type(a) is float:
        need(type(b) in (float, int) and math.isfinite(a) and math.isfinite(b)
             and math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-10), where+' numeric')
    else: need(type(a) is type(b) and a == b, where+' exact')


def transition(s, a):
    x, y, k = s
    xx, yy = [(x, y-1), (x+1, y), (x, y+1), (x-1, y)][a]
    if xx < 0 or xx > 4 or yy < 0 or yy > 4 or (xx == 2 and yy != 2) or ((xx, yy) == (2, 2) and k == 0):
        return s
    return (xx, yy, int(k == 1 or (xx, yy) == (0, 4)))


def world():
    states = {(0, 0, 0)}
    while True:
        more = states | {transition(s, a) for s in states for a in range(4)}
        if more == states: break
        states = more
    states = sorted(states); index = {s: i for i, s in enumerate(states)}
    table = [[index[transition(s, a)] for a in range(4)] for s in states]
    return states, table


def distance(table, states, s, g):
    frontier = deque([(s, 0)]); visited = {s}
    while frontier:
        t, n = frontier.popleft()
        if list(states[t][:2]) == list(g): return n
        for nxt in table[t]:
            if nxt not in visited:
                visited.add(nxt); frontier.append((nxt, n+1))
    raise ValueError('unreachable')


def softmax(logits):
    rows = []
    for row in logits.reshape(-1, logits.shape[-1]):
        top = max(map(float, row)); e = [math.exp(float(v)-top) for v in row]; z = math.fsum(e)
        rows.append([v/z for v in e])
    return np.asarray(rows).reshape(logits.shape)


def decision(P, states, goal):
    n = len(states); values = [abs(s[0]-goal[0])+abs(s[1]-goal[1]) for s in states]
    goalset = {i for i, s in enumerate(states) if list(s[:2]) == list(goal)}
    for _ in range(16):
        q = [[1+math.fsum(float(P[s, a, t])*values[t] for t in range(n)) for a in range(4)] for s in range(n)]
        values = [0.0 if s in goalset else min(q[s]) for s in range(n)]
    choices = [[a for a in range(4) if q[s][a] <= min(q[s])+1e-12] for s in range(n)]
    return [a[0] for a in choices], [len(a) for a in choices]


def execute(table, states, P, choice, nties, case, blind, cap=40):
    s = z = case['start']; pairs = [(s, z)]; aa = []; tt = []
    reason = 'cap'
    for _ in range(cap):
        if list(states[s][:2]) == case['goal']:
            reason = 'goal'; break
        a = choice[z]; aa.append(a); tt.append(nties[z]); oldz = z
        s = table[s][a]
        if blind:
            row = list(map(float, P[oldz, a])); z = row.index(max(row))
        else: z = s
        repeated = (s, z) in pairs
        pairs.append((s, z))
        if list(states[s][:2]) == case['goal']:
            reason = 'goal'; break
        if repeated:
            reason = 'joint_cycle'; break
    return {**case, 'true_states': [v[0] for v in pairs], 'internal_states': [v[1] for v in pairs],
            'actions': aa, 'tie_counts': tt, 'success': reason == 'goal', 'stop_reason': reason, 'steps': len(aa)}


def summarize(rows, base):
    good = [r for r in rows if r['success']]
    counts = Counter(r['stop_reason'] for r in rows)
    paired = {'success_to_failure': 0, 'failure_to_success': 0, 'action_sequence_changed': 0,
              'both_success_shorter': 0, 'both_success_longer': 0}
    for r, b in zip(rows, base):
        paired['success_to_failure'] += int(b['success'] and not r['success'])
        paired['failure_to_success'] += int(not b['success'] and r['success'])
        paired['action_sequence_changed'] += int(b['actions'] != r['actions'])
        paired['both_success_shorter'] += int(b['success'] and r['success'] and r['steps'] < b['steps'])
        paired['both_success_longer'] += int(b['success'] and r['success'] and r['steps'] > b['steps'])
    return {'n': len(rows), 'successes': len(good), 'joint_cycles': counts['joint_cycle'], 'caps': counts['cap'],
            'steps_all': sum(r['steps'] for r in rows),
            'mean_steps_success': math.fsum(r['steps'] for r in good)/len(good) if good else None,
            'mean_excess_steps_success': math.fsum(r['steps']-r['optimal_steps'] for r in good)/len(good) if good else None,
            'paired_vs_soft_feedback': paired,
            'failed_case_indices': [i for i, r in enumerate(rows) if not r['success']]}


def census(P, table, states, rows, train, test):
    visit = Counter(); executed_ok = initial_ok = bad_visits = bad_opt = 0
    d = {(s, tuple(g)): distance(table, states, s, g)
         for g in sorted({tuple(r['goal']) for r in rows}) for s in range(30)}
    for row in rows:
        g = tuple(row['goal'])
        for j, (s, a) in enumerate(zip(row['true_states'], row['actions'])):
            idx = 4*s+a; visit[idx] += 1
            optimal = 1+d[(table[s][a], g)] == d[(s, g)]
            executed_ok += optimal; initial_ok += optimal and j == 0
            values = list(map(float, P[s, a])); winning = [i for i, x in enumerate(values) if x == max(values)]
            wrong = winning != [table[s][a]]; bad_visits += wrong; bad_opt += wrong and optimal
    details = []
    for idx in range(120):
        s, a = divmod(idx, 4); values = list(map(float, P[s, a])); target = table[s][a]
        winning = [i for i, x in enumerate(values) if x == max(values)]
        details.append({'row': idx, 'state': s, 'action': a, 'split': 'train' if idx in train else 'heldout',
                        'executed_visits': visit[idx], 'target': target, 'predicted_set': winning,
                        'strict_correct': winning == [target], 'true_probability': values[target],
                        'sum_brier': math.fsum((x-(i == target))**2 for i, x in enumerate(values)),
                        'capped_nll': -math.log(max(values[target], float.fromhex('0x1.0000000000000p-1022')))})
    def group(weights):
        n = sum(weights); correct = wrong = ties = zero = 0
        for w, r in zip(weights, details):
            correct += w*r['strict_correct']; ties += w*(len(r['predicted_set']) > 1)
            wrong += w*(not r['strict_correct'] and len(r['predicted_set']) == 1)
            zero += w*(r['true_probability'] == 0)
        return {'n': n, 'correct': correct, 'wrong': wrong, 'ties': ties,
                'mean_true_probability': math.fsum(w*r['true_probability'] for w, r in zip(weights, details))/n if n else None,
                'mean_sum_brier': math.fsum(w*r['sum_brier'] for w, r in zip(weights, details))/n if n else None,
                'capped_nll': math.fsum(w*r['capped_nll'] for w, r in zip(weights, details))/n if n else None,
                'zero_true_probability': zero}
    groups = {'all_unique': group([1]*120), 'on_policy_unique': group([int(visit[i] > 0) for i in range(120)]),
              'off_policy_unique': group([int(visit[i] == 0) for i in range(120)]),
              'execution_weighted': group([visit[i] for i in range(120)])}
    for label, pool in [('train', train), ('heldout', test)]:
        groups[label+'_unique'] = group([int(i in pool) for i in range(120)])
        groups[label+'_execution_weighted'] = group([visit[i] if i in pool else 0 for i in range(120)])
    return {'groups': groups, 'rows': details,
            'bfs_optimal_action': {'initial_correct': initial_ok, 'initial_n': len(rows),
                                   'executed_correct': executed_ok, 'executed_n': sum(visit.values()),
                                   'incorrect_prediction_executed_n': bad_visits,
                                   'incorrect_prediction_bfs_optimal': bad_opt}}


def check():
    need(not (OUT/'CHECK_STARTED.json').exists(), 'Check is one attempt')
    need((OUT/'COLLECTED.json').is_file() and not (OUT/'STOP.json').exists(), 'Not a completed collection')
    save(OUT/'CHECK_STARTED.json', {'at_utc': datetime.now(timezone.utc).isoformat(), 'code_sha256': digest(__file__)})
    t0 = time.monotonic()
    try:
        plan = load(OUT/'plan.json'); collected = load(OUT/'COLLECTED.json'); report = load(OUT/'summary.json')
        need(report['status'] == collected['status'] == 'COLLECTED_PENDING_SEPARATE_CHECK', 'Wrong status')
        need(report['plan_sha256'] == digest(OUT/'plan.json'), 'Plan binding')
        for rel, h in collected['files_sha256'].items(): need(digest(OUT/rel) == h, 'Output binding '+rel)
        for rel, h in plan['source_sha256'].items(): need(digest(ROOT/rel) == h, 'Source binding '+rel)
        need(digest(ROOT/plan['accepted_plan_path']) == plan['accepted_plan_sha256'], 'Accepted plan binding')
        for rel, rec in plan['original_inventory'].items():
            need((ROOT/rel).stat().st_size == rec['bytes'] and digest(ROOT/rel) == rec['sha256'], 'Original binding '+rel)
        states, table = world(); compare(plan['states'], [list(s) for s in states])
        original = load(ROOT/'outputs/world-model-planning/V1/plan.json'); compare(original['transitions'], table)
        cases = [{'start': s, 'goal': list(g), 'optimal_steps': distance(table, states, s, g)}
                 for s in range(30) for g in sorted({v[:2] for v in states}) if states[s][:2] != g]
        compare(plan['cases'], cases); need(len(cases) == 600, 'Case census')
        compare(plan['heldout_rows'], original['test']); compare(plan['training_rows'], original['train'])
        expected_arms = ['soft_feedback', 'soft_blind', 'argmax_feedback', 'argmax_blind']
        expected_repairs = [f'singleton_{i:03d}' for i in original['test']] + ['joint_all24']
        compare(plan['execution_arms'], expected_arms); compare(plan['repair_arms'], expected_repairs)
        raw = np.load(ROOT/'outputs/world-model-planning/V1/predictions-direct_11.npy', allow_pickle=False)
        need(raw.shape == (30, 4, 30) and raw.dtype == np.float32 and np.isfinite(raw).all(), 'Raw shape/dtype/finite')
        P = softmax(raw)
        hard = np.zeros_like(P)
        for s in range(30):
            for a in range(4):
                row = list(P[s, a]); hard[s, a, row.index(max(row))] = 1
        with np.load(OUT/'probabilities.npz', allow_pickle=False) as saved:
            need(set(saved.files) == {'soft', 'argmax'}, 'Probability keys')
            compare(saved['soft'].tolist(), P.tolist()); compare(saved['argmax'].tolist(), hard.tolist())
        with gzip.open(OUT/'traces.jsonl.gz', 'rt') as f: saved_rows = [json.loads(line) for line in f]
        need(len(saved_rows) == 17400, 'Incomplete traces')
        policies = load(OUT/'policies.json'); outcomes = {}; offset = 0
        for arm in expected_arms+expected_repairs:
            kernel = (hard if arm.startswith('argmax') else P).copy()
            if arm in expected_repairs:
                changed = original['test'] if arm == 'joint_all24' else [int(arm.split('_')[1])]
                for row in changed:
                    s, a = divmod(row, 4); kernel[s, a] = 0; kernel[s, a, table[s][a]] = 1
            bygoal = {g: decision(kernel, states, g) for g in sorted({tuple(c['goal']) for c in cases})}
            exp_policy = {','.join(map(str, g)): {'actions': a, 'tie_counts': n} for g, (a, n) in bygoal.items()}
            compare(policies[arm], exp_policy, arm+'.policy')
            actual = saved_rows[offset:offset+600]; offset += 600
            for i, (case, row) in enumerate(zip(cases, actual)):
                pi, ties = bygoal[tuple(case['goal'])]
                expected = {'case_index': i, 'arm': arm, **execute(table, states, kernel, pi, ties, case, arm.endswith('_blind'))}
                compare(row, expected, arm+f'.case{i}')
            outcomes[arm] = actual
            need(time.monotonic()-t0 < 300, 'Checker timeout')
        base = outcomes['soft_feedback']
        old_rows = [r for r in load(ROOT/'outputs/world-model-planning/V1/episodes.json') if r['model'] == 'direct_11' and r['horizon'] == 16]
        need(len(old_rows) == 600, 'Original baseline count')
        for n, o in zip(base, old_rows):
            for key in ['start', 'goal', 'optimal_steps', 'actions', 'tie_counts', 'success', 'steps']: compare(n[key], o[key])
            compare(n['true_states'], o['states']); need((n['stop_reason'] == 'joint_cycle') == o['cycle'], 'Original cycle')
        expected_census = census(P, table, states, base, original['train'], original['test'])
        compare(report['native_census'], expected_census, 'census')
        compare(report['execution_2x2'], {k: summarize(outcomes[k], base) for k in expected_arms})
        compare(report['repairs'], {k: summarize(outcomes[k], base) for k in expected_repairs})
        compare(report['counts'], {'execution_episodes': 2400, 'repair_episodes': 15000, 'total_episodes': 17400})
        need(report['native_baseline_exact'] is True and all(report[k] == 0 for k in ['model_calls', 'fits', 'provider_calls', 'new_spending_usd']), 'Scope counts')
        for rel, rec in plan['original_inventory'].items(): need(digest(ROOT/rel) == rec['sha256'], 'Original changed at closure')
        singleton_harms = {k: report['repairs'][k]['paired_vs_soft_feedback']['success_to_failure'] for k in expected_repairs[:-1]}
        joint = outcomes['joint_all24']
        restored = {k: sum(b['success'] and not x['success'] and j['success'] for b, x, j in zip(base, outcomes[k], joint)) for k in expected_repairs[:-1]}
        check = {'status': 'PASS_SEPARATE_NUMERICAL_CHECK', 'at_utc': datetime.now(timezone.utc).isoformat(),
                 'plan_sha256': digest(OUT/'plan.json'), 'summary_sha256': digest(OUT/'summary.json'),
                 'collected_sha256': digest(OUT/'COLLECTED.json'), 'checker_sha256': digest(__file__),
                 'episodes_exact': 17400, 'policies_exact': 29*21, 'census_rows': 120,
                 'singletons_harming_any_cases': sum(v > 0 for v in singleton_harms.values()),
                 'singleton_harm_counts': singleton_harms, 'singleton_harms_restored_by_joint': restored,
                 'comparison': 'All categories, actions, ties, traces and counts exact; summary floating values atol1e-10/rtol1e-9.',
                 'independence': 'Separate implementation and scalar-fsum reference arithmetic; same human-directed agent author as diagnostic.py. No production/helper imports or fit replay. Peer source review, if any, is separate.',
                 'original_files_unchanged': True, 'model_calls': 0, 'fits': 0, 'provider_calls': 0,
                 'elapsed_seconds': time.monotonic()-t0}
        save(OUT/'INDEPENDENT_CHECK.json', check)
        save(OUT/'COMPLETE.json', {'status': 'COMPLETE_CHECKED_POST_HOC_DIAGNOSTIC',
             'plan_sha256': check['plan_sha256'], 'summary_sha256': check['summary_sha256'],
             'independent_check_sha256': digest(OUT/'INDEPENDENT_CHECK.json'),
             'episodes': 17400, 'model_calls': 0, 'fits': 0, 'provider_calls': 0,
             'original_files_unchanged': True, 'files_sha256': {str(p.relative_to(OUT)): digest(p) for p in sorted(OUT.rglob('*')) if p.is_file()}})
        return check
    except BaseException as exc:
        save(OUT/'CHECK_FAILURE.json', {'status': 'FAIL', 'type': type(exc).__name__, 'reason': str(exc)})
        raise


if __name__ == '__main__':
    r = check(); print(json.dumps({k: r[k] for k in ['status', 'episodes_exact', 'elapsed_seconds']}), flush=True)
