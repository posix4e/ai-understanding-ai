"""Invented native-schema records only; never open original study arrays."""
import ast
import copy
from datetime import datetime,timedelta,timezone
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import checker as c


def helpers(original):
    # Reuse fabrication helpers, not the old suite or any original data.
    path=c.ROOT/'research/moe-mechanisms/organ_route_cross_v1/test_audit.py'
    prior=sys.modules.get('audit');sys.modules['audit']=original
    try:
        spec=importlib.util.spec_from_file_location('recovery_invented_fabricator',path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
    finally:
        if prior is None:sys.modules.pop('audit',None)
        else:sys.modules['audit']=prior


def native_metadata(info,length=2):
    info=copy.deepcopy(info)
    for descriptor in info['tail_observations'].values():descriptor['device']='mps:0'
    for name,descriptor in info['tail_sites'].items():
        descriptor['device']='mps:0'
        if name.endswith('_attn'):
            aux=[dict(dtype='torch.bfloat16',shape=[1,16,length,length],raw_sha256=hashlib.sha256(bytes(1*16*length*length*2)).hexdigest())]
            descriptor['auxiliary_before']=aux;descriptor['auxiliary_after']=copy.deepcopy(aux)
    return info


def realistic_fixture(root,original,fabricator):
    out,plan,sha,calls=fabricator.fixture(root)
    # Correct both fabricated producer sidecars and the new collector sidecars,
    # then rebuild every binding/event. No raw tensor values or scores changed.
    for path in (root/'outputs').rglob('*.json'):
        meta=json.loads(path.read_text());path.write_text(json.dumps(native_metadata(meta)))
    for entry,row in zip(plan['schedule'],calls):
        for role in ('input','route'):
            if entry[role+'_metadata_path'] is not None:
                field=role+'_metadata_sha256';entry[field]=row[field]=original.digest(root/entry[role+'_metadata_path'])
        path=out/row['forward_metadata_path'];meta=native_metadata(json.loads(path.read_text()));meta.update(entry)
        path.write_text(json.dumps(meta));row['forward_metadata_sha256']=original.digest(path)
        row.update(native_metadata({k:row[k] for k in ('tail_observations','tail_sites')}))
    byid={e['id']:e for e in plan['schedule']}
    events=original.jsonl(out/'worker-events.jsonl')
    for row in events:
        if 'id' in row:row.update(byid[row['id']])
    (out/'worker-events.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in events))
    (out/'calls.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in calls))
    return out,plan,sha,calls


class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=c.load_original();cls.f=helpers(cls.a)
    def test_exact_three_ast_changes_and_no_other_module_change(self):
        module=c.load_original();before=dict(vars(module));old=inspect.getsource(module.check_full_tail)
        receipt=c.install_schema_adapter(module)
        self.assertEqual([k for k in before if before[k] is not vars(module)[k]],['check_full_tail'])
        self.assertEqual(receipt['device_constants_corrected'],2);self.assertEqual(receipt['attention_expression_corrected'],1)
        revised=c.corrected_source(old)
        class Undo(ast.NodeTransformer):
            def visit_Constant(self,n):
                if n.value=='mps:0':n.value='mps'
                return n
            def visit_Call(self,n):
                n=self.generic_visit(n)
                if isinstance(n.func,ast.Name) and n.func.id=='strict_attention_auxiliary':return ast.List(elts=[ast.Constant(None)],ctx=ast.Load())
                return n
        reverted=Undo().visit(copy.deepcopy(revised))
        self.assertEqual(ast.dump(reverted,include_attributes=False),ast.dump(ast.parse(old),include_attributes=False))
    def test_realistic_schema_fails_frozen_checker_then_passes_only_adapter(self):
        v,m=self.f.invented(dict(arm='W',input_arm='W',route_arm=None));m=native_metadata(m)
        with self.assertRaisesRegex(self.a.AuditError,'Full residual observation'):self.a.check_full_tail(v,m)
        module=c.load_original();c.install_schema_adapter(module);self.assertTrue(module.check_full_tail(v,m)['exact'])
    def test_exact_device_still_required(self):
        module=c.load_original();c.install_schema_adapter(module)
        v,m=self.f.invented(dict(arm='W',input_arm='W',route_arm=None));m=native_metadata(m);m['tail_observations']['b20_residual_input']['device']='mps'
        with self.assertRaises(module.AuditError):module.check_full_tail(v,m)
    def test_attention_descriptor_mutations_rejected(self):
        _,info=self.f.invented(dict(arm='B',input_arm='B',route_arm=None));info=native_metadata(info)
        for field,value in [('dtype','torch.float32'),('shape',[1,16,2,3]),('shape',[True,16,2,2]),('raw_sha256','g'*64),('raw_sha256','a'*63)]:
            bad=copy.deepcopy(info);bad['tail_sites']['b20_attn']['auxiliary_before'][0][field]=value
            with self.subTest(field=field,value=value),self.assertRaises(c.RecoveryError):c.strict_attention_auxiliary(bad,'b20_attn',2)
        for change in ('none','extra','after','object'):
            bad=copy.deepcopy(info);r=bad['tail_sites']['b20_attn']
            if change=='none':r['auxiliary_before']=[None]
            elif change=='extra':r['auxiliary_before'][0]['extra']=1
            elif change=='after':r['auxiliary_after'][0]['raw_sha256']='1'*64
            else:r['auxiliary_objects_preserved']=False
            with self.subTest(change=change),self.assertRaises(c.RecoveryError):c.strict_attention_auxiliary(bad,'b20_attn',2)
    def test_residual_arithmetic_and_locality_remain_strict(self):
        module=c.load_original();c.install_schema_adapter(module)
        for field in ('returned','b21_full_moe_output'):
            v,m=self.f.invented(dict(arm='W',input_arm='W',route_arm=None));m=native_metadata(m);v[field][0,0,0]+=1
            with self.subTest(field=field),self.assertRaises(module.AuditError):module.check_full_tail(v,m)
    def test_changed_frozen_code_and_wrong_edit_sites_rejected(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'audit.py';p.write_text('raise RuntimeError("must never import")')
            with patch.object(c,'ORIGINAL_CODE',p),self.assertRaises(c.RecoveryError):c.load_original()
        with self.assertRaises(c.RecoveryError):c.corrected_source('def check_full_tail(values,meta):\n return True\n')
    def test_original_inventory_mutation_detected_without_import(self):
        with TemporaryDirectory() as d:
            p=Path(d);(p/'file').write_bytes(b'first');plan={'frozen_original_sha256':c.inventory(p)};(p/'file').write_bytes(b'changed')
            with self.assertRaisesRegex(c.RecoveryError,'inventory'):c.verify_original_snapshot(plan,p)
    def test_owner_wrong_parent_deadline_and_second_dispatch(self):
        with TemporaryDirectory() as d:
            p=Path(d);now=datetime.now(timezone.utc);deadline=(now+timedelta(seconds=600)).isoformat();sha='e'*64
            start=dict(at_utc=now.isoformat(),deadline_utc=deadline,owner_pid=111,plan_sha256=sha)
            (p/'STARTED.json').write_text(json.dumps(start))
            event=dict(event='started',pid=222,command=[str(c.PYTHON),'-B',str(c.HERE/'checker.py'),'--plan',str(p/'plan.json'),'--deadline-utc',deadline])
            (p/'owner-events.jsonl').write_text(json.dumps(event)+'\n')
            with patch.object(c,'OUT',p),patch.object(c.os,'getppid',return_value=111),patch.object(c.os,'getpid',return_value=222),patch.object(c,'alive',return_value=True):
                c.owner_guard(sha,deadline)
                with self.assertRaises(c.RecoveryError):c.owner_guard(sha,'wrong')
                (p/'owner-events.jsonl').write_text(json.dumps(event)+'\n'+json.dumps(event)+'\n')
                with self.assertRaises(c.RecoveryError):c.owner_guard(sha,deadline)
    def test_partial_publication_preserved_by_original_helper(self):
        with TemporaryDirectory() as d:
            p=Path(d);(p/'REPORT.json').write_bytes(b'{partial');r=self.a.preserve_invalid_publications(p)
            self.assertEqual((p/'INVALID_REPORT.json').read_bytes(),b'{partial');self.assertIn('REPORT.json',r)


class CompleteArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=TemporaryDirectory();cls.root=Path(cls.tmp.name);cls.a=c.load_original();cls.f=helpers(cls.a)
        cls.out,cls.plan,cls.sha,cls.calls=realistic_fixture(cls.root,cls.a,cls.f)
        cls.adapter=c.install_schema_adapter(cls.a)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_corrected_full576_native_schema_and_original_formulas(self):
        report=self.a.audit_records(self.out,self.plan,self.sha,root=self.root)
        self.assertTrue(report['implementation_pass']);self.assertEqual(report['controls']['native_exact'],192)
        self.assertEqual(report['controls']['self_sham_exact'],192);self.assertEqual(len(report['rows']),96)
        self.assertEqual(report['pooled']['effects']['interaction']['J']['mean']['fraction'],'3')
        self.assertEqual(report['pooled']['arms']['WB']['correct'],96);self.assertEqual(report['pooled']['arms']['BW']['ties'],96)
    def test_missing_and_last_bad_control_prevent_any_score(self):
        with patch.object(self.a,'jsonl',return_value=self.calls[:-1]),patch.object(self.a,'score') as score:
            with self.assertRaises(self.a.AuditError):self.a.audit_records(self.out,self.plan,self.sha,root=self.root)
            score.assert_not_called()
        original=self.a.load_call
        def load(*args,**kw):
            if args[2]['index']==573:raise self.a.AuditError('last self control differs')
            return original(*args,**kw)
        with patch.object(self.a,'load_call',side_effect=load),patch.object(self.a,'cell_report') as score:
            with self.assertRaises(self.a.AuditError):self.a.audit_records(self.out,self.plan,self.sha,root=self.root)
            score.assert_not_called()

if __name__=='__main__':unittest.main()
