"""Bounded foreground owner for one saved-data-only corrected audit."""
import sys
sys.dont_write_bytecode=True
from datetime import datetime,timedelta,timezone
import json,os,signal,subprocess,time
from plan import ROOT,HERE,OUT,PYTHON,verify,read,sha,create,now,require
def append(p,x):
    with p.open('a') as f:f.write(json.dumps(x)+'\n');f.flush();os.fsync(f.fileno())
def members(pgid):
    r=subprocess.run(['/bin/ps','-axo','pid=,pgid='],capture_output=True,text=True,check=True,timeout=5)
    return [int(x.split()[0]) for x in r.stdout.splitlines() if int(x.split()[1])==pgid]
def cleanup(child):
    if child is None:return
    for sig in (signal.SIGTERM,signal.SIGKILL):
        child.poll()
        if not members(child.pid):break
        try:os.killpg(child.pid,sig)
        except ProcessLookupError:pass
        limit=time.monotonic()+3
        while time.monotonic()<limit:
            child.poll()
            if not members(child.pid):break
            time.sleep(.05)
    if child.poll() is None:child.wait(timeout=5)
    require(not members(child.pid),'Recovery child group survived')
def main():
    p=verify();require(os.path.realpath(sys.executable)==os.path.realpath(PYTHON),'Pinned Python required')
    require(not any((OUT/n).exists() for n in ('STARTED.json','COMPLETE.json','STOPPED.json')),'Already attempted')
    start=time.monotonic();begin=datetime.now(timezone.utc);deadline=begin+timedelta(seconds=600)
    plan_sha=sha(OUT/'plan.json');child=None;samples=[]
    create(OUT/'STARTED.json',dict(at_utc=begin.isoformat(),deadline_utc=deadline.isoformat(),owner_pid=os.getpid(),plan_sha256=plan_sha))
    def interrupted(signum,frame):raise SystemExit(128+signum)
    handlers={s:signal.signal(s,interrupted) for s in (signal.SIGTERM,signal.SIGINT)}
    try:
        command=[str(PYTHON),'-B',str(HERE/'checker.py'),'--plan',str(OUT/'plan.json'),'--deadline-utc',deadline.isoformat()]
        with (OUT/'checker.log').open('x') as log:
            child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
            append(OUT/'owner-events.jsonl',dict(event='started',at_utc=now(),pid=child.pid,command=command))
            while True:
                elapsed=time.monotonic()-start;require(elapsed<600,'Recovery deadline expired')
                r=subprocess.run(['/bin/ps','-axo','pid=,ppid=,rss='],check=True,capture_output=True,text=True,timeout=5)
                rows=[tuple(map(int,x.split())) for x in r.stdout.splitlines()];tree={child.pid}
                while True:
                    new=tree|{pid for pid,ppid,_ in rows if ppid in tree}
                    if new==tree:break
                    tree=new
                rss=sum(kib*1024 for pid,_,kib in rows if pid in tree)
                size=sum(f.stat().st_size for f in OUT.rglob('*') if f.is_file())
                sample=dict(at_utc=now(),pid=child.pid,elapsed_seconds=elapsed,rss_bytes=rss,archive_bytes=size)
                append(OUT/'resource-monitor.jsonl',sample);samples.append(sample)
                require(rss<=p['max_rss_bytes'] and size+1024**2<=p['max_new_archive_bytes'],'Recovery resource ceiling exceeded')
                if child.poll() is not None:break
                time.sleep(.25)
        require(not members(child.pid),'Recovery child descendants survived')
        append(OUT/'owner-events.jsonl',dict(event='exit',at_utc=now(),pid=child.pid,returncode=child.returncode,process_group_absent=True))
        require(child.returncode==0,'Corrected checker failed')
        verify();a=read(OUT/'INDEPENDENT_AUDIT.json');r=read(OUT/'REPORT.json')
        require(a['status']=='PASS' and a['plan_sha256']==plan_sha and a['report_sha256']==sha(OUT/'REPORT.json'),'Corrected audit binding differs')
        require(a['implementation_pass'] is True and r['implementation_pass'] is True and r['baseline_replication_pass'] is True,'Corrected controls absent')
        require(time.monotonic()-start<600,'Recovery deadline during closure')
        create(OUT/'COMPLETE.json',dict(status='AUDIT_CORRECTED_SAVED_DATA_COMPLETE',at_utc=now(),plan_sha256=plan_sha,
            report_sha256=sha(OUT/'REPORT.json'),independent_audit_sha256=sha(OUT/'INDEPENDENT_AUDIT.json'),
            elapsed_seconds=time.monotonic()-start,original_status='ROUTE_CROSS_STOPPED',new_model_calls=0,provider_calls=0,fits=0,
            peak_rss_bytes=max(x['rss_bytes'] for x in samples),resource_samples=len(samples),
            final_log_sha256={n:sha(OUT/n) for n in ('owner-events.jsonl','resource-monitor.jsonl','checker.log')},
            scientific_confirmation=False,novelty_established=False,automatic_next_study=False))
        require(time.monotonic()-start<600 and sum(f.stat().st_size for f in OUT.rglob('*') if f.is_file())<=p['max_new_archive_bytes'],'Recovery closure boundary exceeded')
        print(json.dumps(read(OUT/'COMPLETE.json')),flush=True)
    except BaseException as exc:
        error=None
        try:cleanup(child)
        except BaseException as e:error=repr(e)
        if (OUT/'COMPLETE.json').exists():(OUT/'COMPLETE.json').rename(OUT/'INVALID_COMPLETE.json')
        create(OUT/'STOPPED.json',dict(status='SAVED_DATA_AUDIT_CORRECTION_STOPPED',at_utc=now(),reason=repr(exc),cleanup_error=error,
            plan_sha256=plan_sha,child_pid=None if child is None else child.pid,child_returncode=None if child is None else child.poll(),retry_allowed=False))
        raise
    finally:
        for s,h in handlers.items():signal.signal(s,h)
if __name__=='__main__':main()
