"""One separately owned saved-data audit with two explicit schema corrections.

The stopped source/entry point is never edited or invoked. Its hash-bound pure
numerical records path is reused with only check_full_tail's device spelling and
attention-auxiliary descriptor contract corrected. No model or primary imports.
"""
import sys
sys.dont_write_bytecode=True
from datetime import datetime, timezone
from pathlib import Path
import ast
import hashlib
import importlib.util
import inspect
import json
import os
import re
import time

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ORIGINAL=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_V1'
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_RECOVERY_V1'
PYTHON=ROOT/'work/acquisition-representation-venv/bin/python'
ORIGINAL_CODE=ROOT/'research/moe-mechanisms/organ_route_cross_v1/audit.py'
ORIGINAL_CODE_SHA='ce20b5afe67b0176f16d9e44894b16e33f34262137f71cf722fcfad44df16135'
ORIGINAL_PLAN_SHA='c5d010baefac207c34e0c3edd32da44b35920c6a79b8ff88fcbb2233e1fd7de8'
LATE_ORIGINAL=('AUDIT_STARTED.json','AUDIT_FAILURE.json','STOPPED.json')
TIMEOUT=600
RSS_LIMIT=2*1024**3
ARCHIVE_LIMIT=32*1024**2

class RecoveryError(ValueError):pass
def require(ok,message):
    if not ok:raise RecoveryError(message)
def read(path):return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def safe(directory,name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe path')
    p=Path(directory)/name
    require(p.is_file() and p.resolve().is_relative_to(Path(directory).resolve()),'Escaping/missing path')
    return p
def inventory(directory):
    return {str(p.relative_to(directory)):digest(p) for p in sorted(Path(directory).rglob('*')) if p.is_file()}
def same(a,b):return json.dumps(a,sort_keys=True,allow_nan=False)==json.dumps(b,sort_keys=True,allow_nan=False)
def alive(pid):
    require(type(pid) is int and pid>1,'Invalid actor PID')
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False

def strict_attention_auxiliary(meta,site,length):
    """Descriptor/identity evidence only: raw attention weights were not retained."""
    record=meta['tail_sites'][site];before=record['auxiliary_before'];after=record['auxiliary_after']
    require(type(before) is list and len(before)==1 and type(before[0]) is dict,'Expected one attention auxiliary tensor')
    value=before[0]
    require(set(value)=={'dtype','shape','raw_sha256'} and value['dtype']=='torch.bfloat16' and
        same(value['shape'],[1,16,length,length]),'Native attention auxiliary dtype/shape differs')
    require(type(value['raw_sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['raw_sha256']) is not None,'Invalid attention auxiliary SHA256')
    require(same(before,after) and record['auxiliary_objects_preserved'] is True,'Attention auxiliary changed')
    return before

def load_original():
    require(digest(ORIGINAL_CODE)==ORIGINAL_CODE_SHA,'Frozen auditor source changed')
    spec=importlib.util.spec_from_file_location('route_cross_original_numeric_bound',ORIGINAL_CODE)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module

def corrected_source(original_source):
    """Exactly two device constants and the attention branch of one expression."""
    tree=ast.parse(original_source)
    class SchemaOnly(ast.NodeTransformer):
        devices=0;attention=0
        def visit_keyword(self,node):
            node=self.generic_visit(node)
            if node.arg=='device' and isinstance(node.value,ast.Constant) and node.value.value=='mps':
                self.devices+=1;node.value=ast.copy_location(ast.Constant(value='mps:0'),node.value)
            return node
        def visit_IfExp(self,node):
            node=self.generic_visit(node)
            test=node.test
            if (isinstance(test,ast.Compare) and isinstance(test.left,ast.Name) and test.left.id=='branch' and
                len(test.ops)==1 and isinstance(test.ops[0],ast.Eq) and len(test.comparators)==1 and
                isinstance(test.comparators[0],ast.Constant) and test.comparators[0].value=='attn' and
                isinstance(node.body,ast.List) and len(node.body.elts)==1 and isinstance(node.body.elts[0],ast.Constant) and node.body.elts[0].value is None):
                self.attention+=1
                node.body=ast.copy_location(ast.Call(func=ast.Name(id='strict_attention_auxiliary',ctx=ast.Load()),
                    args=[ast.Name(id=n,ctx=ast.Load()) for n in ('meta','site','length')],keywords=[]),node.body)
            return node
    change=SchemaOnly();new=change.visit(tree);ast.fix_missing_locations(new)
    require((change.devices,change.attention)==(2,1),'Frozen schema edit sites differ')
    require(len(new.body)==1 and isinstance(new.body[0],ast.FunctionDef) and new.body[0].name=='check_full_tail','Unexpected replaced function')
    return new

def install_schema_adapter(module):
    original=module.check_full_tail;source=inspect.getsource(original);tree=corrected_source(source)
    namespace=dict(vars(module));namespace['strict_attention_auxiliary']=strict_attention_auxiliary
    exec(compile(tree,str(HERE/'checker.py')+':schema-only-adapter','exec'),namespace)
    replacement=namespace['check_full_tail'];before=dict(vars(module));module.check_full_tail=replacement
    require({k for k in before if before[k] is not vars(module)[k]}=={'check_full_tail'},'Unexpected original module mutation')
    return dict(original_audit_sha256=ORIGINAL_CODE_SHA,
        original_check_full_tail_sha256=hashlib.sha256(source.encode()).hexdigest(),
        corrected_function_ast_sha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest(),
        module_names_changed=['check_full_tail'],device_constants_corrected=2,attention_expression_corrected=1,
        all_other_original_methods_unchanged=True,residual_operations_and_comparisons_unchanged=True)

def verify_original_snapshot(plan,original=ORIGINAL):
    expected=plan['frozen_original_sha256']
    require(type(expected) is dict and expected and inventory(original)==expected,'Stopped archive inventory changed')
    require(digest(Path(original)/'plan.json')==plan['original_plan_sha256']==ORIGINAL_PLAN_SHA,'Original plan changed')
    require(not any((Path(original)/n).exists() for n in ('COMPLETE.json','REPORT.json','INDEPENDENT_AUDIT.json')),'Original unexpectedly graded/completed')
    stop=read(Path(original)/'STOPPED.json');failure=read(Path(original)/'AUDIT_FAILURE.json')
    require(stop['status']=='ROUTE_CROSS_STOPPED' and stop['stage']=='independent_audit' and stop['child_returncode']==1 and
        stop['cleanup_error'] is None and stop['rerun_allowed'] is False and stop['partial_scientific_interpretation_allowed'] is False,'Original STOP differs')
    require(failure['reason']=='AuditError: Full residual observation differs: b20_residual_input' and
        failure['plan_sha256']==stop['plan_sha256']==ORIGINAL_PLAN_SHA and failure['preserved_invalid_publications']=={} and
        failure['rerun_allowed'] is False and failure['partial_interpretation'] is False,'Original audit failure differs')
    return stop

def original_lifecycle(original=ORIGINAL):
    original=Path(original);started=read(original/'STARTED.json');worker=read(original/'WORKER_STARTED.json')
    events=[json.loads(x) for x in (original/'owner-events.jsonl').read_text().splitlines()]
    require([(r['event'],r['stage']) for r in events]==[('started','worker'),('exit','worker'),('started','independent_audit'),('exit','independent_audit')],'Original terminal lifecycle differs')
    require(events[0]['pid']==events[1]['pid']==worker['worker_pid'] and events[2]['pid']==events[3]['pid'] and
        events[1]['returncode']==0 and events[3]['returncode']==1 and all(events[i]['process_group_absent'] is True for i in (1,3)),'Original exit records differ')
    require(worker['owner_pid']==started['owner_pid'] and worker['deadline_utc']==started['deadline_utc'] and
        started['plan_sha256']==worker['plan_sha256']==ORIGINAL_PLAN_SHA,'Original actor bindings differ')
    begin,deadline=[datetime.fromisoformat(started[k]) for k in ('at_utc','deadline_utc')]
    require(begin.tzinfo is not None and deadline.tzinfo is not None and (deadline-begin).total_seconds()==900,'Original deadline contract differs')
    times=[datetime.fromisoformat(r['at_utc']) for r in events]
    require(begin<=times[0]<=times[1]<=times[2]<=times[3]<deadline,'Original execution exceeded/changed deadline')
    oldcode=ROOT/'research/moe-mechanisms/organ_route_cross_v1'
    require(events[0]['command']==[str(PYTHON),str(oldcode/'worker.py'),'--deadline-utc',started['deadline_utc']] and
        events[2]['command']==[str(PYTHON),str(oldcode/'audit.py'),'--directory',str(ORIGINAL)],'Original dispatch commands differ')
    actors={started['owner_pid'],worker['worker_pid'],events[2]['pid']}
    require(all(not alive(pid) for pid in actors),'Original actor still alive')
    for pid in (worker['worker_pid'],events[2]['pid']):
        try:os.killpg(pid,0)
        except ProcessLookupError:pass
        else:raise RecoveryError('Original child group survives')
    return started,worker,events

def verify_plan(plan_path):
    require(Path(plan_path).is_absolute() and Path(plan_path).resolve()==(OUT/'plan.json').resolve(),'Wrong recovery plan path')
    plan=read(plan_path);sha=digest(plan_path)
    require(read(OUT/'REGISTRATION.json')['plan_sha256']==sha,'Recovery registration differs')
    require(plan['status']=='POST_STOP_SAVED_DATA_AUDIT_CORRECTION' and plan['original_directory']==str(ORIGINAL) and plan['output_directory']==str(OUT),'Recovery directories/status differ')
    require(type(plan['timeout_seconds']) is int and plan['timeout_seconds']==TIMEOUT and
        type(plan['max_rss_bytes']) is int and plan['max_rss_bytes']==RSS_LIMIT and
        type(plan['max_new_archive_bytes']) is int and plan['max_new_archive_bytes']==ARCHIVE_LIMIT,'Recovery limits changed')
    require(all(type(plan[k]) is int and plan[k]==0 for k in ('model_calls','provider_calls','fits')) and
        all(plan[k] is False for k in ('original_mutation_allowed','retry_allowed','scientific_confirmation','novelty_established','automatic_next_study')),'Forbidden work/relaxed recovery contract')
    names=('plan.py','owner.py','checker.py','test_checker.py')
    require(set(plan['source_sha256'])=={str((HERE/n).relative_to(ROOT)) for n in names},'Recovery source inventory differs')
    for name,h in plan['source_sha256'].items():
        p=safe(ROOT,name);require(digest(p)==h and digest(safe(OUT/'sources',p.name))==h,'Recovery source changed')
    require(plan['review_sha256'],'No reviewed recovery')
    for name,h in plan['review_sha256'].items():require(digest(safe(ROOT,name))==h,'Recovery review changed')
    verify_original_snapshot(plan)
    return plan,sha

def owner_guard(plan_sha,deadline_utc):
    started=read(OUT/'STARTED.json');begin,deadline=[datetime.fromisoformat(started[k]) for k in ('at_utc','deadline_utc')]
    require(started['owner_pid']==os.getppid() and alive(os.getppid()) and started['plan_sha256']==plan_sha and
        started['deadline_utc']==deadline_utc and begin.tzinfo is not None and deadline.tzinfo is not None and
        (deadline-begin).total_seconds()==TIMEOUT and begin<=datetime.now(timezone.utc)<deadline,'Recovery owner/deadline differs')
    until=time.monotonic()+2
    while True:
        try:events=[json.loads(x) for x in (OUT/'owner-events.jsonl').read_text().splitlines()]
        except (FileNotFoundError,json.JSONDecodeError):events=[]
        if events:break
        require(time.monotonic()<until and datetime.now(timezone.utc)<deadline,'Recovery dispatch absent');time.sleep(.02)
    command=[str(PYTHON),'-B',str(HERE/'checker.py'),'--plan',str(OUT/'plan.json'),'--deadline-utc',deadline_utc]
    require(len(events)==1 and events[0]['event']=='started' and events[0]['pid']==os.getpid() and events[0]['command']==command,'Recovery dispatch differs')
    require(not any((OUT/n).exists() for n in ('STOPPED.json','COMPLETE.json')),'Recovery terminal already exists')
    return started

def guard_size():
    require(sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())+1024**2<=ARCHIVE_LIMIT,'Recovery archive/reserve exceeded')

def run(plan_path,deadline_utc):
    require(not any((OUT/n).exists() for n in ('AUDIT_STARTED.json','AUDIT_FAILURE.json','REPORT.json','INDEPENDENT_AUDIT.json','STOPPED.json','COMPLETE.json')),'Recovery already attempted/terminal')
    plan,sha=verify_plan(plan_path);started=owner_guard(sha,deadline_utc)
    original=load_original();original.runtime_guard();adapter=install_schema_adapter(original)
    create(OUT/'AUDIT_STARTED.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=sha,
        checker_sha256=digest(__file__),owner_pid=os.getppid(),pid=os.getpid(),deadline_utc=deadline_utc,adapter=adapter,retry_allowed=False))
    try:
        oldstart,oldworker,old_events=original_lifecycle()
        original_plan,oldsha=original.verify_plan(ORIGINAL)
        collection=read(ORIGINAL/'COLLECTED.json')
        original.require(collection['plan_sha256']==oldsha and collection['all_controls_pass'] is True and
            original.same_json(collection['counts'],original.counts()),'Original collection incomplete')
        original.check_inventory(ORIGINAL,collection,late=LATE_ORIGINAL)
        cache=original.validate_cache(original_plan)
        original.require(original.same_json(read(ORIGINAL/'MODEL_CACHE_BEFORE.json'),cache) and
            original.same_json(read(ORIGINAL/'MODEL_CACHE_AFTER.json'),cache),'Original cache records changed')
        owner_guard(sha,deadline_utc);guard_size()
        # The only records invocation. Original main()/audit(), source, STOP and outputs are untouched.
        report=original.audit_records(ORIGINAL,original_plan,oldsha,oldstart,oldworker)
        verify_plan(plan_path);original.verify_plan(ORIGINAL);original.check_inventory(ORIGINAL,collection,late=LATE_ORIGINAL)
        owner_guard(sha,deadline_utc);guard_size()
        report.update(status='CORRECTED_SAVED_DATA_ROUTE_CROSS_REPORT',plan_sha256=sha,original_plan_sha256=oldsha,
            at_utc=datetime.now(timezone.utc).isoformat(),scientific_confirmation=False,novelty_established=False,
            recovery_disclosure=dict(original_status='ROUTE_CROSS_STOPPED',original_study_completed=False,
                post_stop_protocol_deviation=True,new_model_calls=0,new_fits=0,new_provider_calls=0,
                correction=adapter,attention_weights_independently_numerically_reconstructed=False,
                attention_evidence='Strict native BF16[1,16,L,L] descriptor, valid recorded hash, before/after equality and preserved-object flag; values were not separately archived.',
                unchanged='All576 records,384 exact controls before any scores, every residual operation, native/donor policy check, numerical allowance, fixed target and effect formula remain unchanged.',
                limitation='Transparent corrected offline audit, not completion of the original stopped protocol or fresh scientific confirmation.'),
            limits=[original_plan['target'],original_plan['interpretation'],original_plan['drift'],
                'Exact rational finite differences are descriptive over96 exposed cells/24 contexts/four worlds; no p-values, mediator fractions or population inference.',
                'Later parent terminal review binds the new owner monitor/log after cleanup. The original complete file inventory is bound before and after this saved-data audit.'])
        create(OUT/'REPORT.json',report);guard_size()
        receipt=dict(status='PASS',plan_sha256=sha,original_plan_sha256=oldsha,report_sha256=digest(OUT/'REPORT.json'),
            implementation_pass=report['implementation_pass'],baseline_replication_pass=report['baseline_replication_pass'],
            checker_sha256=digest(__file__),original_audit_sha256=ORIGINAL_CODE_SHA,adapter=adapter,
            original_collected_sha256=digest(ORIGINAL/'COLLECTED.json'),original_stopped_sha256=digest(ORIGINAL/'STOPPED.json'),
            original_inventory_sha256=plan['frozen_original_sha256'],original_owner_events=old_events,
            original_study_completed=False,post_stop_protocol_deviation=True,model_calls=0,fits=0,provider_calls=0,
            source_and_review_sha256={**plan['source_sha256'],**plan['review_sha256']},
            audit_started_sha256=digest(OUT/'AUDIT_STARTED.json'),started_sha256=digest(OUT/'STARTED.json'))
        create(OUT/'INDEPENDENT_AUDIT.json',receipt)
        owner_guard(sha,deadline_utc);verify_original_snapshot(plan);guard_size()
        return receipt
    except BaseException as exc:
        invalid=original.preserve_invalid_publications(OUT)
        create(OUT/'AUDIT_FAILURE.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=sha,
            reason=type(exc).__name__+': '+str(exc),preserved_invalid_publications=invalid,
            retry_allowed=False,original_status='ROUTE_CROSS_STOPPED',partial_interpretation=False))
        raise

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--deadline-utc',required=True)
    args=parser.parse_args();receipt=run(args.plan,args.deadline_utc)
    print(json.dumps({k:v for k,v in receipt.items() if k not in ('original_inventory_sha256','source_and_review_sha256','original_owner_events')}),flush=True)
