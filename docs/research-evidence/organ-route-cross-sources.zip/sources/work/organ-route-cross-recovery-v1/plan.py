"""One transparent saved-data audit correction. Never restart the stopped study."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ORIGINAL=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_V1'
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_RECOVERY_V1'
PYTHON=ROOT/'work/acquisition-representation-venv/bin/python'
EXPECTED_PLAN='c5d010baefac207c34e0c3edd32da44b35920c6a79b8ff88fcbb2233e1fd7de8'
SOURCES=('plan.py','owner.py','checker.py','test_checker.py')
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text())
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def create(p,x):
    with Path(p).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def inventory(p):return {str(f.relative_to(p)):sha(f) for f in sorted(p.rglob('*')) if f.is_file()}
def sources():return {str((HERE/n).relative_to(ROOT)):sha(HERE/n) for n in SOURCES}
def require(ok,msg):
    if not ok:raise ValueError(msg)
def original_guard():
    require(sha(ORIGINAL/'plan.json')==EXPECTED_PLAN,'Original plan changed')
    require((ORIGINAL/'STOPPED.json').is_file() and (ORIGINAL/'AUDIT_FAILURE.json').is_file(),'Original failure absent')
    require(not any((ORIGINAL/n).exists() for n in ('COMPLETE.json','REPORT.json','INDEPENDENT_AUDIT.json')),'Original result unexpectedly exists')
    require(read(ORIGINAL/'WORKER_COMPLETE.json')['counts']['suffix_finished']==576,'Original collection incomplete')
    require(read(ORIGINAL/'AUDIT_FAILURE.json')['reason']=='AuditError: Full residual observation differs: b20_residual_input','Failure differs')
def prepare():
    require(not OUT.exists(),'Recovery already registered; never recreate')
    original_guard();h=sources()
    reviews={}
    for n in ('RECOVERY_SOURCE_REVIEW.json','PREPARATION_TESTS.json','PARENT_REVIEW.json'):
        p=HERE/n;r=read(p)
        require(r['status'].startswith('PASS') and r['source_sha256']==h,'Missing/stale review '+n)
        reviews[str(p.relative_to(ROOT))]=sha(p)
    for n in ('RECOVERY_DESIGN_REVIEW.json','FAILURE_CLOSURE_REVIEW.json','AUDIT_FAILURE_DIAGNOSIS.json'):
        p=ROOT/'work/organ-route-cross-v1'/n;reviews[str(p.relative_to(ROOT))]=sha(p)
    plan=dict(status='POST_STOP_SAVED_DATA_AUDIT_CORRECTION',created_at_utc=now(),
        original_directory=str(ORIGINAL),output_directory=str(OUT),original_plan_sha256=EXPECTED_PLAN,
        source_sha256=h,frozen_original_sha256=inventory(ORIGINAL),review_sha256=reviews,
        corrections=['Require the native device descriptor mps:0, not mps.',
          'Require a single BF16[1,16,L,L] attention auxiliary descriptor with a valid SHA256, unchanged before/after and object preservation; not [None]. Historical controls still require exact original descriptors.'],
        unchanged='All576 fixed cells/arms, all384 exact controls before any score, all raw numerical checks/tolerances, source identities, full-row BF16 arithmetic, native/donor policy checks, fixed targets and all original effect formulas.',
        limits='Attention auxiliary values are not separately archived; schema and preservation are checked, not independent numerical reconstruction of those values. Original study remains STOPPED. This is a transparent post-STOP corrected audit, not original completion or public preregistration.',
        outcome_exposure='No crossed answer scores were read, graded, fitted or selected before this amendment. The failed original checker decoded the first baseline call for integrity, then stopped before admitting any full call or computing outcomes. Failure diagnosis used frozen source and metadata only.',
        amendment_basis='Explicit post-STOP exception to the original prohibition on regrading: this separately registered retrospective audit corrects two demonstrated checker-schema errors on the complete sealed panel. It does not resume or rerun the original owner, collector or audit entrypoint, and original failure markers remain unchanged.',
        timeout_seconds=600,max_rss_bytes=2*1024**3,max_new_archive_bytes=32*1024**2,
        model_calls=0,provider_calls=0,fits=0,original_mutation_allowed=False,retry_allowed=False,
        stop='Any further structural, numerical, source, lifecycle or resource failure preserves STOP; no second attempt or rule change.',
        scientific_confirmation=False,novelty_established=False,automatic_next_study=False)
    OUT.mkdir();(OUT/'sources').mkdir()
    for n in SOURCES:shutil.copyfile(HERE/n,OUT/'sources'/n)
    create(OUT/'plan.json',plan);create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=sha(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED_SAVED_DATA_AUDIT',plan_sha256=sha(OUT/'plan.json'))),flush=True)
def verify():
    p=read(OUT/'plan.json');require(read(OUT/'REGISTRATION.json')['plan_sha256']==sha(OUT/'plan.json'),'Recovery plan changed')
    original_guard();require(p['source_sha256']==sources(),'Recovery source changed')
    require(inventory(ORIGINAL)==p['frozen_original_sha256'],'Original stopped archive changed')
    for n,h in p['review_sha256'].items():require(sha(ROOT/n)==h,'Recovery review changed')
    for n in SOURCES:require(sha(HERE/n)==sha(OUT/'sources'/n),'Recovery source archive changed')
    return p
if __name__=='__main__':prepare()
