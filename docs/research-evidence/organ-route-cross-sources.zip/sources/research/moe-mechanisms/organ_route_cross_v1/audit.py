"""Raw-first audit of the fixed six-arm full-sequence routing intervention.

Uses copied, previously reviewed numerical/ownership primitives from the census
(no primary worker/suffix/router imports). New accounting, donor-policy checks,
full-row residual reconstruction and exact score contrasts are implemented here.
Softmax reconstruction alone has the inherited fixed 2e-7 pre-cast allowance;
all raw controls/donor operands and every BF16 residual operation are exact.
"""
from __future__ import annotations
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import platform
import sys
import time
import numpy as np
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_V1'
PREP=OUT.with_name(OUT.name+'_PREPARATION')
ORIGINAL=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1'
LAYERS=(20,21,22,23)
SITES=tuple(f'b{i}_{part}' for i in LAYERS for part in ('attn','moe'))
ROUTE_NAMES=('order','tokens','gates','sizes','logits')
ARMS=('B','W','SB','SW','WB','BW')
INPUT_ARM=dict(zip(ARMS,('B','W','B','W','W','B')))
ROUTE_ARM=dict(zip(ARMS,(None,None,'B','W','B','W')))
CONTROLS=('B','W','SB','SW')
SOFTMAX_ATOL=2e-7
K=8
EXPERTS=32
VOCAB=49155
TIMEOUT=900
MEMORY_LIMIT=10*1024**3
ARCHIVE_LIMIT=1024**3
EXCLUSIONS={'owner-events.jsonl','resource-monitor.jsonl','worker.log','independent_audit.log','COLLECTED.json'}
ORIGINAL_SHA={
 'plan.json':'133c644bae49d7e0cf30704e5be5f05797ceff022b5763ef358f95335cdfe701',
 'COMPLETE.json':'535f5fbfd59c8c3576da4c7ef058713e156c6c4514ab7ab23ae309dda5ba25c7',
 'INDEPENDENT_AUDIT.json':'edebd3f5fa06867be5cf9d59319aa73376a03d50174b8186b85fab42817120a8',
 'REPORT.json':'04cb5940073df0ef5c9f2350bc5d80b3d09f48e4b7994a2e98160a6723f45202',
 'COLLECTED.json':'03c58b8b5d142609bcfa28cfe99e99f47a2dae6435ed4e0d3561e04f4a16206c',
 'REGISTRATION.json':'2544ff8ca550e38409432514c0e623a13db598b8dc765cda0c3710cc2a7e56e7'}
SETTINGS=dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',
 suffix_executions=576,decoder_block_executions=2304,contexts=24,worlds=4,cells=96,
 layers=[20,21,22,23],experts=32,top_k=8,arms=list(ARMS),native_replications=192,self_shams=192,crossed_suffixes=192,
 full_host_forwards=0,prefix_forwards=0,reader_applications=0,organ_forwards=0,writer_forwards=0,
 analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0,
 dtype='bfloat16',device='mps',threads=4,batch_size=1,attention='eager',cache=False,logits_scaling=6,
 timeout_seconds=900,max_rss_bytes=MEMORY_LIMIT,max_mps_driver_bytes=MEMORY_LIMIT,max_archive_bytes=ARCHIVE_LIMIT,
 historical_hash_tolerance=0.0)
COMPONENTS=('mask','rope','decoder','attention','moe','router','final_norm','head')

def component_counts():
    return {n+'_'+p:(4 if n in ('decoder','attention','moe','router') else 1) for n in COMPONENTS for p in ('attempts','finished')}
def routing_counts():return {n+'_'+p:4 for n in ('input_linear','output_linear') for p in ('attempts','finished')}
def counts():
    return dict(suffix_attempts=576,suffix_finished=576,**{k:v*576 for k,v in component_counts().items()},
        **{k:v*576 for k,v in routing_counts().items()},router_native_returns=2304,
        attention_native_returns=2304,moe_native_returns=2304,route_overrides=1536,
        full_host_forwards=0,prefix_forwards=0,reader_calls=0,organ_calls=0,writer_calls=0,
        analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)

class AuditError(ValueError):pass


def require(ok,message):
    if not ok:raise AuditError(message)


def read(path):return json.loads(Path(path).read_text())


def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def raw_hash(x):return hashlib.sha256(np.asarray(x).tobytes()).hexdigest()


def exact(a,b):
    a,b=np.asarray(a),np.asarray(b)
    return a.dtype==b.dtype and a.shape==b.shape and a.tobytes()==b.tobytes()


def same_json(a,b):return json.dumps(a,sort_keys=True,allow_nan=False)==json.dumps(b,sort_keys=True,allow_nan=False)


def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def safe(directory,name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts,'Unsafe path')
    p=Path(directory)/name
    require(p.is_file() and p.resolve().is_relative_to(Path(directory).resolve()),'Missing or escaping file')
    return p


def jsonl(path):
    lines=Path(path).read_text().splitlines();require(all(x.strip() for x in lines),'Blank journal row')
    return [json.loads(x) for x in lines]


def is_alive(pid):
    require(type(pid) is int and pid>1,'Invalid actor')
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False


def schedule_fields(row,entry):
    require(all(k in row and same_json(row[k],v) for k,v in entry.items()),'Schedule binding differs')


def bf16_bits(x):
    a=np.asarray(x,dtype=np.float32);require(np.isfinite(a).all(),'Nonfinite BF16 operand')
    u=a.view(np.uint32)
    return ((u+np.uint32(0x7fff)+((u>>16)&1))>>16).astype(np.uint16)


def bf16(x):return (bf16_bits(x).astype(np.uint32)<<16).view(np.float32)


def decode(raw,dtype,shape):
    types={'torch.bfloat16':('<u2',2),'torch.float32':('<f4',4),'torch.int64':('<i8',8),'numpy.float64':('<f8',8)}
    require(dtype in types and all(type(n) is int and n>=0 for n in shape),'Invalid recorded dtype/shape')
    storage,width=types[dtype];a=np.asarray(raw)
    require(a.dtype==np.uint8 and a.shape==(math.prod(shape)*width,),'Invalid raw width')
    v=np.frombuffer(a.tobytes(),dtype=storage)
    if dtype=='torch.bfloat16':v=(v.astype(np.uint32)<<16).view(np.float32)
    return v.reshape(shape)


def load_bundle(path,metadata_path,expected,allow_extra=False):
    meta=read(metadata_path);require(isinstance(meta.get('tensors'),dict),'Missing tensor inventory')
    require(set(expected)<=set(meta['tensors']) if allow_extra else set(expected)==set(meta['tensors']),'Tensor inventory differs')
    values,raws={},{}
    with np.load(path,allow_pickle=False) as archive:
        require(len(archive.files)==len(set(archive.files)),'Duplicate archive member')
        all_keys={n+s for n in meta['tensors'] for s in ('__raw_uint8','__value')}
        require(set(archive.files)==all_keys,'Archive member inventory differs')
        for name,(dtype,shape) in expected.items():
            m=meta['tensors'][name];rk,vk=name+'__raw_uint8',name+'__value'
            require(m['dtype']==dtype and same_json(m['shape'],list(shape)) and m['raw_key']==rk and m['value_key']==vk,'Recorded tensor type differs')
            raw=np.asarray(archive[rk]);v=decode(raw,dtype,shape)
            require(raw_hash(raw)==m['raw_sha256'] and exact(v,archive[vk]),'Raw/hash/readable tensor differs')
            require(np.isfinite(v).all(),'Nonfinite tensor')
            values[name]=v.copy();raws[name]=raw.copy()
    return values,raws,meta


def _ceil32(value):
    x=np.float32(value)
    return np.nextafter(x,np.float32(np.inf),dtype=np.float32) if float(x)<value else x


def _floor32(value):
    x=np.float32(value)
    return np.nextafter(x,np.float32(-np.inf),dtype=np.float32) if float(x)>value else x


def gate_rounding_check(value,reference):
    """Exact FP32 existence in a BF16 RNE bin intersecting the fixed interval."""
    v=np.float32(value);u=int(v.view(np.uint32));require(u&65535==0,'Gate not BF16')
    code=u>>16;require(0<=code<=0x3f80 and math.isfinite(reference),'Gate outside [0,1] or invalid reference')
    lo=max(0.,float(reference)-SOFTMAX_ATOL);hi=min(1.,float(reference)+SOFTMAX_ATOL)
    require(lo<=hi,'Invalid softmax reference')
    def at(bits):return float(np.array(bits<<16,dtype=np.uint32).view(np.float32))
    lower=0. if code==0 else (at(code-1)+float(v))/2
    upper=1. if code==0x3f80 else (float(v)+at(code+1))/2
    low=max(lo,lower);high=min(hi,upper);candidate=_ceil32(low)
    if code%2 and float(candidate)==lower:candidate=np.nextafter(candidate,np.float32(np.inf),dtype=np.float32)
    valid=float(candidate)<=high and not(code%2 and float(candidate)==upper)
    require(valid,'Actual gate outside fixed softmax/BF16 rounding interval')
    first,last=_ceil32(lo),_floor32(hi)
    require(first<=last,'Softmax interval has no FP32 representative')
    return dict(ambiguous=bool(bf16_bits(first)!=bf16_bits(last)),reference=float(reference),
        decoded_error=float(v)-float(reference))


def canonical_route(order,tokens,gates,sizes,logits):
    """Invert native grouped tuples; never infer selected support from nonzero gates."""
    order,tokens,sizes,logits,gates=map(np.asarray,(order,tokens,sizes,logits,gates))
    require(logits.dtype==np.float32 and logits.ndim==2 and logits.shape[1]==EXPERTS and np.isfinite(logits).all(),'Router logits malformed')
    length=len(logits);count=length*K
    require(length>0 and order.dtype==tokens.dtype==sizes.dtype==np.int64,'Router index dtype differs')
    require(order.shape==tokens.shape==gates.shape==(count,) and sizes.shape==(EXPERTS,),'Route shape differs')
    require(gates.dtype==np.float32 and np.isfinite(gates).all() and np.all((gates.view(np.uint32)&65535)==0),'Gate storage differs')
    require(np.array_equal(np.sort(order),np.arange(count)) and np.array_equal(tokens,order//K),'Router permutation/token identity differs')
    require(np.all(sizes>=0) and sum(map(int,sizes))==count,'Router expert counts differ')
    grouped_ids=np.repeat(np.arange(EXPERTS),sizes);support=np.empty(count,dtype=np.int64);slot_gates=np.empty(count,dtype=np.float32)
    support[order]=grouped_ids;slot_gates[order]=gates;support=support.reshape(length,K);slot_gates=slot_gates.reshape(length,K)
    dense=np.zeros((length,EXPERTS),dtype=np.float32);details=[]
    for t in range(length):
        ids=support[t];require(len(set(map(int,ids)))==K,'Duplicate selected expert')
        selected=logits[t,ids].astype(np.float64);excluded=np.delete(logits[t],ids)
        require(np.all(selected[:-1]>=selected[1:]) and min(selected)>=max(excluded),'Selected tuple is not native top-k')
        exp=np.exp(selected-max(selected));reference=exp/math.fsum(map(float,exp))
        checks=[gate_rounding_check(g,p) for g,p in zip(slot_gates[t],reference)]
        dense[t,ids]=slot_gates[t]
        ranked=sorted(map(float,logits[t]),reverse=True);cut=ranked[K-1];gap=Fraction(ranked[K-1])-Fraction(ranked[K])
        high=[e for e,z in enumerate(logits[t]) if float(z)>cut];tied=[e for e,z in enumerate(logits[t]) if float(z)==cut]
        details.append(dict(selected_ids=list(map(int,ids)),selected_gates=list(map(float,slot_gates[t])),
            dense_gates=list(map(float,dense[t])),gate_sum=float(math.fsum(map(float,dense[t]))),
            cutoff_logit=cut,boundary_gap=float(gap),boundary_gap_fraction=str(gap),
            historical_support_unique=gap>0,strictly_above_cutoff=high,at_cutoff=tied,
            slots_at_cutoff=K-len(high),within_selected_ties=len(set(selected))<K,
            gate_rounding_ambiguous=sum(c['ambiguous'] for c in checks),
            maximum_softmax_decoded_error=max(abs(c['decoded_error']) for c in checks)))
    return dict(support=support,gates=slot_gates,dense=dense,rows=details)


def check_inventory(directory,collected,late=()):
    directory=Path(directory)
    actual={str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file() and str(p.relative_to(directory)) not in EXCLUSIONS|set(late)}
    require(actual==set(collected['artifact_sha256']),'Collected inventory differs')
    for name,h in collected['artifact_sha256'].items():require(digest(safe(directory,name))==h,'Collected artifact changed')
    require(sum(p.stat().st_size for p in directory.rglob('*') if p.is_file())<=ARCHIVE_LIMIT,'Archive cap exceeded')


def owner_guard(directory,plan_sha):
    directory=Path(directory);started=read(directory/'STARTED.json');worker=read(directory/'WORKER_STARTED.json')
    require(started['owner_pid']==os.getppid() and is_alive(started['owner_pid']),'Not original live owner')
    require(started['plan_sha256']==worker['plan_sha256']==plan_sha and worker['owner_pid']==started['owner_pid'],'Actor/plan binding differs')
    begin,deadline=[datetime.fromisoformat(started[k]) for k in ('at_utc','deadline_utc')]
    require(begin.tzinfo is not None and deadline.tzinfo is not None and (deadline-begin).total_seconds()==TIMEOUT and datetime.now(timezone.utc)<deadline,'Invalid/expired900-second deadline')
    require(worker['deadline_utc']==started['deadline_utc'],'Worker deadline changed')
    until=time.monotonic()+2
    while True:
        try:events=jsonl(directory/'owner-events.jsonl')
        except (FileNotFoundError,json.JSONDecodeError):events=[]
        if len(events)>=3:break
        require(time.monotonic()<until and datetime.now(timezone.utc)<deadline,'Audit dispatch handshake absent');time.sleep(.02)
    require(len(events)==3 and [(x['event'],x['stage']) for x in events]==[('started','worker'),('exit','worker'),('started','independent_audit')],'Owner lifecycle differs')
    require(events[0]['pid']==events[1]['pid']==worker['worker_pid'] and events[1]['returncode']==0 and events[1]['process_group_absent'] is True and not is_alive(worker['worker_pid']) and events[2]['pid']==os.getpid(),'Worker not inactive/successful')
    try:os.killpg(worker['worker_pid'],0)
    except ProcessLookupError:pass
    else:raise AuditError('Original worker process group survives')
    python=ROOT/'work/acquisition-representation-venv/bin/python'
    require(events[0]['command']==[str(python),str(HERE/'worker.py'),'--deadline-utc',started['deadline_utc']] and events[2]['command']==[str(python),str(HERE/'audit.py'),'--directory',str(directory)],'Dispatch commands differ')
    claim,launch=read(PREP/'LAUNCH_REQUESTED.json'),read(PREP/'LAUNCH_PID.json');command=[str(python),'-u',str(HERE/'owner.py'),'run']
    require(claim['command']==launch['command']==command and claim['plan_sha256']==launch['plan_sha256']==plan_sha and claim['nonce']==launch['nonce']==started['launch_nonce'] and launch['owner_pid']==started['owner_pid'],'Original launch claim differs')
    require(os.getpgid(started['owner_pid'])==os.getsid(started['owner_pid'])==started['owner_pid'],'Detached owner identity differs')
    times=[datetime.fromisoformat(x['at_utc']) for x in events]
    require(begin<=times[0]<=times[1]<=times[2]<deadline,'Owner chronology differs')
    # Owner monitor remains live. Validate a complete-line prefix; never bind its
    # changing file hash as though final. Parent closure binds its final bytes.
    lines=(directory/'resource-monitor.jsonl').read_text().splitlines(keepends=True)
    records=[json.loads(x) for x in lines if x.endswith('\n')]
    require(records and any(r['stage']=='worker' for r in records),'No owner resource samples')
    previous=-math.inf
    for r in records:
        require(r['stage'] in ('worker','independent_audit') and r['pid']==(worker['worker_pid'] if r['stage']=='worker' else os.getpid()),'Monitor actor differs')
        require(type(r['elapsed_seconds']) in (int,float) and math.isfinite(r['elapsed_seconds']) and previous<=r['elapsed_seconds']<TIMEOUT,'Owner sample time invalid');previous=r['elapsed_seconds']
        require(type(r['child_tree_rss_bytes']) is int and 0<=r['child_tree_rss_bytes']<=MEMORY_LIMIT and type(r['archive_bytes']) is int and 0<=r['archive_bytes']<=ARCHIVE_LIMIT,'Owner resource cap exceeded')
    ws=[r for r in records if r['stage']=='worker'];exitrow=events[1]
    require(exitrow['samples']==len(ws) and exitrow['peak_child_tree_rss_bytes']==max(r['child_tree_rss_bytes'] for r in ws) and exitrow['peak_archive_bytes']==max(r['archive_bytes'] for r in ws),'Closed worker resource receipt differs')
    return started,worker,events,records


def preserve_invalid_publications(directory):
    preserved={}
    for name in ('REPORT.json','INDEPENDENT_AUDIT.json'):
        path=Path(directory)/name
        if path.exists():
            invalid=Path(directory)/('INVALID_'+name)
            require(not invalid.exists(),'Invalid publication archive already exists')
            preserved[name]=dict(sha256=digest(path),preserved_as=invalid.name)
            path.rename(invalid)
    return preserved


def expected_state_keys():
    suffixes=('self_attn.q_proj.weight','self_attn.k_proj.weight','self_attn.v_proj.weight',
        'self_attn.o_proj.weight','block_sparse_moe.input_linear.weight','block_sparse_moe.output_linear.weight',
        'block_sparse_moe.router.layer.weight','input_layernorm.weight','post_attention_layernorm.weight')
    return {'model.embed_tokens.weight','model.norm.weight','lm_head.weight'}|{f'model.layers.{i}.{s}' for i in range(24) for s in suffixes}


def runtime_guard():
    require(platform.python_version()==SETTINGS['python'] and np.__version__==SETTINGS['numpy'],'Python/NumPy runtime differs')
    require(Path(sys.executable).resolve()==(ROOT/'work/acquisition-representation-venv/bin/python').resolve(),'Auditor executable differs')
    for package in ('torch','transformers'):require(importlib.metadata.version(package)==SETTINGS[package],'Installed package version differs')


def validate_cache(plan,root=ROOT):
    """Only the previously reviewed cache path/hash helper is imported."""
    relative='research/moe-mechanisms/model_cache_validation/cache_files.py';path=safe(root,relative)
    require(digest(path)==plan['source_sha256'][relative],'Cache helper source differs')
    spec=importlib.util.spec_from_file_location('census_bound_cache_validator',path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    require(len(plan['model_files'])==9,'Expected nine model payloads')
    receipt=[helper.validate_model_cache_file(Path(root)/plan['model_path'],n,h,cache_repository=Path(root)/plan['model_cache_repository']) for n,h in plan['model_files'].items()]
    installed=Path(root)/'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
    require(digest(installed)==plan['installed_model_source_sha256'],'Installed native source differs')
    return receipt


def historical_shapes(length):
    out={'input_ids':('torch.int64',(1,length)),'returned':('torch.bfloat16',(1,length,1024)),
        'final_residual':('torch.bfloat16',(1,length,1024)),'full_logits':('torch.bfloat16',(VOCAB,))}
    for l in LAYERS:
        for n in ('residual_input','after_attention','after_moe'):out[f'b{l}_{n}']=('torch.bfloat16',(1,1,1024))
    for s in SITES:
        for n in ('actual_final','returned_final'):out[f'{s}_{n}']=('torch.bfloat16',(1,1,1024))
    return out


def census_shapes(length,head_dim=64):
    out=historical_shapes(length)
    out.update(cache_position=('torch.int64',(length,)),position_ids=('torch.int64',(1,length)),
        mask=('torch.bfloat16',(1,1,length,length+1)),rope_cos=('torch.bfloat16',(1,length,head_dim)),rope_sin=('torch.bfloat16',(1,length,head_dim)))
    for l in LAYERS:
        prefix=f'b{l}_';out[prefix+'moe_input']=('torch.bfloat16',(1,length,1024))
        for name in ('order','tokens'):out[prefix+'route_'+name]=('torch.int64',(length*K,))
        out[prefix+'route_sizes']=('torch.int64',(EXPERTS,));out[prefix+'route_gates']=('torch.bfloat16',(length*K,));out[prefix+'route_logits']=('torch.float32',(length,EXPERTS))
    return out


def validate_ownership(complete,plan):
    require(complete['status']=='WORKER_COMPLETED' and same_json(complete['counts'],counts()),'Worker status/counts differ')
    require(complete['states_before']==complete['states_after']=={'host':plan['expected_host_state']} and set(plan['expected_host_state'])==expected_state_keys(),'Frozen host states differ')
    require(complete['checks']==dict(ownership_restored=True,states_unchanged=True,cache_unchanged=True,exact_counts=True),'Worker ownership checks differ')
    before,during,after=[complete['identities_'+x] for x in ('before','during','after')]
    require(same_json(before,after),'Ownership was not restored')
    params=expected_state_keys()-{'lm_head.weight'}
    for identity in (before,during,after):
        require(set(identity)=={'requires_grad','training','hooks','forward_methods','grad_none','host_config'},'Identity fields differ')
        for k in set(identity)-{'host_config'}:require(set(identity[k])=={'host'},'Unexpected component owner')
        require(set(identity['requires_grad']['host'])==set(identity['grad_none']['host'])==params,'Parameter flags incomplete')
        require(all(type(v) is bool for v in identity['requires_grad']['host'].values()) and all(v is True for v in identity['grad_none']['host'].values()),'Gradient ownership differs')
        require(identity['hooks']=={'host':{}},'Foreign/leaked hooks')
        require(identity['training']['host'] and all(v is False for v in identity['training']['host'].values()) and identity['training']==before['training'],'Eval inventory differs')
        require(set(identity['forward_methods']['host'])==set(identity['training']['host']) and identity['forward_methods']==before['forward_methods'],'Forward ownership differs')
    require(all(v is False for v in during['requires_grad']['host'].values()),'Trainable state during suffix replay')
    cfg=dict(before['host_config']);cfg['use_cache']=False
    require(same_json(during['host_config'],cfg),'Configured host changed')
    require(type(cfg.get('logits_scaling')) in (int,float) and cfg['logits_scaling']==6,'Native logit scale differs')
    for k,v in dict(hidden_size=1024,num_attention_heads=16,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,use_cache=False,output_attentions=False,output_hidden_states=False,output_router_logits=False).items():
        require(k in cfg and same_json(cfg[k],v),'Host configuration differs: '+k)
    for k in ('analytical_fits','backwards','optimizer_steps','provider_calls','generated_tokens'):require(type(complete[k]) is int and complete[k]==0,'Forbidden work')
    require(type(complete['elapsed_seconds']) in (int,float) and math.isfinite(complete['elapsed_seconds']) and 0<=complete['elapsed_seconds']<=TIMEOUT,'Worker time invalid')
    return {str(l):cfg['residual_multiplier'] for l in LAYERS}


def validate_runtime(directory,plan,plan_sha):
    actual=read(Path(directory)/'RUNTIME.json')
    require(type(actual.get('logits_scaling')) in (int,float) and actual['logits_scaling']==6,'Runtime logit scale differs')
    expected=dict(plan_sha256=plan_sha,**{k:SETTINGS[k] for k in ('python','torch','transformers','numpy')},
        seed=42,threads=4,device='mps',dtype='bfloat16',attention='eager',cache=False,
        output_attentions=False,output_hidden_states=False,output_router_logits=False,logits_scaling=actual['logits_scaling'],
        installed_model_source_sha256=plan['installed_model_source_sha256'])
    require(same_json(actual,expected),'Recorded runtime differs')

def expected_schedule(contexts,inventory):
    require(len(contexts)==24,'Context count differs');rows=[]
    for i,c in enumerate(contexts):
        state,action=divmod(i,3)
        require(c['id']==f's{state}-a{action}' and type(c['state']) is type(c['action']) is int and
            c['state']==state and c['action']==action,'Context identity/order differs')
        require(c['prompt']==f"World state {state}. Actions {'XYZ'[action]}. Next state:",'Original prompt differs')
        ids=c['input_ids'];require(type(ids) is list and 1<len(ids)<=48 and ids[0]==0 and
            all(type(x) is int and 0<=x<VOCAB for x in ids),'Input IDs malformed')
        for wi in range(4):
            wid=f'dev{wi:02d}';sources=dict(B=f'{(i*4+wi)*2:04d}',W=f'{(i*4+wi)*2+1:04d}')
            for arm in ARMS:
                index=len(rows);ia,ra=INPUT_ARM[arm],ROUTE_ARM[arm]
                row=dict(index=index,id=f'{index:04d}',cell_id=f'{c["id"]}-{wid}',context_id=c['id'],world_id=wid,
                    arm=arm,input_arm=ia,route_arm=ra,input_source_id=sources[ia],route_source_id=None if ra is None else sources[ra])
                for role,source_arm in (('input',ia),('route',ra)):
                    for kind,extension in (('call','npz'),('metadata','json')):
                        pk,hk=role+'_'+kind+'_path',role+'_'+kind+'_sha256'
                        if source_arm is None:row[pk]=row[hk]=None;continue
                        name=f'calls/{sources[source_arm]}.{extension}'
                        require(name in inventory,'Original call absent from collection')
                        row[pk]='outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1/'+name;row[hk]=inventory[name]
                rows.append(row)
    return rows

def validate_targets(plan):
    require(same_json(plan['label_ids'],list(range(34,42))),'Candidate labels differ')
    require([w['id'] for w in plan['worlds']]==[f'dev{i:02d}' for i in range(4)],'World order differs')
    for w in plan['worlds']:
        table=w['transitions']
        require(type(table) is list and len(table)==3 and all(type(r) is list and len(r)==8 and
            all(type(v) is int for v in r) and sorted(r)==list(range(8)) for r in table),'World transitions malformed')

def verify_plan(directory,root=ROOT):
    directory,root=Path(directory),Path(root);plan=read(directory/'plan.json');sha=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==sha,'Registration changed')
    require(same_json(plan['settings'],SETTINGS) and set(plan['collection_exclusions'])==EXCLUSIONS,'Settings/exclusions differ')
    old=root/'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1'
    for name,h in ORIGINAL_SHA.items():require(digest(old/name)==h,'Original completion binding changed')
    require(not (old/'STOPPED.json').exists(),'Original study stopped')
    op,done,oa,col=[read(old/n) for n in ('plan.json','COMPLETE.json','INDEPENDENT_AUDIT.json','COLLECTED.json')]
    require(done['status']=='ROUTE_CENSUS_COMPLETE' and oa['status']=='PASS' and
        all(r[k] is True for r in (done,oa) for k in ('implementation_pass','baseline_replication_pass')),'Census admission absent')
    require(done['plan_sha256']==oa['plan_sha256']==col['plan_sha256']==read(old/'REGISTRATION.json')['plan_sha256']==ORIGINAL_SHA['plan.json'] and
        done['report_sha256']==oa['report_sha256']==ORIGINAL_SHA['REPORT.json'] and
        done['independent_audit_sha256']==ORIGINAL_SHA['INDEPENDENT_AUDIT.json'] and
        oa['collected_sha256']==ORIGINAL_SHA['COLLECTED.json'],'Census hash chain differs')
    require(same_json(plan['schedule'],expected_schedule(plan['contexts'],col['artifact_sha256'])),'Fixed576 schedule differs')
    for k in ('expected_host_state','model_path','model_cache_repository','model_files','installed_model_source_sha256','contexts'):
        require(same_json(plan[k],op[k]),'Original model/context changed')
    tail_path='outputs/moe-mechanisms/ORGAN_TAIL_ATTRIBUTION_V1/plan.json'
    require(digest(root/tail_path)==op['lineage_sha256'][tail_path],'Original target plan changed')
    tp=read(root/tail_path)
    for k in ('worlds','label_ids'):require(same_json(plan[k],tp[k]),'Original target identities changed')
    validate_targets(plan)
    require(set(plan['expected_host_state'])==expected_state_keys(),'Host state inventory incomplete')
    names=('protocol.py','routing.py','worker.py','audit.py','owner.py','launch.py','test_routing.py','test_audit.py')
    require(set(plan['source_sha256'])==set(op['source_sha256'])|{'research/moe-mechanisms/organ_route_cross_v1/'+n for n in names},'Source inventory differs')
    require(all(plan['source_sha256'][n]==h for n,h in op['source_sha256'].items()),'Frozen source changed')
    for field in ('source_sha256','lineage_sha256'):
        require(type(plan[field]) is dict and plan[field],'Missing bindings')
        for n,h in plan[field].items():
            require(digest(safe(root,n))==h,'Live source/lineage changed')
            if field=='source_sha256':require(digest(safe(directory/'sources',n))==h,'Archived source changed')
    for e in plan['schedule']:
        for role in ('input','route'):
            for kind in ('call','metadata'):
                n=e[role+'_'+kind+'_path']
                if n is not None:require(digest(safe(root,n))==e[role+'_'+kind+'_sha256'],'Bound source call changed')
    return plan,sha

def call_shapes(length):
    shapes=census_shapes(length)
    for l in LAYERS:
        for n in ROUTE_NAMES:shapes[f'b{l}_actual_route_{n}']=shapes[f'b{l}_route_{n}']
        for branch in ('attn','moe'):shapes[f'b{l}_full_{branch}_output']=('torch.bfloat16',(1,length,1024))
    return shapes

def raw_bf16(value):
    a=np.asarray(value);require(a.dtype==np.float32 and np.all((a.view(np.uint32)&65535)==0),'Not decoded BF16')
    return (a.view(np.uint32)>>16).astype('<u2').tobytes()

def check_full_tail(values,meta):
    """Native BF16 multiply then add on every row; no branch-output replay."""
    length=values['returned'].shape[1];shape=[1,length,1024]
    names={*SITES,'final_residual',*[f'b{l}_{n}' for l in LAYERS for n in ('residual_input','after_attention','after_moe')]}
    require(same_json(meta['tail_entries'],dict.fromkeys(names,1)) and set(meta['tail_sites'])==set(SITES),'Tail entry inventory differs')
    observed={n for n in names if n not in SITES}
    require(set(meta['tail_observations'])==observed,'Tail observation inventory differs')
    multipliers=meta['residual_multipliers']
    require(type(multipliers) is dict and set(multipliers)=={str(l) for l in LAYERS} and
        all(type(x) in (float,int) and math.isfinite(x) for x in multipliers.values()),'Residual scalar malformed')
    def observation(name,value):
        descriptor=dict(shape=shape,dtype='torch.bfloat16',device='mps',nonfinal_sha256=hashlib.sha256(raw_bf16(value[:,:-1])).hexdigest())
        require(same_json(meta['tail_observations'][name],descriptor),'Full residual observation differs: '+name)
        expected=value if name=='final_residual' else value[:,-1:]
        require(exact(values[name],expected),'Retained residual differs: '+name)
    residual=values['returned']
    for l in LAYERS:
        observation(f'b{l}_residual_input',residual)
        for branch,after in (('attn','after_attention'),('moe','after_moe')):
            site=f'b{l}_{branch}';full=values[f'b{l}_full_{branch}_output']
            require(exact(full[:,-1:],values[site+'_actual_final']) and exact(full[:,-1:],values[site+'_returned_final']),'Branch final row was modified')
            nonfinal=hashlib.sha256(raw_bf16(full[:,:-1])).hexdigest()
            aux=[None] if branch=='attn' else [dict(dtype='torch.float32',shape=[length,EXPERTS],raw_sha256=raw_hash(values[f'b{l}_route_logits']))]
            expected=dict(shape=shape,dtype='torch.bfloat16',device='mps',nonfinal_before_sha256=nonfinal,
                nonfinal_after_sha256=nonfinal,auxiliary_before=aux,auxiliary_after=aux,auxiliary_objects_preserved=True,replayed=False)
            require(same_json(meta['tail_sites'][site],expected),'Branch locality/auxiliary differs: '+site)
            scaled=bf16(np.multiply(full,np.float32(multipliers[str(l)]),dtype=np.float32))
            residual=bf16(np.add(residual,scaled,dtype=np.float32))
            observation(f'b{l}_{after}',residual)
    observation('final_residual',residual)
    return dict(full_sequence_additions=8,full_sequence_multiplications=8,exact=True)

def load_source(root,entry,role,length):
    paths=[safe(root,entry[role+'_'+k+'_path']) for k in ('call','metadata')]
    original=Path(root)/'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1'
    require(all(p.resolve().is_relative_to(original.resolve()) for p in paths),'Source escapes frozen census')
    require([digest(p) for p in paths]==[entry[role+'_call_sha256'],entry[role+'_metadata_sha256']],'Source artifact changed')
    values,raw,meta=load_bundle(*paths,census_shapes(length))
    require(meta['plan_sha256']==ORIGINAL_SHA['plan.json'] and meta['id']==entry[role+'_source_id'] and
        type(meta['index']) is int and meta['index']==int(meta['id']) and meta['arm']==entry[role+'_arm'] and
        all(meta[k]==entry[k] for k in ('cell_id','context_id','world_id')) and meta['suffix_completed'] is True,'Source identity differs')
    return values,raw,meta

def check_routing(values,meta,route_source,entry):
    expected_names={f'b{l}_router' for l in LAYERS}|{f'b{l}_full_{p}_output' for l in LAYERS for p in ('attn','moe')}
    require(same_json(meta['routing_entries'],dict.fromkeys(expected_names,1)) and same_json(meta['routing_counts'],routing_counts()),'Fresh expert/route capture counts differ')
    require(set(meta['routing_observations'])=={f'b{l}' for l in LAYERS},'Routing observation inventory differs')
    summaries=[]
    for l in LAYERS:
        actual=[values[f'b{l}_actual_route_{n}'] for n in ROUTE_NAMES]
        checked=canonical_route(*actual)  # Only the live natural tuple is tested against live logits.
        delivered=[values[f'b{l}_route_{n}'] for n in ROUTE_NAMES]
        source=actual if route_source is None else [route_source[f'b{l}_route_{n}'] for n in ROUTE_NAMES]
        for j in range(4):require(exact(delivered[j],source[j]),'Delivered source policy differs')
        require(exact(delivered[4],actual[4]),'Live auxiliary logits changed')
        obs=dict(overridden=route_source is not None,live_auxiliary_object_preserved=True,
            actual_vs_delivered_first4_equal=all(exact(a,b) for a,b in zip(actual[:4],delivered[:4])))
        require(same_json(meta['routing_observations'][f'b{l}'],obs),'Router interception evidence differs')
        if route_source is not None:
            # Frozen donor gates use donor logits, not the receiver's intentionally different logits.
            canonical_route(*(route_source[f'b{l}_route_{n}'] for n in ROUTE_NAMES))
        summaries.append(dict(layer=l,actual_cutoff_ties=sum(not r['historical_support_unique'] for r in checked['rows']),
            actual_final_cutoff_tied=not checked['rows'][-1]['historical_support_unique'],
            delivered_first4_differs=not obs['actual_vs_delivered_first4_equal']))
    return summaries

def load_call(directory,row,entry,context,plan_sha,root=ROOT):
    schedule_fields(row,entry);stem='calls/'+entry['id']
    require(row['forward_path']==stem+'.npz' and row['forward_metadata_path']==stem+'.json','Call paths differ')
    paths=[safe(directory,row[k]) for k in ('forward_path','forward_metadata_path')]
    require([digest(p) for p in paths]==[row['forward_sha256'],row['forward_metadata_sha256']],'New call changed')
    length=len(context['input_ids']);values,raw,meta=load_bundle(*paths,call_shapes(length))
    schedule_fields(meta,entry)
    fields=('suffix_completed','component_counts','tail_entries','tail_sites','tail_observations','residual_multipliers','routing_entries','routing_counts','routing_observations')
    require(meta['plan_sha256']==plan_sha and all(same_json(row[k],meta[k]) for k in fields),'Row/sidecar differs')
    require(row['controls_pass'] is True and row['error'] is None and meta['suffix_completed'] is True and
        same_json(meta['component_counts'],component_counts()),'Incomplete/failed call')
    require(exact(values['input_ids'],np.array([context['input_ids']],dtype=np.int64)),'Token IDs differ')
    source,source_raw,source_meta=load_source(root,entry,'input',length)
    route_source=None
    if entry['route_arm'] is not None:route_source,_,_=load_source(root,entry,'route',length)
    else:require(all(entry['route_'+k] is None for k in ('source_id','call_path','metadata_path','call_sha256','metadata_sha256')),'Native has route donor')
    comparisons={name:exact(raw[name],source_raw[name]) for name in ('input_ids','returned','cache_position','position_ids','mask','rope_cos','rope_sin')}
    require(exact(values['cache_position'],np.arange(length,dtype=np.int64)) and exact(values['position_ids'],np.arange(length,dtype=np.int64)[None]),'Positions differ')
    minimum=np.array(0xff7f0000,dtype=np.uint32).view(np.float32)
    require(exact(values['mask'],np.triu(np.full((length,length+1),minimum,dtype=np.float32),k=1)[None,None]),'Causal mask differs')
    for l in LAYERS:
        for n in ROUTE_NAMES:
            target=values[f'b{l}_actual_route_{n}'] if route_source is None or n=='logits' else route_source[f'b{l}_route_{n}']
            comparisons[f'b{l}_delivered_{n}']=exact(values[f'b{l}_route_{n}'],target)
        for branch in ('attn','moe'):
            full=values[f'b{l}_full_{branch}_output']
            comparisons[f'b{l}_{branch}_full_final']=exact(full[:,-1:],values[f'b{l}_{branch}_actual_final'])
            comparisons[f'b{l}_{branch}_full_nonfinal']=hashlib.sha256(raw_bf16(full[:,:-1])).hexdigest()==meta['tail_sites'][f'b{l}_{branch}']['nonfinal_before_sha256']
    if entry['arm'] in CONTROLS:
        comparisons.update({'historical_'+name:exact(raw[name],source_raw[name]) for name in source})
        for l in LAYERS:
            for n in ROUTE_NAMES:comparisons[f'historical_b{l}_actual_{n}']=exact(values[f'b{l}_actual_route_{n}'],source[f'b{l}_route_{n}'])
        comparisons.update({name:same_json(meta[name],source_meta[name]) for name in ('tail_entries','tail_sites','tail_observations','residual_multipliers')})
    require(all(comparisons.values()) and same_json(row['comparisons'],comparisons),'Exact controls/source claims differ')
    check_full_tail(values,meta)
    diagnostics=check_routing(values,meta,route_source,entry)
    return values,raw,meta,diagnostics
def expected_events(schedule):
    result=[('worker_started',None),('resources','before_loading'),('resources','loaded')]
    for entry in schedule:
        result.extend([('resources','before:'+entry['id']),('suffix_started',entry)])
        for n in ('mask','rope'):
            for p in ('started','finished'):result.append(('component_'+p,dict(**entry,component=n,layer=None)))
        for l in LAYERS:
            for n,p in [('decoder','started'),('attention','started'),('attention','finished'),('moe','started'),('router','started'),('router','finished')]:
                result.append(('component_'+p,dict(**entry,component=n,layer=l)))
            for n in ('input_linear','output_linear'):
                for p in ('started','finished'):result.append(('expert_component_'+p,dict(**entry,component=n,layer=l)))
            for n,p in [('moe','finished'),('decoder','finished')]:result.append(('component_'+p,dict(**entry,component=n,layer=l)))
        for n in ('final_norm','head'):
            for p in ('started','finished'):result.append(('component_'+p,dict(**entry,component=n,layer=None)))
        result.extend([('suffix_finished',entry),('resources','after:'+entry['id']),('call_saved',entry)])
    return result+[('resources','complete'),('worker_completed',None)]

def validate_events(events,schedule,complete,started=None,worker=None):
    expected=expected_events(schedule);require(len(events)==len(expected)==35141,'Event count differs')
    samples=[];last=None;elapsed=-math.inf
    for row,(event,payload) in zip(events,expected):
        require(row['event']==event,'Event sequence differs');at=datetime.fromisoformat(row['at_utc'])
        require(at.tzinfo is not None and (last is None or at>=last),'Event chronology differs');last=at
        if started:require(datetime.fromisoformat(started['at_utc'])<=at<datetime.fromisoformat(started['deadline_utc']),'Event outside deadline')
        if isinstance(payload,dict):
            schedule_fields(row,payload)
            if event=='call_saved':require(row['controls_pass'] is True,'Failed retained call')
        elif event=='resources':
            sample={k:v for k,v in row.items() if k not in ('event','at_utc')}
            require(set(sample)=={'stage','elapsed_seconds','rss_high_water_bytes','mps_driver_bytes','archive_bytes'} and sample['stage']==payload,'Resource schema/stage differs')
            t=sample['elapsed_seconds'];require(type(t) in (float,int) and math.isfinite(t) and elapsed<=t<=TIMEOUT,'Resource time invalid');elapsed=t
            for key,cap in [('rss_high_water_bytes',MEMORY_LIMIT),('mps_driver_bytes',MEMORY_LIMIT),('archive_bytes',ARCHIVE_LIMIT)]:
                require(type(sample[key]) is int and 0<=sample[key]<=cap,'Resource ceiling exceeded')
            samples.append(sample)
        elif event=='worker_started' and worker:require(all(row[k]==worker[k] for k in ('worker_pid','owner_pid','deadline_utc')),'Worker actor differs')
        elif event=='worker_completed':require(same_json(row['counts'],counts()),'Journal final counts differ')
    require(len(samples)==1155 and same_json(samples,complete['resource_samples']),'Resource receipt differs')
    return samples

EFFECTS=dict(route_under_W=('SW','WB'),route_under_B=('BW','SB'),input_under_B_routes=('WB','SB'),
             input_under_W_routes=('SW','BW'),total=('SW','SB'))

def rational(value):
    v=Fraction(value);return dict(fraction=str(v),value=float(v))
def fraction_summary(values):
    require(values,'Empty exact summary');v=[Fraction(x) for x in values]
    return dict(n=len(v),mean=rational(sum(v,Fraction())/len(v)),minimum=rational(min(v)),maximum=rational(max(v)),
                positive=sum(x>0 for x in v),negative=sum(x<0 for x in v),zero=sum(x==0 for x in v))
def score(values,target):
    require(type(target) is int and 0<=target<8,'Invalid fixed target')
    a=np.asarray(values);require(a.shape==(8,) and a.dtype==np.float32 and np.isfinite(a).all(),'Malformed candidate logits')
    q=[Fraction(float(x)) for x in a];others=[j for j in range(8) if j!=target];win=[j for j,x in enumerate(q) if x==max(q)]
    return dict(scores=list(map(float,a)),winner=win[0] if len(win)==1 else None,winners=win,tie=len(win)!=1,
        correct=len(win)==1 and win[0]==target,J=rational(q[target]-sum((q[j] for j in others),Fraction())/7),
        target_minus_other={str(j):rational(q[target]-q[j]) for j in others},best_other_margin=rational(q[target]-max(q[j] for j in others)))

def contrasts(corners):
    out={name:corners[hi]-corners[lo] for name,(hi,lo) in EFFECTS.items()}
    out['interaction']=corners['SW']-corners['WB']-corners['BW']+corners['SB']
    require(out['total']==out['input_under_B_routes']+out['route_under_W']==out['route_under_B']+out['input_under_W_routes'] and
        out['interaction']==out['route_under_W']-out['route_under_B']==out['input_under_W_routes']-out['input_under_B_routes'],'Exact contrast identity failed')
    return out

def tensor_drift(a,b):
    """Descriptive same-input cross minus native; no threshold or exclusion."""
    require(a.dtype==b.dtype==np.float32 and a.shape==b.shape and np.isfinite(a).all() and np.isfinite(b).all(),'Drift operands differ')
    def part(x,y):
        d=x.astype(np.float64)-y.astype(np.float64);flat=d.reshape(-1)
        return dict(coordinates=d.size,raw_equal=exact(x,y),raw_word_changes=int(np.count_nonzero(x.view(np.uint32)!=y.view(np.uint32))),
            numeric_changes=int(np.count_nonzero(d)),maximum_absolute=float(np.max(np.abs(d))) if d.size else 0.,
            L1=math.fsum(map(abs,map(float,flat))),L2=math.sqrt(math.fsum(float(z)*float(z) for z in flat)))
    return dict(final=part(a[:,-1:],b[:,-1:]),nonfinal=part(a[:,:-1],b[:,:-1]))

def cell_report(entries,values,plan,context):
    require([e['arm'] for e in entries]==list(ARMS) and len({e['cell_id'] for e in entries})==1,'Cell arm coverage differs')
    first=entries[0];table=next(w['transitions'] for w in plan['worlds'] if w['id']==first['world_id']);target=table[context['action']][context['state']]
    arms={e['arm']:score(v['full_logits'][plan['label_ids']],target) for e,v in zip(entries,values)}
    effect_j=contrasts({arm:Fraction(r['J']['fraction']) for arm,r in arms.items()})
    seven={str(j):contrasts({arm:Fraction(r['target_minus_other'][str(j)]['fraction']) for arm,r in arms.items()}) for j in range(8) if j!=target}
    effects={name:dict(J=rational(v),target_minus_other={j:rational(d[name]) for j,d in seven.items()}) for name,v in effect_j.items()}
    byarm=dict(zip(ARMS,values));drift={}
    tensors=[f'b{l}_{n}' for l in LAYERS for n in ('full_attn_output','full_moe_output','moe_input')]+['final_residual']
    for arm,base in [('WB','W'),('BW','B')]:
        drift[arm]=dict(reference_arm=base,tensors={name:tensor_drift(byarm[arm][name],byarm[base][name]) for name in tensors})
    return dict(**{k:first[k] for k in ('cell_id','context_id','world_id')},target=target,
        call_ids={e['arm']:e['id'] for e in entries},arms=arms,effects=effects,drift=drift)

def summarize(cells):
    require(len(cells)==96 and len({r['cell_id'] for r in cells})==96,'Incomplete cell panel')
    def group(rows):
        armstats={arm:dict(n=len(rows),correct=sum(r['arms'][arm]['correct'] for r in rows),ties=sum(r['arms'][arm]['tie'] for r in rows),
            J=fraction_summary([r['arms'][arm]['J']['fraction'] for r in rows]),
            best_other_margin=fraction_summary([r['arms'][arm]['best_other_margin']['fraction'] for r in rows])) for arm in ARMS}
        names=(*EFFECTS,'interaction');effects={}
        for name in names:
            effects[name]=dict(J=fraction_summary([r['effects'][name]['J']['fraction'] for r in rows]),
                target_minus_other_by_competitor={str(j):fraction_summary([r['effects'][name]['target_minus_other'][str(j)]['fraction'] for r in rows if j!=r['target']])
                    for j in range(8) if any(j!=r['target'] for r in rows)})
            if name in EFFECTS:
                hi,lo=EFFECTS[name]
                transitions=Counter(str(r['arms'][lo]['winner'])+'->'+str(r['arms'][hi]['winner']) for r in rows)
                effects[name]['choice_changes']=dict(from_arm=lo,to_arm=hi,transitions=dict(sorted(transitions.items())),
                    unique_same=sum(r['arms'][lo]['winner'] is not None and r['arms'][lo]['winner']==r['arms'][hi]['winner'] for r in rows),
                    unique_different=sum(r['arms'][lo]['winner'] is not None and r['arms'][hi]['winner'] is not None and r['arms'][lo]['winner']!=r['arms'][hi]['winner'] for r in rows),
                    at_least_one_tie=sum(r['arms'][lo]['tie'] or r['arms'][hi]['tie'] for r in rows))
        return dict(n=len(rows),arms=armstats,effects=effects)
    worlds={f'dev{i:02d}':[r for r in cells if r['world_id']==f'dev{i:02d}'] for i in range(4)}
    require(all(len(v)==24 and len({r['context_id'] for r in v})==24 for v in worlds.values()),'World/context coverage differs')
    return dict(rows=cells,pooled=group(cells),per_world={w:group(v) for w,v in worlds.items()})

def audit_records(directory,plan,plan_sha,started=None,worker=None,root=ROOT):
    """First all576 structural checks /384 exact controls; only then any scores."""
    directory=Path(directory);schedule=plan['schedule'];require(len(schedule)==576,'Incomplete scheduled panel')
    calls=jsonl(directory/'calls.jsonl');require(len(calls)==576,'Incomplete actual panel')
    require(len({e['id'] for e in schedule})==576 and [e['index'] for e in schedule]==list(range(576)),'Duplicate/noncanonical schedule')
    for row,entry in zip(calls,schedule):schedule_fields(row,entry)
    validate_targets(plan)
    complete=read(directory/'WORKER_COMPLETE.json');require(complete['plan_sha256']==plan_sha,'Worker plan differs')
    multipliers=validate_ownership(complete,plan);validate_runtime(directory,plan,plan_sha)
    samples=validate_events(jsonl(directory/'worker-events.jsonl'),schedule,complete,started,worker)
    lookup={r['stage']:r for r in samples};contexts={c['id']:c for c in plan['contexts']};route_rows=[];controls=Counter()
    for row,entry in zip(calls,schedule):
        require(same_json(row['resources_before'],lookup['before:'+entry['id']]) and same_json(row['resources_after'],lookup['after:'+entry['id']]),'Call resource binding differs')
        values,raw,meta,diagnostics=load_call(directory,row,entry,contexts[entry['context_id']],plan_sha,root)
        require(same_json(meta['residual_multipliers'],multipliers),'Native multiplier changed')
        controls[entry['arm']]+=1
        route_rows.extend(dict(call_id=entry['id'],arm=entry['arm'],cell_id=entry['cell_id'],**r) for r in diagnostics)
    require(controls==Counter(dict.fromkeys(ARMS,96)),'All controls/cross arms must complete')
    # No score/contrast/drift calculation is reachable above this full-panel admission.
    cells=[]
    for offset in range(0,576,6):
        entries=schedule[offset:offset+6];current=[]
        for row,entry in zip(calls[offset:offset+6],entries):
            values,_,_=load_bundle(safe(directory,row['forward_path']),safe(directory,row['forward_metadata_path']),call_shapes(len(contexts[entry['context_id']]['input_ids'])))
            current.append(values)
        cells.append(cell_report(entries,current,plan,contexts[entries[0]['context_id']]))
    report=summarize(cells)
    report.update(implementation_pass=True,baseline_replication_pass=True,counts=counts(),
        controls=dict(native_exact=192,self_sham_exact=192,full_panel_before_scoring=True,all_census_array_comparisons_exact=True,
            actual_source_tuple_comparisons_exact=True,full_row_residual_reconstruction_exact=True),
        route_validation=route_rows,softmax_precast_absolute_allowance=SOFTMAX_ATOL,
        resources=dict(samples=len(samples),maximum_rss_bytes=max(r['rss_high_water_bytes'] for r in samples),
            maximum_mps_driver_bytes=max(r['mps_driver_bytes'] for r in samples),maximum_sampled_archive_bytes=max(r['archive_bytes'] for r in samples),worker_elapsed_seconds=complete['elapsed_seconds']))
    return report

def audit(directory=OUT):
    directory=Path(directory);require(directory.resolve()==OUT.resolve(),'Wrong fixed directory')
    forbidden=('STOPPED.json','WORKER_FAILURE.json','COMPLETE.json','AUDIT_STARTED.json','AUDIT_FAILURE.json','REPORT.json','INDEPENDENT_AUDIT.json')
    require(not any((directory/n).exists() for n in forbidden),'Stopped/terminal/already attempted: no retry/partial grading')
    runtime_guard();plan,plan_sha=verify_plan(directory);started,worker,events,monitor=owner_guard(directory,plan_sha)
    collected=read(directory/'COLLECTED.json')
    require(collected['plan_sha256']==plan_sha and collected['all_controls_pass'] is True and same_json(collected['counts'],counts()),'Incomplete collection')
    check_inventory(directory,collected)
    create(directory/'AUDIT_STARTED.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,pid=os.getpid(),owner_pid=os.getppid(),audit_code_sha256=digest(__file__),rerun_allowed=False))
    try:
        cache=validate_cache(plan)
        require(same_json(read(directory/'MODEL_CACHE_BEFORE.json'),cache) and same_json(read(directory/'MODEL_CACHE_AFTER.json'),cache),'Cache changed')
        report=audit_records(directory,plan,plan_sha,started,worker)
        check_inventory(directory,collected,late=('AUDIT_STARTED.json',));verify_plan(directory)
        require(datetime.now(timezone.utc)<datetime.fromisoformat(started['deadline_utc']),'Deadline expired before publication')
        report.update(status='CONTROLLED_ROUTING_TRAJECTORY_CROSS_REPORTED',plan_sha256=plan_sha,at_utc=datetime.now(timezone.utc).isoformat(),
            model_calls_by_auditor=0,fits_by_auditor=0,scientific_confirmation=False,novelty_established=False,
            limits=[
                'All96 exposed cells over24 contexts and four known worlds, equally weighted; no population inference, p-values or fresh-world claim.',
                'This is the implemented full-sequence four-layer policy: identities, gates, grouping and resulting native numerical effects jointly. It does not isolate final-token routing or individual expert computations.',
                'All384 exact native/self controls precede any crossed output score. Crossed wrong choices and ties remain in every denominator; controls are implementation admission, not a new scientific success threshold.',
                'J and every fixed target-minus-competitor effect are exact rational arithmetic on decoded BF16 logits. Four-corner identities are algebra, not evidence for physically additive components or natural mediation.',
                'The earlier D branch-output clamp differs from W under baseline routes. A failure of the latter cannot refute D categorical sufficiency. Donor routes may themselves encode the supplied answer.',
                'No outcome alone establishes genuine partial-information composition, energy advantage, planning, calibrated confidence, semantic specialization or novelty.',
                'Native router tuple consistency uses the inherited fixed2e-7 precast engineering allowance plus BF16 rounding bins. Delivered cross gates match donor tuples exactly and are not tested against receiver logits.',
                'Frozen sources and captured traces establish native expert/norm/head execution; the auditor independently reconstructs residual arithmetic, not a second full neural forward.',
                'Resource maxima are sampled. The auditor validates a live owner journal/monitor prefix; later parent terminal review must bind final bytes after owner cleanup.'
            ])
        create(directory/'REPORT.json',report)
        receipt=dict(status='PASS',implementation_pass=True,baseline_replication_pass=True,plan_sha256=plan_sha,
            report_sha256=digest(directory/'REPORT.json'),audit_code_sha256=digest(__file__),collected_sha256=digest(directory/'COLLECTED.json'),
            counts=counts(),input_sha256={**collected['artifact_sha256'],'COLLECTED.json':digest(directory/'COLLECTED.json')},
            owner_journal_prefix=events,owner_resource_prefix=monitor,live_owner_logs_final_hash_not_claimed=True,model_calls=0,fits=0,provider_calls=0)
        create(directory/'INDEPENDENT_AUDIT.json',receipt);return receipt
    except BaseException as exc:
        invalid=preserve_invalid_publications(directory)
        create(directory/'AUDIT_FAILURE.json',dict(at_utc=datetime.now(timezone.utc).isoformat(),plan_sha256=plan_sha,
            reason=type(exc).__name__+': '+str(exc),preserved_invalid_publications=invalid,rerun_allowed=False,partial_interpretation=False))
        raise

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',type=Path,default=OUT)
    result=audit(parser.parse_args().directory)
    print(json.dumps({k:v for k,v in result.items() if k not in ('input_sha256','owner_journal_prefix','owner_resource_prefix')}),flush=True)
