"""Invented fake CPU experts only. No pretrained checkpoint or original arrays."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import tempfile
import types
import unittest
from unittest import mock
import numpy as np
import torch
import routing as r
import worker as w

ROOT=Path(__file__).resolve().parents[3]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,ROOT/path)
    value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value);return value


SUFFIX=load('suffix','research/moe-mechanisms/organ_route_census_v1/suffix.py')
F=load('cross_invented_fixture','research/moe-mechanisms/organ_route_census_v1/test_suffix.py')
TAIL,LEGACY=F.TAIL,F.LEGACY
torch.set_num_threads(4)
COUNTS=dict(input_linear=0,output_linear=0)


class Router(torch.nn.Module):
    def forward(self,hidden):
        F.OPERATIONS['routers']+=1
        logits=torch.arange(32,dtype=torch.float32).repeat(len(hidden),1)
        for i in range(len(hidden)):
            if hidden[i,0]>4:logits[i]=logits[i].roll(8)
        selected,ids=logits.topk(8,dim=1);gates=selected.softmax(-1).to(torch.bfloat16)
        flat=ids.flatten();order=flat.argsort()
        self.last=(order,order//8,gates.flatten()[order],flat.bincount(minlength=32).tolist(),logits)
        return self.last


class Grouped(torch.nn.Module):
    def __init__(self,kind):
        super().__init__();self.kind=kind;self.calls=[];self.fail=False

    def forward(self,inputs,sizes):
        COUNTS[self.kind]+=1
        self.calls.append((inputs.detach().clone(),list(sizes)))
        if self.fail:raise RuntimeError('invented grouped expert failure')
        outputs=[]
        for expert,part in enumerate(inputs.split(sizes,dim=0)):
            # A shape-dependent term deliberately permits nonfinal numerical drift.
            out=part*(.02*(expert+1)) + (.002*len(part))
            outputs.append(torch.cat((out,torch.ones_like(out)),dim=-1) if self.kind=='input_linear' else out)
        return torch.cat(outputs,dim=0)


class MoE(torch.nn.Module):
    def __init__(self):
        super().__init__();self.router=Router();self.input_linear=Grouped('input_linear');self.output_linear=Grouped('output_linear')

    def forward(self,hidden):
        flat=hidden.reshape(-1,1024);_,tokens,gates,sizes,logits=self.router(flat)
        inner=self.input_linear(flat[tokens],sizes);a,b=inner.chunk(2,dim=-1)
        result=self.output_linear(torch.nn.functional.silu(a)*b,sizes)*gates[:,None]
        return torch.zeros_like(flat).index_add(0,tokens,result).reshape_as(hidden),logits


class Host(F.Host):
    def __init__(self):
        super().__init__()
        for block in self.model.layers[20:]:block.block_sparse_moe=MoE()
        self.eval()


def inp(arm):
    hidden,ids=F.invented_input()
    if arm=='W':hidden[0,-1,0]=8
    return hidden,ids


def sources(host):
    result={}
    for arm in ('B','W'):
        values,info,error,tail=SUFFIX.collect_suffix(host,*inp(arm),TAIL)
        if error:raise error
        result[arm]=(values,copy.deepcopy(info))
    return result


def capture(host,source,arm,event=lambda *a:None):
    routearm=w.ROUTE_ARM[arm]
    donor=None if routearm is None else {l:{n:source[routearm][0][f'b{l}_route_{n}'] for n in r.ROUTE_NAMES} for l in r.LAYERS}
    policy=r.RoutePolicy(host,donor,event)
    with policy:
        values,info,error,tail=SUFFIX.collect_suffix(host,*inp(w.INPUT_ARM[arm]),TAIL)
    values.update(policy.capture);info.update(policy.info())
    return values,info,error,tail,policy


def context(temp,n=6):
    root=Path(temp);out=root/'new';out.mkdir();old=root/'old';old.mkdir();(out/'plan.json').write_text('{}')
    p=types.SimpleNamespace(ROOT=root,OUT=out,CENSUS=old,read=lambda path:json.loads(Path(path).read_text()),digest=LEGACY.digest)
    rows=[]
    for i in range(n):
        arm=w.ARMS[i%6];ia=w.INPUT_ARM[arm];ra=w.ROUTE_ARM[arm]
        row=dict(index=i,id=f'{i:04d}',cell_id=f'cell{i//6}',context_id='toy',world_id='toy',arm=arm,
            input_arm=ia,route_arm=ra,input_source_id='0000' if ia=='B' else '0001',
            route_source_id=None if ra is None else ('0000' if ra=='B' else '0001'))
        for kind in ('input','route'):
            for key in ('call_path','metadata_path','call_sha256','metadata_sha256'):
                row[kind+'_'+key]=None
        rows.append(row)
    return p,dict(contexts=[dict(id='toy',input_ids=[0,1,2])],schedule=rows)


def execute(p,plan,host,src,counts=None,event=lambda *a,**kw:None,guard=lambda x:None):
    counts=w.initial_counts() if counts is None else counts
    def loader(p,e,kind,length):return src[e[kind+'_arm']]
    with mock.patch.object(w,'load_source',side_effect=loader):
        w.run_calls(dict(host=host),plan,p,TAIL,SUFFIX,LEGACY,LEGACY.identity(dict(host=host)),
                    event,lambda stage:dict(stage=stage),guard,counts)
    return counts


class RoutingTests(unittest.TestCase):
    def test_same_route_shams_reexecute_experts_and_match_every_native_array(self):
        host=Host();src=sources(host)
        for arm in ('B','W','SB','SW'):
            values,info,error,tail,policy=capture(host,src,arm)
            self.assertIsNone(error)
            route=None if w.ROUTE_ARM[arm] is None else src[w.ROUTE_ARM[arm]][0]
            comparisons=w.validate(values,info,tail,policy,*src[w.INPUT_ARM[arm]],route,dict(arm=arm))
            self.assertTrue(all(comparisons.values()))
            self.assertEqual(policy.counts,{k:4 for k in r.expert_counts()})
            for layer in r.LAYERS:
                moe=host.model.layers[layer].block_sparse_moe
                self.assertTrue(moe.input_linear.calls and moe.output_linear.calls)

    def test_cross_consumes_donor_route_but_recipient_live_input_and_aux(self):
        host=Host();src=sources(host)
        values,info,error,tail,policy=capture(host,src,'WB')
        self.assertIsNone(error)
        self.assertTrue(all(w.validate(values,info,tail,policy,*src['W'],src['B'][0],dict(arm='WB')).values()))
        self.assertEqual(r.raw(values['b20_moe_input']),r.raw(src['W'][0]['b20_moe_input']))
        self.assertNotEqual(r.raw(values['b20_moe_input']),r.raw(src['B'][0]['b20_moe_input']))
        for layer in r.LAYERS:
            for name in r.ROUTE_NAMES[:4]:
                self.assertEqual(r.raw(values[f'b{layer}_route_{name}']),r.raw(src['B'][0][f'b{layer}_route_{name}']))
            self.assertEqual(r.raw(values[f'b{layer}_route_logits']),r.raw(values[f'b{layer}_actual_route_logits']))
            self.assertTrue(policy.observations[f'b{layer}']['live_auxiliary_object_preserved'])
        self.assertNotEqual(r.raw(values['b20_actual_route_order']),r.raw(values['b20_route_order']))
        self.assertNotEqual(r.raw(values['final_residual'][:,:-1]),r.raw(src['W'][0]['final_residual'][:,:-1]))

    def test_fixed_source_tie_and_zero_gates_are_not_reselected(self):
        host=Host();src=sources(host)
        chosen=copy.deepcopy(src)
        for layer in r.LAYERS:chosen['B'][0][f'b{layer}_route_gates'].zero_()
        values,info,error,tail,policy=capture(host,chosen,'WB')
        self.assertIsNone(error)
        self.assertEqual(values['b20_route_gates'].count_nonzero().item(),0)
        self.assertEqual(r.raw(values['b20_route_order']),r.raw(chosen['B'][0]['b20_route_order']))

    def test_interceptor_failure_retains_native_return_and_cleans_all_hooks(self):
        host=Host();src=sources(host);before=LEGACY.identity(dict(host=host))
        src['B'][0]['b20_route_order'][0]=src['B'][0]['b20_route_order'][1]
        values,info,error,tail,policy=capture(host,src,'WB')
        self.assertIsInstance(error,ValueError)
        self.assertEqual(policy.entries['b20_router'],1)
        self.assertEqual(info['component_counts']['router_finished'],0)
        self.assertIn('b20_actual_route_logits',values)
        self.assertEqual(before,LEGACY.identity(dict(host=host)))

    def test_full_branch_capture_failure_keeps_native_entry(self):
        host=Host();src=sources(host);before=LEGACY.identity(dict(host=host))
        original=r.RoutePolicy.branch
        def fail(self,layer,name,output):
            if layer==20 and name=='attn':
                self.once('b20_full_attn_output');raise OSError('invented branch capture failure')
            return original(self,layer,name,output)
        with mock.patch.object(r.RoutePolicy,'branch',fail):
            _,info,error,_,policy=capture(host,src,'B')
        self.assertIsInstance(error,OSError)
        self.assertEqual(policy.entries['b20_full_attn_output'],1)
        self.assertEqual(info['component_counts']['attention_finished'],0)
        self.assertEqual(before,LEGACY.identity(dict(host=host)))

    def test_grouped_failure_counts_no_retry_and_cleanup(self):
        host=Host();src=sources(host);before=LEGACY.identity(dict(host=host))
        host.model.layers[21].block_sparse_moe.output_linear.fail=True
        _,_,error,_,policy=capture(host,src,'BW')
        self.assertIsInstance(error,RuntimeError)
        self.assertEqual(policy.counts['output_linear_attempts'],2)
        self.assertEqual(policy.counts['output_linear_finished'],1)
        self.assertEqual(before,LEGACY.identity(dict(host=host)))

    def test_single_use_and_layer_inventory(self):
        with self.assertRaises(ValueError):r.RoutePolicy(Host(),{})
        policy=r.RoutePolicy(Host())
        with policy:pass
        with self.assertRaises(ValueError):
            with policy:pass


class WorkerTests(unittest.TestCase):
    def test_full_576_archive_exact_work_and_no_control_filter(self):
        host=Host();src=sources(host);events=[]
        with tempfile.TemporaryDirectory() as temp:
            p,plan=context(temp,576)
            counts=execute(p,plan,host,src,event=lambda name,**kw:events.append((name,kw)))
            self.assertEqual(counts,w.expected_counts())
            rows=[json.loads(x) for x in (p.OUT/'calls.jsonl').read_text().splitlines()]
            self.assertEqual(len(rows),576)
            self.assertTrue(all(x['controls_pass'] for x in rows))
            self.assertEqual(len(events),576*59)
            self.assertEqual(sum(x['arm'] in ('B','W','SB','SW') for x in rows),384)
            self.assertTrue(all(not x['comparisons'].get('historical_full_logits',False) for x in rows if x['arm'] in ('WB','BW')))
            self.assertEqual(len(list((p.OUT/'calls').glob('*.npz'))),576)

    def test_native_return_count_survives_preobserver_failure(self):
        host=Host();src=sources(host)
        src['B'][0]['b20_route_order'][0]=src['B'][0]['b20_route_order'][1]
        with tempfile.TemporaryDirectory() as temp:
            p,plan=context(temp);plan['schedule']=[plan['schedule'][4]];counts=w.initial_counts()
            with self.assertRaises(ValueError):execute(p,plan,host,src,counts)
            self.assertEqual(counts['router_native_returns'],1)
            self.assertEqual(counts['router_finished'],0)
            self.assertEqual(counts['attention_native_returns'],1)
            row=json.loads((p.OUT/'calls.jsonl').read_text())
            self.assertFalse(row['controls_pass'])
            self.assertTrue((p.OUT/row['forward_path']).exists())

    def test_storage_failure_keeps_completed_counts(self):
        host=Host();src=sources(host)
        with tempfile.TemporaryDirectory() as temp:
            p,plan=context(temp,1);counts=w.initial_counts()
            with mock.patch.object(LEGACY,'retain',side_effect=OSError('invented disk full')):
                with self.assertRaises(OSError):execute(p,plan,host,src,counts)
            self.assertEqual(counts,w.expected_counts(1,0))

    def test_finish_journal_failure_retains_full_raw(self):
        host=Host();src=sources(host)
        with tempfile.TemporaryDirectory() as temp:
            p,plan=context(temp,1)
            def event(name,**kw):
                if name=='suffix_finished':raise OSError('invented finish journal error')
            with self.assertRaises(OSError):execute(p,plan,host,src,event=event)
            row=json.loads((p.OUT/'calls.jsonl').read_text());self.assertFalse(row['controls_pass'])
            self.assertTrue(row['suffix_completed'])
            self.assertTrue((p.OUT/row['forward_metadata_path']).exists())

    def test_resource_failure_retains_only_first_return(self):
        host=Host();src=sources(host)
        with tempfile.TemporaryDirectory() as temp:
            p,plan=context(temp)
            def guard(sample):
                if sample['stage'].startswith('after:'):raise RuntimeError('invented resource stop')
            with self.assertRaises(RuntimeError):execute(p,plan,host,src,guard=guard)
            rows=(p.OUT/'calls.jsonl').read_text().splitlines();self.assertEqual(len(rows),1)
            self.assertFalse(json.loads(rows[0])['controls_pass'])

    def test_source_roundtrip_hash_and_cell_binding(self):
        host=Host();src=sources(host)
        with tempfile.TemporaryDirectory() as temp:
            p,plan=context(temp);entry=plan['schedule'][0]
            metadata=dict(src['B'][1],id='0000',index=0,arm='B',cell_id='cell0',context_id='toy',world_id='toy')
            pointers=LEGACY.retain(p.CENSUS,'saved',src['B'][0],metadata)
            for kind,key in (('call','forward'),('metadata','forward_metadata')):
                entry['input_'+kind+'_path']='old/'+pointers[key+'_path']
                entry['input_'+kind+'_sha256']=pointers[key+'_sha256']
            values,_=w.load_source(p,entry,'input',3)
            self.assertTrue(all(r.raw(values[k])==r.raw(v) for k,v in src['B'][0].items()))
            for key,value in (('cell_id','other'),('input_source_id','0001'),('input_call_sha256','0'*64),('input_call_path','../outside')):
                changed=dict(entry);changed[key]=value
                with self.assertRaises(ValueError):w.load_source(p,changed,'input',3)


if __name__=='__main__':
    try:unittest.main()
    finally:print('INVENTED_OPERATION_COUNTS='+json.dumps(dict(F.OPERATIONS,**COUNTS),sort_keys=True))
