"""Prospective joint-routing trajectory cross on the fixed exposed organ panel."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
OUT=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_V1'
PREP=OUT.with_name(OUT.name+'_PREPARATION')
PYTHON=ROOT/'work/acquisition-representation-venv/bin/python'
CENSUS=ROOT/'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1'
CENSUS_SOURCE=ROOT/'research/moe-mechanisms/organ_route_census_v1'
ORIGINAL=CENSUS
CENSUS_SHA={
 'plan.json':'133c644bae49d7e0cf30704e5be5f05797ceff022b5763ef358f95335cdfe701',
 'COMPLETE.json':'535f5fbfd59c8c3576da4c7ef058713e156c6c4514ab7ab23ae309dda5ba25c7',
 'INDEPENDENT_AUDIT.json':'edebd3f5fa06867be5cf9d59319aa73376a03d50174b8186b85fab42817120a8',
 'REPORT.json':'04cb5940073df0ef5c9f2350bc5d80b3d09f48e4b7994a2e98160a6723f45202',
 'COLLECTED.json':'03c58b8b5d142609bcfa28cfe99e99f47a2dae6435ed4e0d3561e04f4a16206c',
 'REGISTRATION.json':'2544ff8ca550e38409432514c0e623a13db598b8dc765cda0c3710cc2a7e56e7'}
ARMS=('B','W','SB','SW','WB','BW')
INPUT_ARM=dict(zip(ARMS,('B','W','B','W','W','B')))
ROUTE_ARM=dict(zip(ARMS,(None,None,'B','W','B','W')))
SETTINGS=dict(python='3.12.14',torch='2.8.0',transformers='4.56.2',numpy='2.3.3',
 suffix_executions=576,decoder_block_executions=2304,contexts=24,worlds=4,cells=96,
 layers=[20,21,22,23],experts=32,top_k=8,arms=list(ARMS),native_replications=192,self_shams=192,crossed_suffixes=192,
 full_host_forwards=0,prefix_forwards=0,reader_applications=0,organ_forwards=0,writer_forwards=0,
 analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0,
 dtype='bfloat16',device='mps',threads=4,batch_size=1,attention='eager',cache=False,logits_scaling=6,
 timeout_seconds=900,max_rss_bytes=10*1024**3,max_mps_driver_bytes=10*1024**3,max_archive_bytes=1024**3,
 historical_hash_tolerance=0.0)
SOURCES=('protocol.py','routing.py','worker.py','audit.py','owner.py','launch.py','test_routing.py','test_audit.py')
COLLECTION_EXCLUSIONS=('owner-events.jsonl','resource-monitor.jsonl','worker.log','independent_audit.log','COLLECTED.json')
REVIEW_PATHS=('work/organ-route-cross-v1/CROSS_SOURCE_REVIEW.json',
 'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_V1_PREPARATION/PREPARATION_TESTS.json',
 'outputs/moe-mechanisms/ORGAN_ROUTE_CROSS_V1_PREPARATION/PARENT_SOURCE_REVIEW.json')

def now():return datetime.now(timezone.utc).isoformat()
def read(path):return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def relative(path):return str(Path(path).relative_to(ROOT))
def require(ok,message):
    if not ok:raise ValueError(message)
def create(path,value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def safe_path(directory,name):
    path=Path(name);require(not path.is_absolute() and '..' not in path.parts,'Unsafe bound path')
    result=Path(directory)/path
    require(result.resolve().is_relative_to(Path(directory).resolve()),'Bound path escapes root')
    return result
def census_plan():
    for name,h in CENSUS_SHA.items():require(digest(CENSUS/name)==h,'Frozen census changed: '+name)
    require(not (CENSUS/'STOPPED.json').exists(),'Census stopped')
    done,audit,collection=[read(CENSUS/n) for n in ('COMPLETE.json','INDEPENDENT_AUDIT.json','COLLECTED.json')]
    require(done['status']=='ROUTE_CENSUS_COMPLETE' and audit['status']=='PASS' and
        all(x[k] is True for x in (done,audit) for k in ('implementation_pass','baseline_replication_pass')),'Census admission absent')
    require(done['plan_sha256']==audit['plan_sha256']==collection['plan_sha256']==CENSUS_SHA['plan.json'] and
        done['report_sha256']==audit['report_sha256']==CENSUS_SHA['REPORT.json'] and
        done['independent_audit_sha256']==CENSUS_SHA['INDEPENDENT_AUDIT.json'] and
        audit['collected_sha256']==CENSUS_SHA['COLLECTED.json'],'Census completion chain differs')
    return read(CENSUS/'plan.json')

_MODULES={}
def load_census(name):
    require(name in ('protocol','suffix','worker','audit'),'Unlisted census helper')
    path=CENSUS_SOURCE/(name+'.py');old=census_plan()
    require(digest(path)==old['source_sha256'][relative(path)],'Frozen census source changed')
    if name not in _MODULES:
        prior=None
        if name=='worker':
            prior=sys.modules.get('suffix');sys.modules['suffix']=load_census('suffix')
        try:
            spec=importlib.util.spec_from_file_location('route_cross_bound_'+name,path)
            value=importlib.util.module_from_spec(spec);sys.modules[spec.name]=value
            spec.loader.exec_module(value);_MODULES[name]=value
        finally:
            if name=='worker':
                if prior is None:sys.modules.pop('suffix',None)
                else:sys.modules['suffix']=prior
    return _MODULES[name]
def load_tail(name):return load_census('protocol').load_tail(name)
def load_legacy(name):return load_census('protocol').load_legacy(name)
def validate_model_files(plan):return load_census('protocol').validate_model_files(plan)

def schedule(old):
    inventory=read(CENSUS/'COLLECTED.json')['artifact_sha256'];entries=old['schedule'];rows=[]
    require(len(entries)==192,'Census schedule incomplete')
    for offset in range(0,192,2):
        b,w=entries[offset:offset+2]
        require(b['arm']=='B' and w['arm']=='W' and b['cell_id']==w['cell_id'],'Census cell pairing differs')
        sources=dict(B=b,W=w)
        for arm in ARMS:
            index=len(rows);input_arm=INPUT_ARM[arm];route_arm=ROUTE_ARM[arm]
            row=dict(index=index,id=f'{index:04d}',cell_id=b['cell_id'],context_id=b['context_id'],world_id=b['world_id'],
                     arm=arm,input_arm=input_arm,route_arm=route_arm,
                     input_source_id=sources[input_arm]['id'],route_source_id=None if route_arm is None else sources[route_arm]['id'])
            for role,source_arm in (('input',input_arm),('route',route_arm)):
                for kind,extension in (('call','npz'),('metadata','json')):
                    path_key=role+'_'+kind+'_path';hash_key=role+'_'+kind+'_sha256'
                    if source_arm is None:row[path_key]=row[hash_key]=None;continue
                    name='calls/'+sources[source_arm]['id']+'.'+extension
                    require(name in inventory,'Missing source census artifact')
                    row[path_key]=relative(CENSUS/name);row[hash_key]=inventory[name]
                    require(digest(safe_path(CENSUS,name))==inventory[name],'Census source call changed')
            rows.append(row)
    require(len(rows)==576 and len({r['cell_id'] for r in rows})==96,'Fixed cross panel differs')
    return rows
def source_hashes():
    result=dict(census_plan()['source_sha256'])
    for name,h in result.items():require(digest(ROOT/name)==h,'Frozen source changed: '+name)
    for name in SOURCES:result[relative(HERE/name)]=digest(HERE/name)
    return result
def build_plan():
    old=census_plan();tail=load_census('protocol').original_plan()
    keys=('expected_host_state','model_path','model_cache_repository','model_files','installed_model_source_sha256','contexts')
    lineage={relative(CENSUS/n):h for n,h in CENSUS_SHA.items()}
    notes=ROOT/'work/organ-route-cross-v1'
    for name in ('SOURCE_FEASIBILITY.json','IDENTIFIABILITY_REVIEW.json','DESIGN_CRITIQUE.json'):
        lineage[relative(notes/name)]=digest(notes/name)
    for path in ('work/organ-route-census-review/TERMINAL_REVIEW.json',
        'outputs/routing-research/BUDGET_AFTER_JEV_FEEDBACK_AMENDED_NEGATIVE.json'):
        lineage[path]=digest(ROOT/path)
    require(lineage['outputs/routing-research/BUDGET_AFTER_JEV_FEEDBACK_AMENDED_NEGATIVE.json']=='8ebcaabedb7bd09cfdf63b9ccbe6c6b60cf2d31e9d753d09e9b7ec4d6975ff58','Budget basis changed')
    return dict(status='PROSPECTIVE_JOINT_ROUTING_TRAJECTORY_CROSS',created_at_utc=now(),settings=SETTINGS,
        **{k:old[k] for k in keys},worlds=tail['worlds'],label_ids=tail['label_ids'],schedule=schedule(old),
        source_sha256=source_hashes(),lineage_sha256=lineage,collection_exclusions=list(COLLECTION_EXCLUSIONS),
        question='What changes when the frozen full routing trajectory is exchanged between uniform-baseline and supplied-answer states, while native experts recompute their outputs?',
        arms={a:dict(input_arm=INPUT_ARM[a],route_arm=ROUTE_ARM[a]) for a in ARMS},
        design='All96 exposed context/world cells, in original order, with B,W,SB,SW,WB,BW once each. Every suffix starts from the source census full post-writer tensor. No prefix, tokenizer, reader, organ, writer, fitting, generation or provider call.',
        intervention='At all four native routers in blocks20..23, first compute and retain the actual native five-member tuple. For four controlled arms return byte-exact source order,token indices,BF16 gates and expert counts plus the identical live logits object. Native expert linears, nonlinearities, summation, residuals, attention, final norm and vocabulary head all recompute on current inputs. No expert or branch output is replayed.',
        target='The entire implemented full-sequence routing trajectory, jointly identities and coefficients. Group sizes, token order and resulting arithmetic are included. This does not isolate final-token-only semantics, selection versus coefficients, a specific expert, or an ideal real-number intervention.',
        controls='All192 native replications and192 same-route shams must exactly match source full-vocabulary logits, intermediate final rows, full residual, nonfinal hashes, full router logits and actual source route operands. Stop first mismatch and preserve raw partials. Independent audit must check complete576 inventory and all384 controls before any cross-arm outcome scoring.',
        cross_admission='Both cross arms retain all cases. Require finite tensors, fixed source-route first4 identity, unchanged live-logit object/auxiliary, exact frozen model state/ownership, current expert inputs and completed native linear calls. Nonfinal computation differences are outcomes, not grounds for dropping cases. Do not require cross-consumed choices/gates to equal the native top-k of live logits.',
        primary_outcome='J = target logit minus arithmetic mean of the other seven fixed candidate logits. Target and candidate token IDs come unchanged from the earlier source plan. Preserve all seven target-minus-other contrasts, strict unique eight-label choice and target-minus-best-other margin as secondary outcomes.',
        estimands='For every cell report all four corners BB,WW,WB,BW; routing effect under W = J_WW-J_WB; routing effect under B = J_BW-J_BB; input effect under B routing = J_WB-J_BB; input effect under W routing = J_WW-J_BW; interaction = J_WW-J_WB-J_BW+J_BB; total = J_WW-J_BB. Report exact rational contrasts, floating displays, pooled and per-world means, sign counts and paired choice changes. No p-values, mediation fractions, calibrated confidence or population inference.',
        drift='Retain full attention/MoE branch outputs and existing full MoE inputs/final residual. Audit consistency with observed final rows/nonfinal hashes. Report crossed-arm drift relative to same-input native run at every block and final residual; a numeric side effect is included in this implemented-policy effect, not silently excluded.',
        interpretation='A route clamp can reveal dependence of this engineered answer channel on this policy. It cannot refute the earlier branch-clamp shortcut, establish computation transfer, partial-information composition, planning, energy-model superiority, unseen-rule transfer or novelty. Written-source routes were generated using the organ answer and may themselves carry that answer. All24contexts/fourworlds are exposed repeated development cases.',
        stop='On source,shape,finiteness,exact-control,ownership,resource or audit failure preserve STOP and raw records; no outcome grading of partial cross panels, no rerun/resumption/relaxed tolerance or changed gate.',
        resource='One pinned local model load;900seconds including audit; RSS/MPS driver<=10GiB; archive<=1GiB with closure reserve. Exactly576new suffixes and2304blocks are model computation. No automatic follow-up experiment.',
        budget_new_usd=0,budget_inclusive_committed_and_reserved_usd='7.6774551949',budget_remaining_usd='12.3225448051',
        novelty_established=False,scientific_confirmation=False,automatic_next_study=False)
def prepare():
    require(not OUT.exists(),'Already registered; never recreate')
    hashes=source_hashes()
    for path in REVIEW_PATHS:
        r=read(ROOT/path);require(r.get('status','').startswith('PASS'),'Missing passing review: '+path)
        require(r.get('source_sha256')==hashes,'Stale review: '+path)
    plan=build_plan()
    for path in REVIEW_PATHS:plan['lineage_sha256'][path]=digest(ROOT/path)
    validate_model_files(plan);OUT.mkdir()
    for path,h in hashes.items():
        target=OUT/'sources'/path;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/path,target);require(digest(target)==h,'Archived source differs')
    create(OUT/'plan.json',plan);create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)
def verify():
    plan=read(OUT/'plan.json')
    require(read(OUT/'REGISTRATION.json')['plan_sha256']==digest(OUT/'plan.json'),'Plan changed')
    require(plan['settings']==SETTINGS and plan['schedule']==schedule(census_plan()),'Settings/schedule differ')
    require(plan['source_sha256']==source_hashes(),'Source inventory changed')
    for field in ('source_sha256','lineage_sha256'):
        for path,h in plan[field].items():require(digest(safe_path(ROOT,path))==h,'Bound file changed: '+path)
    for path,h in plan['source_sha256'].items():require(digest(safe_path(OUT/'sources',path))==h,'Archived source differs')
    return plan

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare']);parser.parse_args();prepare()
