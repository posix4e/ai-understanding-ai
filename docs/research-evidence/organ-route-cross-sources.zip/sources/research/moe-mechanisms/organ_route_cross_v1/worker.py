"""Fixed six-arm native suffix routing-policy factorial. No primary scoring."""
import argparse
from datetime import datetime, timezone
import hashlib
import inspect
import os
from pathlib import Path
import platform
import resource
import signal
import time

import numpy as np
import torch
from routing import RoutePolicy, ROUTE_NAMES, LAYERS, expert_counts, raw

COMPONENTS = ('mask','rope','decoder','attention','moe','router','final_norm','head')
ARMS = ('B','W','SB','SW','WB','BW')
INPUT_ARM = dict(B='B',W='W',SB='B',SW='W',WB='W',BW='B')
ROUTE_ARM = dict(B=None,W=None,SB='B',SW='W',WB='B',BW='W')
CONTROLS = ('B','W','SB','SW')


def initial_counts():
    return dict(suffix_attempts=0,suffix_finished=0,
        **{n+'_'+p:0 for n in COMPONENTS for p in ('attempts','finished')},**expert_counts(),
        route_overrides=0,router_native_returns=0,attention_native_returns=0,moe_native_returns=0,
        full_host_forwards=0,prefix_forwards=0,reader_calls=0,organ_calls=0,
        writer_calls=0,analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)


def expected_counts(n=576,overrides=1536):
    result=initial_counts();result.update(suffix_attempts=n,suffix_finished=n,route_overrides=overrides)
    result.update(router_native_returns=4*n,attention_native_returns=4*n,moe_native_returns=4*n)
    for name in COMPONENTS+('input_linear','output_linear'):
        for phase in ('attempts','finished'):
            result[name+'_'+phase]=n*(1 if name in ('mask','rope','final_norm','head') else 4)
    return result


def census_shapes(length):
    shape={'input_ids':(torch.int64,(1,length)),'returned':(torch.bfloat16,(1,length,1024)),
        'final_residual':(torch.bfloat16,(1,length,1024)),'full_logits':(torch.bfloat16,(49155,)),
        'cache_position':(torch.int64,(length,)),'position_ids':(torch.int64,(1,length)),
        'mask':(torch.bfloat16,(1,1,length,length+1)),'rope_cos':(torch.bfloat16,(1,length,64)),
        'rope_sin':(torch.bfloat16,(1,length,64))}
    for layer in LAYERS:
        for name in ('residual_input','after_attention','after_moe'):
            shape[f'b{layer}_{name}']=(torch.bfloat16,(1,1,1024))
        for branch in ('attn','moe'):
            for kind in ('actual_final','returned_final'):
                shape[f'b{layer}_{branch}_{kind}']=(torch.bfloat16,(1,1,1024))
        shape[f'b{layer}_moe_input']=(torch.bfloat16,(1,length,1024))
        for name,dtype,sizes in (('order',torch.int64,(length*8,)),('tokens',torch.int64,(length*8,)),
                ('gates',torch.bfloat16,(length*8,)),('sizes',torch.int64,(32,)),('logits',torch.float32,(length,32))):
            shape[f'b{layer}_route_{name}']=(dtype,sizes)
    return shape


def load_source(p,entry,kind,length):
    paths={}
    for suffix in ('call','metadata'):
        relative=Path(entry[kind+'_'+suffix+'_path']);path=p.ROOT/relative
        if relative.is_absolute() or '..' in relative.parts or not path.resolve().is_relative_to(p.CENSUS.resolve()):
            raise ValueError('Bound census path escapes source')
        if p.digest(path)!=entry[kind+'_'+suffix+'_sha256']:
            raise ValueError('Census source changed')
        paths[suffix]=path
    meta=p.read(paths['metadata']);source_id=entry[kind+'_source_id'];arm=entry[kind+'_arm']
    if (meta['id']!=source_id or meta['index']!=int(source_id) or meta['arm']!=arm
        or any(meta[k]!=entry[k] for k in ('cell_id','context_id','world_id')) or meta['suffix_completed'] is not True):
        raise ValueError('Census source/cell binding differs')
    shapes=census_shapes(length)
    if set(meta['tensors'])!=set(shapes):raise ValueError('Census tensor inventory differs')
    values={}
    with np.load(paths['call'],allow_pickle=False) as archive:
        if set(archive.files)!={k+s for k in shapes for s in ('__raw_uint8','__value')}:
            raise ValueError('Census archive members differ')
        for name,(dtype,shape) in shapes.items():
            m=meta['tensors'][name]
            if (m['dtype']!=str(dtype) or m['shape']!=list(shape) or m['raw_key']!=name+'__raw_uint8'
                or m['value_key']!=name+'__value'):raise ValueError('Census tensor encoding differs')
            a=archive[m['raw_key']]
            if a.dtype!=np.uint8 or hashlib.sha256(a.tobytes()).hexdigest()!=m['raw_sha256']:
                raise ValueError('Census raw bytes differ')
            value=torch.from_numpy(a.copy()).view(dtype).reshape(shape)
            readable=(value.float() if dtype==torch.bfloat16 else value).numpy();saved=archive[m['value_key']]
            if (readable.dtype!=saved.dtype or readable.shape!=saved.shape or readable.tobytes()!=saved.tobytes()
                or not bool(torch.isfinite(value).all())):raise ValueError('Census raw/readable differs')
            values[name]=value
    return values,meta


def validate(values,info,tail,policy,source,metadata,route_source,entry):
    n=source['returned'].shape[1];tail.validate();policy.validate(n)
    shapes=census_shapes(n)
    for layer in LAYERS:
        for name in ROUTE_NAMES:
            shapes[f'b{layer}_actual_route_{name}']=shapes[f'b{layer}_route_{name}']
        for branch in ('attn','moe'):
            shapes[f'b{layer}_full_{branch}_output']=(torch.bfloat16,(1,n,1024))
    if set(values)!=set(shapes):raise ValueError('New tensor inventory differs')
    for name,(dtype,shape) in shapes.items():
        if values[name].dtype!=dtype or tuple(values[name].shape)!=shape or not bool(torch.isfinite(values[name]).all()):
            raise ValueError('Malformed/nonfinite new tensor '+name)
    expected={k:v for k,v in expected_counts(1,0).items() if k in info['component_counts']}
    if info['suffix_completed'] is not True or info['component_counts']!=expected:
        raise ValueError('Suffix component counts differ')
    comparisons={name:raw(values[name])==raw(source[name]) for name in (
        'input_ids','returned','cache_position','position_ids','mask','rope_cos','rope_sin')}
    for layer in LAYERS:
        for name in ROUTE_NAMES:
            consumed=values[f'b{layer}_route_{name}']
            actual=values[f'b{layer}_actual_route_{name}']
            target=actual if route_source is None or name=='logits' else route_source[f'b{layer}_route_{name}']
            comparisons[f'b{layer}_delivered_{name}']=raw(consumed)==raw(target)
        for branch in ('attn','moe'):
            full=values[f'b{layer}_full_{branch}_output']
            comparisons[f'b{layer}_{branch}_full_final']=raw(full[:,-1:])==raw(values[f'b{layer}_{branch}_actual_final'])
            comparisons[f'b{layer}_{branch}_full_nonfinal']=hashlib.sha256(raw(full[:,:-1])).hexdigest()==info['tail_sites'][f'b{layer}_{branch}']['nonfinal_before_sha256']
    if entry['arm'] in CONTROLS:
        comparisons.update({'historical_'+name:raw(values[name])==raw(value) for name,value in source.items()})
        for layer in LAYERS:
            for name in ROUTE_NAMES:
                comparisons[f'historical_b{layer}_actual_{name}']=raw(values[f'b{layer}_actual_route_{name}'])==raw(source[f'b{layer}_route_{name}'])
        comparisons.update({name:info[name]==metadata[name] for name in ('tail_entries','tail_sites','tail_observations','residual_multipliers')})
    if not all(comparisons.values()):
        raise ValueError('Fixed source/control equality differs: '+','.join(k for k,v in comparisons.items() if not v))
    return comparisons


def run_calls(modules,plan,p,tail_module,suffix_module,legacy,identity,event,sample,guard,counts):
    (p.OUT/'calls').mkdir();contexts={c['id']:c for c in plan['contexts']};plan_sha=p.digest(p.OUT/'plan.json')
    for entry in plan['schedule']:
        if (entry['arm'] not in ARMS or entry['input_arm']!=INPUT_ARM[entry['arm']]
            or entry['route_arm']!=ROUTE_ARM[entry['arm']]):raise ValueError('Fixed arm mapping differs')
        if legacy.identity(modules)!=identity:raise ValueError('Precall frozen ownership differs')
        before=sample('before:'+entry['id']);guard(before)
        context=contexts[entry['context_id']];n=len(context['input_ids'])
        source,meta=load_source(p,entry,'input',n)
        route_source=None
        if entry['route_arm'] is not None:route_source,_=load_source(p,entry,'route',n)
        elif any(entry['route_'+field] is not None for field in ('source_id','call_path','metadata_path','call_sha256','metadata_sha256')):
            raise ValueError('Native arm has a replay source')
        if source['input_ids'].tolist()!=[context['input_ids']]:raise ValueError('Input IDs differ')
        device=next(modules['host'].parameters()).device;hidden=source['returned'].to(device);ids=source['input_ids'].to(device)
        if raw(hidden)!=raw(source['returned']) or raw(ids)!=raw(source['input_ids']):raise ValueError('Entry transfer changed bytes')
        def start():
            counts['suffix_attempts']+=1
            if counts['suffix_attempts']>576:raise ValueError('Suffix attempt ceiling')
            event('suffix_started',**entry)
        def component(name,phase,layer):event('component_'+phase,component=name,layer=layer,**entry)
        def expert(name,phase,layer):event('expert_component_'+phase,component=name,layer=layer,**entry)
        route_map=None if route_source is None else {l:{n:route_source[f'b{l}_route_{n}'] for n in ROUTE_NAMES} for l in LAYERS}
        policy=RoutePolicy(modules['host'],route_map,expert)
        values={'input_ids':ids.detach().cpu().clone(),'returned':hidden.detach().cpu().clone()}
        info={};failure=None;tail=None
        try:
            with policy:
                values,info,failure,tail=suffix_module.collect_suffix(modules['host'],hidden,ids,tail_module,start,component)
        except BaseException as exc:failure=exc
        finally:
            policy.close();values.update(policy.capture);info.update(policy.info())
        for key,value in info.get('component_counts',{}).items():counts[key]+=value
        for key,value in policy.counts.items():counts[key]+=value
        counts['router_native_returns']+=sum(policy.entries.get(f'b{l}_router',0) for l in LAYERS)
        counts['attention_native_returns']+=sum(policy.entries.get(f'b{l}_full_attn_output',0) for l in LAYERS)
        counts['moe_native_returns']+=sum(policy.entries.get(f'b{l}_full_moe_output',0) for l in LAYERS)
        counts['route_overrides']+=sum(x['overridden'] for x in policy.observations.values())
        counts['suffix_finished']+=int(info.get('suffix_completed',False))
        if info.get('suffix_completed'):
            try:event('suffix_finished',**entry)
            except BaseException as exc:
                if failure is None:failure=exc
        pointers=legacy.retain(p.OUT,'calls/'+entry['id'],values,dict(**entry,plan_sha256=plan_sha,**info))
        comparisons={};after=None
        try:
            if failure is not None:raise failure
            comparisons=validate(values,info,tail,policy,source,meta,route_source,entry)
            if legacy.identity(modules)!=identity:raise ValueError('Postcall hooks/ownership differ')
            after=sample('after:'+entry['id']);guard(after)
        except BaseException as exc:failure=exc
        row=dict(**entry,**info,**pointers,comparisons=comparisons,resources_before=before,resources_after=after,
            controls_pass=failure is None,error=None if failure is None else type(failure).__name__+': '+str(failure))
        legacy.append(p.OUT/'calls.jsonl',row);event('call_saved',**entry,controls_pass=row['controls_pass'])
        if failure is not None:raise failure


def main(deadline_utc):
    import protocol as p
    plan = p.verify(); plan_sha = p.digest(p.OUT / 'plan.json')
    started = p.read(p.OUT / 'STARTED.json')
    if (started['owner_pid'] != os.getppid() or started['plan_sha256'] != plan_sha
            or started['deadline_utc'] != deadline_utc):
        raise ValueError('Original owner binding differs')
    os.kill(os.getppid(), 0)
    if any((p.OUT / name).exists() for name in ('WORKER_STARTED.json', 'COLLECTED.json', 'STOPPED.json', 'COMPLETE.json')):
        raise ValueError('Worker already attempted or terminal')
    deadline = datetime.fromisoformat(deadline_utc)
    if deadline.tzinfo is None:
        raise ValueError('Deadline timezone absent')
    p.create(p.OUT / 'WORKER_STARTED.json', dict(at_utc=p.now(), worker_pid=os.getpid(),
        owner_pid=os.getppid(), plan_sha256=plan_sha, deadline_utc=deadline_utc))
    legacy = p.load_legacy('worker'); tail_module = p.load_tail('tail')
    suffix_module = p.load_census('suffix')
    modules = {}; before_identity = None; states_before = None; during = None
    counts = initial_counts(); active = None; resources = []; begin = time.monotonic()

    def event(name, **fields):
        nonlocal active
        if name == 'suffix_started':
            active = dict(fields)
        legacy.append(p.OUT / 'worker-events.jsonl', dict(at_utc=p.now(), event=name, **fields))

    def sample(stage):
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if platform.system() != 'Darwin':
            rss *= 1024
        value = dict(stage=stage, elapsed_seconds=time.monotonic() - begin,
            rss_high_water_bytes=int(rss), mps_driver_bytes=int(torch.mps.driver_allocated_memory()),
            archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file()))
        resources.append(value); event('resources', **value)
        return value

    def guard(value):
        if os.getppid() != started['owner_pid']:
            raise RuntimeError('Original owner disappeared')
        if datetime.now(timezone.utc) >= deadline:
            raise TimeoutError('Fixed owner deadline expired')
        for field, limit in (('rss_high_water_bytes', 'max_rss_bytes'),
                             ('mps_driver_bytes', 'max_mps_driver_bytes'), ('archive_bytes', 'max_archive_bytes')):
            if value[field] > p.SETTINGS[limit]:
                raise RuntimeError('Fixed resource ceiling exceeded: ' + field)

    def terminated(signum, frame):
        raise SystemExit(128 + signum)

    previous_signal = signal.signal(signal.SIGTERM, terminated)
    try:
        event('worker_started', worker_pid=os.getpid(), owner_pid=os.getppid(), deadline_utc=deadline_utc)
        import transformers
        from transformers import AutoModelForCausalLM
        from transformers.models.granitemoe import modeling_granitemoe
        if (platform.python_version(), torch.__version__, transformers.__version__, np.__version__) != ('3.12.14', '2.8.0', '4.56.2', '2.3.3'):
            raise ValueError('Pinned runtime differs')
        if not torch.backends.mps.is_available() or p.digest(inspect.getfile(modeling_granitemoe)) != plan['installed_model_source_sha256']:
            raise ValueError('Pinned native implementation differs')
        torch.set_num_threads(4)
        if torch.get_num_threads() != 4:
            raise ValueError('Thread count differs')
        guard(sample('before_loading'))
        cache_before = p.validate_model_files(plan)
        p.create(p.OUT / 'MODEL_CACHE_BEFORE.json', cache_before)
        torch.manual_seed(42)
        host = AutoModelForCausalLM.from_pretrained(p.ROOT / plan['model_path'], local_files_only=True,
            torch_dtype=torch.bfloat16, attn_implementation='eager').to('mps').eval()
        modules = dict(host=host)
        before_identity = legacy.identity(modules)
        if any(before_identity['hooks'].values()) or not all(all(v.values()) for v in before_identity['grad_none'].values()):
            raise ValueError('Preexisting hooks or gradients')
        if len(before_identity['requires_grad']['host']) != 218 or len(host.model.layers) != 24:
            raise ValueError('Native architecture differs')
        host.config.use_cache = False
        for parameter in host.parameters():
            parameter.requires_grad_(False)
        during = legacy.identity(modules)
        states_before = dict(host=legacy.state_hash(host))
        if len(states_before['host']) != 219 or states_before['host'] != plan['expected_host_state']:
            raise ValueError('Host state differs')
        p.create(p.OUT / 'RUNTIME.json', dict(plan_sha256=plan_sha, python=platform.python_version(),
            torch=torch.__version__, transformers=transformers.__version__, numpy=np.__version__,
            seed=42, threads=torch.get_num_threads(), device='mps', dtype='bfloat16',
            attention=host.config._attn_implementation, cache=host.config.use_cache,
            output_attentions=host.config.output_attentions, output_hidden_states=host.config.output_hidden_states,
            output_router_logits=host.config.output_router_logits, logits_scaling=host.config.logits_scaling,
            installed_model_source_sha256=p.digest(inspect.getfile(modeling_granitemoe))))
        if len(plan['contexts']) != 24 or len(plan['schedule']) != 576:
            raise ValueError('Fixed panel differs')
        guard(sample('loaded'))
        run_calls(modules, plan, p, tail_module, suffix_module, legacy, during, event, sample, guard, counts)
        if counts != expected_counts():
            raise ValueError('Complete operation counts differ')
        states_after = dict(host=legacy.state_hash(host))
        cache_after = p.validate_model_files(plan)
        p.create(p.OUT / 'MODEL_CACHE_AFTER.json', cache_after)
        after = legacy.restore(modules, before_identity)
        checks = dict(ownership_restored=after == before_identity, states_unchanged=states_before == states_after,
            cache_unchanged=cache_before == cache_after, exact_counts=counts == expected_counts())
        if not all(checks.values()):
            raise ValueError('Terminal frozen identity failure')
        guard(sample('complete'))
        p.create(p.OUT / 'WORKER_COMPLETE.json', dict(status='WORKER_COMPLETED', at_utc=p.now(),
            plan_sha256=plan_sha, counts=counts, states_before=states_before, states_after=states_after,
            identities_before=before_identity, identities_during=during, identities_after=after,
            checks=checks, resource_samples=resources, elapsed_seconds=time.monotonic() - begin,
            analytical_fits=0, backwards=0, optimizer_steps=0, provider_calls=0, generated_tokens=0))
        event('worker_completed', counts=counts)
        exclusions = set(plan['collection_exclusions'])
        inventory = {str(f.relative_to(p.OUT)): p.digest(f) for f in sorted(p.OUT.rglob('*'))
                     if f.is_file() and str(f.relative_to(p.OUT)) not in exclusions}
        guard(dict(resources[-1], archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file())))
        p.create(p.OUT / 'COLLECTED.json', dict(at_utc=p.now(), plan_sha256=plan_sha, counts=counts,
            all_controls_pass=True, artifact_sha256=inventory))
    except BaseException as exc:
        cleanup = None; cleanup_error = None; failure_states = None; failure_state_error = None
        if modules:
            try:
                failure_states = {k: legacy.state_hash(m) for k, m in modules.items()}
            except BaseException as err:
                failure_state_error = repr(err)
        if modules and before_identity is not None:
            try:
                cleanup = legacy.restore(modules, before_identity)
            except BaseException as err:
                cleanup_error = repr(err)
        reason = type(exc).__name__ + ': ' + str(exc)
        try:
            event('worker_failed', counts=counts, reason=reason)
        finally:
            p.create(p.OUT / 'WORKER_FAILURE.json', dict(at_utc=p.now(), plan_sha256=plan_sha,
                counts=counts, active_schedule_entry=active, reason=reason, identities_before=before_identity,
                cleanup_identities=cleanup, cleanup_error=cleanup_error, states_before=states_before,
                available_failure_states=failure_states, failure_state_error=failure_state_error, retry_allowed=False))
        raise
    finally:
        signal.signal(signal.SIGTERM, previous_signal)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--deadline-utc', required=True)
    main(parser.parse_args().deadline_utc)
