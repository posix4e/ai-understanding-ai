"""Launch only this new joint routing cross owner, exactly once."""
import sys
sys.dont_write_bytecode = True
import json
from protocol import ROOT,HERE,OUT,PREP,PYTHON,SETTINGS,verify,digest,load_legacy


def command():return [str(PYTHON),'-u',str(HERE/'owner.py'),'run']


def launch():
    verify()
    primitive=load_legacy('launch_primitive')
    return primitive._launch_owner(command(),ROOT,OUT,PREP,digest(OUT/'plan.json'),SETTINGS['timeout_seconds'])


if __name__=='__main__':
    print(json.dumps(launch(),indent=2),flush=True)
