"""Invented numerical examples and a complete serialized576-call fake archive.

No primary worker/router imports, no Torch, model, original arrays or fitting.
"""
import copy
import hashlib
import json
from fractions import Fraction
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import numpy as np
import audit as a


def route(length=2,written=False,tied=False):
    ids=np.tile(np.arange(8,16) if written else np.arange(8),(length,1)).astype(np.int64)
    logits=np.zeros((length,32),dtype=np.float32)
    for t in range(length):logits[t,ids[t]]=0 if tied else np.arange(8,0,-1)
    x=np.take_along_axis(logits,ids,axis=1).astype(np.float64);q=np.exp(x-x.max(axis=1,keepdims=True));q/=q.sum(axis=1,keepdims=True)
    g=a.bf16(q.astype(np.float32));order=np.argsort(ids.reshape(-1),kind='stable').astype(np.int64)
    sizes=np.bincount(ids.reshape(-1),minlength=32).astype(np.int64)
    return order,order//8,g.reshape(-1)[order],sizes,logits


def raw_array(value,dtype):
    if dtype=='torch.bfloat16':return (value.view(np.uint32)>>16).astype('<u2').view(np.uint8).reshape(-1)
    return np.frombuffer(value.tobytes(),dtype=np.uint8)


def write_bundle(path,arrays,metadata,shapes):
    path.parent.mkdir(parents=True,exist_ok=True);members={};meta=copy.deepcopy(metadata);meta['tensors']={}
    for name,(dtype,shape) in shapes.items():
        value=np.asarray(arrays[name]);raw=raw_array(value,dtype);rk,vk=name+'__raw_uint8',name+'__value'
        members[rk]=raw;members[vk]=value
        meta['tensors'][name]=dict(dtype=dtype,shape=list(shape),raw_key=rk,value_key=vk,raw_sha256=a.raw_hash(raw))
    np.savez(path,**members);path.with_suffix('.json').write_text(json.dumps(meta));return meta


def invented(entry,target=0,length=2):
    shape=a.call_shapes(length)
    v={n:np.zeros(s,dtype=np.int64 if d=='torch.int64' else np.float32) for n,(d,s) in shape.items()}
    v['input_ids']=np.array([[0,1]],dtype=np.int64);v['cache_position']=np.arange(length,dtype=np.int64);v['position_ids']=np.arange(length,dtype=np.int64)[None]
    minimum=np.array(0xff7f0000,dtype=np.uint32).view(np.float32)
    v['mask']=np.triu(np.full((length,length+1),minimum,dtype=np.float32),k=1)[None,None];v['rope_cos'].fill(1)
    written=entry['input_arm']=='W';donor_written=(entry['route_arm']=='W') if entry['route_arm'] is not None else written
    if written:v['returned'][:,-1:]=1
    residual=v['returned'].copy();sites={};obs={};routing={};actual=route(length,written);delivered=route(length,donor_written)
    def observation(name,value,full=False):
        v[name]=value.copy() if full else value[:,-1:].copy()
        obs[name]=dict(shape=[1,length,1024],dtype='torch.bfloat16',device='mps',nonfinal_sha256=hashlib.sha256(a.raw_bf16(value[:,:-1])).hexdigest())
    for l in a.LAYERS:
        for n,x in zip(a.ROUTE_NAMES,actual):v[f'b{l}_actual_route_{n}']=x.copy()
        for i,n in enumerate(a.ROUTE_NAMES):v[f'b{l}_route_{n}']=(actual[i] if n=='logits' else delivered[i]).copy()
        observation(f'b{l}_residual_input',residual)
        for branch,after in [('attn','after_attention'),('moe','after_moe')]:
            if branch=='moe':v[f'b{l}_moe_input']=residual.copy()
            value=(.5 if written else .25) if branch=='attn' else (.75 if donor_written else .5)
            full=np.full((1,length,1024),value,dtype=np.float32);v[f'b{l}_full_{branch}_output']=full
            for key in ('actual_final','returned_final'):v[f'b{l}_{branch}_{key}']=full[:,-1:].copy()
            nh=hashlib.sha256(a.raw_bf16(full[:,:-1])).hexdigest()
            aux=[None] if branch=='attn' else [dict(dtype='torch.float32',shape=[length,32],raw_sha256=a.raw_hash(actual[4]))]
            sites[f'b{l}_{branch}']=dict(shape=[1,length,1024],dtype='torch.bfloat16',device='mps',nonfinal_before_sha256=nh,
                nonfinal_after_sha256=nh,auxiliary_before=aux,auxiliary_after=copy.deepcopy(aux),auxiliary_objects_preserved=True,replayed=False)
            residual=a.bf16(residual+a.bf16(full*np.float32(.22)))
            observation(f'b{l}_{after}',residual)
        routing[f'b{l}']=dict(overridden=entry['route_arm'] is not None,live_auxiliary_object_preserved=True,
            actual_vs_delivered_first4_equal=written==donor_written)
    observation('final_residual',residual,True)
    # Hand-chosen four corners: BB=-1, WW=4, WB=2, BW=-2; all other labels0.
    J={'B':-1,'W':4,'SB':-1,'SW':4,'WB':2,'BW':-2}[entry['arm']]
    v['full_logits'][34+target]=J
    info=dict(suffix_completed=True,component_counts=a.component_counts(),tail_entries=dict.fromkeys([*a.SITES,*obs],1),
        tail_sites=sites,tail_observations=obs,residual_multipliers={str(l):.22 for l in a.LAYERS},
        routing_entries=dict.fromkeys([*[f'b{l}_router' for l in a.LAYERS],*[f'b{l}_full_{b}_output' for l in a.LAYERS for b in ('attn','moe')]],1),
        routing_counts=a.routing_counts(),routing_observations=routing)
    return v,info


def comparison_claims(v,info,entry):
    keys=['input_ids','returned','cache_position','position_ids','mask','rope_cos','rope_sin']
    keys += [f'b{l}_delivered_{n}' for l in a.LAYERS for n in a.ROUTE_NAMES]
    keys += [f'b{l}_{b}_full_{n}' for l in a.LAYERS for b in ('attn','moe') for n in ('final','nonfinal')]
    if entry['arm'] in a.CONTROLS:
        keys += ['historical_'+n for n in a.census_shapes(2)]
        keys += [f'historical_b{l}_actual_{n}' for l in a.LAYERS for n in a.ROUTE_NAMES]
        keys += ['tail_entries','tail_sites','tail_observations','residual_multipliers']
    return dict.fromkeys(keys,True)


def fixture(root):
    out=root/'new';out.mkdir();sha='f'*64
    contexts=[dict(id=f's{s}-a{x}',state=s,action=x,prompt=f"World state {s}. Actions {'XYZ'[x]}. Next state:",input_ids=[0,1]) for s in range(8) for x in range(3)]
    inventory={f'calls/{i:04d}.{ext}':'0'*64 for i in range(192) for ext in ('npz','json')}
    schedule=a.expected_schedule(contexts,inventory)
    worlds=[dict(id=f'dev{w:02d}',transitions=[[(s+x+w)%8 for s in range(8)] for x in range(3)]) for w in range(4)]
    plan=dict(contexts=contexts,worlds=worlds,label_ids=list(range(34,42)),schedule=schedule,
        expected_host_state=dict.fromkeys(a.expected_state_keys(),'c'*64),installed_model_source_sha256='d'*64)
    for e in schedule:
        if e['arm'] not in ('B','W'):continue
        c=contexts[int(e['index'])//24];target=worlds[int(e['world_id'][-2:])]['transitions'][c['action']][c['state']]
        values,info=invented(e,target);oldinfo={k:v for k,v in info.items() if not k.startswith('routing_')}
        oldmeta=dict(**{k:e[k] for k in ('arm','cell_id','context_id','world_id')},index=int(e['input_source_id']),id=e['input_source_id'],plan_sha256=a.ORIGINAL_SHA['plan.json'],**oldinfo)
        path=root/e['input_call_path'];write_bundle(path,values,oldmeta,a.census_shapes(2))
        inventory['calls/'+e['input_source_id']+'.npz']=a.digest(path);inventory['calls/'+e['input_source_id']+'.json']=a.digest(path.with_suffix('.json'))
    plan['schedule']=schedule=a.expected_schedule(contexts,inventory)
    events=[];samples=[]
    for kind,payload in a.expected_events(schedule):
        row=dict(event=kind,at_utc='2026-10-06T00:00:00+00:00')
        if kind=='resources':
            sample=dict(stage=payload,elapsed_seconds=len(samples)/1000,rss_high_water_bytes=10,mps_driver_bytes=10,archive_bytes=10)
            row.update(sample);samples.append(sample)
        elif isinstance(payload,dict):row.update(payload)
        if kind=='call_saved':row['controls_pass']=True
        if kind=='worker_completed':row['counts']=a.counts()
        events.append(row)
    lookup={r['stage']:r for r in samples};calls=[]
    for e in schedule:
        c=contexts[e['index']//24];target=worlds[int(e['world_id'][-2:])]['transitions'][c['action']][c['state']]
        v,info=invented(e,target);path=out/'calls'/f"{e['id']}.npz"
        write_bundle(path,v,dict(**e,plan_sha256=sha,**info),a.call_shapes(2))
        calls.append(dict(**e,**info,comparisons=comparison_claims(v,info,e),controls_pass=True,error=None,
            forward_path=str(path.relative_to(out)),forward_metadata_path=str(path.with_suffix('.json').relative_to(out)),
            forward_sha256=a.digest(path),forward_metadata_sha256=a.digest(path.with_suffix('.json')),
            resources_before=lookup['before:'+e['id']],resources_after=lookup['after:'+e['id']]))
    params=a.expected_state_keys()-{'lm_head.weight'}
    cfg=dict(hidden_size=1024,num_attention_heads=16,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,
        logits_scaling=6.0,use_cache=True,output_attentions=False,output_hidden_states=False,output_router_logits=False,residual_multiplier=.22)
    before=dict(requires_grad={'host':dict.fromkeys(params,True)},grad_none={'host':dict.fromkeys(params,True)},
        hooks={'host':{}},training={'host':{'':False}},forward_methods={'host':{'':[123,False]}},host_config=cfg)
    during=copy.deepcopy(before);during['requires_grad']['host']=dict.fromkeys(params,False);during['host_config']['use_cache']=False
    complete=dict(status='WORKER_COMPLETED',plan_sha256=sha,counts=a.counts(),states_before={'host':plan['expected_host_state']},states_after={'host':plan['expected_host_state']},
        identities_before=before,identities_during=during,identities_after=copy.deepcopy(before),
        checks=dict(ownership_restored=True,states_unchanged=True,cache_unchanged=True,exact_counts=True),resource_samples=samples,elapsed_seconds=1,
        analytical_fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)
    runtime=dict(plan_sha256=sha,**{k:a.SETTINGS[k] for k in ('python','torch','transformers','numpy')},seed=42,threads=4,device='mps',dtype='bfloat16',attention='eager',cache=False,
        output_attentions=False,output_hidden_states=False,output_router_logits=False,logits_scaling=6.0,installed_model_source_sha256=plan['installed_model_source_sha256'])
    for name,data in [('WORKER_COMPLETE.json',complete),('RUNTIME.json',runtime)]: (out/name).write_text(json.dumps(data))
    (out/'calls.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in calls));(out/'worker-events.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in events))
    return out,plan,sha,calls


class MathTests(unittest.TestCase):
    def test_exact_j_all_seven_and_ties(self):
        x=np.arange(8,dtype=np.float32);r=a.score(x,7)
        self.assertEqual(r['J']['fraction'],'4');self.assertEqual(r['best_other_margin']['fraction'],'1');self.assertEqual(len(r['target_minus_other']),7)
        tie=a.score(np.ones(8,dtype=np.float32),3);self.assertIsNone(tie['winner']);self.assertTrue(tie['tie']);self.assertFalse(tie['correct'])
    def test_hand_calculated_factorial_and_zero_interaction_not_zero_effect(self):
        r=a.contrasts(dict(SB=Fraction(-1),SW=Fraction(4),WB=Fraction(2),BW=Fraction(-2)))
        self.assertEqual(r,dict(route_under_W=2,route_under_B=-1,input_under_B_routes=3,input_under_W_routes=6,total=5,interaction=3))
        additive=a.contrasts(dict(SB=Fraction(0),WB=Fraction(2),BW=Fraction(3),SW=Fraction(5)))
        self.assertEqual(additive['interaction'],0);self.assertEqual(additive['route_under_W'],3)
    def test_pooled_zero_preserves_opposite_signs(self):
        r=a.fraction_summary([Fraction(1,7),Fraction(-1,7)])
        self.assertEqual(r['mean']['fraction'],'0');self.assertEqual((r['positive'],r['negative'],r['zero']),(1,1,0))
    def test_cross_donor_valid_even_not_live_topk(self):
        e=dict(arm='WB',input_arm='W',route_arm='B');v,m=invented(e);donor,_=invented(dict(arm='B',input_arm='B',route_arm=None))
        rows=a.check_routing(v,m,donor,e);self.assertTrue(all(x['delivered_first4_differs'] for x in rows))
        with self.assertRaises(a.AuditError):a.canonical_route(*(v['b20_route_'+n] for n in a.ROUTE_NAMES))
    def test_wrong_donor_and_live_logit_mutations(self):
        e=dict(arm='WB',input_arm='W',route_arm='B');v,m=invented(e);donor,_=invented(dict(arm='B',input_arm='B',route_arm=None))
        v['b20_route_gates']=v['b20_route_gates'][::-1].copy()
        with self.assertRaises(a.AuditError):a.check_routing(v,m,donor,e)
        v,m=invented(e);v['b20_actual_route_logits'][0,0]=99
        with self.assertRaises(a.AuditError):a.check_routing(v,m,donor,e)
    def test_group_permutation_not_slot_identity(self):
        native=a.canonical_route(*route(written=True));self.assertEqual(native['rows'][0]['selected_ids'],list(range(8,16)))
        parts=list(route());parts[0][0]=parts[0][1]
        with self.assertRaises(a.AuditError):a.canonical_route(*parts)
    def test_cutoff_ties_remain_valid(self):
        r=a.canonical_route(*route(tied=True));self.assertTrue(all(not x['historical_support_unique'] for x in r['rows']))
    def test_full_residual_chain_and_nonfinal_mutation(self):
        v,m=invented(dict(arm='W',input_arm='W',route_arm=None));a.check_full_tail(v,m)
        v['b22_full_moe_output'][0,0,1]+=1
        with self.assertRaises(a.AuditError):a.check_full_tail(v,m)
    def test_final_displacement_and_auxiliary_mutations(self):
        v,m=invented(dict(arm='W',input_arm='W',route_arm=None));v['returned'][:,-1:]=0
        with self.assertRaises(a.AuditError):a.check_full_tail(v,m)
        v,m=invented(dict(arm='W',input_arm='W',route_arm=None));m['tail_sites']['b20_moe']['auxiliary_objects_preserved']=False
        with self.assertRaises(a.AuditError):a.check_full_tail(v,m)
    def test_drift_signed_zero_counts_as_bit_change_not_numeric(self):
        x=np.zeros((1,2,2),np.float32);y=x.copy();y[0,0,0]=-0.
        d=a.tensor_drift(x,y)['nonfinal'];self.assertEqual(d['raw_word_changes'],1);self.assertEqual(d['numeric_changes'],0);self.assertEqual(d['L2'],0)
    def test_raw_width_nonfinite_and_no_fallback(self):
        with self.assertRaises(a.AuditError):a.decode(np.zeros(2,dtype=np.uint8),'torch.float32',(1,))
        with self.assertRaises(a.AuditError):a.score(np.full(8,np.nan,dtype=np.float32),0)
        with self.assertRaises(a.AuditError):a.score(np.zeros(8,np.float32),True)
    def test_partial_publication_retained(self):
        with TemporaryDirectory() as d:
            p=Path(d);(p/'REPORT.json').write_bytes(b'{partial');r=a.preserve_invalid_publications(p)
            self.assertEqual((p/'INVALID_REPORT.json').read_bytes(),b'{partial');self.assertEqual(r['REPORT.json']['sha256'],a.digest(p/'INVALID_REPORT.json'))


class ArchiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=TemporaryDirectory();cls.root=Path(cls.tmp.name);cls.out,cls.plan,cls.sha,cls.calls=fixture(cls.root)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def test_complete576_raw_archive_then_exact_effects(self):
        report=a.audit_records(self.out,self.plan,self.sha,root=self.root)
        self.assertTrue(report['implementation_pass']);self.assertEqual(len(report['rows']),96)
        self.assertEqual(report['controls']['native_exact'],192);self.assertEqual(report['controls']['self_sham_exact'],192)
        self.assertEqual(report['pooled']['effects']['interaction']['J']['mean']['fraction'],'3')
        self.assertEqual(report['pooled']['arms']['WB']['correct'],96);self.assertEqual(report['pooled']['arms']['BW']['ties'],96)
        self.assertEqual(report['resources']['samples'],1155);self.assertEqual(report['counts']['input_linear_finished'],2304)
        self.assertTrue(report['rows'][0]['drift']['WB']['tensors']['b20_full_moe_output']['nonfinal']['numeric_changes']>0)
    def test_missing_calls_closes_before_decode_and_score(self):
        with patch.object(a,'jsonl',return_value=self.calls[:-1]),patch.object(a,'load_call') as load,patch.object(a,'score') as score:
            with self.assertRaises(a.AuditError):a.audit_records(self.out,self.plan,self.sha,root=self.root)
            load.assert_not_called();score.assert_not_called()
    def test_last_self_sham_failure_prevents_all_scores(self):
        original=a.load_call
        def load(*args,**kwargs):
            if args[2]['index']==573:raise a.AuditError('invented final SW mismatch')
            return original(*args,**kwargs)
        with patch.object(a,'load_call',side_effect=load),patch.object(a,'cell_report') as score:
            with self.assertRaises(a.AuditError):a.audit_records(self.out,self.plan,self.sha,root=self.root)
            score.assert_not_called()
    def test_changed_source_hash(self):
        entry=copy.deepcopy(self.plan['schedule'][0]);row=copy.deepcopy(self.calls[0]);entry['input_call_sha256']=row['input_call_sha256']='a'*64
        with self.assertRaises(a.AuditError):a.load_call(self.out,row,entry,self.plan['contexts'][0],self.sha,self.root)
    def test_wrong_dtype_rejected(self):
        row=copy.deepcopy(self.calls[0]);p=self.out/row['forward_metadata_path'];old=p.read_bytes();m=json.loads(old)
        try:
            m['tensors']['returned']['dtype']='torch.float32';p.write_text(json.dumps(m));row['forward_metadata_sha256']=a.digest(p)
            with self.assertRaises(a.AuditError):a.load_call(self.out,row,self.plan['schedule'][0],self.plan['contexts'][0],self.sha,self.root)
        finally:p.write_bytes(old)
    def test_parameter_restoration_and_counts(self):
        c=a.read(self.out/'WORKER_COMPLETE.json');c['identities_after']['requires_grad']['host']['model.norm.weight']=False
        with self.assertRaises(a.AuditError):a.validate_ownership(c,self.plan)
        c=a.read(self.out/'WORKER_COMPLETE.json');c['counts']['input_linear_finished']=2303
        with self.assertRaises(a.AuditError):a.validate_ownership(c,self.plan)
    def test_expert_event_and_resource_rejected(self):
        c=a.read(self.out/'WORKER_COMPLETE.json');events=a.jsonl(self.out/'worker-events.jsonl');events[0]['at_utc']='2026-10-07T00:00:00+00:00'
        with self.assertRaises(a.AuditError):a.validate_events(events,self.plan['schedule'],c)
        events=a.jsonl(self.out/'worker-events.jsonl');events[1]['mps_driver_bytes']=a.MEMORY_LIMIT+1
        with self.assertRaises(a.AuditError):a.validate_events(events,self.plan['schedule'],c)
    def test_numeric_scale_bool_rejected(self):
        c=a.read(self.out/'WORKER_COMPLETE.json');a.validate_ownership(c,self.plan)
        for k in ('before','during','after'):c['identities_'+k]['host_config']['logits_scaling']=True
        with self.assertRaises(a.AuditError):a.validate_ownership(c,self.plan)

if __name__=='__main__':unittest.main()
