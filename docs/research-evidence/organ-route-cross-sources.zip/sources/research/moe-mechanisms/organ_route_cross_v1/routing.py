"""Exact recorded dispatch policy; native router and live experts still execute."""
import hashlib
import torch

LAYERS = (20, 21, 22, 23)
ROUTE_NAMES = ('order', 'tokens', 'gates', 'sizes', 'logits')
EXPERT_COMPONENTS = ('input_linear', 'output_linear')


def raw(value):
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def expert_counts():
    return {n+'_'+p: 0 for n in EXPERT_COMPONENTS for p in ('attempts','finished')}


def validate_route(route, length, device):
    if not isinstance(route, tuple) or len(route) != 5:
        raise ValueError('Router must return five members')
    order, tokens, gates, sizes, logits = route
    if (order.dtype != torch.int64 or tokens.dtype != torch.int64 or gates.dtype != torch.bfloat16
        or logits.dtype != torch.float32 or tuple(order.shape) != (length*8,)
        or tuple(tokens.shape) != (length*8,) or tuple(gates.shape) != (length*8,)
        or tuple(logits.shape) != (length,32) or not isinstance(sizes,list) or len(sizes) != 32
        or any(type(x) is not int or x < 0 for x in sizes) or sum(sizes) != length*8
        or any(v.device != device for v in (order,tokens,gates,logits))):
        raise ValueError('Router type/shape/device differs')
    if (sorted(order.detach().cpu().tolist()) != list(range(length*8))
        or tokens.detach().cpu().tolist() != (order//8).detach().cpu().tolist()
        or not bool(torch.isfinite(gates).all()) or not bool(torch.isfinite(logits).all())
        or not bool(((gates >= 0) & (gates <= 1)).all())):
        raise ValueError('Router permutation/gate structure differs')
    grouped = [e for e,count in enumerate(sizes) for _ in range(count)]
    slots = [None]*(length*8)
    for position, expert in zip(order.detach().cpu().tolist(),grouped):
        slots[position] = expert
    if any(len(set(slots[i:i+8])) != 8 for i in range(0,len(slots),8)):
        raise ValueError('Duplicate token/expert dispatch')


class RoutePolicy:
    """Install before frozen suffix observers, so they observe the delivered tuple."""
    def __init__(self, model, source=None, event=lambda name,phase,layer: None):
        if source is not None and set(source) != set(LAYERS):
            raise ValueError('Fixed four-layer route source required')
        self.model, self.source, self.event = model, source, event
        self.capture = {}; self.entries = {}; self.observations = {}
        self.counts = expert_counts(); self.handles = []; self.used = False

    def once(self, name):
        self.entries[name] = self.entries.get(name,0)+1
        if self.entries[name] != 1:
            raise ValueError('Repeated routing capture '+name)

    def route(self, layer, args, output):
        self.once(f'b{layer}_router')
        # Retain every available native return before checking or substituting it.
        if isinstance(output, tuple):
            for name, value in zip(ROUTE_NAMES, output):
                if name == 'sizes' and isinstance(value,list):
                    value = torch.tensor(value,dtype=torch.int64)
                if isinstance(value,torch.Tensor):
                    self.capture[f'b{layer}_actual_route_{name}'] = value.detach().cpu().clone()
        length = args[0].shape[0]
        validate_route(output,length,args[0].device)
        delivered = output
        if self.source is not None:
            saved = self.source[layer]
            first = tuple(saved[name].to(device=args[0].device).clone() for name in ROUTE_NAMES[:3])
            sizes = saved['sizes'].detach().cpu().tolist()
            delivered = (*first,sizes,output[4])
            validate_route(delivered,length,args[0].device)
            if any(raw(delivered[i]) != raw(saved[name]) for i,name in enumerate(ROUTE_NAMES[:3])):
                raise ValueError('Replay route device transfer changed bytes')
            if sizes != saved['sizes'].tolist():
                raise ValueError('Replay expert sizes changed')
        self.observations[f'b{layer}'] = dict(overridden=self.source is not None,
            live_auxiliary_object_preserved=delivered[4] is output[4],
            actual_vs_delivered_first4_equal=all(raw(a)==raw(b) for a,b in zip(output[:3],delivered[:3]))
                and output[3] == delivered[3])
        return delivered if self.source is not None else None

    def branch(self, layer, name, output):
        key=f'b{layer}_full_{name}_output'; self.once(key)
        if isinstance(output,tuple) and output and isinstance(output[0],torch.Tensor):
            self.capture[key]=output[0].detach().cpu().clone()
        # Read-only; the frozen tail observer validates the native tuple contract.

    def expert(self, name, phase, layer):
        key=name+'_'+('attempts' if phase=='started' else 'finished')
        self.counts[key]+=1
        self.event(name,phase,layer)

    def __enter__(self):
        if self.used:
            raise ValueError('Route policy is single-use')
        self.used=True
        try:
            for layer in LAYERS:
                block=self.model.model.layers[layer]; moe=block.block_sparse_moe
                self.handles.append(moe.router.register_forward_hook(
                    lambda m,a,o,l=layer:self.route(l,a,o)))
                for name, module in (('attn',block.self_attn),('moe',moe)):
                    self.handles.append(module.register_forward_hook(
                        lambda m,a,o,l=layer,n=name:self.branch(l,n,o)))
                for name in EXPERT_COMPONENTS:
                    module=getattr(moe,name)
                    self.handles.append(module.register_forward_pre_hook(
                        lambda m,a,l=layer,n=name:self.expert(n,'started',l)))
                    self.handles.append(module.register_forward_hook(
                        lambda m,a,o,l=layer,n=name:self.expert(n,'finished',l)))
            return self
        except BaseException:
            self.close(); raise

    def close(self):
        for handle in reversed(self.handles):
            handle.remove()
        self.handles=[]

    def __exit__(self,*exc):
        self.close(); return False

    def info(self):
        return dict(routing_entries=self.entries,routing_counts=self.counts,routing_observations=self.observations)

    def validate(self,length):
        names={f'b{l}_router' for l in LAYERS}|{f'b{l}_full_{n}_output' for l in LAYERS for n in ('attn','moe')}
        if set(self.entries)!=names or any(x!=1 for x in self.entries.values()):
            raise ValueError('Routing/branch capture inventory differs')
        if self.counts != {k:4 for k in expert_counts()}:
            raise ValueError('Fresh grouped expert execution count differs')
        if set(self.observations)!={f'b{l}' for l in LAYERS} or not all(x['live_auxiliary_object_preserved'] for x in self.observations.values()):
            raise ValueError('Live router auxiliary was changed')
        for name,value in self.capture.items():
            if not bool(torch.isfinite(value).all()):
                raise ValueError('Nonfinite routing capture '+name)
            if '_full_' in name and (value.dtype!=torch.bfloat16 or tuple(value.shape)!=(1,length,1024)):
                raise ValueError('Full branch shape/dtype differs')
