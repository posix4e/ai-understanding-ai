"""One claimed local execution, with a fixed wall/memory/archive boundary."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime,timedelta,timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import time
from protocol import ROOT,HERE,OUT,PREP,PYTHON,SETTINGS,verify,create,read,digest,now


def append(path, value):
    with path.open('a') as f:
        f.write(json.dumps(value,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())


def group_members(pgid):
    result=subprocess.run(['/bin/ps','-axo','pid=,pgid='],check=True,capture_output=True,text=True,timeout=5)
    return [pid for pid,group in (map(int,line.split()) for line in result.stdout.splitlines() if line.strip())
            if group==pgid]


def terminate_and_reap(child):
    if child is None:return
    # An exited group leader does not prove its descendants have exited.
    for sig in (signal.SIGTERM,signal.SIGKILL):
        child.poll()
        if not group_members(child.pid):break
        try:os.killpg(child.pid,sig)
        except ProcessLookupError:pass
        limit=time.monotonic()+5
        while time.monotonic()<limit:
            child.poll()
            if not group_members(child.pid):break
            time.sleep(.05)
    if child.poll() is None:child.wait(timeout=5)
    if group_members(child.pid):raise RuntimeError('Child process group did not disappear')


def validate_owner_receipt(claim,receipt,command,plan_sha,pid):
    if (claim.get('command')!=command or receipt.get('command')!=command or
        claim.get('plan_sha256')!=plan_sha or receipt.get('plan_sha256')!=plan_sha or
        receipt.get('owner_pid')!=pid or not claim.get('nonce') or receipt.get('nonce')!=claim['nonce']):
        raise ValueError('Not the originally claimed owner')


def monitor(child,stage,start):
    peak_rss=0;peak_archive=0;samples=0
    while True:
        elapsed=time.monotonic()-start
        if elapsed>=SETTINGS['timeout_seconds']:raise TimeoutError('Fixed total deadline exceeded during '+stage)
        census=subprocess.run(['/bin/ps','-axo','pid=,ppid=,rss='],check=True,
                              capture_output=True,text=True,timeout=5)
        processes=[tuple(map(int,line.split())) for line in census.stdout.splitlines() if line.strip()]
        members={child.pid}
        while True:
            expanded=members|{pid for pid,parent,_ in processes if parent in members}
            if expanded==members:break
            members=expanded
        rss=sum(kib*1024 for pid,_,kib in processes if pid in members)
        archive=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
        peak_rss=max(peak_rss,rss);peak_archive=max(peak_archive,archive);samples+=1
        append(OUT/'resource-monitor.jsonl',dict(at_utc=now(),stage=stage,pid=child.pid,
            elapsed_seconds=elapsed,child_tree_rss_bytes=rss,archive_bytes=archive))
        if rss>SETTINGS['max_rss_bytes']:raise MemoryError('Child tree RSS ceiling exceeded')
        # Reserve one MiB for the last monitor sample and closure/failure receipts.
        if archive+1024**2>SETTINGS['max_archive_bytes']:raise RuntimeError('Archive ceiling/reserve exceeded')
        code=child.poll()
        if code is not None:return dict(returncode=code,samples=samples,peak_child_tree_rss_bytes=peak_rss,
                                       peak_archive_bytes=peak_archive)
        time.sleep(.25)


def run():
    verify()
    if Path(sys.executable).resolve()!=PYTHON.resolve():raise ValueError('Pinned Python required')
    if any((OUT/n).exists() for n in ('STARTED.json','COMPLETE.json','STOPPED.json','COLLECTED.json')):
        raise ValueError('Already attempted; never run again')
    claim=read(PREP/'LAUNCH_REQUESTED.json');command=[str(PYTHON),'-u',str(HERE/'owner.py'),'run']
    receipt_deadline=time.monotonic()+2
    while True:
        try:receipt=read(PREP/'LAUNCH_PID.json');break
        except (FileNotFoundError,json.JSONDecodeError):
            if time.monotonic()>=receipt_deadline:raise ValueError('Launch receipt unavailable')
            time.sleep(.02)
    plan_sha=digest(OUT/'plan.json')
    validate_owner_receipt(claim,receipt,command,plan_sha,os.getpid())
    if os.getpgid(0)!=os.getpid() or os.getsid(0)!=os.getpid():raise ValueError('Owner requires claimed detached session')
    started=datetime.now(timezone.utc);deadline=started+timedelta(seconds=SETTINGS['timeout_seconds'])
    start=time.monotonic();child=None;stage=None;resources={}
    create(OUT/'STARTED.json',dict(at_utc=started.isoformat(),deadline_utc=deadline.isoformat(),
        owner_pid=os.getpid(),plan_sha256=plan_sha,launch_nonce=claim['nonce']))
    def interrupt(signum,frame):raise SystemExit(128+signum)
    handlers={s:signal.signal(s,interrupt) for s in (signal.SIGTERM,signal.SIGINT)}
    def event(kind,**fields):append(OUT/'owner-events.jsonl',dict(event=kind,at_utc=now(),**fields))
    try:
        commands=[('worker',[str(PYTHON),str(HERE/'worker.py'),'--deadline-utc',deadline.isoformat()]),
                  ('independent_audit',[str(PYTHON),str(HERE/'audit.py'),'--directory',str(OUT)])]
        for stage,command in commands:
            if time.monotonic()-start>=SETTINGS['timeout_seconds']:raise TimeoutError('Deadline before '+stage)
            with (OUT/f'{stage}.log').open('x') as log:
                child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,
                                       stdin=subprocess.DEVNULL,start_new_session=True)
                event('started',stage=stage,pid=child.pid,command=command)
                resources[stage]=monitor(child,stage,start)
            leftovers=group_members(child.pid)
            if leftovers:
                terminate_and_reap(child)
                raise RuntimeError('Descendants survived stage leader; preserved as execution failure')
            resources[stage]['process_group_absent']=True
            event('exit',stage=stage,pid=child.pid,**resources[stage])
            if resources[stage]['returncode']!=0:raise RuntimeError(stage+' failed; preserve raw record')
            verify()
        audit=read(OUT/'INDEPENDENT_AUDIT.json');report=read(OUT/'REPORT.json')
        if (audit.get('status')!='PASS' or audit.get('implementation_pass') is not True or
            audit.get('plan_sha256')!=plan_sha or audit.get('report_sha256')!=digest(OUT/'REPORT.json') or
            audit.get('audit_code_sha256')!=digest(HERE/'audit.py') or report.get('implementation_pass') is not True or
            audit.get('baseline_replication_pass') is not True or
            report.get('baseline_replication_pass') is not True):
            raise ValueError('Independent audit binding/admission differs')
        if time.monotonic()-start>=SETTINGS['timeout_seconds']:raise TimeoutError('Deadline during closure')
        create(OUT/'COMPLETE.json',dict(at_utc=now(),status='ROUTE_CROSS_COMPLETE',
            plan_sha256=plan_sha,report_sha256=digest(OUT/'REPORT.json'),
            independent_audit_sha256=digest(OUT/'INDEPENDENT_AUDIT.json'),
            baseline_replication_pass=audit['baseline_replication_pass'],implementation_pass=True,
            elapsed_seconds=time.monotonic()-start,full_host_forwards=0,suffix_executions=576,decoder_block_executions=2304,organ_forwards=0,
            reader_applications=0,writer_forwards=0,backwards=0,analytical_fits=0,
            optimizer_steps=0,provider_calls=0,generated_tokens=0,resources=resources,
            final_log_sha256={n:digest(OUT/n) for n in
                ('owner-events.jsonl','resource-monitor.jsonl','worker.log','independent_audit.log')},
            scientific_confirmation=False,novelty_established=False,automatic_next_study=False))
        # Check after the durable receipt; never leave a success marker for an
        # over-deadline or oversized closure. Preserve any rejected marker.
        archive=sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
        if time.monotonic()-start>=SETTINGS['timeout_seconds'] or archive>SETTINGS['max_archive_bytes']:
            os.rename(OUT/'COMPLETE.json',OUT/'INVALID_COMPLETE_BOUNDARY.json')
            raise RuntimeError('Durable closure exceeded deadline/archive boundary')
        print(json.dumps(read(OUT/'COMPLETE.json')),flush=True)
    except BaseException as exc:
        cleanup=None
        try:terminate_and_reap(child)
        except BaseException as err:cleanup=repr(err)
        if (OUT/'COMPLETE.json').exists():
            os.rename(OUT/'COMPLETE.json',OUT/'ABORTED_COMPLETE.json')
        if not (OUT/'STOPPED.json').exists():
            create(OUT/'STOPPED.json',dict(at_utc=now(),status='ROUTE_CROSS_STOPPED',
                reason=type(exc).__name__+': '+str(exc),plan_sha256=plan_sha,stage=stage,
                elapsed_seconds=time.monotonic()-start,child_pid=child.pid if child else None,
                child_returncode=child.poll() if child else None,cleanup_error=cleanup,
                rerun_allowed=False,partial_scientific_interpretation_allowed=False))
        raise
    finally:
        for sig,handler in handlers.items():signal.signal(sig,handler)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['run']);p.parse_args();run()
