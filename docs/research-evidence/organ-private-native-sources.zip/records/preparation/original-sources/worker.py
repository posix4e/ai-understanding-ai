"""One native collection, no scorer, hook or transfer fit. Import-safe."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
from pathlib import Path
import copy
import hashlib
import importlib.metadata
import json
import os
import platform
import resource
import signal
import threading
import time
import protocol as p

HOOKS=('_forward_pre_hooks','_forward_hooks','_backward_pre_hooks','_backward_hooks')


def owner_guard(start,plan_sha,deadline):
    p.require(start['plan_sha256']==plan_sha and start['owner_pid']==os.getppid() and start['deadline_utc']==deadline,
              'Not the original owner/deadline')
    os.kill(start['owner_pid'],0)
    p.require(datetime.now(timezone.utc)<datetime.fromisoformat(deadline), 'Worker deadline expired')
    p.require(not any((p.OUT/n).exists() for n in ('STOPPED.json','COMPLETE.json')), 'Owner terminal already exists')


def raw_bytes(value,torch):
    return value.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()


def state_hash(model,torch):
    return {n:hashlib.sha256(raw_bytes(v,torch)).hexdigest() for n,v in model.state_dict().items()}


def identity(model):
    return dict(training={n:m.training for n,m in model.named_modules()},
        requires_grad={n:v.requires_grad for n,v in model.named_parameters()},
        parameters={n:[id(v),v.data_ptr(),str(v.device),str(v.dtype)] for n,v in model.named_parameters()},
        buffers={n:[id(v),v.data_ptr(),str(v.device),str(v.dtype)] for n,v in model.named_buffers()},
        grads_none={n:v.grad is None for n,v in model.named_parameters()},
        hooks={n:{k:list(getattr(m,k,{})) for k in HOOKS if getattr(m,k,{})} for n,m in model.named_modules()
               if any(getattr(m,k,{}) for k in HOOKS)},
        forward_methods={n:['forward' in m.__dict__,id(getattr(m.forward,'__func__',m.forward))] for n,m in model.named_modules()},
        config=copy.deepcopy(model.config.to_dict()),generation_config=copy.deepcopy(model.generation_config.to_dict()))


def restore(model,before):
    for n,v in model.named_parameters():v.requires_grad_(before['requires_grad'][n])
    for n,m in model.named_modules():m.training=before['training'][n]
    model.config.use_cache=before['config']['use_cache']
    return identity(model)


def retain(directory,stem,values,metadata,torch,np):
    arrays={}; descriptions={}
    for name,value in values.items():
        cpu=value.detach().cpu().contiguous()
        raw=cpu.reshape(-1).view(torch.uint8).numpy().copy()
        readable=(cpu.float() if cpu.dtype==torch.bfloat16 else cpu).numpy().copy()
        rk,vk=name+'__raw_uint8',name+'__value';arrays[rk]=raw;arrays[vk]=readable
        descriptions[name]=dict(dtype=str(cpu.dtype),shape=list(cpu.shape),raw_key=rk,value_key=vk,
            raw_sha256=hashlib.sha256(raw.tobytes()).hexdigest(),finite=bool(np.isfinite(readable).all()))
    file,side=directory/(stem+'.npz'),directory/(stem+'.json')
    with file.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
    p.create(side,dict(metadata,tensors=descriptions))
    return dict(forward_path=str(file.relative_to(p.OUT)),forward_sha256=p.digest(file),
                forward_metadata_path=str(side.relative_to(p.OUT)),forward_metadata_sha256=p.digest(side))


def run_calls(cases,forward,retain_call,validate,event,guard,counts,last):
    """Injectable sequencing; returned data are retained even if return journaling fails."""
    rows=[]
    for case in cases:
        guard('before_forward',case);values={};error=None;returned=False;artifact={}
        counts['forward_attempts']+=1;event('forward_started',id=case['id'],index=case['index'])
        try:
            values=forward(case);returned=True;counts['forward_finished']+=1
            last.clear();last.update(values)
            try:event('forward_returned',id=case['id'],index=case['index'])
            except BaseException as exc:error=exc
        except BaseException as exc:error=exc
        try:
            artifact=retain_call(case,values)
            if error is None:validate(case,values)
        except BaseException as exc:
            if error is None:error=exc
        row={k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
        row.update(artifact,forward_completed=returned,controls_pass=error is None,error=None if error is None else repr(error))
        p.append(p.OUT/'calls.jsonl',row);counts['calls_saved']+=1
        event('call_saved',id=case['id'],index=case['index'],controls_pass=row['controls_pass'])
        rows.append(row)
        if error is not None:raise error
        guard('after_forward',case)
    return rows


def main(deadline_utc):
    plan,plan_sha=p.verify();start=p.read(p.OUT/'STARTED.json');owner_guard(start,plan_sha,deadline_utc)
    p.require(Path(sys.executable).resolve()==p.PYTHON.resolve(),'Pinned Python required')
    p.require(not any((p.OUT/n).exists() for n in ('WORKER_STARTED.json','WORKER_COMPLETE.json','WORKER_FAILURE.json','calls.jsonl')), 'Worker already attempted')
    p.create(p.OUT/'WORKER_STARTED.json',dict(at_utc=p.now(),worker_pid=os.getpid(),owner_pid=os.getppid(),plan_sha256=plan_sha,deadline_utc=deadline_utc))
    stop_thread=threading.Event();model=None;before=None;torch=None;last={};samples=[];counts=dict(
        model_load_attempts=0,model_load_finished=0,forward_attempts=0,forward_finished=0,calls_saved=0,
        hooks=0,fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)
    def event(kind,**fields):p.append(p.OUT/'worker-events.jsonl',dict(event=kind,at_utc=p.now(),**fields))
    def watchdog():
        while not stop_thread.wait(.25):
            try:owner_guard(start,plan_sha,deadline_utc)
            except BaseException:
                try:p.create(p.OUT/'LIFETIME_STOP.json',dict(at_utc=p.now(),reason='Owner/deadline watchdog failed'))
                finally:os.kill(os.getpid(),signal.SIGTERM)
                return
    thread=threading.Thread(target=watchdog,daemon=True);thread.start()
    def guard(stage,case=None):
        owner_guard(start,plan_sha,deadline_utc)
        sample=dict(at_utc=p.now(),stage=stage,call_id=None if case is None else case['id'],
            elapsed_seconds=(datetime.now(timezone.utc)-datetime.fromisoformat(start['at_utc'])).total_seconds(),
            rss_high_water_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            mps_driver_bytes=torch.mps.driver_allocated_memory(),mps_allocated_bytes=torch.mps.current_allocated_memory(),
            archive_bytes=sum(f.stat().st_size for f in p.OUT.rglob('*') if f.is_file()))
        p.append(p.OUT/'worker-resources.jsonl',sample);samples.append(sample)
        p.require(sample['rss_high_water_bytes']<=p.SETTINGS['max_rss_bytes'] and
                  sample['mps_driver_bytes']<=p.SETTINGS['max_mps_bytes'] and
                  sample['archive_bytes']+1024**2<=p.SETTINGS['max_archive_bytes'],'Worker resource ceiling exceeded')
    try:
        event('worker_started')
        import numpy as np
        import torch
        from transformers import AutoModelForCausalLM
        versions=dict(python=platform.python_version(),**{n:importlib.metadata.version(n) for n in ('torch','transformers','numpy','tokenizers')})
        p.require(versions==p.VERSIONS and torch.backends.mps.is_available(),'Pinned runtime unavailable')
        torch.set_num_threads(4);torch.manual_seed(42)
        cache_before=p.validate_model_files(plan);p.create(p.OUT/'MODEL_CACHE_BEFORE.json',cache_before)
        guard('before_load');counts['model_load_attempts']+=1;event('model_load_started')
        model=AutoModelForCausalLM.from_pretrained(str(p.ROOT/plan['model_path']),local_files_only=True,trust_remote_code=False,
            dtype=torch.bfloat16,attn_implementation='eager').to('mps')
        counts['model_load_finished']+=1;event('model_load_finished');before=identity(model)
        p.create(p.OUT/'IDENTITY_BEFORE.json',before)
        p.require(not before['hooks'] and all(v[2] in ('mps','mps:0') and v[3]=='torch.bfloat16' for v in before['parameters'].values()), 'Non-native model placement/hooks')
        states_before=state_hash(model,torch);p.create(p.OUT/'STATE_BEFORE.json',states_before)
        p.require(states_before==plan['expected_host_state'] and len(states_before)==219,'Loaded state differs from pinned state')
        model.eval();model.requires_grad_(False);model.config.use_cache=False
        configured=identity(model);p.create(p.OUT/'IDENTITY_CONFIGURED.json',configured)
        p.create(p.OUT/'RUNTIME.json',dict(versions=versions,device='mps',dtype='torch.bfloat16',threads=torch.get_num_threads(),
            initial_seed=torch.initial_seed(),attention=model.config._attn_implementation,cache=model.config.use_cache,
            no_task_hooks=True,logits_to_keep=1,model_source_sha256=p.digest(p.MODEL_SOURCE),
            resource_scope='Owner samples whole child-tree RSS during execution; worker samples RSS/MPS before/after loading and each call. Samples do not prove an unobserved continuous peak.'))
        guard('after_load');(p.OUT/'calls').mkdir()
        def forward(case):
            ids=torch.tensor([case['input_ids']],dtype=torch.int64,device='mps')
            last.clear();last['input_ids']=ids
            with torch.inference_mode():output=model(input_ids=ids,use_cache=False,logits_to_keep=1,return_dict=True)
            # No candidate slicing or finiteness check before durable retention.
            return dict(input_ids=ids,full_logits=output.logits)
        def store(case,values):
            return retain(p.OUT/'calls',f"{case['index']:02d}",values,dict(plan_sha256=plan_sha,
                **{k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}),torch,np)
        def validate(case,values):
            ids,logits=values['input_ids'],values['full_logits']
            p.require(ids.dtype==torch.int64 and ids.tolist()==[case['input_ids']], 'Input mutation')
            p.require(logits.dtype==torch.bfloat16 and tuple(logits.shape)==(1,1,49155) and logits.device.type=='mps'
                      and bool(torch.isfinite(logits).all()),'Malformed/nonfinite returned logits')
        rows=run_calls(plan['cases'],forward,store,validate,event,guard,counts,last)
        p.require(identity(model)==configured,'Configured model ownership changed')
        after=restore(model,before);p.create(p.OUT/'IDENTITY_AFTER.json',after)
        states_after=state_hash(model,torch);p.create(p.OUT/'STATE_AFTER.json',states_after)
        cache_after=p.validate_model_files(plan);p.create(p.OUT/'MODEL_CACHE_AFTER.json',cache_after)
        p.require(after==before and states_before==states_after and cache_before==cache_after,'State/cache/restoration changed')
        p.verify();guard('complete')
        p.require(counts==dict(model_load_attempts=1,model_load_finished=1,forward_attempts=20,forward_finished=20,calls_saved=20,
            hooks=0,fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0),'Physical counts differ')
        event('worker_completed')
        p.create(p.OUT/'WORKER_COMPLETE.json',dict(status='WORKER_COLLECTED_UNGRADED',at_utc=p.now(),plan_sha256=plan_sha,
            counts=counts,resource_samples=samples,all_structural_controls_pass=all(r['controls_pass'] for r in rows),
            state_unchanged=True,ownership_restored=True,cache_unchanged=True,task_scores_computed=False))
        p.create(p.OUT/'COLLECTED.json',dict(status='COLLECTED_UNGRADED',at_utc=p.now(),plan_sha256=plan_sha,counts=counts,
            artifact_sha256=p.inventory(p.OUT,p.EXCLUSIONS),task_scores_computed=False))
    except BaseException as exc:
        evidence_errors=[]
        if model is not None and before is not None:
            for name,fn in (('IDENTITY_FAILURE.json',lambda:restore(model,before)),('STATE_FAILURE.json',lambda:state_hash(model,torch))):
                try:p.create(p.OUT/name,fn())
                except BaseException as error:evidence_errors.append(name+': '+repr(error))
        if last and torch is not None:
            try:retain(p.OUT,'failure-last',last,dict(plan_sha256=plan_sha,failure_only=True),torch,np)
            except BaseException as error:evidence_errors.append('last_raw: '+repr(error))
        p.create(p.OUT/'WORKER_FAILURE.json',dict(at_utc=p.now(),status='WORKER_STOPPED_UNGRADED',plan_sha256=plan_sha,
            reason=repr(exc),counts=counts,evidence_errors=evidence_errors,retry_allowed=False,task_scores_computed=False));raise
    finally:
        stop_thread.set();thread.join(timeout=2)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--deadline-utc',required=True);main(**vars(parser.parse_args()))
