"""Manufactured archives only: no tokenizer, model, checkpoint or study outputs."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
from datetime import datetime,timedelta,timezone
import copy
import hashlib
import importlib.util
import json
import tempfile
import unittest
from unittest.mock import patch
import numpy as np

spec=importlib.util.spec_from_file_location('private_native_audit_tested',Path(__file__).with_name('audit.py'))
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)


def save(path,value):path.write_text(json.dumps(value,allow_nan=False)+'\n')
def jsonl(path,rows):path.write_text(''.join(json.dumps(v,allow_nan=False)+'\n' for v in rows))
def bf16(values):return (values.astype('<f4').view('<u4')>>16).astype('<u2').view('uint8').reshape(-1)


class Fixture:
    def __init__(self,directory):
        self.out=Path(directory);self.sha='f'*64
        self.cases=a.expected_cases()
        for c in self.cases:
            c.update(input_ids=[0,10+a.CARRIERS.index(c['carrier']),20+c['a'],30,40+c['b'],50],prefix_index=3,candidate_ids=a.LABELS.copy())
        sources={f'research/test/{name}':'0'*64 for name in ('protocol.py','worker.py','owner.py','audit.py','test_native.py','test_audit.py')}
        state={f'p{i}':'a'*64 for i in range(219)}
        self.plan=dict(cases=self.cases,candidate_ids=a.LABELS,source_sha256=sources,expected_host_state=state,
            model_files={'config.json':'b'*64},installed_model_source_sha256='c'*64,
            versions={'python':'invented','numpy':np.__version__},settings=dict(max_rss_bytes=10*1024**3,max_mps_bytes=10*1024**3,max_archive_bytes=1024**3),
            collection_exclusions=['COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl'])
        now=datetime(2026,1,1,tzinfo=timezone.utc)
        at=lambda seconds:(now+timedelta(seconds=seconds)).isoformat()
        save(self.out/'plan.json',self.plan);save(self.out/'REGISTRATION.json',{'plan_sha256':self.sha})
        save(self.out/'STARTED.json',dict(at_utc=at(0),deadline_utc=at(900),owner_pid=111,plan_sha256=self.sha))
        save(self.out/'WORKER_STARTED.json',dict(at_utc=at(.1),deadline_utc=at(900),owner_pid=111,worker_pid=112,plan_sha256=self.sha))
        (self.out/'sources').mkdir();(self.out/'calls').mkdir()
        for name in sources:(self.out/'sources'/Path(name).name).write_text('invented source\n')
        for name in ('worker.log','independent_audit.log','owner-events.jsonl'):(self.out/name).write_text('')
        cache={'config.json':dict(sha256='b'*64,size_bytes=10,resolved_path='/invented/config')}
        for name in ('MODEL_CACHE_BEFORE.json','MODEL_CACHE_AFTER.json'):save(self.out/name,cache)
        for name in ('STATE_BEFORE.json','STATE_AFTER.json'):save(self.out/name,state)
        identity=dict(training={'':True},requires_grad={f'p{i}':True for i in range(218)},
            parameters={f'p{i}':[i+1,i+1000,'mps:0','torch.bfloat16'] for i in range(218)},buffers={},
            grads_none={f'p{i}':True for i in range(218)},hooks={},forward_methods={'':[False,999]},
            config=dict(hidden_size=1024,num_hidden_layers=24,num_local_experts=32,num_experts_per_tok=8,vocab_size=a.VOCAB,
                        use_cache=True,logits_scaling=6.0),generation_config={})
        for name in ('IDENTITY_BEFORE.json','IDENTITY_AFTER.json'):save(self.out/name,identity)
        configured=copy.deepcopy(identity);configured.update(training={'':False},requires_grad={k:False for k in identity['parameters']})
        configured['config']['use_cache']=False;save(self.out/'IDENTITY_CONFIGURED.json',configured)
        save(self.out/'RUNTIME.json',dict(versions=self.plan['versions'],device='mps',dtype='torch.bfloat16',threads=4,
            initial_seed=42,attention='eager',cache=False,no_task_hooks=True,logits_to_keep=1,model_source_sha256='c'*64))
        self.rows=[]
        for case in self.cases:
            x=np.full((1,1,a.VOCAB),-16,dtype='<f4');x[0,0,544]=0;x[0,0,2126]=0
            x[0,0,544 if case['a']^case['b'] else 2126]=1
            self.rows.append(self.write_call(case,x))
        jsonl(self.out/'calls.jsonl',self.rows)
        events=[dict(event=k,at_utc=at(.2+i*.1)) for i,k in enumerate(('worker_started','model_load_started','model_load_finished'))]
        for case in self.cases:
            for kind in ('forward_started','forward_returned','call_saved'):
                e=dict(event=kind,at_utc=at(1+len(events)*.1),id=case['id'],index=case['index'])
                if kind=='call_saved':e['controls_pass']=True
                events.append(e)
        events.append(dict(event='worker_completed',at_utc=at(19)));jsonl(self.out/'worker-events.jsonl',events)
        pairs=[('before_load',None),('after_load',None)]
        for c in self.cases:pairs.extend((k,c['id']) for k in ('before_forward','after_forward'))
        pairs.append(('complete',None))
        samples=[dict(at_utc=at(1+i*.3),stage=k,call_id=cid,elapsed_seconds=1+i*.3,
            rss_high_water_bytes=1000,mps_driver_bytes=2000,mps_allocated_bytes=1000,archive_bytes=3000) for i,(k,cid) in enumerate(pairs)]
        jsonl(self.out/'worker-resources.jsonl',samples)
        jsonl(self.out/'resource-monitor.jsonl',[dict(at_utc=at(t),stage=k,pid=112 if k=='worker' else 113,
            elapsed_seconds=t,child_tree_rss_bytes=2000,archive_bytes=4000) for t,k in ((1,'worker'),(20,'worker'),(21,'independent_audit'))])
        save(self.out/'WORKER_COMPLETE.json',dict(status='WORKER_COLLECTED_UNGRADED',at_utc=at(20),plan_sha256=self.sha,
            counts=a.expected_counts(),resource_samples=samples,all_structural_controls_pass=True,state_unchanged=True,
            ownership_restored=True,cache_unchanged=True,task_scores_computed=False))
        self.seal()

    def write_call(self,case,x):
        arrays={};meta={};ids=np.array([case['input_ids']],dtype='<i8')
        for name,value in (('input_ids',ids),('full_logits',x)):
            raw=value.view('uint8').reshape(-1) if name=='input_ids' else bf16(value)
            arrays[name+'__raw_uint8']=raw;arrays[name+'__value']=value
            meta[name]=dict(dtype='torch.int64' if name=='input_ids' else 'torch.bfloat16',shape=list(value.shape),
                raw_key=name+'__raw_uint8',value_key=name+'__value',raw_sha256=a.raw_sha(raw),finite=bool(np.isfinite(value).all()))
        i=case['index'];np.savez_compressed(self.out/f'calls/{i:02d}.npz',**arrays)
        fields={k:case[k] for k in ('index','id','phase','repeat_of','carrier','a','b')}
        save(self.out/f'calls/{i:02d}.json',dict(fields,plan_sha256=self.sha,tensors=meta))
        return dict(fields,forward_path=f'calls/{i:02d}.npz',forward_sha256=a.digest(self.out/f'calls/{i:02d}.npz'),
            forward_metadata_path=f'calls/{i:02d}.json',forward_metadata_sha256=a.digest(self.out/f'calls/{i:02d}.json'),
            forward_completed=True,controls_pass=True,error=None)

    def alter_call(self,index,change):
        with np.load(self.out/f'calls/{index:02d}.npz') as z:x=z['full_logits__value'].copy()
        change(x);self.rows[index]=self.write_call(self.cases[index],x);jsonl(self.out/'calls.jsonl',self.rows);self.seal()

    def seal(self):
        excluded=set(self.plan['collection_exclusions'])
        hashes={str(p.relative_to(self.out)):a.digest(p) for p in self.out.rglob('*') if p.is_file() and str(p.relative_to(self.out)) not in excluded}
        save(self.out/'COLLECTED.json',dict(status='COLLECTED_UNGRADED',plan_sha256=self.sha,counts=a.expected_counts(),
            artifact_sha256=hashes,task_scores_computed=False))


class AuditTests(unittest.TestCase):
    def setUp(self):self.temp=tempfile.TemporaryDirectory();self.f=Fixture(self.temp.name)
    def tearDown(self):self.temp.cleanup()
    def run_audit(self):return a.audit_records(self.f.out,self.f.plan,self.f.sha)

    def test_complete20_positive_and_fixed_effects(self):
        r=self.run_audit();self.assertTrue(r['native_gate_pass']);self.assertEqual(r['primary']['correct'],16)
        self.assertEqual(r['repeats']['exact_matches'],4)
        self.assertEqual(r['groups']['lamp']['paired_margin_effects'],dict(copy=2.,invert=-2.,required_sign_reversal=True))
        self.assertEqual(r['rows'][0]['choice'],'off');self.assertEqual(r['rows'][1]['choice'],'on')

    def test_wrong_and_tie_complete_negative_no_subset(self):
        self.f.alter_call(1,lambda x:x.__setitem__((0,0,544),-1))
        self.f.alter_call(2,lambda x:x.__setitem__((0,0,544),0))
        r=self.run_audit();self.assertFalse(r['native_gate_pass']);self.assertEqual(r['primary']['correct'],14)
        self.assertEqual(r['primary']['ties'],1);self.assertEqual(len(r['rows']),20)
        self.assertFalse(r['groups']['lamp']['quartet_pass'])

    def test_repeat_finite_variation_valid_negative(self):
        self.f.alter_call(19,lambda x:x.__setitem__((0,0,100),-15))
        r=self.run_audit();self.assertEqual(r['primary']['correct'],16)
        self.assertEqual(r['repeats']['exact_matches'],3);self.assertFalse(r['native_gate_pass'])

    def test_last_raw_nonfinite_prevents_all_scoring(self):
        self.f.alter_call(19,lambda x:x.__setitem__((0,0,100),float('inf')))
        with patch.object(a,'decode_logits',side_effect=AssertionError('must not score')) as spy:
            with self.assertRaisesRegex(a.AuditError,'Nonfinite'):self.run_audit()
            spy.assert_not_called()

    def test_missing_call_is_not_negative_grade(self):
        jsonl(self.f.out/'calls.jsonl',self.f.rows[:-1]);self.f.seal()
        with self.assertRaisesRegex(a.AuditError,'Incomplete calls'):self.run_audit()

    def test_truth_case_mapping_and_bool_rejected(self):
        self.f.plan['cases'][0]['a']=True
        with self.assertRaisesRegex(a.AuditError,'schedule'):self.run_audit()

    def test_token_prefix_and_repeat_identity(self):
        self.f.plan['cases'][1]['input_ids'][1]=99
        with self.assertRaisesRegex(a.AuditError,'prefix'):a.validate_cases(self.f.plan)

    def test_raw_readable_corruption(self):
        path=self.f.out/'calls/00.npz'
        with np.load(path) as z:data={k:z[k].copy() for k in z.files}
        data['full_logits__value'][0,0,200]=-15
        np.savez_compressed(path,**data);self.f.rows[0]['forward_sha256']=a.digest(path)
        jsonl(self.f.out/'calls.jsonl',self.f.rows);self.f.seal()
        with self.assertRaisesRegex(a.AuditError,'Raw/readable'):self.run_audit()

    def test_hash_and_unexpected_archive_rejected(self):
        (self.f.out/'calls/00.json').write_text('{}')
        with self.assertRaisesRegex(a.AuditError,'artifact changed'):self.run_audit()

    def test_state_and_configuration_restore(self):
        path=self.f.out/'STATE_AFTER.json';data=a.read(path);data['p0']='d'*64;save(path,data);self.f.seal()
        with self.assertRaisesRegex(a.AuditError,'state changed'):self.run_audit()

    def test_journal_return_and_resource_cap(self):
        path=self.f.out/'worker-events.jsonl';events=a.lines(path);events[4]['event']='call_saved';jsonl(path,events);self.f.seal()
        with self.assertRaisesRegex(a.AuditError,'Event order'):self.run_audit()

    def test_full_vocab_diagnostics_do_not_gate_candidate(self):
        self.f.alter_call(1,lambda x:x.__setitem__((0,0,400),10))
        r=self.run_audit();self.assertTrue(r['native_gate_pass'])
        self.assertFalse(r['rows'][1]['full_vocab']['strict_legal_top1'])
        self.assertEqual(r['rows'][1]['full_vocab']['winner'],400)

    def test_signedzero_repeat_is_raw_nonexact(self):
        self.f.alter_call(16,lambda x:x.__setitem__((0,0,544),-0.))
        r=self.run_audit();self.assertEqual(r['primary']['correct'],16);self.assertFalse(r['native_gate_pass'])
        self.assertTrue(r['repeats']['rows'][0]['strict_choice_equal'])


if __name__=='__main__':unittest.main()
