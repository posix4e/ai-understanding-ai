Reading bundle for the completed native copy/invert prerequisite.
Contains frozen study source, registered plan, tokenizer-v2 proof, completion, full report and independent audit.
Also preserves tokenizer-v1 failure, boundary diagnosis/amendment and original preparation source snapshots. All complete prompts were unchanged.
All 20 raw return bundles are included as unchanged bytes; the publisher did not decode or regrade them.
Model weights and the installed runtime are excluded; this is not a self-contained reproduction or a new execution authorization.
This tests native candidate preference only, before any organ splice; it establishes neither internal computation nor novelty.
