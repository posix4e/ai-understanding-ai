"""Independent raw-first, NumPy-only native screen audit. Never calls a model.

The protocol is reused only for frozen source/cache/registration verification.
Truth, text schedule, BF16 decoding and scoring are implemented here independently.
All20 sealed calls are validated before any preference is calculated. A finite
wrong/tied prediction or changed repeat is a complete negative engineering gate.
"""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import os
import subprocess
import time
import numpy as np

CARRIERS = ('lamp', 'light', 'sign', 'indicator')
LABELS = {'on': 544, 'off': 2126}
VOCAB = 49155


class AuditError(ValueError): pass
def require(ok, message):
    if not ok: raise AuditError(message)
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def same(a, b): return canonical(a) == canonical(b)
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def raw_sha(value): return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()
def read(path):
    return json.loads(Path(path).read_text(), parse_constant=lambda x: (_ for _ in ()).throw(AuditError(x)))
def lines(path): return [json.loads(x) for x in Path(path).read_text().splitlines()]
def live_lines(path):
    """A live owner log is only an immutable newline-terminated prefix here."""
    data=Path(path).read_bytes();end=data.rfind(b'\n')
    return [json.loads(x) for x in data[:end+1].splitlines()] if end>=0 else []
def create(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
def safe(directory, name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe archive path')
    result = Path(directory)/name
    require(result.is_file() and result.resolve().is_relative_to(Path(directory).resolve()), 'Missing/escaping archive file')
    return result
def finite_number(v): return type(v) in (int, float) and math.isfinite(v)
def timestamp(v): return datetime.fromisoformat(v.replace('Z', '+00:00')).timestamp()


def expected_cases():
    result = []
    for carrier in CARRIERS:
        for a in (0, 1):
            for b in (0, 1):
                state = ('off', 'on')[a]
                prefix = f'The {carrier} has exactly two states: on and off.\nInitially, the {carrier} is {state}.'
                action = ('left in the same state', 'switched to the opposite state')[b]
                suffix = f'\n\nThe {carrier} is then {action}.\nAfter this, the {carrier} is'
                result.append(dict(index=len(result), id=f'n{len(result):02d}', phase='primary', repeat_of=None,
                                   carrier=carrier, a=a, b=b, prefix_text=prefix, suffix_text=suffix, input_text=prefix+suffix))
    for i in range(4):
        donor = result[4*i+2*(i//2)+i%2]
        result.append(dict(donor, index=16+i, id=f'n{16+i:02d}', phase='repeat', repeat_of=donor['id']))
    return result


def validate_cases(plan):
    require(same(plan['candidate_ids'], LABELS), 'Candidate identity changed')
    cases = plan['cases']; require(len(cases) == 20, 'Expected full20 schedule')
    prefixes = {}; sizes = {}
    for case, expected in zip(cases, expected_cases()):
        require(same({k:case[k] for k in expected}, expected), 'Literal case/schedule changed')
        require(set(case) == set(expected)|{'input_ids','prefix_index','candidate_ids'}, 'Unexpected case field')
        require(same(case['candidate_ids'], LABELS), 'Case candidate identity changed')
        ids = case['input_ids']; boundary = case['prefix_index']
        require(type(ids) is list and 1 < len(ids) <= 128 and ids[0] == 0
                and all(type(x) is int and 0 <= x < VOCAB for x in ids), 'Invalid frozen tokens')
        require(type(boundary) is int and 0 < boundary < len(ids)-1, 'Invalid prefix boundary')
        key = (case['carrier'], case['a'])
        if key in prefixes: require(prefixes[key] == ids[:boundary+1], 'Operation enters the fact prefix')
        prefixes[key] = ids[:boundary+1]; sizes[key] = boundary
        if case['phase'] == 'repeat':
            source = cases[int(case['repeat_of'][1:])]
            require(ids == source['input_ids'] and boundary == source['prefix_index'], 'Repeat tokens changed')
    for carrier in CARRIERS: require(sizes[carrier,0] == sizes[carrier,1], 'Fact prefix lengths differ')
    return cases


def load_bundle(directory, row, case, plan_sha):
    """Check both raw and readable arrays, never using readable values as authority."""
    raw_path = safe(directory, row['forward_path']); meta_path = safe(directory, row['forward_metadata_path'])
    require(digest(raw_path) == row['forward_sha256'] and digest(meta_path) == row['forward_metadata_sha256'], 'Bundle file hash differs')
    info = read(meta_path)
    for key in ('index','id','phase','repeat_of','carrier','a','b'):
        require(same(info[key], case[key]) and same(row[key], case[key]), 'Call identity differs: '+key)
    require(info['plan_sha256'] == plan_sha, 'Call plan binding differs')
    require(set(info['tensors']) == {'input_ids','full_logits'}, 'Tensor set differs')
    tensors = {}; raw = {}
    specs = {'input_ids':('torch.int64', [1,len(case['input_ids'])], '<i8'),
             'full_logits':('torch.bfloat16', [1,1,VOCAB], '<f4')}
    with np.load(raw_path, allow_pickle=False) as bundle:
        require(set(bundle.files) == {n+s for n in specs for s in ('__raw_uint8','__value')}, 'NPZ member set differs')
        for name,(dtype,shape,readable) in specs.items():
            m = info['tensors'][name]
            require(m['dtype'] == dtype and same(m['shape'],shape)
                    and m['raw_key'] == name+'__raw_uint8' and m['value_key'] == name+'__value', 'Tensor schema differs')
            r = bundle[m['raw_key']]; value = bundle[m['value_key']]
            size = int(np.prod(shape)) * (8 if name == 'input_ids' else 2)
            require(r.dtype == np.dtype('uint8') and r.ndim == 1 and r.size == size, 'Raw tensor size/dtype differs')
            require(raw_sha(r) == m['raw_sha256'], 'Raw tensor SHA differs')
            require(value.dtype.str == readable and list(value.shape) == shape, 'Readable tensor dtype/shape differs')
            if name == 'input_ids': decoded = np.frombuffer(r.tobytes(), dtype='<i8').reshape(shape)
            else: decoded = (np.frombuffer(r.tobytes(), dtype='<u2').astype('<u4') << 16).view('<f4').reshape(shape)
            require(decoded.tobytes() == value.tobytes(), 'Raw/readable tensor bytes disagree')
            require(np.isfinite(decoded).all(), 'Nonfinite raw tensor')
            if 'finite' in m: require(m['finite'] is True, 'Recorded finite flag differs')
            tensors[name] = decoded.copy(); raw[name] = r.tobytes()
    require(tensors['input_ids'].tolist() == [case['input_ids']], 'Actual input tokens differ')
    if 'input_ids_sha256' in info:
        require(info['input_ids_sha256'] == hashlib.sha256(raw['input_ids']).hexdigest(), 'Input hash binding differs')
    require(row['forward_completed'] is True and row['controls_pass'] is True and row['error'] is None, 'Uncontrolled/incomplete call')
    return dict(info=info, tensors=tensors, raw=raw)


def decode_logits(logits, case):
    x = np.asarray(logits)
    require(x.dtype == np.dtype('float32') and x.shape == (1,1,VOCAB) and np.isfinite(x).all(), 'Invalid full logits')
    values = x.reshape(-1).astype(np.float64)
    on, off = (float(values[LABELS[k]]) for k in ('on','off'))
    margin = on-off; choice = 'on' if margin > 0 else 'off' if margin < 0 else None
    target = 'on' if case['a'] ^ case['b'] else 'off'
    full_max = float(values.max()); winners = np.flatnonzero(values == full_max)
    weights = np.exp(values-full_max); denominator = math.fsum(float(v) for v in weights)
    cm = max(on,off); cp = math.exp(on-cm)/(math.exp(on-cm)+math.exp(off-cm))
    return dict(index=case['index'],id=case['id'],phase=case['phase'],repeat_of=case['repeat_of'],
                carrier=case['carrier'],a=case['a'],b=case['b'],target=target,choice=choice,
                correct=choice==target,tie=choice is None,logits={'on':on,'off':off},
                margin_on_minus_off=margin,conditional_q={'on':cp,'off':1-cp},
                full_vocab=dict(winner=int(winners[0]) if len(winners)==1 else None,tie_count=int(len(winners)),
                    strict_legal_top1=len(winners)==1 and int(winners[0]) in LABELS.values(),
                    candidate_mass=float((weights[544]+weights[2126])/denominator)))


def score_complete(cases, bundles):
    require(len(cases)==len(bundles)==20, 'No scoring incomplete panel')
    rows = [decode_logits(bundle['tensors']['full_logits'],case) for case,bundle in zip(cases,bundles)]
    groups = {}
    for carrier in CARRIERS:
        selected = [r for r in rows[:16] if r['carrier']==carrier]
        groups[carrier] = dict(n=4,correct=sum(r['correct'] for r in selected),ties=sum(r['tie'] for r in selected),
            quartet_pass=all(r['correct'] for r in selected),operations={})
        for b,name in ((0,'copy'),(1,'invert')):
            part = [r for r in selected if r['b']==b]
            groups[carrier]['operations'][name] = dict(n=2,correct=sum(r['correct'] for r in part),ties=sum(r['tie'] for r in part))
        m = {(r['a'],r['b']):r['margin_on_minus_off'] for r in selected}
        groups[carrier]['paired_margin_effects'] = dict(copy=m[1,0]-m[0,0],invert=m[1,1]-m[0,1],
            required_sign_reversal=m[1,0]-m[0,0]>0 and m[1,1]-m[0,1]<0)
    repeats = []
    for i in range(16,20):
        j = int(cases[i]['repeat_of'][1:]); lhs,rhs = bundles[i]['raw'],bundles[j]['raw']
        repeats.append(dict(id=cases[i]['id'],repeat_of=cases[i]['repeat_of'],
            input_exact=lhs['input_ids']==rhs['input_ids'],full_logits_exact=lhs['full_logits']==rhs['full_logits'],
            strict_choice_equal=rows[i]['choice'] is not None and rows[i]['choice']==rows[j]['choice']))
    exact = sum(r['input_exact'] and r['full_logits_exact'] for r in repeats)
    primary = dict(n=16,correct=sum(r['correct'] for r in rows[:16]),ties=sum(r['tie'] for r in rows[:16]))
    return dict(status='NATIVE_PRIVATE_INPUT_SCREEN_COMPLETE',implementation_pass=True,
        native_gate_pass=primary['correct']==16 and exact==4,counts=dict(primary=16,repeats=4,total=20),
        primary=primary,groups=groups,rows=rows,repeats=dict(n=4,exact_matches=exact,pass_gate=exact==4,rows=repeats),
        limits=['Fixed20 native candidate-preference engineering census; no organ or state transplant was tested.',
                'Conditional on/off weights are not calibrated probabilities. Full-vocabulary diagnostics do not gate readiness.',
                'Four lexical quartets are not16 independent population draws; no p-values, novelty or causal mechanism claim.',
                'All cases are retained; finite wrong/tied choices and changed repeats are complete negative readiness.',
                'Earlier closed studies and confirmation remain closed; a pass does not launch a subsequent study.'])


def expected_counts():
    return dict(model_load_attempts=1,model_load_finished=1,forward_attempts=20,forward_finished=20,calls_saved=20,
                hooks=0,fits=0,backwards=0,optimizer_steps=0,provider_calls=0,generated_tokens=0)


def check_inventory(directory, plan, plan_sha):
    require(not any((directory/n).exists() for n in ('STOPPED.json','COMPLETE.json','WORKER_FAILURE.json','LIFETIME_STOP.json')), 'Closed/failed archive')
    collection = read(directory/'COLLECTED.json')
    require(collection['status']=='COLLECTED_UNGRADED' and collection['plan_sha256']==plan_sha
            and collection['task_scores_computed'] is False and same(collection['counts'],expected_counts()), 'Incomplete collection')
    expected = {'plan.json','REGISTRATION.json','STARTED.json','WORKER_STARTED.json','MODEL_CACHE_BEFORE.json',
        'MODEL_CACHE_AFTER.json','IDENTITY_BEFORE.json','IDENTITY_CONFIGURED.json','IDENTITY_AFTER.json',
        'STATE_BEFORE.json','STATE_AFTER.json','RUNTIME.json','calls.jsonl','worker-events.jsonl',
        'worker-resources.jsonl','WORKER_COMPLETE.json'}
    expected |= {'sources/'+Path(n).name for n in plan['source_sha256']}
    expected |= {f'calls/{i:02d}.{ext}' for i in range(20) for ext in ('json','npz')}
    hashes = collection['artifact_sha256']
    require(set(hashes)==expected, 'Collection inventory coverage differs')
    excluded = {'COLLECTED.json','worker.log','independent_audit.log','owner-events.jsonl','resource-monitor.jsonl'}
    require(set(plan['collection_exclusions'])==excluded, 'Unexpected collection exclusion')
    actual = {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}
    require(actual == expected|excluded, 'Unbound/missing archive file')
    for name,h in hashes.items(): require(digest(safe(directory,name))==h, 'Immutable artifact changed: '+name)
    rows = lines(directory/'calls.jsonl'); require(len(rows)==20, 'Incomplete calls journal')
    for i,row in enumerate(rows):
        require(row['forward_path']==f'calls/{i:02d}.npz' and row['forward_metadata_path']==f'calls/{i:02d}.json', 'Call path/schedule differs')
        require(row['forward_sha256']==hashes[row['forward_path']]
                and row['forward_metadata_sha256']==hashes[row['forward_metadata_path']], 'Call hash chain differs')
    return collection, rows


def check_state(directory, plan, plan_sha):
    before,after = (read(directory/n) for n in ('STATE_BEFORE.json','STATE_AFTER.json'))
    require(before==after==plan['expected_host_state'] and len(before)==219, 'Host state changed')
    require(all(type(v) is str and len(v)==64 and all(c in '0123456789abcdef' for c in v) for v in before.values()), 'Invalid state hash')
    initial,configured,restored = (read(directory/n) for n in ('IDENTITY_BEFORE.json','IDENTITY_CONFIGURED.json','IDENTITY_AFTER.json'))
    require(same(initial,restored) and len(initial['parameters'])==218, 'Host ownership not restored')
    for k in ('parameters','buffers','grads_none','hooks','forward_methods','generation_config'):
        require(same(initial[k],configured[k]), 'Configured ownership changed: '+k)
    require(initial['hooks']=={} and all(v is True for v in initial['grads_none'].values()), 'Hooks/gradients present')
    require(set(initial['requires_grad'])==set(configured['requires_grad'])==set(initial['parameters']), 'Parameter flag coverage differs')
    require(set(initial['training'])==set(configured['training'])==set(initial['forward_methods']), 'Module coverage differs')
    require(all(type(v) is bool for v in initial['training'].values()) and all(type(v) is bool for v in initial['requires_grad'].values()), 'Invalid original flags')
    require(all(v is False for v in configured['training'].values()) and all(v is False for v in configured['requires_grad'].values()), 'Not frozen/eval')
    for value in initial['parameters'].values():
        require(len(value)==4 and all(type(x) is int and x>0 for x in value[:2])
                and value[2] in ('mps','mps:0') and value[3]=='torch.bfloat16', 'Invalid native parameter placement')
    expected_config = dict(initial['config'],use_cache=False)
    require(same(configured['config'],expected_config), 'Configured model changed')
    cfg = initial['config']
    for k,v in {'hidden_size':1024,'num_hidden_layers':24,'num_local_experts':32,'num_experts_per_tok':8,'vocab_size':VOCAB}.items():
        require(type(cfg[k]) is int and cfg[k]==v, 'Architecture differs: '+k)
    require(finite_number(cfg['logits_scaling']) and cfg['logits_scaling']==6, 'Head scaling differs')
    runtime = read(directory/'RUNTIME.json')
    expected = dict(versions=plan['versions'],device='mps',dtype='torch.bfloat16',threads=4,initial_seed=42,
        attention='eager',cache=False,no_task_hooks=True,logits_to_keep=1,model_source_sha256=plan['installed_model_source_sha256'])
    require(same({k:runtime[k] for k in expected},expected), 'Runtime differs')
    cache1,cache2 = (read(directory/n) for n in ('MODEL_CACHE_BEFORE.json','MODEL_CACHE_AFTER.json'))
    require(same(cache1,cache2) and set(cache1)==set(plan['model_files']), 'Cache receipts differ')
    for name,h in plan['model_files'].items(): require(cache1[name]['sha256']==h,'Cache receipt hash differs')
    complete = read(directory/'WORKER_COMPLETE.json')
    require(complete['status']=='WORKER_COLLECTED_UNGRADED' and complete['plan_sha256']==plan_sha
            and same(complete['counts'],expected_counts()) and complete['task_scores_computed'] is False, 'Worker completion differs')
    for k in ('all_structural_controls_pass','state_unchanged','ownership_restored','cache_unchanged'):
        require(complete[k] is True, 'Worker control failed: '+k)
    return complete


def check_journal_resources(directory,plan,cases,complete):
    start = read(directory/'STARTED.json'); begin = timestamp(start['at_utc']); deadline=timestamp(start['deadline_utc'])
    require(deadline-begin==900, 'Inclusive deadline changed')
    event_specs=[('worker_started',None),('model_load_started',None),('model_load_finished',None)]
    for c in cases: event_specs.extend((k,c) for k in ('forward_started','forward_returned','call_saved'))
    event_specs.append(('worker_completed',None))
    events=lines(directory/'worker-events.jsonl'); require(len(events)==64, 'Event count differs')
    previous=begin
    for event,(kind,case) in zip(events,event_specs):
        require(event['event']==kind,'Event order differs')
        t=timestamp(event['at_utc']); require(previous<=t<=deadline,'Event outside original chronology');previous=t
        if case is not None: require(event['id']==case['id'] and same(event['index'],case['index']),'Event case differs')
        if kind=='call_saved': require(event['controls_pass'] is True,'Failed saved call')
    samples=lines(directory/'worker-resources.jsonl')
    expected=[('before_load',None),('after_load',None)]
    for c in cases: expected.extend((k,c['id']) for k in ('before_forward','after_forward'))
    expected.append(('complete',None))
    require(len(samples)==43 and same(samples,complete['resource_samples']),'Worker resource coverage differs')
    previous=begin
    for sample,(stage,call_id) in zip(samples,expected):
        require(sample['stage']==stage and sample['call_id']==call_id,'Resource sequence differs')
        t=timestamp(sample['at_utc']); require(previous<=t<=deadline,'Resource timestamp outside deadline');previous=t
        for key,cap in (('rss_high_water_bytes','max_rss_bytes'),('mps_driver_bytes','max_mps_bytes'),('archive_bytes','max_archive_bytes')):
            require(type(sample[key]) is int and 0<=sample[key]<=plan['settings'][cap], 'Resource cap/field differs: '+key)
        require(type(sample['mps_allocated_bytes']) is int and 0<=sample['mps_allocated_bytes']<=sample['mps_driver_bytes'], 'MPS resource fields differ')
        require(finite_number(sample['elapsed_seconds']) and 0<=sample['elapsed_seconds']<=900,'Elapsed resource time differs')
    require(begin<=timestamp(complete['at_utc'])<=deadline,'Worker completion after deadline')
    monitor=live_lines(directory/'resource-monitor.jsonl'); require(monitor,'No owner monitor evidence')
    for row in monitor:
        require(row['stage'] in ('worker','independent_audit') and begin<=timestamp(row['at_utc'])<=deadline,'Owner sample invalid')
        require(type(row['child_tree_rss_bytes']) is int and 0<=row['child_tree_rss_bytes']<=plan['settings']['max_rss_bytes'],'Owner RSS cap')
        require(type(row['archive_bytes']) is int and 0<=row['archive_bytes']<=plan['settings']['max_archive_bytes'],'Owner storage cap')
    times=[timestamp(r['at_utc']) for r in monitor]
    require(times==sorted(times),'Owner monitor times decreased')
    return dict(worker_samples=43,worker_events=64,
        peak_worker_rss_bytes=max(x['rss_high_water_bytes'] for x in samples),
        peak_mps_driver_bytes=max(x['mps_driver_bytes'] for x in samples),
        owner_samples_observed=len(monitor),peak_owner_child_tree_rss_bytes=max(x['child_tree_rss_bytes'] for x in monitor),
        maximum_owner_sample_gap_seconds=max((b-a for a,b in zip(times,times[1:])),default=0),
        scope='Sampled worker/owner evidence, not a continuous peak proof. Owner final publication binds completed live logs.')


def owner_guard(directory,plan_sha):
    start=read(directory/'STARTED.json'); worker=read(directory/'WORKER_STARTED.json')
    require(start['plan_sha256']==worker['plan_sha256']==plan_sha and start['owner_pid']==worker['owner_pid']==os.getppid(), 'Original parent binding differs')
    require(worker['deadline_utc']==start['deadline_utc'] and time.time()<timestamp(start['deadline_utc']), 'Deadline mismatch/expired')
    os.kill(start['owner_pid'],0)
    require(not any((directory/n).exists() for n in ('STOPPED.json','COMPLETE.json')),'Owner closed')
    # Popen can reach this child before its parent durably appends the start event.
    until=time.monotonic()+2
    while True:
        try: events=lines(directory/'owner-events.jsonl')
        except (FileNotFoundError,json.JSONDecodeError):events=[]
        if len(events)>=3 or time.monotonic()>=until:break
        time.sleep(.02)
    require(len(events)==3,'Unexpected owner dispatch count')
    a,b,c=events
    require(a['event']=='started' and a['stage']=='worker' and b['event']=='exit' and b['stage']=='worker'
        and a['pid']==b['pid']==worker['worker_pid'] and b['returncode']==0 and b['process_group_absent'] is True
        and c['event']=='started' and c['stage']=='independent_audit' and c['pid']==os.getpid(),'Invalid original stage lifecycle')
    require(Path(a['command'][2]).name=='worker.py' and a['command'][3:]==['--deadline-utc',start['deadline_utc']]
        and Path(c['command'][2]).name=='audit.py' and c['command'][3:]==['--directory',str(directory)],'Owner command changed')
    processes=subprocess.run(['/bin/ps','-axo','pid=,pgid='],check=True,capture_output=True,text=True,timeout=5)
    require(not any(int(line.split()[1])==worker['worker_pid'] for line in processes.stdout.splitlines()),'Original worker group still active')
    return start


def audit_records(directory,plan,plan_sha):
    """Pure saved-data audit after CLI source/owner admission; no model imports."""
    directory=Path(directory);cases=validate_cases(plan)
    collected,rows=check_inventory(directory,plan,plan_sha)
    complete=check_state(directory,plan,plan_sha)
    resources=check_journal_resources(directory,plan,cases,complete)
    bundles=[load_bundle(directory,row,case,plan_sha) for row,case in zip(rows,cases)]
    # All20 raw and structural checks precede every scoring call.
    report=score_complete(cases,bundles)
    report.update(plan_sha256=plan_sha,collected_sha256=digest(directory/'COLLECTED.json'),
        physical_counts=expected_counts(),resources=resources,
        controls=dict(state_entries=219,parameter_entries=218,state_includes_buffers=True,
            ownership_restored=True,states_unchanged=True,all_raw_calls_valid=True))
    for output,bundle in zip(report['rows'],bundles):
        output['full_logits_raw_sha256']=hashlib.sha256(bundle['raw']['full_logits']).hexdigest()
        output['input_ids_raw_sha256']=hashlib.sha256(bundle['raw']['input_ids']).hexdigest()
    check_inventory(directory,plan,plan_sha)
    return report


def main(directory):
    import protocol as p
    directory=Path(directory).resolve();require(directory==p.OUT.resolve(),'Wrong registered directory')
    require(not any((directory/n).exists() for n in ('REPORT.json','INDEPENDENT_AUDIT.json','AUDIT_FAILURE.json')),'Audit already attempted')
    plan,plan_sha=p.verify(directory)
    try:
        require(Path(sys.executable).resolve()==p.PYTHON.resolve() and np.__version__==plan['versions']['numpy'],'Audit runtime differs')
        start=owner_guard(directory,plan_sha);cache=p.validate_model_files(plan)
        report=audit_records(directory,plan,plan_sha)
        require(p.validate_model_files(plan)==cache,'Cache changed during audit')
        require(p.verify(directory)[1]==plan_sha,'Plan changed during audit');owner_guard(directory,plan_sha)
        create(directory/'REPORT.json',report)
        audit=dict(status='PASS',implementation_pass=True,native_gate_pass=report['native_gate_pass'],
            plan_sha256=plan_sha,report_sha256=digest(directory/'REPORT.json'),audit_code_sha256=digest(__file__),
            collected_sha256=report['collected_sha256'],started_sha256=digest(directory/'STARTED.json'),
            source_sha256=plan['source_sha256'],pid=os.getpid(),owner_pid=os.getppid(),at_utc=datetime.now(timezone.utc).isoformat(),
            numerical_scope='Independent raw BF16 decoding and XOR truth/case/score implementation; protocol source/cache verification reused.')
        create(directory/'INDEPENDENT_AUDIT.json',audit);print(json.dumps(audit),flush=True)
    except BaseException as exc:
        rejected={}
        for name in ('REPORT.json','INDEPENDENT_AUDIT.json'):
            path=directory/name
            if path.exists():
                rejected[name]=digest(path);os.rename(path,directory/('INVALID_'+name))
        create(directory/'AUDIT_FAILURE.json',dict(status='AUDIT_FAILED_UNGRADED',at_utc=datetime.now(timezone.utc).isoformat(),
            plan_sha256=plan_sha,reason=repr(exc),rejected_publication_sha256=rejected,retry_allowed=False));raise


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--directory',required=True);main(**vars(parser.parse_args()))
