"""Invented filesystem/control-flow tests; never load pretrained tensors."""
from datetime import datetime,timedelta,timezone
from pathlib import Path
from unittest import mock
import ast
import importlib.util
import json
import os
import sys
import tempfile
import unittest
import protocol as p
import worker
import owner


class ContractTests(unittest.TestCase):
    def test_amendment_changes_only_boundary_partition(self):
        rows=p.cases();old=[dict(r,prefix_text=r['prefix_text']+'\n\n',suffix_text=r['suffix_text'][2:]) for r in rows]
        self.assertTrue(p.amended_case_identity(rows,old))
        self.assertTrue(all(r['prefix_text'].endswith('.') and r['suffix_text'].startswith('\n\n') for r in rows))
    def test_amendment_rejects_changed_full_prompt_and_case(self):
        rows=p.cases();old=[dict(r,prefix_text=r['prefix_text']+'\n\n',suffix_text=r['suffix_text'][2:]) for r in rows]
        for field,value in (('input_text',rows[0]['input_text']+' '),('a',True),('repeat_of','n99')):
            changed=[dict(r) for r in rows];changed[0][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):p.amended_case_identity(changed,old)
    def test_balanced_complete_truth_and_repeat_sources(self):
        rows=p.cases();self.assertEqual(len(rows),20)
        self.assertEqual(len({r['id'] for r in rows}),20)
        for carrier in p.CARRIERS:
            quartet=[r for r in rows[:16] if r['carrier']==carrier]
            self.assertEqual([(r['a'],r['b']) for r in quartet],[(0,0),(0,1),(1,0),(1,1)])
            self.assertEqual([r['a']^r['b'] for r in quartet],[0,1,1,0])
            for a in (0,1):
                pair=[r for r in quartet if r['a']==a]
                self.assertEqual(pair[0]['prefix_text'],pair[1]['prefix_text'])
        self.assertEqual([r['repeat_of'] for r in rows[16:]],['n00','n05','n10','n15'])
        for r in rows[16:]:self.assertEqual(r['input_text'],rows[int(r['repeat_of'][1:])]['input_text'])

    def test_normal_hf_blob_and_external_symlink(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);repo=root/'repo';snap=repo/'snapshots'/'rev';snap.mkdir(parents=True)
            (repo/'blobs').mkdir();blob=repo/'blobs'/'bound';blob.write_bytes(b'invented')
            (snap/'asset').symlink_to('../../blobs/bound')
            self.assertEqual(p.model_payload(snap,repo,'asset').resolve(),blob.resolve())
            for name in ('../escape','/absolute','C:\\escape','a/b',''):
                with self.subTest(name=name),self.assertRaises(ValueError):p.model_payload(snap,repo,name)
            outside=root/'outside';outside.write_text('invented');(snap/'escape').symlink_to(outside)
            with self.assertRaises(ValueError):p.model_payload(snap,repo,'escape')

    def test_exclusive_write_preserves_old(self):
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'record.json';p.create(file,{'value':1})
            with self.assertRaises(FileExistsError):p.create(file,{'value':2})
            self.assertEqual(p.read(file),{'value':1})

    def test_import_surface_no_model_construction(self):
        tree=ast.parse((p.HERE/'worker.py').read_text())
        for node in tree.body:
            if isinstance(node,(ast.Import,ast.ImportFrom)):
                self.assertNotIn(getattr(node,'module',None),('torch','transformers'))
        text=(p.HERE/'worker.py').read_text()
        self.assertNotIn('register_forward',text)
        self.assertIn('trust_remote_code=False',text)


class CollectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.out=Path(self.tmp.name);patch=mock.patch.object(p,'OUT',self.out);patch.start();self.addCleanup(patch.stop)
        self.counts={'forward_attempts':0,'forward_finished':0,'calls_saved':0};self.trace=[];self.last={}
    def forward(self,case):self.trace.append(('forward',case['id']));return {'invented_raw':case['id']}
    def retain(self,case,value):self.trace.append(('retain',case['id']));return {'retained_invented':True}
    def validate(self,case,value):self.trace.append(('validate',case['id']))
    def event(self,event,**kw):self.trace.append((event,kw.get('id')))
    def guard(self,*args):pass
    def run_panel(self,rows=None,**overrides):
        args=dict(cases=p.cases() if rows is None else rows,forward=self.forward,retain_call=self.retain,
                  validate=self.validate,event=self.event,guard=self.guard,counts=self.counts,last=self.last)
        args.update(overrides);return worker.run_calls(**args)
    def test_full20_fake_control_flow_raw_before_validation(self):
        result=self.run_panel();self.assertEqual(len(result),20)
        self.assertEqual(self.counts,{'forward_attempts':20,'forward_finished':20,'calls_saved':20})
        for case in p.cases():self.assertLess(self.trace.index(('retain',case['id'])),self.trace.index(('validate',case['id'])))
        self.assertEqual(len((self.out/'calls.jsonl').read_text().splitlines()),20)
    def test_nonfinite_validator_failure_retains_and_stops(self):
        def invalid(*args):raise ValueError('invented nonfinite')
        with self.assertRaisesRegex(ValueError,'nonfinite'):self.run_panel(validate=invalid)
        self.assertEqual(self.counts,{'forward_attempts':1,'forward_finished':1,'calls_saved':1})
        row=json.loads((self.out/'calls.jsonl').read_text());self.assertTrue(row['retained_invented']);self.assertFalse(row['controls_pass'])
    def test_return_journal_failure_still_retains(self):
        def event(kind,**kw):
            if kind=='forward_returned':raise OSError('invented journal failure')
        with self.assertRaisesRegex(OSError,'journal'):self.run_panel(event=event)
        self.assertIn(('retain','n00'),self.trace);self.assertEqual(self.counts['forward_finished'],1)
        self.assertFalse(json.loads((self.out/'calls.jsonl').read_text())['controls_pass'])
    def test_storage_failure_counts_physical_return(self):
        def fail(*args):raise OSError('invented storage failure')
        with self.assertRaisesRegex(OSError,'storage'):self.run_panel(retain_call=fail)
        self.assertEqual(self.counts,{'forward_attempts':1,'forward_finished':1,'calls_saved':1})
    def test_forward_failure_never_calls_again(self):
        def fail(*args):raise RuntimeError('invented forward failure')
        with self.assertRaisesRegex(RuntimeError,'forward'):self.run_panel(forward=fail)
        self.assertEqual(self.counts,{'forward_attempts':1,'forward_finished':0,'calls_saved':1})


class LifecycleTests(unittest.TestCase):
    def test_process_tree_includes_grandchild_not_other(self):
        self.assertEqual(owner.process_tree_rss([(10,1,3),(11,10,5),(12,11,7),(20,1,100)],10),15*1024)
    def test_deadline_rejected_before_process_work(self):
        with mock.patch.object(owner.time,'monotonic',return_value=901):
            with self.assertRaisesRegex(ValueError,'deadline'):owner.boundary(0,datetime.now(timezone.utc)+timedelta(seconds=900))
    def test_worker_rejects_unrelated_parent(self):
        deadline=(datetime.now(timezone.utc)+timedelta(seconds=10)).isoformat()
        with mock.patch.object(worker.os,'getppid',return_value=99):
            with self.assertRaisesRegex(ValueError,'owner'):worker.owner_guard({'plan_sha256':'x','owner_pid':98,'deadline_utc':deadline},'x',deadline)
    def test_exited_leader_requires_group_absence(self):
        child=mock.Mock(pid=123);child.poll.return_value=0
        with mock.patch.object(owner,'group_members',side_effect=[[124],[],[],[]]),mock.patch.object(owner.os,'killpg') as kill:
            owner.cleanup(child);kill.assert_called_once_with(123,owner.signal.SIGTERM)
    def owner_fixture(self,first_code):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);out=Path(temp.name)
        code=out/'code';code.mkdir();(code/'audit.py').write_text('invented source')
        p.create(out/'REPORT.json',{'implementation_pass':True,'plan_sha256':'x','native_gate_pass':False})
        p.create(out/'INDEPENDENT_AUDIT.json',{'status':'PASS','implementation_pass':True,'plan_sha256':'x',
            'native_gate_pass':False,'report_sha256':p.digest(out/'REPORT.json'),'audit_code_sha256':p.digest(code/'audit.py')})
        child=mock.Mock(pid=123);child.poll.return_value=first_code
        patches=[mock.patch.object(p,'OUT',out),mock.patch.object(p,'HERE',code),mock.patch.object(p,'PYTHON',Path(sys.executable)),
            mock.patch.object(p,'verify',return_value=({},'x')),mock.patch.object(p,'validate_model_files',return_value={}),
            mock.patch.object(owner,'boundary',return_value=0),mock.patch.object(owner,'group_members',return_value=[]),
            mock.patch.object(owner.signal,'signal'),mock.patch.object(owner.signal,'setitimer'),
            mock.patch.object(owner.subprocess,'Popen',return_value=child),mock.patch.object(owner,'monitor',return_value=
                {'returncode':first_code,'samples':1,'peak_child_tree_rss_bytes':0,'peak_archive_bytes':0})]
        mocks=[q.start() for q in patches]
        for q in patches:self.addCleanup(q.stop)
        # Real files bound by the fabricated report; no scientific process or input is opened.
        (out/'resource-monitor.jsonl').write_text('{}\n')
        return out,mocks[-2]
    def test_complete_negative_does_not_retry_or_launch_transfer(self):
        out,popen=self.owner_fixture(0)
        with mock.patch('builtins.print'):owner.run()
        self.assertEqual(popen.call_count,2);self.assertFalse(p.read(out/'COMPLETE.json')['native_gate_pass'])
        self.assertFalse((out/'STOPPED.json').exists())
    def test_worker_failure_prevents_auditor(self):
        out,popen=self.owner_fixture(1)
        with self.assertRaisesRegex(ValueError,'worker failed'):owner.run()
        self.assertEqual(popen.call_count,1);self.assertTrue((out/'STOPPED.json').exists());self.assertFalse((out/'COMPLETE.json').exists())


if __name__=='__main__':unittest.main()
