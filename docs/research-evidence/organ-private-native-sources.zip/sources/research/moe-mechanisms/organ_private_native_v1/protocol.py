"""Fixed20 native prerequisite. Import-safe; tokenizer and registration are explicit."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
from pathlib import Path, PureWindowsPath
import hashlib
import importlib.util
import json
import os
import shutil

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/moe-mechanisms/ORGAN_PRIVATE_NATIVE_V1'
PREP = ROOT / 'work/organ-private-input-v1'
TOKENS = PREP / 'tokenizer-v2'
AMENDMENT = PREP / 'TOKEN_BOUNDARY_AMENDMENT.json'
AMENDMENT_SHA = 'b7835810bdfe0dadbb41406e0b0a1a78960ce9ccc9a3a59fbf14a96338e27967'
ORIGINAL_SOURCES = PREP / 'original-preparation-sources'
PYTHON = ROOT / 'work/acquisition-representation-venv/bin/python'
BASELINE = ROOT / 'outputs/moe-mechanisms/ORGAN_ROUTE_CENSUS_V1/plan.json'
BASELINE_SHA = '133c644bae49d7e0cf30704e5be5f05797ceff022b5763ef358f95335cdfe701'
MODEL_SOURCE = ROOT / 'work/acquisition-representation-venv/lib/python3.12/site-packages/transformers/models/granitemoe/modeling_granitemoe.py'
MODEL_SOURCE_SHA = 'db9858ac0c9666a22d460e8a798df8086394e9084e45df93129d1474df1db40a'
SOURCES = ('protocol.py', 'worker.py', 'owner.py', 'audit.py', 'test_native.py', 'test_audit.py')
CARRIERS = ('lamp', 'light', 'sign', 'indicator')
SETTINGS = dict(timeout_seconds=900, max_rss_bytes=10*1024**3, max_mps_bytes=10*1024**3,
                max_archive_bytes=1024**3, minimum_free_bytes=1024**3, max_tokens=128,
                seed=42, threads=4, device='mps', dtype='bfloat16', attention='eager',
                cache=False, batch_size=1, logits_to_keep=1, forwards=20, primary=16, repeats=4)
VERSIONS = dict(python='3.12.14', torch='2.8.0', transformers='4.56.2', numpy='2.3.3', tokenizers='0.22.2')
EXCLUSIONS = ('COLLECTED.json', 'worker.log', 'independent_audit.log', 'owner-events.jsonl', 'resource-monitor.jsonl')


def require(ok, message):
    if not ok: raise ValueError(message)
def now(): return datetime.now(timezone.utc).isoformat()
def read(path): return json.loads(Path(path).read_text())
def digest(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def canonical(value): return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
def object_sha(value): return hashlib.sha256(canonical(value)).hexdigest()
def create(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())
def append(path, value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value, allow_nan=False)+'\n'); f.flush(); os.fsync(f.fileno())
def inventory(path, excluded=()):
    return {str(p.relative_to(path)):digest(p) for p in sorted(Path(path).rglob('*'))
            if p.is_file() and str(p.relative_to(path)) not in excluded}
def safe(root, name):
    require(type(name) is str and name and not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe archive path')
    p=root/name; require(p.is_file() and p.resolve().is_relative_to(root.resolve()), 'Missing/escaping archive path'); return p


def model_payload(snapshot, repository, name):
    require(type(name) is str and name not in ('', '.', '..') and '/' not in name and '\\' not in name
            and not PureWindowsPath(name).drive and '\0' not in name, 'Expected model filename leaf')
    repo=Path(repository).resolve(strict=True); snap=Path(snapshot).resolve(strict=True)
    require(snap.is_dir() and snap.is_relative_to(repo), 'Snapshot outside bound model repository')
    path=snap/name; target=path.resolve(strict=True)
    require(target.is_file() and target.is_relative_to(repo), 'Model payload outside bound repository')
    return path


def validate_model_files(plan, weights=True):
    result={}
    for name, expected in plan['model_files'].items():
        if not weights and name == 'model.safetensors': continue
        path=model_payload(ROOT/plan['model_path'], ROOT/plan['model_cache_repository'], name)
        target=path.resolve(); before=target.stat(); actual=digest(target); after=target.stat()
        require((before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
                and path.resolve()==target and actual==expected, 'Model payload changed: '+name)
        result[name]=dict(sha256=actual, size_bytes=after.st_size, resolved_path=str(target))
    return result


def baseline_metadata():
    require(digest(BASELINE)==BASELINE_SHA and digest(MODEL_SOURCE)==MODEL_SOURCE_SHA, 'Pinned metadata/native source changed')
    old=read(BASELINE)
    return {key:old[key] for key in ('model_path','model_cache_repository','model_files','expected_host_state')}


def cases():
    rows=[]
    for carrier in CARRIERS:
        for a in (0,1):
            for b in (0,1):
                prefix=f'The {carrier} has exactly two states: on and off.\nInitially, the {carrier} is '+('on' if a else 'off')+'.'
                operation='left in the same state' if b==0 else 'switched to the opposite state'
                suffix=f'\n\nThe {carrier} is then {operation}.\nAfter this, the {carrier} is'
                rows.append(dict(index=len(rows), id=f'n{len(rows):02d}', phase='primary', repeat_of=None,
                    carrier=carrier,a=a,b=b,prefix_text=prefix,suffix_text=suffix,input_text=prefix+suffix))
    for i,carrier in enumerate(CARRIERS):
        original=rows[4*i+2*(i//2)+(i%2)]
        rows.append(dict(original,index=len(rows),id=f'n{len(rows):02d}',phase='repeat',repeat_of=original['id']))
    return rows


def amended_case_identity(rows, original):
    require(len(rows)==len(original)==20, 'Amendment changed panel size')
    for new,old in zip(rows,original):
        require(canonical({k:v for k,v in new.items() if k not in ('prefix_text','suffix_text')})==
                canonical({k:v for k,v in old.items() if k not in ('prefix_text','suffix_text')}),
                'Amendment changed a complete prompt or case identity')
        require(old['prefix_text']==new['prefix_text']+'\n\n' and new['suffix_text']=='\n\n'+old['suffix_text'],
                'Amendment is not the exact period/separator partition')
    return True


def verify_amendment():
    require(digest(AMENDMENT)==AMENDMENT_SHA, 'Boundary amendment changed')
    amendment=read(AMENDMENT)
    for name,expected in amendment['source_sha256'].items():
        require(digest(safe(ROOT,name))==expected, 'Original preparation evidence changed')
    manifest=read(ORIGINAL_SOURCES/'MANIFEST.json')
    require(manifest==read(PREP/'IMPLEMENTATION_PREFLIGHT_RESULT.json')['source_sha256'], 'Original source inventory changed')
    for name,expected in manifest.items():
        require(digest(ORIGINAL_SOURCES/Path(name).name)==expected, 'Original archived source changed')
    spec=importlib.util.spec_from_file_location('private_native_original_case_generator',ORIGINAL_SOURCES/'protocol.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    amended_case_identity(cases(),old.cases())
    require(SETTINGS==old.SETTINGS and VERSIONS==old.VERSIONS, 'Amendment changed scientific/runtime settings')
    return dict(amendment_sha256=AMENDMENT_SHA,original_manifest_sha256=digest(ORIGINAL_SOURCES/'MANIFEST.json'),
                original_stop_sha256=digest(PREP/'tokenizer-v1/STOPPED.json'),
                original_case_identity_sha256=object_sha(old.cases()),
                all20_full_texts_and_identities_unchanged=True,only_prefix_suffix_partition_changed=True)


def tokenize_cases(tokenizer):
    """Exactly the agreed texts, no alternate template or multi-token fallback."""
    rows=[]; prefixes={}; lengths={}
    for case in cases():
        text=case['input_text']; body=tokenizer.encode(text, add_special_tokens=False)
        require(tokenizer.decode(body.ids, skip_special_tokens=False)==text, 'Prompt does not roundtrip')
        prefix=tokenizer.encode(case['prefix_text'],add_special_tokens=False)
        require(body.ids[:len(prefix.ids)]==prefix.ids and len(prefix.ids)<len(body.ids), 'Fact prefix tokens merge into operation')
        end=len(case['prefix_text'])
        require(all(stop<=end for _,stop in body.offsets[:len(prefix.ids)]) and body.offsets[len(prefix.ids)][0]>=end,
                'Token offset crosses fact/operation boundary')
        for word,token in (('on',544),('off',2126)):
            extended=tokenizer.encode(text+' '+word,add_special_tokens=False).ids
            require(extended==body.ids+[token], 'Candidate is not one exact appended token: '+word)
        ids=[0]+body.ids; key=(case['carrier'],case['a'])
        require(len(ids)<=128 and all(type(x) is int and x>=0 for x in ids), 'Input token guard failed')
        if key in prefixes: require(prefixes[key]==[0]+prefix.ids,'Operation changed fact prefix')
        prefixes[key]=[0]+prefix.ids; lengths[key]=len(prefix.ids)
        rows.append(dict(case,input_ids=ids,prefix_index=len(prefix.ids),candidate_ids={'on':544,'off':2126}))
    for carrier in CARRIERS: require(lengths[carrier,0]==lengths[carrier,1], 'State changes fact-prefix token length')
    for row in rows[16:]:
        original=next(r for r in rows[:16] if r['id']==row['repeat_of'])
        require(row['input_ids']==original['input_ids'] and row['input_text']==original['input_text'], 'Repeat changed')
    return rows


def prepare_tokens():
    require(not TOKENS.exists(), 'Tokenizer preparation already attempted')
    TOKENS.mkdir(parents=True); create(TOKENS/'STARTED.json',dict(at_utc=now(),protocol_sha256=digest(__file__)))
    try:
        require(Path(sys.executable).resolve()==PYTHON.resolve(),'Pinned Python required')
        amendment=verify_amendment()
        metadata=baseline_metadata(); before=validate_model_files(metadata,weights=False)
        import tokenizers
        require(tokenizers.__version__==VERSIONS['tokenizers'],'Pinned tokenizer version differs')
        tokenizer=tokenizers.Tokenizer.from_file(str(ROOT/metadata['model_path']/'tokenizer.json'))
        rows=tokenize_cases(tokenizer)
        require(validate_model_files(metadata,weights=False)==before,'Tokenizer assets changed')
        create(TOKENS/'TOKENS.json',rows)
        create(TOKENS/'COMPLETE.json',dict(status='TOKENIZER_PREFLIGHT_PASS',at_utc=now(),
            protocol_sha256=digest(__file__),tokens_sha256=digest(TOKENS/'TOKENS.json'),cases=20,
            primary=16,repeats=4,prefix_groups=8,candidate_ids={'on':544,'off':2126},
            lengths=[len(r['input_ids']) for r in rows],tokenizer_version=tokenizers.__version__,
            model_metadata_sha256=before,amendment=amendment,model_calls=0,weights_read=False,alternatives_tried=0))
        print(json.dumps(read(TOKENS/'COMPLETE.json')),flush=True)
    except BaseException as exc:
        create(TOKENS/'STOPPED.json',dict(status='TOKENIZER_PREFLIGHT_STOPPED',at_utc=now(),reason=repr(exc),
            protocol_sha256=digest(__file__),retry_allowed=False,model_calls=0));raise


def source_hashes(): return {str((HERE/n).relative_to(ROOT)):digest(HERE/n) for n in SOURCES}
def build_plan():
    amendment=verify_amendment()
    require((TOKENS/'COMPLETE.json').is_file() and not (TOKENS/'STOPPED.json').exists(),'No valid tokenizer preflight')
    token=read(TOKENS/'COMPLETE.json'); rows=read(TOKENS/'TOKENS.json')
    require(token['status']=='TOKENIZER_PREFLIGHT_PASS' and token['tokens_sha256']==digest(TOKENS/'TOKENS.json')
            and len(rows)==20 and all(all(row[k]==v for k,v in c.items()) for row,c in zip(rows,cases())), 'Frozen tokens/cases differ')
    metadata=baseline_metadata(); validate_model_files(metadata)
    lineage=[BASELINE,PREP/'NATIVE_FEASIBILITY_DESIGN.json',PREP/'ROOT_DIRECTION_DECISION.json',
             PREP/'WORKER_SCHEMA.json',TOKENS/'STARTED.json',TOKENS/'TOKENS.json',TOKENS/'COMPLETE.json',
             AMENDMENT,*[ROOT/name for name in read(AMENDMENT)['source_sha256']],
             *[ORIGINAL_SOURCES/Path(name).name for name in read(ORIGINAL_SOURCES/'MANIFEST.json')]]
    return dict(status='FIXED_NATIVE_PRIVATE_INPUT_CAPABILITY',created_at_utc=now(),settings=SETTINGS,versions=VERSIONS,
        **metadata,source_sha256=source_hashes(),installed_model_source_path=str(MODEL_SOURCE.relative_to(ROOT)),
        installed_model_source_sha256=MODEL_SOURCE_SHA,lineage_sha256={str(p.relative_to(ROOT)):digest(p) for p in lineage},
        cases=rows,candidate_ids={'on':544,'off':2126},collection_exclusions=list(EXCLUSIONS),boundary_amendment=amendment,
        scope='20 native forced-choice forwards only. Complete16/16 primary plus4 byte-exact repeats; no transfer fit, hooks, generation or automatic next study. Finite nonexact repeats are a complete negative readiness result, not a structural STOP.',
        scoring='Strict on/off candidate preference; ties incorrect/unresolved. Full-vocabulary diagnostics descriptive only. Native readiness requires all16 correct and all4 raw repeats exact; score only after the full20 collection.',
        no_retry=True,scientific_confirmation=False,novelty_established=False)


def register():
    require(not OUT.exists(),'Registration already exists')
    plan=build_plan(); reviews={}
    for name in ('SOURCE_REVIEW.json','PREPARATION_TESTS.json'):
        path=PREP/name; record=read(path)
        require(record['status'].startswith('PASS') and record['source_sha256']==plan['source_sha256'],'Stale/missing review')
        reviews[str(path.relative_to(ROOT))]=digest(path)
    plan['review_sha256']=reviews
    OUT.mkdir(parents=True); (OUT/'sources').mkdir()
    for name in SOURCES: shutil.copyfile(HERE/name,OUT/'sources'/name)
    create(OUT/'plan.json',plan);create(OUT/'REGISTRATION.json',dict(at_utc=now(),plan_sha256=digest(OUT/'plan.json')))
    print(json.dumps(dict(status='REGISTERED',plan_sha256=digest(OUT/'plan.json'))),flush=True)


def verify(directory=OUT):
    directory=Path(directory); plan=read(directory/'plan.json'); h=digest(directory/'plan.json')
    require(read(directory/'REGISTRATION.json')['plan_sha256']==h,'Registration changed')
    require(plan['settings']==SETTINGS and plan['versions']==VERSIONS and plan['source_sha256']==source_hashes(),'Plan/source setting changed')
    require(digest(MODEL_SOURCE)==plan['installed_model_source_sha256']==MODEL_SOURCE_SHA,'Native model source changed')
    for name,expected in plan['source_sha256'].items():
        require(digest(directory/'sources'/Path(name).name)==expected,'Archived source changed')
    for group in ('lineage_sha256','review_sha256'):
        for name,expected in plan[group].items():require(digest(safe(ROOT,name))==expected,'Lineage/review changed')
    require(plan['cases']==read(TOKENS/'TOKENS.json') and plan['collection_exclusions']==list(EXCLUSIONS),'Schedule/inventory contract changed')
    return plan,h


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['tokenize','register']);args=parser.parse_args()
    {'tokenize':prepare_tokens,'register':register}[args.mode]()
